

## What is this directoy?
As its name says, it has some examples for the users and developers of the 
package. 

Use the directory as it is instructed in the user guide. 
