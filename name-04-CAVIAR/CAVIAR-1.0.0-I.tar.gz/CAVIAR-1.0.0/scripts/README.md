
## What is this directoy?

This folder contains the script that have been used in developing CAVIAR.
Some of the files may contain only a (maybe-working!) example of a shell command.
We hope it becomes more than this in the future. 


The 'user' directory is for users. 


The 'developer' directory have some scripts useful for developing.
