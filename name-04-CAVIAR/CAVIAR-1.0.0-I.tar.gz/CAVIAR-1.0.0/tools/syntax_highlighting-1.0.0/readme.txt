
This directory provide syntax highliting of CAVIAR scripting language for some 
text editors. Use the files as instructed. Please report any problem to the authors
to be fixed in the future releases. We happily accept and add any other text
editor syntax highlighting files that have been created by the CAVIAR users.
