
A test to check whether periodic boundary condition works in the different 
configuration and after code development.
