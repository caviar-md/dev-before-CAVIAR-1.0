

## What we have here?

This directory is devided into user, doxygen and developer guide.

We recommend you to start learning by running example codes and changing the
parameters.

