This folder 'unique', contains the classes which cannot be placed in any category. In the 
future they may have their own base classes. Since they will not be called by 
other objects, changing them to child classes of something else won't bother much.
