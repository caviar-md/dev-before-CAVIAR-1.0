
//========================================================================
//
// Copyright (C) 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the CAVIAR package.
//
// The CAVIAR package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the CAVIAR distribution.
//
//========================================================================

#include "caviar/objects/shape/circle.h"
#include "caviar/utility/interpreter_io_headers.h"

namespace caviar {
namespace objects {
namespace shape {

Circle::Circle (CAVIAR *fptr) : Shape {fptr},  flatness_tol{0.001} {
  FC_OBJECT_INITIALIZE_INFO
}
Circle::~Circle() {}
   
bool Circle::read (caviar::interpreter::Parser * parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
      

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    ASSIGN_REAL_3D_VECTOR(center,"CIRCLE read: ","")
    else ASSIGN_REAL_3D_VECTOR(normal,"CIRCLE read: ","")
    else ASSIGN_REAL(radius,"CIRCLE read:","")
    else ASSIGN_REAL(flatness_tol,"CIRCLE read:","")
    else error->all (FC_FILE_LINE_FUNC_PARSE, " CIRCLE read: Unknown variable or command");
  }
  
  return in_file;;
}

bool Circle::on_the_plane(const Vector<double> &v) {
  Vector<double> v_1 = v - center;
  if (v_1*normal>flatness_tol)
    return false;
  return true;
}

bool Circle::is_inside(const Vector<double> &v) {
  if (!on_the_plane(v))
    return false;
  Vector<double> v_1 = v - center;
  if (v_1*v_1 > radius*radius)
    return false;
  return true;
}
    
bool Circle::is_inside(const Vector<double> &v, const double r) {  
  if (!on_the_plane(v))
    return false;
  Vector<double> v_1 = v - center;
  if (v_1*v_1 > (radius-r)*(radius-r))
    return false;
  return true;
}    
    
bool Circle::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
  std::string s = "incomplete function:";
  s += __FILE__ + std::to_string(__LINE__) + __func__;  
  output->warning(s);
  std::cout << "  " << v << r << contact_vector   << std::endl;     
  return false;
}
  
} //shape
} //objects
} // namespace caviar

