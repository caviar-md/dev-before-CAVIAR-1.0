
This example is mentioned in the CAVIAR-1.0 paper.

Copy a compiled version of CAVIAR binary (configured with deal.II library) here and 
run the code:

  $ CAVIAR < e7-hopper.casl
