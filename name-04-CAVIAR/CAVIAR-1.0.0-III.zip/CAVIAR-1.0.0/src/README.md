
## What is this directoy?

This directory with its subdirectories contains mainly all the C++ source files 
for CAVIAR package. One can use them according to CAVIAR license.
