## What to do?

If you have Doxygen installed on your system,  open a terminal here and execute

 $ doxygen caviar-config.doxy
 
It may takes a few minutes. After that, a doxygen html document is generated. 
Open 'index.html' to see the doc.


