
This example is mentioned in the CAVIAR-1.0 paper.

These are the results for the simulation after a 15ns run.

We recommend you to visualize the results with these programs:

'o_xyz_first_middle_and_last_frame.xyz' Ovito or  VMD.

'o_induced_charge' with 'plot_induced_charges.sh' which uses bash shell and gnuplot.

'smooth_mesh.vtk' with paraview.
