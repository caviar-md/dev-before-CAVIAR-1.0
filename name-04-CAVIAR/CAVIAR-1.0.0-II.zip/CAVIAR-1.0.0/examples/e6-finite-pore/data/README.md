
This example is mentioned in the CAVIAR-1.0 paper.

These geometries and meshes are made with SALOME-Platform.
