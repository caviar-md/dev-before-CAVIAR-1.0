#include "kakaka_preprocessors.h"
#include "kakaka_shape.h"
#include "kakaka_utility.h"
#include "parser.h"
#include "lexer.h"


namespace kkk {
	namespace shape {
// ========================
// ========================
// ========================
//			Shape
// ========================
// ========================
// ========================

		Shape::Shape () {};
		Shape::~Shape () {};
		bool Shape::read(Parser * parser) {};
		bool Shape::is_inside(Vector<double> v) {};
// ========================
// ========================
// ========================
//			Circle
// ========================
// ========================
// ========================

		Circle::Circle (Output * out, Error * err, All_objects * all_obj) :
				output{out}, error{err},all_objects{all_obj}, FLATNESS_TOLL{0.001}{};
		Circle::~Circle() {};
		
		bool Circle::read(Parser * parser) {
			output->info("Data_reader_Kakaka: Atom");
			bool in_file = true;

			while(true) {
				GET_A_TOKEN_FOR_CREATION
				ASSIGN_REAL_3D_VECTOR(CENTER,"CIRCLE read: ","")
				else ASSIGN_REAL_3D_VECTOR(NORMAL,"CIRCLE read: ","")
				else ASSIGN_REAL(RADIUS,"CIRCLE read:","")
				else ASSIGN_REAL(FLATNESS_TOLL,"CIRCLE read:","")
				else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: CIRCLE read: Unknown variable or command");
			}
	
			return in_file;;

		}

		bool Circle::on_the_plane(Vector<double> v) {
			Vector<double> v_1 = v - CENTER;
			if (v_1*NORMAL>FLATNESS_TOLL)
				return false;
		}

		bool Circle::is_inside(Vector<double> v) {
			if (!on_the_plane(v))
				return false;
			Vector<double> v_1 = v - CENTER;
			if (v_1*v_1 > RADIUS*RADIUS)
				return false;
			return true;
		}


// ========================
// ========================
// ========================
// 			Closed_lines
// ========================
// ========================
// ========================
	
	Closed_lines::Closed_lines (Output * out, Error * err, All_objects * all_obj) :
				output{out}, error{err},all_objects{all_obj},FLATNESS_TOLL{0.001}{};	

	Closed_lines::~Closed_lines (){};	


	void Closed_lines::make_basis_vectors() {
		if (p_3D.size() > 1) {
			Vector<Real_t> vec1 = p_3D[1] - p_3D[0];
			Vector<Real_t> vec2 = p_3D[2] - p_3D[0];
			std::vector<std::vector<Real_t>> mat_inv;
			n_vector = cross_product (vec1, vec2);
			u_vector = vec1;
			v_vector = cross_product (n_vector, u_vector);
			normalize(u_vector);
			normalize(v_vector);
			normalize(n_vector);
		}
	}
	void Closed_lines::make_uv_vectors() {
		for (int i = 0; i<p_3D.size(); ++i) {
			Vector<Real_t> dp = p_3D[i] - p_3D[0];
			Real_t u_i = u_vector * dp;
			Real_t v_i = v_vector * dp;
			u_list.push_back (u_i);
			v_list.push_back (v_i);
		}
	}
	void Closed_lines::make_transform_matrix() {
		Real_t m[3][3];
		m[0][0] = u_vector.x;	m[0][1] = u_vector.y;	m[0][2] = u_vector.z;
		m[1][0] = v_vector.x;	m[1][1] = v_vector.y;	m[1][2] = v_vector.z;
		m[2][0] = n_vector.x;	m[2][1] = n_vector.y;	m[2][2] = n_vector.z;

		Real_t det =  m[0][0] * (m[1][1] * m[2][2] - m[2][1] * m[1][2]) -
			            m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
	              	m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);

		Real_t invdet = 1. / det;

		mat_inv[0][0] = (m[1][1] * m[2][2] - m[2][1] * m[1][2]) * invdet;
		mat_inv[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * invdet;
		mat_inv[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * invdet;
		mat_inv[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * invdet;
		mat_inv[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * invdet;
		mat_inv[1][2] = (m[1][0] * m[0][2] - m[0][0] * m[1][2]) * invdet;
		mat_inv[2][0] = (m[1][0] * m[2][1] - m[2][0] * m[1][1]) * invdet;
		mat_inv[2][1] = (m[2][0] * m[0][1] - m[0][0] * m[2][1]) * invdet;
		mat_inv[2][2] = (m[0][0] * m[1][1] - m[1][0] * m[0][1]) * invdet;
	}
	void Closed_lines::uv_to_xyz (Real_t u_i, Real_t v_i, Vector<Real_t> &p_i) {
		p_i.x = mat_inv[0][0]*u_i + mat_inv[0][1]*v_i + p_3D[0].x;
		p_i.y = mat_inv[1][0]*u_i + mat_inv[1][1]*v_i + p_3D[0].y;
		p_i.z = mat_inv[2][0]*u_i + mat_inv[2][1]*v_i + p_3D[0].z;
	}
	void Closed_lines::xyz_to_uv (const Vector<Real_t> &p_i, Real_t &u_i, Real_t &v_i) {
		Vector<Real_t> dp = p_i - p_3D[0];
		u_i = u_vector * dp;
		v_i = v_vector * dp;
	}

	bool Closed_lines::is_inside (double u_i, double v_i) // using Jordan curve theorem,
			// checks whether the point is inside the curve or not;
			// it has a bug when (v_list[i] == v_list[j])
	{
		bool c = false;
		int nvert = p_3D.size();
//	 	for (int i = 0; int j = nvert-1; i < nvert; j = i++) 
		int j = nvert - 1;
		for (int i = 0; i < nvert; ++i) {
			if ( ((v_list[i]>v_i) != (v_list[j]>v_i)) &&
      			(u_i < (u_list[j]-u_list[i]) * (v_i-v_list[i]) / (v_list[j]-v_list[i]) + u_list[i]) )
      	c = !c;
			j = i;
		}
  	return c;
	}
	


// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

	}
}

