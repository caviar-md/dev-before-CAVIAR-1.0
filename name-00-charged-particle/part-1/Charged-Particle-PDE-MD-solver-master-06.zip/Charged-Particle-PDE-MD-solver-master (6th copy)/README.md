MD
==

Compilation
-----------

You need CMake and a C++14 compliant compiler to compile this program. Use the
following commands in the top level directory for an out of source build (recommended):

    mkdir build && cd build
    cmake ..
    make

### MPI

If you have an MPI implementation installed on your system and available in your
system path, it will be used to compile a parallel version of the software. On
some distributions you might have to use `module avail` to find the MPI module and
then load it with `module load` to make MPI available in your system path.

If you have an MPI implementation installed but you wish to compile without it you
can use the following command instead:

    cmake -DUSE_MPI=NO ..
