#include "output.h"

#include "atom_data.h"
#include "communicator.h"

Output::Output (MD *md) : Pointers{md}, atom_data{md->atom_data}, comm{md->comm}, energy_step{100}, position_step{1000} {}

void Output::info (std::string & str) {
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout <<"info: "<< str << std::endl;
#else
	std::cout <<"info: "<< str << std::endl;
#endif
}
void Output::info (const char *str) {
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout <<"info: "<< str << std::endl;
#else
	std::cout <<"info: "<< str << std::endl;
#endif
}

void Output::comment (std::string & str) {
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout << str << std::flush;
#else
	std::cout << str << std::flush;
#endif
}
void Output::comment (const char *str) {
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout << str << std::flush;
#else
	std::cout << str << std::flush;
#endif
}

void Output::dump_data (int i) {
	if (i%energy_step == 0)
		dump_energy (i);
	if (i%position_step == 0)
		dump_position (i);
}

void Output::dump_energy (int i) {
	
}

void Output::dump_position (int i) {
	atom_data = md->atom_data;
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);	

	const int nprocs = comm->nprocs;
	const int me = comm->me;

  const auto &pos = atom_data -> owned.position;
  const auto &id  = atom_data -> owned.id; 
	const auto &type = atom_data ->owned.type;	

	std::vector<std::vector<int>> all_id;
	std::vector<Vector<double>> all_pos;
	std::vector<int> all_type;
	
	const auto nla = pos.size();//atom_data -> num_local_atoms;
	const auto nta = atom_data -> num_total_atoms;
//	std::cout <<"nla" << nla <<std::endl;
//	std::cout <<"nta" << nta <<std::endl;
	int nla_list [ nprocs ];

	if (nprocs > 1) {
//		for (auto j=0;j<atom_data->ghost.id.size(); ++j)\
			if (atom_data->ghost.id[j] == 26)\
				std::cout<<"me:" << me << "\tt:" << i <<std::endl;			

//		for (auto j=0;j<pos.size(); ++j)\
			if (id[j] == 26)\
				std::cout<<"me:" << me << " p:" << atom_data->owned.acceleration[j] << "\tt:" << i << "\ttyp:" << type[j] <<std::endl;			
//		std::cout<<"me:" << me << " g:" << atom_data->ghost.position.size() << std::endl;
//		std::cout<<"me:" << me << " " << pos.size() << id.size() << type.size() << atom_data->owned.acceleration.size() << atom_data -> owned.velocity.size() <<std::endl;
		if (me != 0) { //==================================// nla send
			MPI_Send (&nla, 1, MPI_INT, 0, 0, mpi_comm);
		} else {
			nla_list[0]=nla;
			for (int i=1; i < nprocs; ++i) {
				MPI_Recv (nla_list+i, 1, MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// id send
			MPI_Send (id.data(), nla, MPI_INT, 0, 0, mpi_comm); // ********CHANGE id to INT before send it *****//
		} else {

			all_id.resize (nprocs);

			for (int i=0; i < nla; ++i) { // local copy
				all_id[0].push_back (id[i]);
			}
			for (int i=1; i < nprocs; ++i) {
				int tmp [nla_list[i]];
				MPI_Recv (&tmp, nla_list[i], MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
				for (int j=0; j<nla_list[i];++j)
					all_id[i].push_back(tmp[j]);
			}
		} //-----------------------------------------------//

			MPI_Barrier (mpi_comm);


		if (me != 0) { //==================================// pos send
			for (auto i=0; i<pos.size (); ++i){
				Vector<double> p_tmp {pos[i].x, pos[i].y, pos[i].z};
				MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, 0, id[i], mpi_comm);
			}
		} else {
			all_pos.reserve(nta);
			for (auto i=0; i<nla; ++i){
				Vector<double> p_tmp;
				p_tmp = pos[i];
				all_pos.push_back (p_tmp);
			}

			for (int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) {
					Vector<double> p_tmp;
					MPI_Recv (&p_tmp, 3, MPI_DOUBLE, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_pos.push_back (p_tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// type send
			for (auto i=0; i<pos.size (); ++i){
				MPI_Send (&type[i], 1, MPI_INT, 0, id[i], mpi_comm); 
			}
		} else {
			all_type.reserve(nta);
			for (auto i=0; i<nla; ++i){
				int tmp = type[i];
				all_type.push_back (tmp);
			}

			for (int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) { 
					int tmp;
					MPI_Recv (&tmp, 1, MPI_INT, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_type.push_back (tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);


	} else {//==================================// one_processor MPI counterpart.
					// this part can be written in a more concise way.
			all_id.resize (nprocs);
			for (int i=0; i < nla; ++i) { 
				all_id[0].push_back (id[i]);
				all_pos.push_back (pos[i]);
				all_type.push_back (type[i]);

			}
	
	} //-----------------------------------------------//

	MPI_Barrier (mpi_comm);

	if (me == 0) {
/*		std::cout<<nla_list[0] <<" " << nla_list[1] << std::endl;
		int k = 0;
		for (auto i = 0; i < nprocs; ++i) {
			for (auto j = 0; j < all_id[i].size(); ++j) {
				std::cout << i << ": " << all_id[i][j] << " p: " << all_pos[k] << std::endl;
				++k;
			}
		}*/
		ofs_positions << all_type.size() << "\nAtom\n";
		for (auto i=0; i<all_type.size(); ++i) {
			ofs_positions << all_type[i] << " " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n" << std::flush;
		}
	}
//	if (me==0)\
		std::cout <<" i:" << i << std::flush;
#else
//	std::cout <<" i:" << i << std::flush;
  auto &all_pos = atom_data -> owned.position;
	auto &all_type = atom_data ->owned.type;	
	int nta = atom_data -> num_total_atoms;
	ofs_positions << nta << "\nAtom\n";
	for (auto i = 0; i<nta; ++i) {
		ofs_positions << all_type[i] << " " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n";
	}
#endif

}

void Output::close_files () {
#ifdef USE_MPI
	if (comm->me == 0) {
		close_them ();
	}
#else
	close_them ();
#endif
}


void Output::open_files () {
#ifdef USE_MPI
	if (comm->me ==0){
		open_them ();
	}
#else
	open_them ();
#endif
}


void Output::close_them () {
	ofs_energy.close ();
	ofs_positions.close	();
	ofs_velocities.close ();
}


void Output::open_them () {

	std::string str_energy = "o_e",
							str_positions	= "o_p",
							str_velocities = "o_v";		

	std::string str_filename = "";
	char buffer[50] = "";

/*
#ifdef USE_MPI
	sprintf ( buffer, "_me%u", comm->me );
	str_filename.append ( buffer);
#endif
*/

/*
 	sprintf ( buffer, "_n%u", G_no_grains );
	str_filename.append ( buffer);
*/
	str_positions.append ( str_filename);
	str_positions.append ( ".xyz");

	str_filename.append ( ".txt" );

	str_energy.append (str_filename);
//	str_positions.append (str_filename);
	str_velocities.append (str_filename);

	const char * char_energy = str_energy.c_str ();
	const char * char_positions = str_positions.c_str ();
	const char * char_velocities	= str_velocities.c_str ();

	ofs_energy.open	(char_energy);
	ofs_positions.open (char_positions);
	ofs_velocities.open	(char_velocities);
}

void Output::print_hello () {
	for (int i = 1; i<5; i++) {
		ofs_energy << i <<" hello\n";
		ofs_positions << i <<" hello\n"<<std::flush;
		ofs_velocities << i <<" hello\n"<<std::flush;
	}
}
