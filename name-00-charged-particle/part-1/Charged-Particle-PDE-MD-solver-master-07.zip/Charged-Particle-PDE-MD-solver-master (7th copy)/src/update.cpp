#include "update.h"

#include "output.h"
#include "integrate.h"
//#include "error.h"
//#include "parser.h"
//#include "domain.h"
//
#include <ctime>

Update::Update (MD *md) : Pointers{md}, integrate{new Integrate{md}}, output{md->output}, dt{0.0001} {}

Update::~Update () {
	delete integrate;
}

bool Update::run (int nsteps) {
	output->info ("Simulation started.");
  verify_settings ();
  setup ();

  integrate->run (nsteps, dt);

  cleanup ();
	output->info ("Simulation finished.");
	std::cout << "info: simulation time: " << tot_time << std::endl;
}

void Update::verify_settings () {
//  if (self_ghost())
//		error->all (FILE_LINE_FUNC, "Self ghost can happen. Force field cutoff is larger than half of a domain.");
}

void Update::setup () {
	output->open_files ();
	t_start = clock();
}

void Update::cleanup () {
	output->close_files ();
  t_end = clock();
 	tot_time =  ( (float)t_end - (float)t_start ) / CLOCKS_PER_SEC;
}
/*
bool Update::self_ghost () {
	const auto x_llow = domain->x_lower_local;
	const auto x_lupp = domain->x_upper_local;
	const auto y_llow = domain->y_lower_local;
	const auto y_lupp = domain->y_upper_local;
	const auto z_llow = domain->z_lower_local;
	const auto z_lupp = domain->z_upper_local;

	const auto x_width = x_lupp - x_llow;
	const auto y_width = y_lupp - y_llow;
	const auto z_width = z_lupp - z_llow;

	const auto cutoff = force_field->cutoff;
	if (2*cutoff>x_width || 2*cutoff>y_width || 2*cutoff>z_width)
		return true;
	return false;
}*/
