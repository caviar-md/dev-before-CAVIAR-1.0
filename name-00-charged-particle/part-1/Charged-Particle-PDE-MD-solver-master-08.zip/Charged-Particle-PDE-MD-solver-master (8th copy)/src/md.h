#ifndef MD_H
#define MD_H

#include <iostream>
#include <fstream>
#include <map>

#ifdef USE_MPI
#include <mpi.h>
#endif

#include "types.h"

class MD {
public:
#ifdef USE_MPI
  MD (int, char**, MPI_Comm);
#else
  MD (int, char**);
#endif
  ~MD ();
  void execute ();
  
#ifdef USE_MPI
  MPI_Comm mpi_comm;
#endif
  class Communicator *comm;
  class Error *error;
  class Output *output;
  class Input *input;
  class Domain *domain;
  class Atom_data *atom_data;
  class Update *update;
  class Force_field *force_field;
  class Neighbor *neighbor;
  class Writer *writer;
  
  std::ofstream log;
  std::istream in;
  std::ostream out, err;
  bool log_flag, out_flag, err_flag;
 	bool force_field_made;

  std::map<std::string,int> int_variables;
  std::map<std::string,Real_t> real_variables;
  std::map<std::string,std::string> string_variables;
};

#endif
