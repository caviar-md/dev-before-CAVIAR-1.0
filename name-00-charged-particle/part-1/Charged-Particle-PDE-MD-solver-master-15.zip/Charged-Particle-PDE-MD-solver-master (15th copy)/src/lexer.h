#ifndef LEXER_H
#define LEXER_H

#include <string>
#include <istream>
#include <sstream>

#include "pointers.h"

enum class Kind : char {
  identifier, string, int_number, real_number, eof,
  plus='+', minus='-', mul='*', div='/', truediv, modulus='%', assign='=', lp='(', rp=')', squote='\'', dquote='"', comment='#', backslash='\\',eol='\n'
};

struct Token {
  Kind kind;
  // making this a union will complicate destructor and assignment operator b/c of std::string
  std::string string_value;
  int int_value;
  Real_t real_value;
};

class Token_stream : protected Pointers {
public:
  Token_stream (class MD *);
  Token_stream (class MD *, const std::string &);
  ~Token_stream ();
  Token get ();
  Token & current ();
  void set_input (std::istream &);
  std::string line;
  unsigned int col;
private:
  void getline ();
  inline char get_char () {++col; return line_stream.get ();}
  inline void putback_char (char ch) {--col; line_stream.putback (ch);}
  char get_nonblank_char ();
  Token get_number_literal (char);
  Token get_string_literal (char);
  
  std::istream *input_stream;
  std::istringstream line_stream;
  Token ct;
  bool stream_is_file, get_new_line, end_of_file;
};

#endif
