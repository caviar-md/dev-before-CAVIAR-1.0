#ifndef OUTPUT_H
#define OUTPUT_H

#include "pointers.h"

class Output : protected Pointers {
public:
  Output (class MD *);
	void open_files (); // calls open_them() with MPI considerations
	void close_files (); // calls close_them() with MPI considerations
	void print_hello (); // a test funciton
	void dump_data (int); // calls dump_XXX() funcitons 
	void comment (std::string &); // ostream commens.
	void comment (const char *); // ostream comments.
	void info (std::string &); // ostream comments as info.
	void info (const char *); // ostream comments as info.
	void set_parameters (class Parser *); // set parameters :)

private:
	class Atom_data *atom_data;
	class Communicator *comm;

	void open_them (); // open files after making their names
	void close_them (); // closes files
	void dump_energy (int); // dump energy to file 
	void dump_xyz (int); // dump positions to file in xyz format
	void dump_povray (int); // dump positions to snapshot files in povray format

	int energy_step, xyz_step, povray_step; // number of steps to output data

	std::ofstream ofs_energy,  ofs_xyz, ofs_velocities, ofs_povray; // output files

	bool output_energy, output_xyz, output_povray; // if true, outputs would be created	
};

#endif
