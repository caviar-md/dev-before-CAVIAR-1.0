#ifndef ERROR_H
#define ERROR_H

#include "pointers.h"

class Error : protected Pointers {
public:
  Error (MD *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const char *);
  void one (const char *, int, const char *, const std::string &, unsigned int, const char *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
  void one (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
};

#endif
