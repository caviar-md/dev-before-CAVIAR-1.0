#ifndef NEIGHBOR_H
#define NEIGHBOR_H

#include "pointers.h"

#include <vector>

class Neighbor : protected Pointers {
public:
  Neighbor (class MD *);
  
	void init();
  bool rebuild_neighlist ();
  void build_neighlist ();
  std::vector<std::vector<LocalID_t>> neighlist;    
private:
	class Force_field *force_field;
  double cutoff, cutoff_extra;
};

#endif
