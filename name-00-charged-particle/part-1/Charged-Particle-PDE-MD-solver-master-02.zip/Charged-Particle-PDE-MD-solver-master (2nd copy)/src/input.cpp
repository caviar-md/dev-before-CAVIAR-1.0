#include "input.h"

#include <map>
#include <cmath>

#include "error.h"
#include "parser.h"
#include "update.h"
#include "all_data_reader.h"
#include "all_atom_data.h"
#include "all_force_field.h"

const std::map<std::string,CommandFunc> Input::commands_map = {
  {"atom_style", &Input::atom_style},
  {"force_field", &Input::force_field_cmd},
  {"force_field_parameters", &Input::force_field_parameters},
//	{"boundary",&Input::boundary},
//	{"timestep",&Input::timestep},
  {"read_data", &Input::read_data},
  {"int", &Input::add_int_var},
  {"real", &Input::add_real_var},
  {"string", &Input::add_string_var},
  {"print", &Input::print},
  {"run", &Input::run},
  {"exit", &Input::exit},
  {"quit", &Input::exit}
};

Input::Input (MD *md) : Pointers {md}, parser {new Parser{md}} {}

Input::Input (MD *md, const std::string &file) : Pointers {md}, parser {new Parser{md, file}} {}

Input::~Input () {
  delete parser;
}

void Input::read () {
  while (read_command ());
}

bool Input::read_command () {
  auto command = parser->get_command_identifier();
  if (commands_map.count (command) == 0) error->all (FILE_LINE_FUNC, "Invalid command");
  return (this->*commands_map.at(command)) ();
}

bool Input::atom_style () {
  auto atom_style_identifier = parser->get_identifier();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  if (atom_style_identifier != "simple") {
    delete atom_data;
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)     \
    if (reader_identifier == #key) atom_data = new Class {md};
#include "all_atom_data.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  }
  return true;
}

bool Input::force_field_cmd () {
	bool correct_forcefield_type = false;
  auto force_field_identifier = parser->get_identifier();
  
#define FORCE_FIELD_CLASS
#define ForceFieldStyle(key,Class)     		\
  if (force_field_identifier == #key) { 	\
		force_field = new Class {md, parser}; \
		md -> force_field_made = true;				\
		correct_forcefield_type = true; 			\
	}
#include "all_force_field.h"
#undef ForceFieldStyle
#undef FORCE_FIELD_CLASS

  if (! parser->end_of_line () || !correct_forcefield_type ) error->all (FILE_LINE_FUNC, "Invalid syntax: this type of force field doesn't exist.");
}

bool Input::force_field_parameters () {
  force_field->set_parameters (parser);
	parser->end_of_line();
//  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
}

bool Input::read_data () {
  // the following two initialization must be on separate lines to insure correct order
  auto reader_identifier = parser->get_identifier();
  auto data_file = parser->get_string();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)                \
  if (reader_identifier == #key) {                \
    auto data_reader = new Class (md, data_file); \
    auto result = data_reader->read ();           \
    delete data_reader;                           \
    return result;                                \
  }
#include "all_data_reader.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  
  return false;
}

bool Input::add_int_var () {
  auto var_name = parser->get_identifier();
  delete_var (var_name);
  if (! parser->assignment()) error->all (FILE_LINE_FUNC, "Expected assignment operator");
  int_variables[var_name] = parser->get_int();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  return true;
}

bool Input::add_real_var () {
  auto var_name = parser->get_identifier();
  delete_var (var_name);
  if (! parser->assignment()) error->all (FILE_LINE_FUNC, "Expected assignment operator");
  real_variables[var_name] = parser->get_real();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  return true;
}

bool Input::add_string_var () {
  auto var_name = parser->get_identifier();
  delete_var (var_name);
  if (! parser->assignment()) error->all (FILE_LINE_FUNC, "Expected assignment operator");
  string_variables[var_name] = parser->get_string();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  return true;
}

bool Input::run () {
  auto num_steps = parser->get_int();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  return update->run (num_steps);
}

bool Input::print () {
  parser->write_to_stream (std::cout);
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
  return true;
}

bool Input::exit () {
  return false;
}

void Input::delete_var (const std::string &key) {
  int_variables.erase (key);
  real_variables.erase (key);
  string_variables.erase (key);
}
