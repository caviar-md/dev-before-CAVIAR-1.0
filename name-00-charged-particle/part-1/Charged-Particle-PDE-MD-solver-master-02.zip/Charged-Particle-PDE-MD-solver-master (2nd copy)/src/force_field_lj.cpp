#include "force_field_lj.h"

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"

Force_field_lj::Force_field_lj (MD *md, Parser *parser) : Force_field {md, parser},
epsilon (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
sigma (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) {
  cutoff = parser->get_real ();
	std::cout << "A Lennard-Jones force field is made." << std::endl;
}

bool Force_field_lj::set_parameters (Parser *parser) {
  int type_i = parser->get_int ();
  
  if (type_i < 1 || type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");
  
  int type_j = parser->get_int ();
  if (type_j < 1 || type_j > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");

	--type_i;
	--type_j;

  Real_t eps_ij = parser->get_real ();
  if (eps_ij < 0)
  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");
  epsilon [type_i][type_j] = epsilon [type_j][type_i] = eps_ij;
  
  Real_t sigma_ij = parser->get_real ();
  if (sigma_ij <= 0)
  error->all (FILE_LINE_FUNC, "Sigma have to be larger than 0 .");
  sigma [type_i][type_j] = sigma [type_j][type_i] = sigma_ij;
	std::cout << "Force field parameter set." << std::endl;
}

void Force_field_lj::calculate_acceleration () {
//	std::cout<<"gs:"<<atom_data->ghost.position.size() <<std::endl;
/*
	auto &gpos = atom_data->ghost.position;
	auto &gid = atom_data->ghost.id;
	for (auto i = 0;i<gpos.size();++i){
		std::cout <<"gid:" <<gid[i]<< " gpos:" << gpos[i] << std::endl;
	}
	auto &opos = atom_data->owned.position;
	auto &oid = atom_data->owned.id;
	for (auto i = 0;i<opos.size();++i){
		std::cout << "oid:"<<oid[i]<< " opos:" << opos[i] << std::endl;
	}
	std::cout<< std::endl;
// */

  auto cutoff_sq = cutoff * cutoff;
  const auto &neighbor_list = neighbor -> neighlist;
  for (auto i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
  	const auto type_i = atom_data -> owned.type [i] - 1;
    const auto mass_i = atom_data -> owned.mass [ type_i ];
//			std::cout<<"ns:"<<neighbor_list[i].size() <<std::endl;
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size(); 
      if (is_ghost) {
        j -= neighbor_list.size ();
      	const auto &pos_j = atom_data->ghost.position [j];
      	const auto type_j = atom_data->ghost.type [j] - 1;
      	const auto mass_j = atom_data->owned.mass [ type_j ]; // there's no mass exchange//

		
//			if (atom_data->owned.id[i] == data.id[j]) {std::cout << "a"; continue;}  // BUUUUG		
//			if (atom_data->owned.id[i] == data.id[j]) { continue;}  // BUUUUG		
//			std::cout<<"pi:"<<pos_i << " pj:" << pos_j <<std::endl;
//			std::cout<<"dr:"<<dr <<std::endl;
//      auto dr = atom_data->periodic_distance (pos_j - pos_i, 1, 1, 1); // periodic boundary distance

      	auto dr = pos_j - pos_i; 
      	auto r_sq = dr*dr;
      	if (r_sq > cutoff_sq) continue;
      	const auto eps_ij = epsilon [type_i] [type_j];
      	const auto sigma_ij =  sigma [type_i] [type_j];
      	auto rho_c_inv = sigma_ij / cutoff;
      	auto rho_c_6_inv = ipow (rho_c_inv, 6);
      	auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
      	auto rho_c_18_inv = rho_c_12_inv*rho_c_6_inv;
      	auto r_sq_inv = 1/r_sq;
      	auto rho_sq_inv = sigma_ij*sigma_ij*r_sq_inv;
      	auto rho_6_inv = rho_sq_inv*rho_sq_inv*rho_sq_inv;
      	auto rho_12_inv = rho_6_inv*rho_6_inv;
      	auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + (2*rho_c_18_inv - rho_c_12_inv) * r_sq*r_sq/ipow (sigma_ij, 6) ) * dr;
//			std::cout<<"f:"<<force <<std::endl;

				atom_data -> owned.acceleration [i] += force / mass_i;

			} else {
      	const auto &pos_j = atom_data->owned.position [j];
      	const auto type_j = atom_data->owned.type [j] - 1;
      	const auto mass_j = atom_data->owned.mass [ type_j ];

//			if (atom_data->owned.id[i] == data.id[j]) {std::cout << "a"; continue;}  // BUUUUG
//			if (atom_data->owned.id[i] == data.id[j]) { continue;}  // BUUUUG		
//			std::cout<<"pi:"<<pos_i << " pj:" << pos_j <<std::endl;
//			std::cout<<"dr:"<<dr <<std::endl;
//      auto dr = atom_data->periodic_distance (pos_j - pos_i, 1, 1, 1); // periodic boundary distance

      	auto dr = pos_j - pos_i; 
      	auto r_sq = dr*dr;
      	if (r_sq > cutoff_sq) continue;
      	const auto eps_ij = epsilon [type_i] [type_j];
      	const auto sigma_ij =  sigma [type_i] [type_j];
      	auto rho_c_inv = sigma_ij / cutoff;
      	auto rho_c_6_inv = ipow (rho_c_inv, 6);
      	auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
      	auto rho_c_18_inv = rho_c_12_inv*rho_c_6_inv;
      	auto r_sq_inv = 1/r_sq;
      	auto rho_sq_inv = sigma_ij*sigma_ij*r_sq_inv;
      	auto rho_6_inv = rho_sq_inv*rho_sq_inv*rho_sq_inv;
      	auto rho_12_inv = rho_6_inv*rho_6_inv;
      	auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + (2*rho_c_18_inv - rho_c_12_inv) * r_sq*r_sq/ipow (sigma_ij, 6) ) * dr;
//			std::cout<<"f:"<<force <<std::endl;

				atom_data -> owned.acceleration [i] += force / mass_i;
      	atom_data -> owned.acceleration [j] -= force / mass_j;
			
			}
    }   
  }
}


