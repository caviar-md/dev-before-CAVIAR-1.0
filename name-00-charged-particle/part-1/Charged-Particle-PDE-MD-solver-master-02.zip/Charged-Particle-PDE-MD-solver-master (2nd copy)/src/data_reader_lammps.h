#ifdef DATA_READER_CLASS

DataReaderStyle(LAMMPS,Data_reader_LAMMPS)

#else

#ifndef DATA_READER_LAMMPS_H
#define DATA_READER_LAMMPS_H

#include "pointers.h"

class Data_reader_LAMMPS : protected Pointers {
public:
  Data_reader_LAMMPS (class MD *, const std::string &);
  ~Data_reader_LAMMPS ();
  
  bool read ();
private:
  bool header ();
  bool verify_and_set_header ();
  bool body ();
  bool read_atoms ();
	bool read_masses ();
  
  class Parser *parser;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;
  Real_t xlo, xhi, ylo, yhi, zlo, zhi;
};

#endif
#endif
