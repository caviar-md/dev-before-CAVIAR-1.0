#ifndef TYPES_H
#define TYPES_H

#include <limits>

using LocalID_t = unsigned int;
using GlobalID_t = unsigned int;
using AtomType_t = unsigned int;
using Real_t = double;

constexpr auto max_GlobalID = std::numeric_limits<GlobalID_t>::max();

#endif
