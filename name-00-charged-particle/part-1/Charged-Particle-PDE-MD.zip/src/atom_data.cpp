#include "atom_data.h"

#include <algorithm>

#include "communicator.h"
#include "domain.h"
#include "force_field.h"

constexpr auto expected_imbalance_factor = 1.1;

Atom_data::Atom_data (MD *md) : Pointers{md}, num_local_atoms{0}, num_total_atoms{0}, num_atom_types{0} {}

Atom_data::~Atom_data () {
  
}

void Atom_data::set_num_total_atoms (GlobalID_t n) {
  num_total_atoms = n;
  num_local_atoms_est = n * expected_imbalance_factor / comm->nprocs;
}

void Atom_data::allocate () {
  owned.id.reserve (num_local_atoms_est);
  owned.charge.reserve (num_local_atoms_est);
  owned.position.reserve (num_local_atoms_est);
  owned.velocity.reserve (num_local_atoms_est);
  owned.acceleration.reserve (num_local_atoms_est);
}

bool Atom_data::add_atom (GlobalID_t id, AtomType_t type, Real_t ch, const Vector<Real_t> &pos, const std::vector<Real_t> &, const std::vector<int> &) {
//		std::cout<<"\n" <<id<< std::endl;
  if (pos.x >= domain->x_lower_local && pos.x < domain->x_upper_local &&
      pos.y >= domain->y_lower_local && pos.y < domain->y_upper_local &&
      pos.z >= domain->z_lower_local && pos.z < domain->z_upper_local) {
    owned.type.push_back (type);
    owned.position.push_back (pos);
		owned.charge.push_back (ch);
		owned.id.push_back ( id );
		std::cout<<"\n" <<id<< std::endl;
//		std::cout<<"\n" <<pos<< std::endl;
		owned.velocity.push_back (Vector<Real_t> {0,0,0});
		owned.acceleration.push_back (Vector<Real_t> {0,0,0});
    ++num_local_atoms;
    return true;
  }
  else return false;
}

bool Atom_data::add_masses ( int type, Real_t m ) {
	owned.mass.push_back (m); 
}



void Atom_data::exchange_owned () {
#ifdef USE_MPI

	int x_bc = 1, y_bc = 1, z_bc = 1; //periodic boundary condition

	force_field = md->force_field;
	cutoff = force_field->cutoff;
//	std::cout << "cutoff" << cutoff << std::endl;
	
	const int nprocs = comm->nprocs;


	double x_llow = domain->x_lower_local;
	double x_lupp = domain->x_upper_local;
	double y_llow = domain->y_lower_local;
	double y_lupp = domain->y_upper_local;
	double z_llow = domain->z_lower_local;
	double z_lupp = domain->z_upper_local;

	double x_width = x_llow - x_lupp;
	double y_width = y_llow - y_lupp;
	double z_width = z_llow - z_lupp;


	int left = comm->left;
	int right = comm->right;
	int up = comm->up;
	int down = comm->down;
	int top = comm->top;
	int bottom = comm->bottom;

	std::vector<int> o_send_id; // contains all IDs to be deleted from the domain after sending.
	std::vector<int> o_send_id_left,o_send_id_right,o_send_id_up,o_send_id_down,o_send_id_top,o_send_id_bottom; // ID of owned to be sent
	std::vector<int> o_recv_id_left,o_recv_id_right,o_recv_id_up,o_recv_id_down,o_recv_id_top,o_recv_id_bottom; // ID of owned to be recieved

	std::vector<int> g_send_id_left,g_send_id_right,g_send_id_up,g_send_id_down,g_send_id_top,g_send_id_bottom; // ID of ghosts to be sent
	std::vector<int> g_recv_id_left,g_recv_id_right,g_recv_id_up,g_recv_id_down,g_recv_id_top,g_recv_id_bottom; // ID of ghosts to be recieved


	int o_recv_n_left=0, o_recv_n_right=0, o_recv_n_down=0, o_recv_n_up=0, o_recv_n_bottom=0 ,o_recv_n_top=0; // num of owned to be received
	int g_recv_n_left=0, g_recv_n_right=0, g_recv_n_down=0, g_recv_n_up=0, g_recv_n_bottom=0 ,g_recv_n_top=0; // num of ghosts to be received

	
	int me = comm->me;

	for (auto i=0; i<num_local_atoms; ++i) { 
		if (owned.position[i].x < x_llow) {
			o_send_id_left.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
			continue;
	 	}
		if (owned.position[i].x > x_lupp) {
			o_send_id_right.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
		 	continue;
	 	}
		if (owned.position[i].y < y_llow) {		
			o_send_id_down.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
		 	continue;
	 	}
		if (owned.position[i].y > y_lupp) {
			o_send_id_up.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
		 	continue;
	 	}
		if (owned.position[i].z < z_llow) {
			o_send_id_bottom.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
		 	continue;
	 	}
		if (owned.position[i].z > z_lupp)	{		
			o_send_id_top.push_back (owned.id[i]);
			o_send_id.push_back (owned.id[i]);
		 	continue;
	 	}
	}


	MPI_Barrier (mpi_comm);

	if (left == right ) {
		if (x_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].x += x_width;
				}
				while (owned.position[i].x > domain->x_upper_local) {
					owned.position[i].x -= x_width;
				}
			}
		}
	} else {
		int s_left = o_send_id_left.size();
		int s_right = o_send_id_right.size();

		MPI_Send (&s_left, 1, MPI_INT, left,  10, mpi_comm);
		MPI_Recv (&o_recv_n_right, 				1, MPI_INT, right, 10, mpi_comm, MPI_STATUS_IGNORE);


		MPI_Send (&s_right, 1, MPI_INT, right,  11, mpi_comm);
		MPI_Recv (&o_recv_n_left, 			 	 1, MPI_INT, left,   11, mpi_comm, MPI_STATUS_IGNORE);


		MPI_Send (o_send_id_left.data(), o_send_id_left.size(), MPI_INT, left, 21, mpi_comm);//====send ID
		int tmp_r [o_recv_n_right];
		MPI_Recv (&tmp_r, o_recv_n_right, MPI_INT, right, 21, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_right;++j)
			o_recv_id_right.push_back(tmp_r[j]);//----recv ID


		for (auto i : o_send_id_left) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_left) //=====send pos
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		} // ----recv pose

		for (auto i : o_send_id_left) //=====send vel
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		} // ----recv pose




		MPI_Send (o_send_id_right.data(), o_send_id_right.size(), MPI_INT, right, 22, mpi_comm);
		int tmp_l [o_recv_n_left];
		MPI_Recv (&tmp_l, o_recv_n_left, MPI_INT, left, 22, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_left;++j)
			o_recv_id_left.push_back(tmp_l[j]);

		for (auto i : o_send_id_right) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type

		for (auto i : o_send_id_right)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_right)//send vel
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);

	if (down == up) {
		if (y_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].y < domain->y_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].y += y_width;
				}
				while (owned.position[i].y > domain->y_upper_local) {
					owned.position[i].y -= y_width;
				}
			}
		}
	} else {
		int s_down = o_send_id_down.size();
		int s_up = o_send_id_up.size();

		MPI_Send (&s_down, 1, MPI_INT, down,  12, mpi_comm);
		MPI_Recv (&o_recv_n_up, 				  1, MPI_INT, up,    12, mpi_comm, MPI_STATUS_IGNORE);

		MPI_Send (&s_up,   1, MPI_INT, up,   13, mpi_comm);
		MPI_Recv (&o_recv_n_down, 				1, MPI_INT, down, 13, mpi_comm, MPI_STATUS_IGNORE);



		MPI_Send (o_send_id_down.data(), o_send_id_down.size(), MPI_INT, down, 23, mpi_comm);
		int tmp_u [o_recv_n_up];
		MPI_Recv (&tmp_u, o_recv_n_up, MPI_INT, up, 23, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_up;++j)
			o_recv_id_up.push_back(tmp_u[j]);

		for (auto i : o_send_id_down) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_down)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_down)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}


		MPI_Send (o_send_id_up.data(), o_send_id_up.size(), MPI_INT, up, 24, mpi_comm);
		int tmp_d [o_recv_n_down];
		MPI_Recv (&tmp_d, o_recv_n_down, MPI_INT, down, 24, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_down;++j)
			o_recv_id_down.push_back(tmp_d[j]);

		for (auto i : o_send_id_up) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_up)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_up)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);


	if (bottom == top) {
		if (z_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].z < domain->z_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].z += z_width;
				}
				while (owned.position[i].z > domain->z_upper_local) {
					owned.position[i].z -= z_width;
				}
			}
		}
	} else {
		int s_bot = o_send_id_bottom.size();
		int s_top = o_send_id_top.size();

		MPI_Send (&s_bot, 1, MPI_INT, bottom, 14, mpi_comm);
		MPI_Recv (&o_recv_n_top, 				    1, MPI_INT, top,    14, mpi_comm, MPI_STATUS_IGNORE);

		MPI_Send (&s_top,    1, MPI_INT, top,    15, mpi_comm);
		MPI_Recv (&o_recv_n_bottom, 				1, MPI_INT, bottom, 15, mpi_comm, MPI_STATUS_IGNORE);



		MPI_Send (o_send_id_bottom.data(), o_send_id_bottom.size(), MPI_INT, bottom, 24, mpi_comm);
		int tmp_t [o_recv_n_top];
		MPI_Recv (&tmp_t, o_recv_n_top, MPI_INT, top, 24, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_top;++j)
			o_recv_id_top.push_back(tmp_t[j]);

		for (auto i : o_send_id_bottom) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_bottom)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}
		for (auto i : o_send_id_bottom)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}



		MPI_Send (o_send_id_top.data(), o_send_id_top.size(), MPI_INT, top, 25, mpi_comm);
		int tmp_b [o_recv_n_bottom];
		MPI_Recv (&tmp_b, o_recv_n_bottom, MPI_INT, bottom, 25, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_bottom;++j)
			o_recv_id_bottom.push_back(tmp_b[j]);

		for (auto i : o_send_id_top) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_top)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_top)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);

	std::sort(o_send_id.begin(), o_send_id.end(), std::greater<int>());
	for (auto i : o_send_id) {
		owned.position.erase (owned.position.begin()+i);	
		owned.velocity.erase (owned.velocity.begin()+i);	
		owned.acceleration.erase (owned.acceleration.begin()+i);	
		owned.type.erase (owned.type.begin()+i);	
	}

#else
	auto x_width = domain->x_upper_local - domain->x_lower_local;
	auto y_width = domain->y_upper_local - domain->y_lower_local;
	auto z_width = domain->z_upper_local - domain->z_lower_local;

	for (auto i = 0 ; i < num_local_atoms; ++i) {
		if (x_bc == 1) {
 		
			while (owned.position[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].x += x_width;
			}
			while (owned.position[i].x > domain->x_upper_local) {
				owned.position[i].x -= x_width;
			}
		}
	
		if (y_bc == 1) {
			while (owned.position[i].y < domain->y_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].y += y_width;
			}
			while (owned.position[i].y > domain->y_upper_local) {
				owned.position[i].y -= y_width;
			}
		}
	
		if (z_bc == 1) {
			while (owned.position[i].z < domain->z_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].z += z_width;
			}
			while (owned.position[i].z > domain->z_upper_local) {
				owned.position[i].z -= z_width;
			}
		}
	}
#endif
}

/*
Vector<Real_t> Atom_data::periodic_distance ( Vector<Real_t> dr, int x_c, int y_c, int z_c) {
	auto x_width = domain->x_upper_local - domain->x_lower_local;
	auto y_width = domain->y_upper_local - domain->y_lower_local;
	auto z_width = domain->z_upper_local - domain->z_lower_local;
#ifdef USE_MPI
	if (comm->nprocs_x == 1) {
		if (x_c == 1) {
			while (dr.x < -0.5*x_width) {//using "while"instead of "if"... why "if" isn't enough?
				dr.x += x_width;
			}
			while (dr.x >= 0.5*x_width) {
				dr.x -= x_width;
			}			
		}
	}
	if (comm->nprocs_y == 1) {
		if (y_c == 1) {
			while (dr.y < -0.5*y_width) {
				dr.y += y_width;
			}
			while (dr.y >= 0.5*y_width) {
				dr.y -= y_width;
			}
		}
	}
	if (comm->nprocs_z == 1) {
		if (z_c == 1) {
			while (dr.z < -0.5*z_width){
				dr.z += z_width;
			}
			while (dr.z >= 0.5*z_width) {
				dr.z -= z_width;
			}
		}
	}
#else
	if (x_c == 1) {
		while (dr.x < -0.5*x_width) {//using "while"instead of "if"... why "if" isn't enough?
			dr.x += x_width;
		}
		while (dr.x >= 0.5*x_width) {
			dr.x -= x_width;
		}			
	}
	if (y_c == 1) {
		while (dr.y < -0.5*y_width) {
			dr.y += y_width;
		}
		while (dr.y >= 0.5*y_width) {
			dr.y -= y_width;
		}
	}
	if (z_c == 1) {
		while (dr.z < -0.5*z_width){
			dr.z += z_width;
		}
		while (dr.z >= 0.5*z_width) {
			dr.z -= z_width;
		}
	}
#endif
	return dr;
}*/

void Atom_data::exchange_ghost () {
#ifdef USE_MPI

	int x_bc = 1, y_bc = 1, z_bc = 1; //periodic boundary condition

	const int nprocs = comm->nprocs;


	double x_llow = domain->x_lower_local;
	double x_lupp = domain->x_upper_local;
	double y_llow = domain->y_lower_local;
	double y_lupp = domain->y_upper_local;
	double z_llow = domain->z_lower_local;
	double z_lupp = domain->z_upper_local;

	double x_width = x_llow - x_lupp;
	double y_width = y_llow - y_lupp;
	double z_width = z_llow - z_lupp;


	int left = comm->left;
	int right = comm->right;
	int up = comm->up;
	int down = comm->down;
	int top = comm->top;
	int bottom = comm->bottom;

	std::vector<int> o_send_id; // contains all IDs to be deleted from the domain after sending.
	std::vector<int> o_send_id_left,o_send_id_right,o_send_id_up,o_send_id_down,o_send_id_top,o_send_id_bottom; // ID of owned to be sent
	std::vector<int> o_recv_id_left,o_recv_id_right,o_recv_id_up,o_recv_id_down,o_recv_id_top,o_recv_id_bottom; // ID of owned to be recieved

	std::vector<int> g_send_id_left,g_send_id_right,g_send_id_up,g_send_id_down,g_send_id_top,g_send_id_bottom; // ID of ghosts to be sent
	std::vector<int> g_recv_id_left,g_recv_id_right,g_recv_id_up,g_recv_id_down,g_recv_id_top,g_recv_id_bottom; // ID of ghosts to be recieved


	int o_recv_n_left=0, o_recv_n_right=0, o_recv_n_down=0, o_recv_n_up=0, o_recv_n_bottom=0 ,o_recv_n_top=0; // num of owned to be received
	int g_recv_n_left=0, g_recv_n_right=0, g_recv_n_down=0, g_recv_n_up=0, g_recv_n_bottom=0 ,g_recv_n_top=0; // num of ghosts to be received

	
	int me = comm->me;

	for (auto i=0; i<num_local_atoms; ++i) {

		if (owned.position[i].x < x_llow + cutoff) 
			g_send_id_left.push_back (owned.id[i]);

		if (owned.position[i].x > x_lupp + cutoff) 
			g_send_id_right.push_back (owned.id[i]);

 		if (owned.position[i].y < y_llow + cutoff) 
			g_send_id_down.push_back (owned.id[i]);
		
		if (owned.position[i].y > y_lupp + cutoff) 
			g_send_id_up.push_back (owned.id[i]);

 		if (owned.position[i].z < z_llow + cutoff) 
			g_send_id_bottom.push_back (owned.id[i]);

 		if (owned.position[i].z > z_lupp + cutoff)
			g_send_id_top.push_back (owned.id[i]);
	}


	MPI_Barrier (mpi_comm);

	if (left == right ) {
		if (x_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].x += x_width;
				}
				while (owned.position[i].x > domain->x_upper_local) {
					owned.position[i].x -= x_width;
				}
			}
		}
	} else {
		int s_left = o_send_id_left.size();
		int s_right = o_send_id_right.size();

		MPI_Send (&s_left, 1, MPI_INT, left,  10, mpi_comm);
		MPI_Recv (&o_recv_n_right, 				1, MPI_INT, right, 10, mpi_comm, MPI_STATUS_IGNORE);


		MPI_Send (&s_right, 1, MPI_INT, right,  11, mpi_comm);
		MPI_Recv (&o_recv_n_left, 			 	 1, MPI_INT, left,   11, mpi_comm, MPI_STATUS_IGNORE);


		MPI_Send (o_send_id_left.data(), o_send_id_left.size(), MPI_INT, left, 21, mpi_comm);//====send ID
		int tmp_r [o_recv_n_right];
		MPI_Recv (&tmp_r, o_recv_n_right, MPI_INT, right, 21, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_right;++j)
			o_recv_id_right.push_back(tmp_r[j]);//----recv ID


		for (auto i : o_send_id_left) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_left) //=====send pos
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		} // ----recv pose

		for (auto i : o_send_id_left) //=====send vel
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], left, mpi_comm);
		for (auto i : o_recv_id_right) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, right, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		} // ----recv pose




		MPI_Send (o_send_id_right.data(), o_send_id_right.size(), MPI_INT, right, 22, mpi_comm);
		int tmp_l [o_recv_n_left];
		MPI_Recv (&tmp_l, o_recv_n_left, MPI_INT, left, 22, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_left;++j)
			o_recv_id_left.push_back(tmp_l[j]);

		for (auto i : o_send_id_right) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type

		for (auto i : o_send_id_right)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_right)//send vel
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], right, mpi_comm);
		for (auto i : o_recv_id_left) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, left, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);

	if (down == up) {
		if (y_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].y < domain->y_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].y += y_width;
				}
				while (owned.position[i].y > domain->y_upper_local) {
					owned.position[i].y -= y_width;
				}
			}
		}
	} else {
		int s_down = o_send_id_down.size();
		int s_up = o_send_id_up.size();

		MPI_Send (&s_down, 1, MPI_INT, down,  12, mpi_comm);
		MPI_Recv (&o_recv_n_up, 				  1, MPI_INT, up,    12, mpi_comm, MPI_STATUS_IGNORE);

		MPI_Send (&s_up,   1, MPI_INT, up,   13, mpi_comm);
		MPI_Recv (&o_recv_n_down, 				1, MPI_INT, down, 13, mpi_comm, MPI_STATUS_IGNORE);



		MPI_Send (o_send_id_down.data(), o_send_id_down.size(), MPI_INT, down, 23, mpi_comm);
		int tmp_u [o_recv_n_up];
		MPI_Recv (&tmp_u, o_recv_n_up, MPI_INT, up, 23, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_up;++j)
			o_recv_id_up.push_back(tmp_u[j]);

		for (auto i : o_send_id_down) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_down)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_down)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], down, mpi_comm);
		for (auto i : o_recv_id_up) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, up, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}


		MPI_Send (o_send_id_up.data(), o_send_id_up.size(), MPI_INT, up, 24, mpi_comm);
		int tmp_d [o_recv_n_down];
		MPI_Recv (&tmp_d, o_recv_n_down, MPI_INT, down, 24, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_down;++j)
			o_recv_id_down.push_back(tmp_d[j]);

		for (auto i : o_send_id_up) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_up)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_up)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], up, mpi_comm);
		for (auto i : o_recv_id_down) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, down, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);


	if (bottom == top) {
		if (z_bc == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (owned.position[i].z < domain->z_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					owned.position[i].z += z_width;
				}
				while (owned.position[i].z > domain->z_upper_local) {
					owned.position[i].z -= z_width;
				}
			}
		}
	} else {
		int s_bot = o_send_id_bottom.size();
		int s_top = o_send_id_top.size();

		MPI_Send (&s_bot, 1, MPI_INT, bottom, 14, mpi_comm);
		MPI_Recv (&o_recv_n_top, 				    1, MPI_INT, top,    14, mpi_comm, MPI_STATUS_IGNORE);

		MPI_Send (&s_top,    1, MPI_INT, top,    15, mpi_comm);
		MPI_Recv (&o_recv_n_bottom, 				1, MPI_INT, bottom, 15, mpi_comm, MPI_STATUS_IGNORE);



		MPI_Send (o_send_id_bottom.data(), o_send_id_bottom.size(), MPI_INT, bottom, 24, mpi_comm);
		int tmp_t [o_recv_n_top];
		MPI_Recv (&tmp_t, o_recv_n_top, MPI_INT, top, 24, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_top;++j)
			o_recv_id_top.push_back(tmp_t[j]);

		for (auto i : o_send_id_bottom) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_bottom)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}
		for (auto i : o_send_id_bottom)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], bottom, mpi_comm);
		for (auto i : o_recv_id_top) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, top, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}



		MPI_Send (o_send_id_top.data(), o_send_id_top.size(), MPI_INT, top, 25, mpi_comm);
		int tmp_b [o_recv_n_bottom];
		MPI_Recv (&tmp_b, o_recv_n_bottom, MPI_INT, bottom, 25, mpi_comm, MPI_STATUS_IGNORE);
		for (int j=0; j<o_recv_n_bottom;++j)
			o_recv_id_bottom.push_back(tmp_b[j]);

		for (auto i : o_send_id_top) //=====send type
			MPI_Send (&owned.type[i], 1, MPI_INT, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			int tmp;
			MPI_Recv (&tmp, 1, MPI_INT, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.type.push_back (tmp);
		} // ----recv type


		for (auto i : o_send_id_top)
			MPI_Send (&owned.position[i].x, 3, MPI_DOUBLE, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.position.push_back (p_tmp);
			owned.id.push_back (i);
		}

		for (auto i : o_send_id_top)
			MPI_Send (&owned.velocity[i].x, 3, MPI_DOUBLE, owned.id[i], top, mpi_comm);
		for (auto i : o_recv_id_bottom) {
			Vector<double> p_tmp;
			MPI_Recv (&p_tmp, 3, MPI_DOUBLE, bottom, i, mpi_comm, MPI_STATUS_IGNORE);
			owned.velocity.push_back (p_tmp);
			owned.acceleration.push_back ( Vector<Real_t>	{0.0,0.0,0.0});
		}

	}

	MPI_Barrier (mpi_comm);

	std::sort(o_send_id.begin(), o_send_id.end(), std::greater<int>());
	for (auto i : o_send_id) {
		owned.position.erase (owned.position.begin()+i);	
		owned.velocity.erase (owned.velocity.begin()+i);	
		owned.acceleration.erase (owned.acceleration.begin()+i);	
		owned.type.erase (owned.type.begin()+i);	
	}

/*




	MPI_Barrier (mpi_comm);



	ghost.position.clear();*/
#else
	auto x_width = domain->x_upper_local - domain->x_lower_local;
	auto y_width = domain->y_upper_local - domain->y_lower_local;
	auto z_width = domain->z_upper_local - domain->z_lower_local;

	for (auto i = 0 ; i < num_local_atoms; ++i) {
		if (x_bc == 1) {
 		
			while (owned.position[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].x += x_width;
			}
			while (owned.position[i].x > domain->x_upper_local) {
				owned.position[i].x -= x_width;
			}
		}
	
		if (y_bc == 1) {
			while (owned.position[i].y < domain->y_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].y += y_width;
			}
			while (owned.position[i].y > domain->y_upper_local) {
				owned.position[i].y -= y_width;
			}
		}
	
		if (z_bc == 1) {
			while (owned.position[i].z < domain->z_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				owned.position[i].z += z_width;
			}
			while (owned.position[i].z > domain->z_upper_local) {
				owned.position[i].z -= z_width;
			}
		}
	}
#endif
}


