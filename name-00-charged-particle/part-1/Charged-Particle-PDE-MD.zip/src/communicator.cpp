#include "communicator.h"

#include <vector>

#include "domain.h"

Communicator::Communicator (MD *md) : Pointers{md} {
  grid_index_x = grid_index_y = grid_index_z = left = right = down = up = bottom = top = me = 0;
  nprocs_x = nprocs_y = nprocs_z = nprocs = 1;
#ifdef USE_MPI
  MPI_Comm_rank (mpi_comm, &me);
  MPI_Comm_size (mpi_comm, &nprocs);
  nprocs_x = nprocs;
#endif
}

void Communicator::calculate_procs_grid () {
#ifdef USE_MPI
  find_best_grid ();
  
  grid_index_x = me % nprocs_x;
  grid_index_y = me / nprocs_x % nprocs_y;
  grid_index_z = me / nprocs_x / nprocs_y;

  left = grid2rank (grid_index_x == 0 ? nprocs_x-1 : (grid_index_x-1)%nprocs_x, grid_index_y, grid_index_z);
  right = grid2rank (grid_index_x == nprocs_x-1 ? 0 : (grid_index_x+1)%nprocs_x, grid_index_y, grid_index_z);
  
  down = grid2rank (grid_index_x, grid_index_y == 0 ? nprocs_y-1 : (grid_index_y-1)%nprocs_y, grid_index_z);
  up = grid2rank (grid_index_x, grid_index_y == nprocs_y-1 ? 0 : (grid_index_y+1)%nprocs_y, grid_index_z);
  
  bottom = grid2rank (grid_index_x, grid_index_y, grid_index_z == 0 ? nprocs_z - 1 : (grid_index_z-1)%nprocs_z);
  top = grid2rank (grid_index_x, grid_index_y, grid_index_z == nprocs_z-1 ? 0 : (grid_index_z+1)%nprocs_z);
/*	if (me==0)
  	std::cout << "nprocs_x:" << nprocs_x << " nprocs_y:" << nprocs_y << " nprocs_z:" << nprocs_z << std::endl;
  std::cout << "me:" << me << " grid_index_x:" <<	grid_index_x << " grid_index_y:" <<	grid_index_y << " grid_index_z:" <<	grid_index_z << std::endl;
	std::cout << "me:" << me << " left:" << left << " right:" << right << " up:" << up << " down:" << down <<  " top:" << top << " bottom:" << bottom << std::endl;*/
#endif
}

void Communicator::broadcast (bool &flag) {
#ifdef USE_MPI
  MPI_Bcast (&flag, 1, MPI::BOOL, 0, mpi_comm);
#endif
}

void Communicator::broadcast (size_t &n) {
#ifdef USE_MPI
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
#endif
}

void Communicator::broadcast (size_t &n, char *str) {
#ifdef USE_MPI
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
  MPI_Bcast (str, n, MPI::CHAR, 0, mpi_comm);
#endif
}

void Communicator::broadcast (std::string &str) {
#ifdef USE_MPI
  int n = me == 0 ? str.length() : 0;
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
  MPI_Barrier (mpi_comm);
	char tmp[n]="";
  strcpy (tmp, str.c_str());
  MPI_Bcast (tmp, n, MPI::CHAR, 0, mpi_comm);
	if (tmp ) {
		if ( tmp[0] ) {
			str.assign (const_cast<const char *> (tmp), n);
		} else { }
	} else { }
  MPI_Barrier (mpi_comm);
/*
  int n = me == 0 ? str.length() : 0;
	std::cout<<"a:"<<std::endl;
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
	std::cout<<"b:"<<std::endl;
  MPI_Barrier (mpi_comm);
	std::cout<<"N:"<<n<<std::endl;
	std::cout<<"c:"<<std::endl;
	char *tmp = new char[n];
		std::cout<<"d:"<<std::endl;
  strcpy (tmp, str.c_str());
	std::cout<<"e:"<<std::endl;
  MPI_Bcast (tmp, n, MPI::CHAR, 0, mpi_comm);
	std::cout<<"f:"<<std::endl;
	std::cout << str << ' ' << tmp<< std::endl;
	if (tmp ) {
		std::cout<<"1:"<<std::endl;
		if ( tmp[0] ) {
			std::cout<<"2:"<<std::endl;
			str.assign (const_cast<const char *> (tmp), n);
		} else {
			std::cout<<"3:"<<std::endl;
		}
	} else {
		std::cout<<"4:"<<std::endl;
	}

	std::cout<<"g:"<<std::endl;
  MPI_Barrier (mpi_comm);
	std::cout << "h:tmp:" << tmp << " tmp[0]:" << tmp[0] << " n:" << n << " str:" << str << std::endl;
	if (tmp && tmp[0]) delete [] tmp;
	std::cout << "i:tmp:" << tmp << " tmp[0]:" << tmp[0] << " n:" << n << " str:" << str << std::endl;
	std::cout<<"i:"<<std::endl;
*/
#endif
}

static std::vector<std::array<int,3>> possible_grids (int nprocs) {
  std::vector<std::array<int,3>> grids;
  for (auto nprocs_x = 1; nprocs_x<=nprocs; ++nprocs_x) {
    if (nprocs % nprocs_x) continue;
    auto nprocs_yz = nprocs / nprocs_x;
    for (auto nprocs_y = 1; nprocs_y<=nprocs_yz; ++nprocs_y) {
      if (nprocs_yz % nprocs_y) continue;
      grids.push_back ({nprocs_x, nprocs_y, nprocs_yz/nprocs_y});
    }
  }
  return grids;
}

void Communicator::find_best_grid () {
  auto box_length_x = domain->x_upper_global - domain->x_lower_global;
  auto box_length_y = domain->y_upper_global - domain->y_lower_global;
  auto box_length_z = domain->z_upper_global - domain->z_lower_global;
  
  auto area_xy = box_length_x*box_length_y, area_xz = box_length_x*box_length_z, area_yz = box_length_y*box_length_z;
  
  auto grids = possible_grids (nprocs);
  auto min_area = 1.1*(area_xy + area_xz + area_yz);
  auto min_area_index = 0;
  for (auto i=0; i<grids.size(); ++i) {
    auto area = area_xy/grids[i][0]/grids[i][1] + area_xz/grids[i][0]/grids[i][2] + area_yz/grids[i][1]/grids[i][2];
    if (area < min_area) {
      min_area = area;
      min_area_index = i;
    }
  }
  nprocs_x = grids[min_area_index][0];
  nprocs_y = grids[min_area_index][1];
  nprocs_z = grids[min_area_index][2];
}
