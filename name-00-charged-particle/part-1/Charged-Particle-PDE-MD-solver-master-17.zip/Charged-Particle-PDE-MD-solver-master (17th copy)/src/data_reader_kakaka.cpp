#include "data_reader_kakaka.h"
#include "utilities_kakaka.h"
#include "preprocessors_kakaka.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"

Data_reader_Kakaka::Data_reader_Kakaka (MD *md, const std::string &file) : Pointers{md}, parser{new Parser{md, file}},
	all_objects{new kkk::All_objects}, num_total_atoms{0}, num_atom_types{0}, output{md->output} {}

Data_reader_Kakaka::~Data_reader_Kakaka () {
  delete parser;
}

//const std::map<std::string,kkk::CommandFunc> Data_reader_Kakaka::commands_map = {
const std::map<std::string,CommandFuncKKK> Data_reader_Kakaka::commands_map = {
		{	"READ_FILE", &Data_reader_Kakaka::Read_file},
 		{	"ELEMENT", &Data_reader_Kakaka::Element},
		{	"ATOM", &Data_reader_Kakaka::Atom},
		{	"MOLECULE", &Data_reader_Kakaka::Molecule},
		{	"RANDOM_GENERATOR", &Data_reader_Kakaka::Random_generator},
		{	"BOUNDARY", &Data_reader_Kakaka::Boundary},
		{	"MOLECULE_DISTRIBUTION", &Data_reader_Kakaka::Molecule_distribution},
		{	"ADD_ATOM", &Data_reader_Kakaka::ADD_ATOM},
		{	"ADD_MOLECULE", &Data_reader_Kakaka::ADD_MOLECULE},
		{	"INT_CONSTANT", &Data_reader_Kakaka::INT_CONSTANT},
		{	"REAL_CONSTANT", &Data_reader_Kakaka::REAL_CONSTANT},//{"CONSTANT", &Data_reader_Kakaka::REAL_CONSTANT},
		{	"INT_2D_VECTOR", &Data_reader_Kakaka::INT_2D_VECTOR},
		{	"REAL_2D_VECTOR", &Data_reader_Kakaka::REAL_2D_VECTOR},
		{	"INT_3D_VECTOR", &Data_reader_Kakaka::INT_3D_VECTOR},
		{	"REAL_3D_VECTOR", &Data_reader_Kakaka::REAL_3D_VECTOR}//,{"VECTOR", &Data_reader_Kakaka::REAL_3D_VECTOR}

};

bool Data_reader_Kakaka::read () {
	bool in_file = true;
	while (in_file) {
		auto token = parser->get_val_token();
		if (token.kind == Kind::eof) break;
		if (token.kind == Kind::eol) continue;
		auto command = token.string_value;

		std::map<std::string,kkk::Dictionary>::iterator it;
		if (commands_map.count (command) == 0) {
			it = all_objects->dictionary.find(command);
			if (it == all_objects->dictionary.end())
				error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Invalid Kakaka command or object NAME");
			if (it->second.type == kkk::gdst("ELEMENT")) 
				in_file = all_objects->elements[it->second.index].read(parser);
			if (it->second.type == kkk::gdst("ATOM")) 
				in_file = all_objects->atoms[it->second.index].read(parser);
			if (it->second.type == kkk::gdst("MOLECULE")) 
				in_file = all_objects->molecules[it->second.index].read(parser);

		} else {
			in_file = (this->*commands_map.at(command)) ();
		}
	}
}


bool Data_reader_Kakaka::Read_file () {
}



bool Data_reader_Kakaka::Element () {
	output->info("Data_reader_Kakaka: Element");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double MASS = 0, RADIUS = 0, CHARGE = 0;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL(RADIUS,"ELEMENT: ","")
		else ASSIGN_REAL(MASS,"ELEMENT: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}


	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: cannot make an ELEMENT without NAME");

	int e_type = all_objects->elements.size ();
	kkk::Element e_ (output, error,all_objects, MASS, RADIUS, CHARGE, e_type);
//	Element (Output * , Error *, All_objects *, double m, double r, double ch, int t);
	all_objects->elements.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("ELEMENT"), all_objects->elements.size()-1);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	return in_file;
}


bool Data_reader_Kakaka::Atom () {
	output->info("Data_reader_Kakaka: Atom");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> POSITION{0,0,0},VELOCITY{0,0,0};
	kkk::Molecule * FATHER = 0;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}


	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: cannot make an ATOM without NAME");

	int e_type = all_objects->atoms.size ();
	kkk::Atom a_ (output, error, all_objects, FATHER, POSITION, VELOCITY);
	all_objects->atoms.push_back ( a_);
	
	kkk::Dictionary dict (kkk::gdst("ATOM"), all_objects->atoms.size()-1);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	return in_file;
}


bool Data_reader_Kakaka::Molecule () {
	output->info("Data_reader_Kakaka: MOLECULE");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> POSITION{0,0,0},VELOCITY{0,0,0};
	kkk::Molecule * FATHER = 0;

	while(true) {
		auto token = parser->get_val_token();
		if (token.kind == Kind::eol) break;
		if (token.kind == Kind::eof) {in_file = false; break;}
		ASSIGN_NAME
		else ASSIGN_REAL_3D_VECTOR(POSITION,"MOLECULE: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"MOLECULE: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}


	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: cannot make an ATOM without NAME");

	int e_type = all_objects->molecules.size ();
	kkk::Molecule M_ (output, error, all_objects, FATHER, POSITION, VELOCITY);
	all_objects->molecules.push_back ( M_);
	
	kkk::Dictionary dict (kkk::gdst("MOLECULE"), all_objects->molecules.size()-1);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	return in_file;
}

bool Data_reader_Kakaka::ADD_ATOM () {
/*
	auto token_1 = parser->get_val_token();
	if (token_1.kind != Kind::identifier) 
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME");
	auto name_1 = token_1.string_value;

	std::map<std::string,kkk::Dictionary>::iterator it_1, it_2;
	it_1 = all_objects->dictionary.find(name_1);
	if (it_1 == all_objects->dictionary.end())
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Undefined object NAME");

	auto token_2 = parser->get_val_token();
	if (token_2.kind != Kind::identifier) 
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME or ");
	auto name_2 = token_2.string_value;
	if (name_2 == "TO_MOLECULE" || name_2 == "TO") {
		token_2 = parser->get_val_token();
		if (token_2.kind != Kind::identifier) 
			error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME ");
		name_2 = token_2.string_value;
	}

	it_2 = all_objects->dictionary.find(name_2);
	if (it_2 == all_objects->dictionary.end())
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Undefined object NAME");

	all_objects->molecules[it_2->second.index].add_atom(all_objects->atoms[it_2->second.index]);
*/
}


bool Data_reader_Kakaka::ADD_MOLECULE () {
	/*
	auto token_1 = parser->get_val_token();
	if (token_1.kind != Kind::identifier) 
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME");
	auto name_1 = token_1.string_value;

	std::map<std::string,kkk::Dictionary>::iterator it_1, it_2;
	it_1 = all_objects->dictionary.find(name_1);
	if (it_1 == all_objects->dictionary.end())
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Undefined object NAME");

	auto token_2 = parser->get_val_token();
	if (token_2.kind != Kind::identifier) 
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME or ");
	auto name_2 = token_2.string_value;
	if (name_2 == "TO_MOLECULE" || name_2 == "TO") {
		token_2 = parser->get_val_token();
		if (token_2.kind != Kind::identifier) 
			error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected NAME ");
		name_2 = token_2.string_value;
	}

	it_2 = all_objects->dictionary.find(name_2);
	if (it_2 == all_objects->dictionary.end())
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Undefined object NAME");

	auto token_3 = parser->get_val_token();
	if (token_3.kind != Kind::eol || token_3.kind == Kind::eof) {
		all_objects->molecules[it_2->second.index].add_atom(all_objects->atoms[it_2->second.index]);
		return true;
	}

	if (token_3.kind != Kind::identifier)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ADD_ATOM: Expected command ");
	if (token_3.string_value == "AT_POSITOIN") {

	} 
	if (token_3.string_value == "AT_POSITOIN") {

	} 

*/

}


bool Data_reader_Kakaka::INT_CONSTANT () {

}
bool Data_reader_Kakaka::REAL_CONSTANT () {

}

bool Data_reader_Kakaka::INT_2D_VECTOR () {
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<int> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else ASSIGN_INT_2D_VECTOR(v,"INT_2D_VECTOR: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}

	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: cannot make an VECTOR without NAME");


	all_objects->int_2d_vectors.push_back (v);
	int index = all_objects->int_2d_vectors.size ();

	kkk::Dictionary dict (kkk::gdst("INT_2D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return true;
}

bool Data_reader_Kakaka::REAL_2D_VECTOR () {
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<double> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else ASSIGN_REAL_2D_VECTOR(v,"REAL_2D_VECTOR: " ,"")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}

	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: cannot make an VECTOR without NAME");


	all_objects->real_2d_vectors.push_back (v);
	int index = all_objects->real_2d_vectors.size ();

	kkk::Dictionary dict (kkk::gdst("REAL_2D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return true;
}
bool Data_reader_Kakaka::INT_3D_VECTOR () {
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<int> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else ASSIGN_INT_3D_VECTOR(v,"INT_3D_VECTOR: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}

	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: cannot make an VECTOR without NAME");


	all_objects->int_3d_vectors.push_back (v);
	int index = all_objects->int_3d_vectors.size ();

	kkk::Dictionary dict (kkk::gdst("INT_3D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return true;
}

bool Data_reader_Kakaka::REAL_3D_VECTOR () {
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else ASSIGN_REAL_3D_VECTOR(v,"REAL_3D_VECTOR: ","")
		else ASSIGN_NAME_WITHOUT_KEYWORD
	}

	if (!name_called)
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: cannot make an VECTOR without NAME");


	all_objects->real_3d_vectors.push_back (v);
	int index = all_objects->real_3d_vectors.size ();

	kkk::Dictionary dict (kkk::gdst("REAL_3D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return true;
}


bool Data_reader_Kakaka::Random_generator () {

}

bool Data_reader_Kakaka::Boundary () {

}
bool Data_reader_Kakaka::Molecule_distribution () {

}

