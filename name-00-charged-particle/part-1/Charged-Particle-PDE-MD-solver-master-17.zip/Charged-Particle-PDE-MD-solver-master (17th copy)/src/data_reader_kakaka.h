#ifdef DATA_READER_CLASS

DataReaderStyle(Kakaka,Data_reader_Kakaka)

#else

#ifndef DATA_READER_Kakaka_H
#define DATA_READER_Kakaka_H

#include "pointers.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "utilities_kakaka.h"

class Data_reader_Kakaka;

//namespace kkk {
using CommandFuncKKK = bool (Data_reader_Kakaka::*)(); // a pointer to boolean function of Kakaka class.
//}

class Data_reader_Kakaka : protected Pointers {
public:
  Data_reader_Kakaka (class MD *, const std::string &);
  ~Data_reader_Kakaka ();

	bool read ();

private:
	bool execute ();
  class Parser *parser;
	class Output *output;
	class kkk::All_objects *all_objects;

	GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;

	Real_t xlo, xhi, ylo, yhi, zlo, zhi;


//	const static std::map<std::string,kkk::CommandFunc> commands_map;
	const static std::map<std::string,CommandFuncKKK> commands_map;

	bool Read_file () ;
	bool Element () ;
	bool Atom () ;
	bool Molecule () ;
	bool Random_generator () ;
	bool Boundary ();
	bool ADD_ATOM ();
	bool ADD_MOLECULE ();
	bool INT_CONSTANT ();
	bool REAL_CONSTANT ();
	bool INT_2D_VECTOR ();
	bool REAL_2D_VECTOR ();
	bool INT_3D_VECTOR ();
	bool REAL_3D_VECTOR ();
	bool Molecule_distribution ();



};




#endif
#endif
 
