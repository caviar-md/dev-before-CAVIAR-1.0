#ifndef UTILITIES_KAKAKA_H
#define UTILITIES_KAKAKA_H

//#include "data_reader_kakaka.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"

namespace kkk {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::map<std::string,int> dictionary_second_type = {
	{"ELEMENT",1},
	{"ATOM",2},
	{"MOLECULE",3},	
	{"RANDOM_GENERATOR",4},	
	{"BOUNDARY",5},	
	{"INT_CONSTANT",-1},	
	{"REAL_CONSTANT",-2},	
	{"INT_2D_VECTOR",-3},	
	{"REAL_2D_VECTOR",-4},	
	{"INT_3D_VECTOR",-5},	
	{"REAL_3D_VECTOR",-6},
};


class Molecule;
class Atom;
class Dictionary;
class All_objects;

class Element {
	public:
		Element () ;
		Element (Output * , Error *, All_objects *, double m, double r, double ch, int t);
		~Element ();

		bool read (Parser *);
	private:
		class Output * output;
		class Error * error;
		class All_objects * all_objects;

		int type_number;
		double MASS, RADIUS, CHARGE;
};

// ========================
// ========================
// ========================

class Molecule {
	public:
		Molecule ();
		Molecule (Output * , Error *, All_objects *, class Molecule *,  Vector<double>, Vector<double>);
		~Molecule ();

		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const;	
		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}

		bool read (Parser *);

		bool add_atom (Atom &);	
		bool add_molecule (Molecule &);	
	
		Molecule * FATHER;

	private:
	Vector<double> POSITION, VELOCITY;
	std::vector<Atom> atoms;
	std::vector<Molecule> molecules;
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};

// ========================
// ========================
// ========================

class Atom {
	public:
		Atom ();
		Atom (Output * , Error *,All_objects *, class Molecule *,  Vector<double>, Vector<double>);
		~Atom () ;


		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const; 

		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}

		bool read (Parser *);
		Molecule * FATHER;
	private:
	Vector<double> POSITION, VELOCITY;

	int type;
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};

// ========================
// ========================
// ========================

class Random_generator {
	public:
		Random_generator () {};
		~Random_generator () {};
	private:
};
// ========================
// ========================
// ========================

class Boundary {
	public:
		Boundary () {};
		~Boundary () {};
};
// ========================
// ========================
// ========================

class Dictionary {
	public:
	Dictionary () { };
	Dictionary (int t, int i) : type(t), index(i){ };
	~Dictionary () {};
	int type; // type of the vector
	int index; // index of the vector
//	string object_type ; // the same as int type
};


class Shape_Closed_2D_Line_in_3D {
public:
	Shape_Closed_2D_Line_in_3D ();	
	std::vector<Vector<Real_t>> p_3D; // vertex points of the shape in 3D space
	Vector<Real_t> n_vector, u_vector, v_vector; //  basis vectors of the plane: normal and (u,v)
	std::vector<Real_t> u_list, v_list; // array containing u and v coordinates of the vertices in the plane
	Real_t mat_inv[3][3]; // inverse of the transformation matrix;
	void make_basis_vectors() {
		if (p_3D.size() > 1) {
			Vector<Real_t> vec1 = p_3D[1] - p_3D[0];
			Vector<Real_t> vec2 = p_3D[2] - p_3D[0];
			std::vector<std::vector<Real_t>> mat_inv;
			n_vector = cross_product (vec1, vec2);
			u_vector = vec1;
			v_vector = cross_product (n_vector, u_vector);
			normalize(u_vector);
			normalize(v_vector);
			normalize(n_vector);
		}
	}
	void make_uv_vectors() {
		for (int i = 0; i<p_3D.size(); ++i) {
			Vector<Real_t> dp = p_3D[i] - p_3D[0];
			Real_t u_i = u_vector * dp;
			Real_t v_i = v_vector * dp;
			u_list.push_back (u_i);
			v_list.push_back (v_i);
		}
	}
	void make_transform_matrix() {
		Real_t m[3][3];
		m[0][0] = u_vector.x;	m[0][1] = u_vector.y;	m[0][2] = u_vector.z;
		m[1][0] = v_vector.x;	m[1][1] = v_vector.y;	m[1][2] = v_vector.z;
		m[2][0] = n_vector.x;	m[2][1] = n_vector.y;	m[2][2] = n_vector.z;

		Real_t det =  m[0][0] * (m[1][1] * m[2][2] - m[2][1] * m[1][2]) -
			            m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
	              	m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);

		Real_t invdet = 1. / det;

		mat_inv[0][0] = (m[1][1] * m[2][2] - m[2][1] * m[1][2]) * invdet;
		mat_inv[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * invdet;
		mat_inv[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * invdet;
		mat_inv[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * invdet;
		mat_inv[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * invdet;
		mat_inv[1][2] = (m[1][0] * m[0][2] - m[0][0] * m[1][2]) * invdet;
		mat_inv[2][0] = (m[1][0] * m[2][1] - m[2][0] * m[1][1]) * invdet;
		mat_inv[2][1] = (m[2][0] * m[0][1] - m[0][0] * m[2][1]) * invdet;
		mat_inv[2][2] = (m[0][0] * m[1][1] - m[1][0] * m[0][1]) * invdet;
	}
	void uv_to_xyz (Real_t u_i, Real_t v_i, Vector<Real_t> &p_i) {
		p_i.x = mat_inv[0][0]*u_i + mat_inv[0][1]*v_i + p_3D[0].x;
		p_i.y = mat_inv[1][0]*u_i + mat_inv[1][1]*v_i + p_3D[0].y;
		p_i.z = mat_inv[2][0]*u_i + mat_inv[2][1]*v_i + p_3D[0].z;
	}
	void xyz_to_uv (const Vector<Real_t> &p_i, Real_t &u_i, Real_t &v_i) {
		Vector<Real_t> dp = p_i - p_3D[0];
		u_i = u_vector * dp;
		v_i = v_vector * dp;
	}

	bool is_inside (double u_i, double v_i) // using Jordan curve theorem,
			// checks whether the point is inside the curve or not;
			// it has a bug when (v_list[i] == v_list[j])
	{
		bool c = false;
		int nvert = p_3D.size();
//	 	for (int i = 0; int j = nvert-1; i < nvert; j = i++) 
		int j = nvert - 1;
		for (int i = 0; i < nvert; ++i) {
			if ( ((v_list[i]>v_i) != (v_list[j]>v_i)) &&
      			(u_i < (u_list[j]-u_list[i]) * (v_i-v_list[i]) / (v_list[j]-v_list[i]) + u_list[i]) )
      	c = !c;
			j = i;
		}
  	return c;
	}
	

};




class Molecule_distribution {
	public:
		Molecule_distribution () ;
		~Molecule_distribution () ;
/*	
	Random *;
	Grid *;
	Boundary *;
	Molecule*;
	Atom *;*/
	void distribute();

};

class All_objects {
	public:
	All_objects () {};

	std::map<std::string,kkk::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<kkk::Element> elements; // 1
	std::vector<kkk::Atom> atoms; // 2
	std::vector<kkk::Molecule> molecules; // 3
	std::vector<kkk::Boundary> boundaries; // 4
	std::vector<kkk::Random_generator> random_generators; // 5
	std::vector<int> int_constants; // -1
	std::vector<double> real_constants; // -2
	std::vector<Vector2D<int>> int_2d_vectors; // -3
	std::vector<Vector2D<double>> real_2d_vectors; // -4
	std::vector<Vector<int>> int_3d_vectors; // -5
	std::vector<Vector<double>> real_3d_vectors; // -6

} ;//all_objects;

} // NAMESPACE KKK finished


#endif
 
