#ifndef INPUT_H
#define INPUT_H

#include <istream>
#include <map>

#include "pointers.h"

using CommandFunc = bool (Input::*)();

class Input : protected Pointers {
public:
  Input (class MD *);
  Input (class MD *, const std::string &);
  ~Input ();
  
  void read ();
private:
  class Parser *parser;
  const static std::map<std::string,CommandFunc> commands_map;
  
  bool read_command ();
  
  bool atom_style ();
  bool force_field_cmd (); // force_field command.
  bool force_field_parameters ();
  bool read_data ();
  bool add_int_var ();
  bool add_real_var ();
  bool add_string_var ();
  bool run ();
  bool print ();
  bool exit ();
	bool timestep ();
	bool boundary ();
	bool output_step ();
 	bool geometry_call ();

  void delete_var (const std::string &);
};

#endif
