#include "data_reader_morad.h"

//#include <set>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"

//static const std::set<std::string> section_keywords {"Atoms"};

Data_reader_Morad::Data_reader_Morad (MD *md, const std::string &file) : Pointers{md}, parser{new Parser{md, file}}, num_total_atoms{0}, num_atom_types{0}, xlo{-.5}, xhi{.5}, ylo{-.5}, yhi{.5}, zlo{-.5}, zhi{.5}, output{md->output}, list_priority_made{false} {}

Data_reader_Morad::~Data_reader_Morad () {
  delete parser;
}

bool Data_reader_Morad::read () {
  bool in_file = true;
  while (in_file) {
    auto token = parser->get_val_token();
    switch (token.kind) {
      case Kind::eof: {
				in_file = false;
				output->info ("data reader Morad: reading file finished.");
				
			}	break;
      
      case Kind::eol:
        continue;
      
      case Kind::identifier: {
				if (token.string_value == "random_generator") { //=============== random_generator =============//
					auto t1 = parser->get_val_token (); // random generator name
					int randseed = 1;
					int dist_type = 1;
					Real_t dist_uniform_min = -1.0, dist_uniform_max = 1.0; // used in uniform
					Real_t dist_normal_std = 1.0, dist_normal_mean = 0.0;
					while(true) {
						auto t2 = parser->get_val_token ();
						if (t2.kind == Kind::eol) {
							break;
						} else if (t2.string_value == "seed") {
							randseed = parser->get_literal_int ();
						} else if (t2.string_value == "uniform") {
							dist_type = 1;
						} else if (t2.string_value == "normal") {
							dist_type = 2;
						} else if (t2.string_value == "std") {
							dist_normal_std = parser->get_literal_real ();
						} else if (t2.string_value == "mean") {
							dist_normal_mean = parser->get_literal_real ();
						} else if (t2.string_value == "min_max") {
							dist_uniform_min = parser->get_literal_real ();
							dist_uniform_max = parser->get_literal_real ();
						}
					}

					std::mt19937 current_rand_gen (randseed);
					rnd_gen.push_back (current_rand_gen);
					if (dist_type == 1) {
						std::uniform_real_distribution<> dist (dist_uniform_min, dist_uniform_max);
						rnd_dist_uniform.push_back (dist);
						map_rnd_gen.insert (std::make_pair (t1.string_value, std::make_pair (rnd_gen.size()-1, std::make_pair (dist_type, rnd_dist_uniform.size()-1))));
					} else if (dist_type == 2) {
						std::normal_distribution<> dist (dist_normal_mean, dist_normal_std); // ************ check this
//						std::cout << dist.min() << " " << dist.max() << " " << dist.mean() << " " << dist.stddev() << "\n";
						rnd_dist_normal.push_back (dist);
						map_rnd_gen.insert (std::make_pair (t1.string_value, std::make_pair (rnd_gen.size()-1, std::make_pair (dist_type, rnd_dist_normal.size()-1))));
					}
					var_names_types.insert (std::make_pair(t1.string_value,4));

			} else if (token.string_value == "simulation_box") { //=============== simulation box =============//
					auto t1 = parser->get_val_token ();
					if (t1.string_value == "x") {
						xlo = parser->get_literal_real ();
						xhi = parser->get_literal_real ();
					} else if (t1.string_value == "y") {
						ylo = parser->get_literal_real ();
						yhi = parser->get_literal_real ();
					} else if (t1.string_value == "z") {
						zlo = parser->get_literal_real ();
						zhi = parser->get_literal_real ();
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "position") { //=============== position =============// ***
					auto type = parser->get_literal_int (); // particle type
					auto t2 = parser->get_val_token (); // "x" or "y" or "z"
					auto t3 = parser->get_val_token (); // list_names

					if (t2.string_value == "x") {
						ppx.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "y") {
						ppy.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "z") {
						ppz.insert (std::make_pair (type, t3.string_value));
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "velocity") {  //=============== velocity =============// ***
					auto type = parser->get_literal_int (); // particle type
					auto t2 = parser->get_val_token (); // "x" or "y" or "z"
					auto t3 = parser->get_val_token (); // list_names

					if (t2.string_value == "x") {
						pvx.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "y") {
						pvy.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "z") {
						pvz.insert (std::make_pair (type, t3.string_value));
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "mass") {  //=============== mass =============// ***
					auto type = parser->get_literal_int ();
					auto val1 = parser->get_literal_real ();
					map_mass.insert (std::make_pair (type,val1));
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "radius") {  //=============== radius =============// ***
					auto type = parser->get_literal_int ();
					auto val1 = parser->get_literal_real ();
					map_radius.insert (std::make_pair (type,val1));
					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "charge") {  //=============== charge =============// ***
					auto type = parser->get_literal_int ();
					auto val1 = parser->get_literal_real ();
					map_charge.insert (std::make_pair (type,val1));
					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "no_overlap")  {  //=============== no_overlap =============//
					std::vector<int> val1;
					while (true) {
						auto t1 = parser->get_val_token ();
						if (t1.kind == Kind::int_number) {
							val1.push_back (t1.int_value);
						} else if (t1.kind == Kind::eol || t1.kind == Kind::eof) {
							if (val1.size() == 0)
								error->all (FILE_LINE_FUNC, "Invalid syntax. Expected integer values.");
							break;
						} else {
							if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected integer values.");
						}
					}

				} else if (token.string_value == "constant") {  //=============== constant =============// ***
					auto t1 = parser->get_val_token (); // name of constant
					auto val1 = parser->get_literal_real (); // value of constant
					map_constants.insert (std::make_pair (t1.string_value, val1));
					var_names_types.insert (std::make_pair(t1.string_value,0));				
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				}else if (token.string_value == "list_values") {  //=============== list_values =============//
					auto t1 = parser->get_val_token ();
					std::vector <Real_t> vals;
					while (true) {
						auto t2 = parser->get_val_token ();
						if (t2.kind == Kind::eol) {
							break;
						} else {
							vals.push_back (t2.real_value);
						}
					}
					list_values.push_back (vals);
					map_list_values.insert (std::make_pair(t1.string_value, list_values.size()-1));
					var_names_types.insert (std::make_pair(t1.string_value, 1));				


				} else if (token.string_value == "random") {  //=============== random =============//
					auto t1 = parser->get_val_token (); // name of list
					auto t2 = parser->get_val_token (); // name of random generator
					auto val1 = parser->get_literal_int (); // length of the list
					map_random.insert (std::make_pair(t1.string_value, std::make_pair(t2.string_value, val1) ));
					var_names_types.insert (std::make_pair(t1.string_value,3));
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "grid") {  //=============== grid =============//
					auto t1 = parser->get_val_token (); // name of grid
					auto val1 = parser->get_literal_real (); // length of the list
					auto val2 = parser->get_literal_real (); // length of the list
					auto val3 = parser->get_literal_int (); // length of the list
					Real_t val_cor = 0 ;//= (val2 - val1)/val3;
					grid_min_max.push_back(std::make_pair(val1, val2 + val_cor));
					grid_partitions.push_back (val3);
					map_grid.insert (std::make_pair(t1.string_value,grid_partitions.size()-1));
					var_names_types.insert (std::make_pair(t1.string_value,2));	
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

				} else if (token.string_value == "list_priority") {  //=============== list_priority =============//
					list_priority_made = true;
					while (true) {
						auto t1 = parser->get_val_token ();
						if (t1.kind == Kind::eol) {
							break;
						} else {
							list_priority.push_back (t1.int_value);
						}
					}

				} else if (token.string_value == "output") {  //=============== output =============//


  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
				} else if (token.string_value == "add_atom") {  //=============== add_type =============//
					auto val_type = parser->get_literal_int ();
					auto val_x = parser->get_literal_int ();
					auto val_y = parser->get_literal_int ();
					auto val_z = parser->get_literal_int ();
					auto val_vx = parser->get_literal_int ();
					auto val_vy = parser->get_literal_int ();
					auto val_vz = parser->get_literal_int ();
					add_atom (val_type, val_x, val_y, val_z, val_vx, val_vy, val_vz);
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
				} else {
        	error->all (FILE_LINE_FUNC, "Invalid syntax. Unknown identifier.");
				}
			}
		}
	}
	execute ();
}

bool Data_reader_Morad::execute () {
	calculate_list_priority ();
	calculate_positions ();
	calculate_velocities ();
	assign_to_atom_data ();
}


std::string Data_reader_Morad::give_data_structure_type (std::map<int,std::string> &ppxyz, const int atom_type, int &data_type) {

	std::map <int,std::string>::iterator it_pp; // <atom type, data structure name>         ppx, ppy, ppz
	std::map <std::string,int> ::iterator it_vnt; // <data structure name, data structure type>      var_names_types
	it_pp = ppxyz.find (atom_type);
	if (it_pp == ppxyz.end()) {
		error->all (FILE_LINE_FUNC, "data reader Morad: Undefined atom type.");
	} else {
		it_vnt = var_names_types.find (it_pp->second);
		if (it_vnt == var_names_types.end() ) {
			error->all (FILE_LINE_FUNC, "data reader Morad: Undefined data structure name.");
		} else {
			data_type = it_vnt->second; // data structure type
			return it_pp->second;  // data structure name
		}
	}
}

int Data_reader_Morad::give_data_structure_length (std::string data_name, const int data_type) {
	switch (data_type) {
		case 0: 
		return 1;						
		
		
		case 1: {
			std::map <std::string,int>::iterator it;
			it = map_list_values.find (data_name);
			if (it == map_list_values.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				int list_values_index = it->second;
				return list_values [list_values_index].size();
			}
		}
		
		case 2: {
			std::map <std::string,int>::iterator it;
			it = map_grid.find (data_name);
			if (it == map_grid.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return grid_partitions[it->second];
			}
		}


		case 3:{
			std::map <std::string,std::pair<std::string,int>>::iterator it; // map_random; // f:name.  s.f:name of rnd_maps  s:s: num of values
			it = map_random.find (data_name);
			if (it == map_random.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return it->second.second;// data length
			}
		}
	}
}

Real_t Data_reader_Morad::make_value (std::string data_name, const int data_type, const int i_n) {
	switch (data_type) {
		case 0: {
			std::map <std::string,Real_t>::iterator it;
			it = map_constants.find (data_name);
			if (it == map_constants.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return it->second;
			}
		}
		
		case 1: {
			std::map <std::string,int>::iterator it;
			it = map_list_values.find (data_name);
			if (it == map_list_values.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return list_values [it->second][i_n];
			}
		}
		
		case 2: {
			std::map <std::string,int>::iterator it;
			it = map_grid.find (data_name);
			if (it == map_grid.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				int gp = grid_partitions[it->second];
				Real_t min = grid_min_max[it->second].first;
				Real_t max = grid_min_max[it->second].second;
				return min + i_n*(max - min)/gp; //**** check this
			}
		}


		case 3:{
			std::map <std::string,std::pair<std::string,int>>::iterator it; // map_random; // f:name.  s.f:name of rnd_maps  s:s: num of values
			it = map_random.find (data_name);
			if (it == map_random.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				std::map <std::string,std::pair<int,std::pair<int,int>>>::iterator it2;// map_rnd; // first one is the name, second.first:(index of generator)   second.second.first:(type of distribution)   second.second.second:(index of distribution)
				it2 = map_rnd_gen.find (it->second.first);
				if (it2 == map_rnd_gen.end() ) {
					error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
				} else {
					int dist_type = it2->second.second.first;//.first;
					if (dist_type == 1) {
						return rnd_dist_uniform[it2->second.second.second](rnd_gen[it2->second.first]);
					} else if (dist_type == 2){
						return rnd_dist_normal[it2->second.second.second](rnd_gen[it2->second.first]);
					}
				}
			}
		}
	}
}


bool Data_reader_Morad::calculate_positions () {
		
	for (auto atom_type : list_priority) {
		int data_type_x, data_type_y, data_type_z;
		int data_type_vx, data_type_vy, data_type_vz;

		std::string data_name_x = give_data_structure_type ( ppx, atom_type, data_type_x );
		std::string data_name_y = give_data_structure_type ( ppy, atom_type, data_type_y );
		std::string data_name_z = give_data_structure_type ( ppz, atom_type, data_type_z );

		std::string data_name_vx = give_data_structure_type ( pvx, atom_type, data_type_vx );
		std::string data_name_vy = give_data_structure_type ( pvy, atom_type, data_type_vy );
		std::string data_name_vz = give_data_structure_type ( pvz, atom_type, data_type_vz );

		int data_length_x = give_data_structure_length (data_name_x, data_type_x);
		int data_length_y = give_data_structure_length (data_name_y, data_type_y);
		int data_length_z = give_data_structure_length (data_name_z, data_type_z);


		int ix = 0 ,iy = 0 ,iz = 0;
		int ix_f = data_length_x , iy_f = data_length_y, iz_f = data_length_z;
		int tot_atoms = ix_f * iy_f * iz_f;
		int num_atoms = 0, n_contacts = 0;
		int n_contacts_limit = 10; // a limit of tries to make contactless particles
//		std::cout << "ix_f: " << ix_f << " iy_f: " << iy_f << " iz_f: " << iz_f <<"\n";


		while (n_contacts < n_contacts_limit) {

				Real_t x = make_value (data_name_x, data_type_x, ix);
				Real_t y = make_value (data_name_y, data_type_y, iy);
				Real_t z = make_value (data_name_z, data_type_z, iz);

				if (contact_check (atom_type, x, y, z)) { ++n_contacts; continue;}

				Real_t vx = make_value (data_name_x, data_type_x, ix);
				Real_t vy = make_value (data_name_y, data_type_y, iy);
				Real_t vz = make_value (data_name_z, data_type_z, iz);

				add_atom (atom_type, x, y, z, vx, vy, vz);

				++num_atoms;
				++ix;
				if (ix == ix_f) { ix = 0; ++iy;}
				if (iy == iy_f) { iy = 0; ++iz;}
				if (iz == iz_f) { break;}
//				std::cout << " ixiyiz " <<ix << " " << iy << " " << iz << "\n";
		}
		std::cout << "info: data reader Morad: " << num_atoms << " atoms of type " << atom_type << " is made. requested " << tot_atoms <<" atoms.\n";
	}
}

bool Data_reader_Morad::calculate_auto_priority () {

}

bool Data_reader_Morad::calculate_velocities () {

}

bool Data_reader_Morad::assign_to_atom_data () {

}

bool Data_reader_Morad::add_atom (int atom_type, Real_t x, Real_t y, Real_t z, Real_t vx, Real_t vy, Real_t vz) {
//	std::cout << atom_type << " \t" << x << " \t" << y << " \t" << z << " \t" << vx << " \t" << vy << " \t" << vz << " \n";
}

bool Data_reader_Morad::contact_check (int atom_type, Real_t x, Real_t y, Real_t z) {
	return false;
}


bool Data_reader_Morad::verify_and_set_header () {
  
  domain->x_lower_global = xlo;
  domain->x_upper_global = xhi;
  domain->y_lower_global = ylo;
  domain->y_upper_global = yhi;
  domain->z_lower_global = zlo;
  domain->z_upper_global = zhi;
  
//  atom_data->set_num_atom_types (num_atom_types);
//  atom_data->set_num_total_atoms (num_total_atoms);
}

/*
bool Data_reader_Morad::read_atoms () {
	parser->end_of_line ();	parser->end_of_line ();
  for (auto i=0; i<num_total_atoms; ++i) {
    GlobalID_t id = parser->get_literal_int ();
    GlobalID_t tag = parser->get_literal_int ();
    AtomType_t type = parser->get_literal_int ();
		Real_t charge = parser->get_literal_real ();
    Real_t x = parser->get_literal_real (), y = parser->get_literal_real (), z = parser->get_literal_real ();
    parser->end_of_line ();
    atom_data->add_atom (id, type, charge, Vector<Real_t> {x, y, z});
  }
}

bool Data_reader_Morad::read_masses () {
	parser->end_of_line ();	parser->end_of_line ();
	for (auto i=0; i<num_atom_types; ++i) {
    int type = parser->get_literal_int ();
		Real_t m = parser->get_literal_real ();
		if (type !=i+1) error->all (FILE_LINE_FUNC, "Input masses have to be in order from 1 to number of atom types.");
		atom_data->add_masses (type, m);
		parser->end_of_line ();
	}
}
*/
