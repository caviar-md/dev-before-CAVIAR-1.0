#ifdef FORCE_FIELD_CLASS

ForceFieldStyle(LJ,Force_field_lj)

#else

#ifndef FORCE_FIELD_LJ_H
#define FORCE_FIELD_LJ_H

#include "force_field.h"

#include <vector>

class Force_field_lj : public Force_field {
public:
  Force_field_lj (class MD *, class Parser *);
  ~Force_field_lj () {};
  
  bool set_parameters (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> epsilon,sigma;
};

#endif
#endif
