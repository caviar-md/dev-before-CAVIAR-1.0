#include "force_field_dpd_acc.h"

#include <cmath>
#include <map>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"
#include "update.h"
#include "communicator.h"

#define _KB 1.0  // boltzman

Force_field_dpd_acc::Force_field_dpd_acc (MD *md, Parser *parser) : Force_field {md, parser},
conserv_coef (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
dissip_coef (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) {
	temperature = parser->get_literal_real ();
	cutoff = parser->get_literal_real ();
	rnd_seed 	= parser->get_literal_int ();

	if (temperature < 0.0)
    error->all (FILE_LINE_FUNC, "DPD temperature have to be non-negative.");

	if (cutoff < 0.0)
    error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");

	rnd_generator.seed(rnd_seed);

	output->info ("A DPD_ACC force field is made.");
	kinetic_energy=0.0; potential_energy=0.0;
}

bool Force_field_dpd_acc::set_parameters (Parser *parser) {
  int type_i = parser->get_literal_int ();
  
  if (type_i < 1 || type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");
  
  int type_j = parser->get_literal_int ();
  if (type_j < 1 || type_j > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");

	--type_i;
	--type_j;

  Real_t conserv_coef_ij = parser->get_literal_real ();
  if (conserv_coef_ij < 0)
  error->all (FILE_LINE_FUNC, "Conservative force coef. have to be non-negative.");
  conserv_coef [type_i][type_j] = conserv_coef [type_j][type_i] = conserv_coef_ij;
  
  Real_t dissip_coef_ij = parser->get_literal_real ();
  if (dissip_coef_ij <= 0)
  error->all (FILE_LINE_FUNC, "Dissipative force coef. have to be larger than 0 .");
  dissip_coef [type_i][type_j] = dissip_coef [type_j][type_i] = dissip_coef_ij;
	output->info ("Force field parameter set.");
}


// /*
void Force_field_dpd_acc::calculate_acceleration () {
#ifdef USE_MPI
	auto neighbor_domains = comm ->neighbor_domains;
	std::vector<int> g_num_recv, g_num_send;
  std::vector<std::vector<Vector<Real_t>>> g_send_accel, g_recv_accel;
	std::vector<std::vector<GlobalID_t>> g_send_id, g_recv_id;
	int nd = comm -> neighbor_domains.size();
	g_send_accel.resize (nd);
	g_recv_accel.resize (nd);
	g_send_id.resize (nd);
	g_recv_id.resize (nd);
	g_num_recv.resize (nd,0);
	g_num_send.resize (nd,0);

	std::map <int, int> rank_to_index;
	for (auto i=0; i < comm -> neighbor_domains.size(); ++i) { // this doesn't need to be reconstructed in every step
		rank_to_index [neighbor_domains[i]] = i;				// only after send_owned() happened it is needed to be cleared.
	}
#else
  std::vector<Vector<Real_t>> g_send_accel;
	std::vector<GlobalID_t> g_send_id;
#endif

	std::map <GlobalID_t, GlobalID_t> id_to_index;
	for (auto i=0; i < atom_data -> owned.id.size(); ++i) { // this doesn't need to be reconstructed in every step
		id_to_index [atom_data -> owned.id[i]] = i;				// only after send_owned() happened it is needed to be cleared.
	}


  auto cutoff_sq = cutoff * cutoff;
	const auto dt = md -> update -> dt; 
	auto dt_sq_inv = 1.0 / std::sqrt(dt);
  const auto &neighbor_list = neighbor -> neighlist;
  for (auto i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
		const auto &vel_i = atom_data -> owned.velocity [i];
  	const auto type_i = atom_data -> owned.type [i] - 1;
    const auto mass_i = atom_data -> owned.mass [ type_i ];
		const auto id_i   = atom_data -> owned.id [i];
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j, vel_j;
			Real_t type_j, mass_j;
			GlobalID_t id_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
 				id_j = atom_data -> ghost.id [j];
				if (id_i>id_j) {
				  continue;  // there's another continue below which can make problems if we do a "++g_num_recv;" here
				}
      	pos_j = atom_data -> ghost.position [j];
				vel_j = atom_data -> ghost.velocity [j];
      	type_j = atom_data -> ghost.type [j] - 1;

			} else {
      	pos_j = atom_data -> owned.position [j];
				vel_j = atom_data -> owned.velocity [j];
      	type_j = atom_data -> owned.type [j] - 1;
			}
      mass_j = atom_data->owned.mass [ type_j ];
      auto dr = pos_j - pos_i;
			auto dv = vel_j - vel_i;
      auto r_sq = dr*dr;
			auto r_sqrt = std::sqrt(r_sq);
      if (r_sq > cutoff_sq) continue;
			auto dr_norm = dr / r_sqrt;
      const auto conserv_coef_ij = conserv_coef [type_i] [type_j];
      const auto dissip_coef_ij =  dissip_coef [type_i] [type_j];
			auto sigma = std::sqrt (2.0 * _KB *temperature*dissip_coef_ij);
			auto w_r = 1.0 - (r_sqrt/cutoff);
			auto alpha = rnd_ndist (rnd_generator); // 
			auto force_conserv = conserv_coef_ij * w_r;
			auto force_dissip = - dissip_coef_ij * w_r * w_r * (dr_norm * dv);
			auto force_rand = sigma * w_r * alpha* dt_sq_inv;
      auto force = (force_conserv + force_dissip + force_rand) * dr_norm;

			atom_data -> owned.acceleration [i] += force / mass_i;
			if (!is_ghost)
      	atom_data -> owned.acceleration [j] -= force / mass_j;
			else {
#ifdef USE_MPI
				int rti = rank_to_index [atom_data -> ghost_rank[j] ]; 
				g_send_accel [rti].push_back (-force / mass_j);
				g_send_id    [rti].push_back (id_j);
				g_num_send [rti]++;
#else
				g_send_accel.push_back (-force / mass_j);
				g_send_id.push_back (id_j);								
#endif
			}
		}
  }

#ifdef USE_MPI
	for (auto i=1;i<nd;++i) {
		MPI_Send (&g_num_send[i], 1, MPI_INT, neighbor_domains[i], 0, mpi_comm);
		MPI_Recv (&g_num_recv[i], 1, MPI_INT, neighbor_domains[i], 0, mpi_comm, MPI_STATUS_IGNORE);
	}

	MPI_Barrier (mpi_comm); 

	for (auto i=1;i<nd;++i) {
		int send_size = g_num_send[i];
		if (send_size != 0) {
			MPI_Send (&g_send_accel[i][0], 3*send_size, MPI_DOUBLE, neighbor_domains[i], 0, mpi_comm);
			MPI_Send (&g_send_id[i][0], send_size, MPI_INT, neighbor_domains[i], 1, mpi_comm);	
		}
	}

	for (auto i=1;i<nd;++i) {
		int recv_size = g_num_recv[i];
		if (recv_size != 0) {
			g_recv_id[i].resize (recv_size);
			g_recv_accel[i].resize (recv_size);
			MPI_Recv (&g_recv_accel[i][0], 3*recv_size, MPI_DOUBLE, neighbor_domains[i], 0, mpi_comm, MPI_STATUS_IGNORE);
			MPI_Recv (&g_recv_id[i][0], recv_size, MPI_INT, neighbor_domains[i], 1, mpi_comm, MPI_STATUS_IGNORE);
		}
	}

	for (auto i=1;i<nd;++i) {
		for (auto j=0; j < g_num_recv[i];++j) {
			int k = id_to_index.at (g_recv_id[i][j]);
			atom_data -> owned.acceleration [k] += g_recv_accel[i][j];
		}
	}

	for (auto j=0; j < g_send_id[0].size();++j) {
		int k = id_to_index.at (g_send_id[0][j]);
		atom_data -> owned.acceleration [k] += g_send_accel[0][j]; // note that we didn't send this part.
	}
#else
	for (auto j=0; j < g_send_id.size();++j) {
		int k = id_to_index.at (g_send_id[j]);
		atom_data -> owned.acceleration [k] += g_send_accel[j]; 
	}
#endif
}


