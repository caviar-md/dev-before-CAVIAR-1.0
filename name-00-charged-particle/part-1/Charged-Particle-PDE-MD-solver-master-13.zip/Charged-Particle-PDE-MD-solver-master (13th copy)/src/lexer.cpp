#define NO_PARSER

#include "lexer.h"

#include "communicator.h"
#include "error.h"

static constexpr size_t max_buffer_size = 1024;

Token_stream::Token_stream (MD *md) : Pointers{md}, get_new_line{true}, stream_is_file{false}, input_stream{&std::cin} {}

Token_stream::Token_stream (MD *md, const std::string &file) : Pointers{md}, get_new_line{true}, stream_is_file{true}, input_stream{new std::ifstream {file}} {
  if (input_stream->fail()) {
    std::string tmp = "Can not open file: '";
    tmp += file;
    tmp += '\'';
    error->all (FILE_LINE_FUNC, tmp);
  }
}

Token_stream::~Token_stream () {
  if (stream_is_file) delete input_stream;
}

void Token_stream::getline () {
  col = 0;
  if (comm->me == 0) {
    std::getline (*input_stream, line);
    end_of_file = input_stream->eof();
		line += '\n';
  } else
  line = "";
  comm->broadcast (end_of_file);
  comm->broadcast (line);
  line_stream = std::istringstream (line);
  get_new_line = false;
}

char Token_stream::get_nonblank_char () {
  char ch;
  do {
    ch = get_char ();
  } while (isblank (ch));
  return ch;
}

Token Token_stream::get () {
  if (get_new_line) getline();
  if (end_of_file) return ct={Kind::eof};
  char ch = get_nonblank_char();
  
  while (ch == '\\') {
    if (get_char () == '\n') {
      getline();
      ch = get_nonblank_char();
    } else error->all (FILE_LINE_FUNC, "unexpected character after line continuation character");
  }
  
  bool num_is_real = false;
  switch (ch) {
		case ':':// /****/ added in order to have no problem in reading unv files
    case '*':
    case '+':
    case '-':
    case '%':
    case '(':
    case ')':
    case '=':
      return ct = {static_cast<Kind>(ch)};
    
    case '/':
      ch = get_char ();
      if (ch == '/') return ct = {Kind::truediv};
      else {
        putback_char (ch);
        return ct = {Kind::div};
      }
    
    case '#':
    case '\n':
      get_new_line = true;
      return ct = {Kind::eol};
    
    case '.':
    case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
      return get_number_literal (ch);
    
    case '\'':
    case '"':
      return get_string_literal (ch);
    
    default:
      if (isalpha(ch) || ch == '_') {
        ct.string_value = ch;
        while ((ch = get_char ()) && (isalnum(ch) || ch == '_'))
          ct.string_value += ch; // append ch to end of string_value
//         std::cout << int(ch) << line_stream.eof() << std::endl;
        putback_char (ch);
        ct.kind = Kind::identifier;
        return ct;
      }
      error->all (FILE_LINE_FUNC, "Invalid token");
  }
}

Token & Token_stream::current () {
  return ct;
}

Token Token_stream::get_number_literal (char first_char) {
  bool num_is_real = (first_char == '.');
  std::string tmp;
  tmp += first_char;
  char ch;
  
  while (!num_is_real) {
    ch = get_char ();
    tmp += ch;
    if (isdigit(ch)) continue;
    else if (ch == '.') {
      num_is_real = true;
      break;
    } else if (ch == 'e' || ch == 'E') {
      ch = get_char ();
      tmp += ch;
      if (isdigit(ch)) {
        num_is_real = true;
        break;
      } else if (ch == '+' || ch == '-') {
        ch = get_char ();
        tmp += ch;
        if (isdigit(ch)) {
          num_is_real = true;
          break;
        } else error->all (FILE_LINE_FUNC, "Invalid token");
      } else error->all (FILE_LINE_FUNC, "Invalid token");
    } else break;
  }
  
  while (tmp.length()) {
    putback_char (tmp.back());
    tmp.pop_back();
  }
  
  ct.kind = num_is_real ? Kind::real_number : Kind::int_number;
  if (num_is_real) line_stream >> ct.real_value;
  else line_stream >> ct.int_value;
  return ct;
}

Token Token_stream::get_string_literal (char delim) {
  ct.kind = Kind::string;
  ct.string_value.clear();
  char ch, ch2, ch3;
  bool triple = false;
  constexpr auto eof = std::char_traits<char>::eof();
  
  if ((ch = get_char ()) == delim) {
    if ((ch2 = get_char ()) == delim) triple = true;
    else {
      putback_char (ch2);
      putback_char (ch);
    }
  } else putback_char (ch);
  
  while (line_stream.get(ch)) {
    if (ch == '\\') {
      switch (get_char ()) {
        case '\'':
          ct.string_value += '\'';
          break;
        case '"':
          ct.string_value += '"';
          break;
        case '\n':
          getline();
          break;
        case 'a':
          ct.string_value += '\a';
          break;
        case 'b':
          ct.string_value += '\b';
          break;
        case 'f':
          ct.string_value += '\f';
          break;
        case 'n':
          ct.string_value += '\n';
          break;
        case 'r':
          ct.string_value += '\r';
          break;
        case 't':
          ct.string_value += '\t';
          break;
        case 'v':
          ct.string_value += '\v';
          break;
        case '\\':
        default:
          ct.string_value += '\\';
      }
    } else if (ch == delim) {
      if (triple) {
        if ((ch2 = get_char ()) == delim) {
          if ((ch3 = get_char ()) == delim) break;
          else {
            if (ch3 == '\n') getline();
            ct.string_value += ch;
            ct.string_value += ch2;
            ct.string_value += ch3;
          }
        } else {
          if (ch2 == '\n') getline();
          ct.string_value += ch;
          ct.string_value += ch2;
        }
      } else break;
    } else if (ch == '\n') {
      if (triple) {
        ct.string_value += '\n';
        getline();
      } else error->all (FILE_LINE_FUNC, "EOL while scanning string literal");
    } else if (ch == eof) error->all (FILE_LINE_FUNC, "EOF while scanning triple-quoted string literal");
    else ct.string_value += ch;
  }
  
  return ct;
}
