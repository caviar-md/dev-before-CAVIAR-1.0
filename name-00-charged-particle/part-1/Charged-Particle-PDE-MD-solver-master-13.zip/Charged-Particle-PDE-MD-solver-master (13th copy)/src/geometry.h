#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "pointers.h"

#include <vector>
#include <map>

#include "vector.h"

class Geometry : protected Pointers {
	public:
	Geometry (class MD *);
	~Geometry ();

//	void read_unv (const std::string &); // read unv format // IT HAS SOME BUGS
	void read_vtk (const std::string &); // read vtk format // There's many unneeded points. 

	void make_grid (); // contains the faces neccesary to check
										 // make_grid has to be called after domain determination

	void lowest_highest_coord(); // calculates gxlo, gxhi, gylo...

	void make_normal (); // after reading unv file, it calculates normal vectors
	void make_edge_norms (); // makes normals of faces made of edges and other normals used in check_inside() algorithm. 
	void pre_correct_normals (); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.
	void merge_vertices (); // It checks if the two vertices are similar.Then makes a map of all vertices to the similar ones with the lower index
	void invert_normals (); // multiply all the normal Vectors with -1
	void check_inside (const Vector<Real_t> &, const Real_t, Vector<Real_t> &); // different algorithms
	void calculate_acceleration ();
//	void invert_normals (); // invert all the normals in case needed

	void pre_execute (); // call some functions and pre-calculate grids and so...
	bool set_parameters (class Parser *); //called by command script
	bool geometry_force;
	bool make_invert_normals;

	void output_mesh_povray (); // povray output mesh ".pov"
	void output_mesh_vmd (); // vmd output mesh ".tcl"
	void output_normals_vmd (); // vmd output normals ".tcl"
	void output_edges_vmd (); // vmd output edges  ".tcl"

	std::vector<Real_t> radius; // it is public in order to be used at "output.cpp"

	private:


	std::vector<Vector<Real_t>> vertex;	// contains cartesian coordinates
	std::vector<std::vector<int>> vertex_map;	// made in "merge_vertices()" it's a map to the index of possible similar vertex with the lower index
//	std::vector<std::vector<std::pair<int, int>>> edge;		// contains vertex indices
	std::vector<std::vector<int>> face;	// contains vertex indices of ngons
	std::vector<Vector<Real_t>> normal; // normal of faces (inward or outward?)
//	std::vector<std::vector<Vector<Real_t>>> edge_norms1; // addition of normals of neighbor faces for each edge
//	std::vector<std::vector<Vector<Real_t>>> edge_norms2; // face[][j]-face[][j+1]
	std::vector<std::vector<Vector<Real_t>>> edge_norms3; // norm1 cross norm 2

//	std::vector<std::vector<int>> faces_of_vertex; // contains the face index which share one specific vectex;
//	std::vector<std::vector<int>> faces_of_edge; // contains the face index which share one specific edge;
	std::map<std::vector<int>,std::vector<int>> edges; // first: the edge that has vertex[i],vertex[j] ... second: face[m],face[n] that has this edge
	std::map<std::vector<int>,std::vector<int>>::iterator it_edges;
	std::vector<std::vector<std::vector<std::vector<int>>>> grid; // contains face indices within the grid;

	Real_t gxlo, gylo, gzlo, gxhi, gyhi, gzhi; // highest and lowest coordinates of vertices;

	Real_t dx_part, dy_part, dz_part; // used in grid
	int nx_part, ny_part, nz_part;   // used in grid;
	Real_t thickness; // it defines the maximum thickness of each surface. If a particle go farther than it inside, it won't be inside anymore.
	Real_t young_modulus;
	Real_t grid_toll; // used in gridding; if zero, makes bugs in cases when grid is on a face.
};

#endif
