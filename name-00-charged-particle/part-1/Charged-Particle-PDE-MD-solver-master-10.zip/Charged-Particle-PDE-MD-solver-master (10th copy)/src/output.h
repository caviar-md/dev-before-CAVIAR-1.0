#ifndef OUTPUT_H
#define OUTPUT_H

#include "pointers.h"

class Output : protected Pointers {
public:
  Output (class MD *);
	void open_files ();
	void close_files ();
	void print_hello ();
	void dump_data (int);
	void comment (std::string &);
	void comment (const char *);
	void info (std::string &);
	void info (const char *);
	int energy_step, position_step;
private:
	class Atom_data *atom_data;
	class Communicator *comm;

	void open_them ();
	void close_them ();
	void dump_energy (int);
	void dump_position (int);

	std::ofstream ofs_energy,  ofs_positions, ofs_velocities;
  
};

#endif
