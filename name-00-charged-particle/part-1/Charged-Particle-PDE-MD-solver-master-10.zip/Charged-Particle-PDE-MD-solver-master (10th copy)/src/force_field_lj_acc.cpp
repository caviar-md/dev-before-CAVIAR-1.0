#include "force_field_lj_acc.h"

#include <cmath>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"
#include "communicator.h"

Force_field_lj_acc::Force_field_lj_acc (MD *md, Parser *parser) : Force_field {md, parser},
epsilon (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
sigma (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) {
  cutoff = parser->get_real ();
	if (cutoff < 0.0)
    error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");
	output->info ("A Lennard-Jones (ACC) force field is made.");
	kinetic_energy=0.0; potential_energy=0.0;
}

bool Force_field_lj_acc::set_parameters (Parser *parser) {
  int type_i = parser->get_int ();
  
  if (type_i < 1 || type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");
  
  int type_j = parser->get_int ();
  if (type_j < 1 || type_j > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");

	--type_i;
	--type_j;

  Real_t eps_ij = parser->get_real ();
  if (eps_ij < 0)
  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");
  epsilon [type_i][type_j] = epsilon [type_j][type_i] = eps_ij;
  
  Real_t sigma_ij = parser->get_real ();
  if (sigma_ij <= 0)
  error->all (FILE_LINE_FUNC, "Sigma have to be larger than 0 .");
  sigma [type_i][type_j] = sigma [type_j][type_i] = sigma_ij;
	output->info ("Force field parameter set.");
}

void Force_field_lj_acc::calculate_acceleration () { // this scheme may make you to only send ghosts with higher ID even in Atom_data class
#ifdef USE_MPI
	auto neighbor_domains = comm ->neighbor_domains;
	std::vector<int> g_num_recv, g_num_send;
  std::vector<std::vector<Vector<Real_t>>> g_send_accel, g_recv_accel;
	std::vector<std::vector<GlobalID_t>> g_send_id, g_recv_id;
	int nd = comm -> neighbor_domains.size();
	g_send_accel.resize (nd);
	g_recv_accel.resize (nd);
	g_send_id.resize (nd);
	g_recv_id.resize (nd);
	g_num_recv.resize (nd,0);
	g_num_send.resize (nd,0);

	std::map <int, int> rank_to_index;
	for (auto i=0; i < comm -> neighbor_domains.size(); ++i) { // this doesn't need to be reconstructed in every step
		rank_to_index [neighbor_domains[i]] = i;				// only after send_owned() happened it is needed to be cleared.
	}
#else
  std::vector<Vector<Real_t>> g_send_accel;
	std::vector<GlobalID_t> g_send_id;
#endif

	std::map <GlobalID_t, GlobalID_t> id_to_index;
	for (auto i=0; i < atom_data -> owned.id.size(); ++i) { // this doesn't need to be reconstructed in every step
		id_to_index [atom_data -> owned.id[i]] = i;				// only after send_owned() happened it is needed to be cleared.
	}

	potential_energy = 0.0;
  auto cutoff_sq = cutoff * cutoff;
  const auto &neighbor_list = neighbor -> neighlist;
  for (auto i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
  	const auto type_i = atom_data -> owned.type [i] - 1;
    const auto mass_i = atom_data -> owned.mass [ type_i ];
	 	const auto id_i = atom_data -> owned.id [i];	
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j;
			Real_t type_j, mass_j;
			GlobalID_t id_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
 				id_j = atom_data -> ghost.id [j];
				if (id_i>id_j) {
				  continue;  // there's another continue below which can make problems if we do a "++g_num_recv;" here
				}
      	pos_j = atom_data -> ghost.position [j];
      	type_j = atom_data -> ghost.type [j] - 1;

			} else {
      	pos_j = atom_data -> owned.position [j];
      	type_j = atom_data -> owned.type [j] - 1;
			}
      mass_j = atom_data->owned.mass [ type_j ];
      auto dr = pos_j - pos_i; 
      auto r_sq = dr*dr;
      if (r_sq > cutoff_sq) continue;
      const auto eps_ij = epsilon [type_i] [type_j];
      const auto sigma_ij =  sigma [type_i] [type_j];
//      auto rho_c_inv = sigma_ij / cutoff;
//      auto rho_c_6_inv = ipow (rho_c_inv, 6);
//      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
//      auto rho_c_18_inv = rho_c_12_inv*rho_c_6_inv;
      auto r_c_sq_inv = 1/(cutoff*cutoff);
      auto rho_c_sq_inv = sigma_ij*sigma_ij*r_c_sq_inv;
      auto rho_c_6_inv = rho_c_sq_inv*rho_c_sq_inv*rho_c_sq_inv;
      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
      auto r_sq_inv = 1/r_sq;
      auto rho_sq_inv = sigma_ij*sigma_ij*r_sq_inv;
      auto rho_6_inv = rho_sq_inv*rho_sq_inv*rho_sq_inv;
      auto rho_12_inv = rho_6_inv*rho_6_inv;
//      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + (2*rho_c_18_inv - rho_c_12_inv) * r_sq*r_sq/ipow (sigma_ij, 6) ) * dr;
      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + 
														 +12*rho_c_12_inv*r_c_sq_inv - 6*rho_c_6_inv*r_c_sq_inv 	) * dr;
			auto dr_norm = std::sqrt(r_sq);
			auto r_m_rc = dr_norm-cutoff;
			potential_energy += 4*eps_ij*(+rho_12_inv - rho_6_inv 
														 				-rho_c_12_inv + rho_c_6_inv 
																		+4.0*eps_ij*(-12*rho_c_12_inv*r_c_sq_inv +6*rho_c_6_inv*r_c_sq_inv )*r_m_rc*dr_norm);
			atom_data -> owned.acceleration [i] += force / mass_i;
			if (!is_ghost)
      	atom_data -> owned.acceleration [j] -= force / mass_j;
			else {
#ifdef USE_MPI
				int rti = rank_to_index [atom_data -> ghost_rank[j] ]; 
				g_send_accel [rti].push_back (-force / mass_j);
				g_send_id    [rti].push_back (id_j);
				g_num_send [rti]++;
#else
				g_send_accel.push_back (-force / mass_j);
				g_send_id.push_back (id_j);								
#endif
			}
		}
  }

#ifdef USE_MPI
	for (auto i=1;i<nd;++i) {
		MPI_Send (&g_num_send[i], 1, MPI_INT, neighbor_domains[i], 0, mpi_comm);
		MPI_Recv (&g_num_recv[i], 1, MPI_INT, neighbor_domains[i], 0, mpi_comm, MPI_STATUS_IGNORE);
	}

	MPI_Barrier (mpi_comm); 

	for (auto i=1;i<nd;++i) {
		int send_size = g_num_send[i];
		if (send_size != 0) {
			MPI_Send (&g_send_accel[i][0], 3*send_size, MPI_DOUBLE, neighbor_domains[i], 0, mpi_comm);
			MPI_Send (&g_send_id[i][0], send_size, MPI_INT, neighbor_domains[i], 1, mpi_comm);	
		}
	}

	for (auto i=1;i<nd;++i) {
		int recv_size = g_num_recv[i];
		if (recv_size != 0) {
			g_recv_id[i].resize (recv_size);
			g_recv_accel[i].resize (recv_size);
			MPI_Recv (&g_recv_accel[i][0], 3*recv_size, MPI_DOUBLE, neighbor_domains[i], 0, mpi_comm, MPI_STATUS_IGNORE);
			MPI_Recv (&g_recv_id[i][0], recv_size, MPI_INT, neighbor_domains[i], 1, mpi_comm, MPI_STATUS_IGNORE);
		}
	}

	for (auto i=1;i<nd;++i) {
		for (auto j=0; j < g_num_recv[i];++j) {
			int k = id_to_index.at (g_recv_id[i][j]);
			atom_data -> owned.acceleration [k] += g_recv_accel[i][j];
		}
	}

	for (auto j=0; j < g_send_id[0].size();++j) {
		int k = id_to_index.at (g_send_id[0][j]);
		atom_data -> owned.acceleration [k] += g_send_accel[0][j]; // note that we didn't send this part.
	}
#else
	for (auto j=0; j < g_send_id.size();++j) {
		int k = id_to_index.at (g_send_id[j]);
		atom_data -> owned.acceleration [k] += g_send_accel[j]; 
	}
#endif
}


