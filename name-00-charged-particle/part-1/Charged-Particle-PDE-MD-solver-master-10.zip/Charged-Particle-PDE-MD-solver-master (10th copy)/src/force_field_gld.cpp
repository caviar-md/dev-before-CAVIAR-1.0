#include "force_field_gld.h"

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "vector.h"
#include "output.h"

#include <cmath>

Force_field_gld::Force_field_gld (MD *md, Parser *parser) : Force_field {md, parser}
//,epsilon (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
//sigma (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) 
{
  cutoff = parser->get_real ();
	if (cutoff < 0.0)
    error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");

	gravity.x =  parser->get_real ();
	gravity.y =  parser->get_real ();
	gravity.z = - parser->get_real (); // a bug in parser
	elastic_coef.resize (atom_data->num_atom_types);
	dissip_coef.resize (atom_data->num_atom_types);
	radius.resize (atom_data->num_atom_types);
	output->info ("A granular linear dashpot force field is made.");
	kinetic_energy=0.0; potential_energy=0.0;
}

bool Force_field_gld::set_parameters (Parser *parser) {
  int type_i = parser->get_int ();
  
  if (type_i < 1 || type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be larger than 0 and smaller than number of the atom types.");

 	--type_i; 
  Real_t ela_i = parser->get_real ();
  if (ela_i < 0)
  	error->all (FILE_LINE_FUNC, "Elastic coef. have to be non-negative.");
  elastic_coef [type_i] = elastic_coef [type_i] = ela_i;
  
  Real_t dis_i = parser->get_real ();
  if (dis_i < 0)
  	error->all (FILE_LINE_FUNC, "Dissipation coef. have to be non-negative.");
  dissip_coef [type_i] = dissip_coef [type_i] = dis_i;

  Real_t rad_i = parser->get_real ();
  if (rad_i < 0)
  	error->all (FILE_LINE_FUNC, "Radius have to be non-negative.");
  radius [type_i] = radius [type_i] = rad_i;

	output->info ("Force field parameter set.");
}

void Force_field_gld::calculate_acceleration () {
 	const auto &g_pos = atom_data -> ghost.position;
  const auto &g_vel = atom_data -> ghost.velocity;
  const auto &g_type = atom_data -> ghost.type;
  const auto &g_id = atom_data -> ghost.id;
  auto cutoff_sq = cutoff * cutoff;
  const auto &neighbor_list = neighbor -> neighlist;
  for (auto i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
    const auto &vel_i = atom_data -> owned.velocity [i];
  	const auto type_i = atom_data -> owned.type [i] - 1;
    const auto mass_i = atom_data -> owned.mass [ type_i ];
    const auto ela_i = elastic_coef [type_i];
    const auto dis_i = dissip_coef [type_i];
		const auto rad_i = radius [type_i];
		if (type_i > 0)
     		atom_data -> owned.acceleration [i] += gravity;
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j, vel_j;
			Real_t type_j, mass_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
      	pos_j = atom_data->ghost.position [j];
				vel_j = atom_data->ghost.velocity [j];
      	type_j = atom_data->ghost.type [j] - 1;
			} else {
      	pos_j = atom_data->owned.position [j];
				vel_j = atom_data->owned.velocity [j];
      	type_j = atom_data->owned.type [j] - 1;
			}
     	mass_j = atom_data->owned.mass [ type_j ];
	    auto dr = pos_j - pos_i;
			auto r_sq = dr*dr;
      if (r_sq > cutoff_sq) continue;
      const auto ela_j = elastic_coef [type_j];
      const auto dis_j = dissip_coef [type_j];
			const auto rad_j = radius [type_j];
			auto rr = std::sqrt(r_sq);
			auto xi = rad_i+rad_j-rr;
			if (xi > 0.0) {
				auto Y = ela_i*ela_j/(ela_i+ela_j);
				auto A = -0.5*(dis_i+dis_j);
				auto reff = (rad_i*rad_j)/(rad_i+rad_j);
				auto dvx = vel_i.x-vel_j.x;
				auto dvy = vel_i.y-vel_j.y;
				auto dvz = vel_i.z-vel_j.z;
				auto rr_rez = 1.0/rr;
				auto ex = dr.x*rr_rez;
				auto ey = dr.y*rr_rez;
				auto ez = dr.z*rr_rez;
				auto xidot = -(ex*dvx+ey*dvy+ez*dvz);
//				auto fn = std::sqrt(xi)*Y*std::sqrt(reff)*(+xi+A*xidot);	//visco-elastic
				auto fn =Y*std::sqrt(reff)*(+xi+A*xidot);										//linear-dashpot
				if (fn < 0.0) fn = 0.0;
				auto force_i = Vector <Real_t> {-fn*ex, -fn*ey, -fn*ez};
				auto force_j = -force_i;
				if (type_i > 0)
      		atom_data -> owned.acceleration [i] += (force_i / mass_i);
				if (!is_ghost)
					if (type_j > 0)
      			atom_data -> owned.acceleration [j] += (force_j / mass_j);
			} 			
    }   
  }
}


