#include "geometry.h"

#include <string>
#include <cmath>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"

template <typename T>
constexpr Vector<T> cross_product (const Vector<T> &v1, const Vector<T> &v2) {
	return	Vector<T> {v1.y*v2.z - v1.z*v2.y, v1.z*v2.x - v1.x*v2.z, v1.x*v2.y - v1.y*v2.x};
}

Geometry::Geometry (MD *md) : Pointers{md} {}

Geometry::~Geometry () { }

void  Geometry::pre_execute () {
	lowest_highest_coord ();
	make_normal ();
	correct_normals ();
	make_grid ();
	Vector <Real_t> v1 {10.0,10.0,10.0};
	check_inside (v1);

}

void Geometry::lowest_highest_coord () {
	gxlo = vertex[0].x;	gylo = vertex[0].y;
	gzlo = vertex[0].z;	gxhi = vertex[0].x;
	gyhi = vertex[0].y;	gzhi = vertex[0].z;

	for (auto v : vertex) {
		if (gxlo > v.x) gxlo = v.x;		if (gylo > v.y) gylo = v.y;		if (gzlo > v.z) gzlo = v.z;
		if (gxhi < v.x) gxhi = v.x;		if (gyhi < v.y) gyhi = v.y;		if (gzhi < v.z) gzhi = v.z;
	}
	std::cout << "info: geometry: min. and max. of geometry coordinates:"
						<< " gxlo: " << gxlo << " gxhi: "	 << gxhi \
						<< " gylo: " << gylo << " gyhi: "	 << gyhi \
						<< " gzlo: " << gzlo << " gzhi: "	 << gzhi << std::endl;

}

void Geometry::merge_vertices () { // There can be a function that merge vertices which are closer than a small distance.
	vertex_map.resize (vertex.size());
	for (int i=0;i<vertex.size();++i) {
		for (int j=i+1;j<vertex.size();++j) {
 			if (vertex[i]==vertex[j]) {
				vertex_map[j].push_back(i);
			}
		}
	}
}

void Geometry::read_vtk (const std::string &file) {
	class Parser *parser = new Parser {md, file};
	std::cout << "info: geometry: reading a geometry vtk file: "<< file << std::endl;
	while(true) {

		auto t0 = parser->get_val_token ();
		struct Token t1;
		if (t0.kind==Kind::eof) break;

		if (t0.kind==Kind::identifier) {
			if (t0.string_value == "POINTS") {
				output->info("geometry: read vtk: POINTS");
				int no_points = parser->get_literal_int();
				parser->get_val_token ();
				parser->end_of_line();
				int xyz = 0;
				Real_t x,y,z;
				while (true) {
					t1 = parser->get_val_token ();
					if (t1.kind==Kind::identifier) break;
					if (t1.kind==Kind::eol) t1 = parser->get_val_token ();
					if (t1.kind==Kind::identifier) break;
					if (xyz==0) {
						if (t1.kind==Kind::int_number)
							x = t1.int_value;
						else 
							x = t1.real_value;
					} else if (xyz==1) {
						if (t1.kind==Kind::int_number)
							y = t1.int_value;
						else 
							y = t1.real_value;

					} else {
						if (t1.kind==Kind::int_number)
							z = t1.int_value;
						else 
							z = t1.real_value;
						vertex.push_back (Vector<Real_t> {x, y, z});
					}
					++xyz;
					if (xyz==3) xyz=0;
				}
			}
		}
	

		if (t1.string_value=="VERTICES") {
			output->info("geometry: read vtk: VERTICES");
			while(true) {
				t1 = parser->get_val_token ();
				if (t1.kind==Kind::identifier) {
//					std::cout<<"identifier " << t1.string_value<<std::endl;
					merge_vertices();
					break;
					}
			}
		}
		if (t1.string_value=="LINES") {
			output->info("geometry: read vtk: LINES");
			while(true) {
				t1 = parser->get_val_token ();
				if (t1.kind==Kind::identifier) {
//					std::cout<<"identifier " << t1.string_value<<std::endl;
					break;
					}
			}
		}
		if (t1.string_value=="POLYGONS") {
			faces_of_vertex.resize (vertex.size());
			output->info("geometry: read vtk: POLYGONS");
			int no_polygons = parser->get_literal_int ();
			int no_something = parser->get_literal_int ();
			parser->end_of_line ();
			for (int i=0;i<no_polygons;++i) {
				int num = parser->get_literal_int ();
				int num1 = parser->get_literal_int ();
				int num2 = parser->get_literal_int ();
				int num3 = parser->get_literal_int ();
//				std::cout << num << " " << num1 << " " << num2 << " " << num3 << "\n";

				num1 = (vertex_map[num1].size()==0)?num1 :vertex_map[num1][1];  // uses vertex_map instead of vertex
				num2 = (vertex_map[num2].size()==0)?num2 :vertex_map[num2][1];  //
				num3 = (vertex_map[num3].size()==0)?num3 :vertex_map[num3][1];	//

				std::vector<int> gons;
				gons.push_back (num1); gons.push_back (num2); gons.push_back (num3);
				face.push_back (gons);			

				faces_of_vertex[num1].push_back(i); faces_of_vertex[num2].push_back(i); faces_of_vertex[num3].push_back(i);


#define ADD_EDGE(NUM1,NUM2)																		\
				{																											\
					std::vector<int> check_face = {i};									\
					std::vector<int> check_edge; 												\
					if (NUM1<NUM2) check_edge = {NUM1,NUM2};						\
					else check_edge = {NUM2,NUM1};											\
					it_edges = edges.find(check_edge);									\
					if (it_edges == edges.end()) {											\
						edges.insert (make_pair(check_edge,check_face));	\
					}	else {																						\
						it_edges->second.push_back(i);										\
					}																										\
				}
				ADD_EDGE(num1,num2);
				ADD_EDGE(num2,num3);
				ADD_EDGE(num3,num1);

#undef ADD_EDGE
				parser->end_of_line();
			}
			
			break;
		}

	}
/*
	for (int i=0;i<vertex.size();++i)
		std::cout<<vertex[i]<<std::endl;

	for (int i = 0; i<face.size();++i) {
		std::cout << i << ": ";
		for (int j = 0; j<face[i].size();++j) {
			std::cout<<face[i][j]<< " ";
		}
		std::cout <<"\n";
	}
*/

}

void Geometry::make_normal () { // It's supposed here that the vertices are written in order (right-hand rotation) in unv file
	for (int i=0;i<face.size();++i) {
		if (face[i].size()<3) continue;
		Vector<Real_t> v1 = vertex[face[i][1]] - vertex[face[i][0]];
		Vector<Real_t> v2 = vertex[face[i][2]] - vertex[face[i][0]];
		Vector<Real_t> n = cross_product (v1,v2);
//		std::cout<<"v1: "<<v1 << " v2 :" << v2 << " v1*v2: "<< n <<std::endl;
		Real_t n_lenght = sqrt (n.x*n.x + n.y*n.y + n.z*n.z);
		n /= n_lenght;
		normal.push_back(n);
	}

	for (int i=0;i<face.size();++i) {
		std::cout<<"normal: " <<normal[i]<<std::endl;
		for (int j=0;j<face[i].size();++j) {
			std::cout<<"\t\t"<< vertex[face[i][j]]<<std::endl;
		}
	}
}

void Geometry::correct_normals () {

	for (it_edges = edges.begin(); it_edges != edges.end(); ++it_edges) {
		std::cout << it_edges->first[0] << " " << it_edges->first[1] << " " << it_edges->second[0];
		if (it_edges->second.size()==2) 
			std::cout << " " <<it_edges->second[1] <<"\n";
		else 
			std::cout << "\n";
	}
}

void Geometry::make_grid () {
	const double toll = 0; //***********//

	nx_part=ny_part=nz_part=5;

	grid.resize(nx_part);
	for (int i=0;i<nx_part;++i)
		grid[i].resize(ny_part);

	for (int i=0;i<nx_part;++i)
		for (int j=0;j<ny_part;++j)
			grid[i][j].resize(nz_part);


	dx_part = (gxhi-gxlo)/nx_part;
	dy_part = (gyhi-gylo)/ny_part;
	dz_part = (gzhi-gzlo)/nz_part;
//	std::cout << "parts: "<<dx_part << " " << dy_part << " " << dz_part << std::endl;

	for (int i=0;i<face.size();++i) {
		double fxlo = vertex[face[i][0]].x - toll, 
					 fxhi = vertex[face[i][0]].x + toll, 
					 fylo = vertex[face[i][0]].y - toll, 
					 fyhi = vertex[face[i][0]].y + toll, 
					 fzlo = vertex[face[i][0]].z - toll, 
					 fzhi = vertex[face[i][0]].z + toll;
//		std::cout<<fxlo<<" "<<fxhi<<" "<< fylo<<" "<<fyhi<<" "<< fzlo<<" "<<fzhi<<"\n";
		for (int j=1;j<face[i].size();++j) {
			if (fxlo > vertex[face[i][j]].x - toll)
				fxlo = vertex[face[i][j]].x - toll;
			if (fxhi < vertex[face[i][j]].x + toll)
				fxhi = vertex[face[i][j]].x + toll;
			if (fylo > vertex[face[i][j]].y - toll)
				fylo = vertex[face[i][j]].y - toll;
			if (fyhi < vertex[face[i][j]].y + toll)
				fyhi = vertex[face[i][j]].y + toll;
			if (fzlo > vertex[face[i][j]].z - toll)
				fzlo = vertex[face[i][j]].z - toll;
			if (fzhi < vertex[face[i][j]].z + toll)
				fzhi = vertex[face[i][j]].z + toll;
		}
		
		int xindex_lo = int((fxlo-gxlo)/dx_part);
		int xindex_hi = int((fxhi-gxlo)/dx_part);
		int yindex_lo = int((fylo-gylo)/dy_part);
		int yindex_hi = int((fyhi-gylo)/dy_part);
		int zindex_lo = int((fzlo-gzlo)/dz_part);
		int zindex_hi = int((fzhi-gzlo)/dz_part);

//		std::cout <<"xyzindex_lo_hi: " <<xindex_lo<<" "<<xindex_hi<<" "<<yindex_lo<<" "<<yindex_hi<<" "<<zindex_lo<<" "<<zindex_hi<<"\n";

		if (xindex_lo<0) xindex_lo = 0;
		if (yindex_lo<0) yindex_lo = 0;
		if (zindex_lo<0) zindex_lo = 0;

		if (xindex_hi>nx_part-1) xindex_hi = nx_part-1;
		if (yindex_hi>ny_part-1) yindex_hi = ny_part-1;
		if (zindex_hi>nz_part-1) zindex_hi = nz_part-1;


		for (int jx=xindex_lo; jx<=xindex_hi; ++jx)
			for (int jy=yindex_lo; jy<=yindex_hi; ++jy)		
				for (int jz=zindex_lo; jz<=zindex_hi; ++jz) {
//					std::cout<<"jx: " << jx << " jy: " << jy << " jz: " << jz << std::endl;
					grid[jx][jy][jz].push_back (i);
				}
	}
//-- 

//-- 

}

void Geometry::check_inside (const Vector<Real_t> &v1) {
//-- 
	int xindex = int((v1.x-gxlo)/dx_part);
	int yindex = int((v1.y-gylo)/dy_part);
	int zindex = int((v1.z-gzlo)/dz_part);

	if (xindex<0) xindex = 0;
	if (yindex<0) yindex = 0;
	if (zindex<0) zindex = 0;

	if (xindex>nx_part-1) xindex = nx_part-1;
	if (yindex>ny_part-1) yindex = ny_part-1;
	if (zindex>nz_part-1) zindex = nz_part-1;

	Vector<Real_t> force{0.0,0.0,0.0};

/*
	std::cout << grid.size() << std::endl;

	for (int i=0;i<grid.size();++i)
		std::cout << grid[i].size() << " ";

	std::cout << std::endl;

	for (int i=0;i<grid.size();++i){
		for (int j=0;j<grid.size();++j)
			std::cout << grid[i][j].size() << " ";
		std::cout << std::endl;
	}
*/
 /* 
	std::cout << std::endl;
	for (int i=0;i<grid.size();++i)
		for (int j=0;j<grid.size();++j)
			for (int k=0;k<grid.size();++k)
			std::cout << grid[i][j][k].size() << " ";

	std::cout << std::endl;
	std::cout << std::endl;
 */
	std::cout << "grid.size(): " <<  grid[xindex][yindex][zindex].size() << std::endl;

	for (auto i : grid[xindex][yindex][zindex]) 
	{
// 		/*
		Vector<Real_t> v2 {v1.x - vertex[face[i][0]].x,
		                   v1.y - vertex[face[i][0]].y,
											 v1.z - vertex[face[i][0]].z};

		Real_t v2_dot_norm = v2*normal[i];
		std::cout<<v2_dot_norm<<"\n";
//			normal[i].x*
		if (v2_dot_norm<0) {  // check whether (v2_dot_norm>0) is correct or (v2_dot_norm<0). One of them reverse the direction of outside and inside
			bool is_inside=true;
			for (int j=0; j<face[i].size(); ++j) {

				Vector<Real_t> v3;
			 	if (j==face[i].size()-1) v3 = {vertex[face[i][0]].x - vertex[face[i][j]].x,
				  									           vertex[face[i][0]].y - vertex[face[i][j]].y,
													             vertex[face[i][0]].z - vertex[face[i][j]].z};

				else 	v3 = {vertex[face[i][j+1]].x - vertex[face[i][j]].x,
				 			      vertex[face[i][j+1]].y - vertex[face[i][j]].y,
							      vertex[face[i][j+1]].z - vertex[face[i][j]].z};

				Vector<Real_t> norm_line = cross_product  (normal[i],v3);
				

 				Vector<Real_t> v4 {v1.x - vertex[face[i][j]].x,
		                   		 v1.y - vertex[face[i][j]].y,
											     v1.z - vertex[face[i][j]].z};

				Real_t v4_dot_norm_line = v4*norm_line;
				if (v4_dot_norm_line<0) { // check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). One of them is disasterous
					is_inside=false;break; // note that the polygon need to be convex for this formula to be true.
				}
			}
			if (is_inside) {

				std::cout << "inside\n";
				//force += -normal[i]*v2_dot_norm;
				//break; // use this for a faster scheme
			} else {
				std::cout << "outside\n";
			}
		}
//		*/
	}

//-- 


//-- 

}



void Geometry::read_unv (const std::string &file) {
	class Parser *parser = new Parser {md, file};
	std::cout << "info: geometry: reading a geometry unv file: "<< file << std::endl;

//   error->all (FILE_LINE_FUNC, "expected '-1' ");

	bool look_for_section = true;
	int section_code = 0;

	while(true) {

		auto token = parser->get_val_token ();
		if (token.kind==Kind::eof) break;

		if (look_for_section) {
			if (token.kind==Kind::int_number) {
				if (token.int_value==-1) {
					parser->end_of_line ();
					section_code = parser->get_literal_int ();
					parser->end_of_line ();
					look_for_section = false;
//					std::cout<<token.int_value<<std::endl;
				} else {
//					std::cout<<token.int_value<<std::endl;			
				}
			}
		}


		if (!look_for_section) {
			switch (section_code) {
				case 2411: {
					output->info("geometry: unv file: reading section 2411");
					auto val1 = parser->get_literal_int ();
					while (true) {
						while(!parser->end_of_line()) {}
						Real_t x = parser->get_literal_real ();
	 					Real_t y = parser->get_literal_real ();
	 					Real_t z = parser->get_literal_real ();
						vertex.push_back (Vector<Real_t> {x, y, z});
						parser->end_of_line ();
						val1 = parser->get_literal_int ();
//					std::cout<< x << " " << y << " " << z << std::endl;
						if (val1 == -1) break;
					}
					look_for_section = true;
					section_code = 0;
					output->info("geometry: unv file: reading section finished.");
				} break;

				case 2412: {
					output->info("geometry: unv file: reading section 2412");
					while (true) {
						auto val1 = parser->get_literal_int ();
						if (val1 == -1) break;
						val1 = parser->get_literal_int ();
						if (val1 == 11) {
							for (int i=0;i<4;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
							for (int i=0;i<3;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
							for (int i=0;i<2;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
						}
						else {
							int ngon;
							for (int i=0;i<4;++i)
								ngon = parser->get_literal_int ();
							parser->end_of_line ();		
							std::vector<int> gons;
//						std::cout<<ngon<<std::endl;
							for (int i=0;i<ngon;++i)
								gons.push_back (parser->get_literal_int ());
							face.push_back (gons);
							parser->end_of_line ();
//						for (int i=0;i<ngon;++i)
//							std::cout<<gons[i] << " ";
//						std::cout<< std::endl;
						}
					}
					look_for_section = true;
					section_code = 0;
					output->info("geometry: unv file: reading section finished.");
  			} break;

				case 0: {
				  std::cout<<"info: geometry: unv file : Section code is not found: " << section_code << std::endl;
					look_for_section = true;
					section_code = 0;
				} break;

				default: {
					std::cout<<"info: geometry: unv file: Undefined section code: " << section_code << std::endl;
					while(true) {
						while(!parser->end_of_line ()) {};
						auto t = parser->get_val_token ();
						if (t.kind==Kind::int_number)
							if (t.int_value == -1) {
								look_for_section = true;
								section_code = 0;
								break;
							}
					}
			  } break;

			}
		}

	}
	output->info("geometry: unv file: reading finished.");
	delete parser;
	
//	for (int i=0;i<vertex.size();++i) std::cout<<vertex[i]<<std::endl;
}


