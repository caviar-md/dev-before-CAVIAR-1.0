#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "pointers.h"

#include <utility> //?? Do we need this
#include <vector>
#include <map>

#include "vector.h"

class Geometry : protected Pointers {
	public:
	Geometry (class MD *);
	~Geometry ();

//	void read_text (const std::string &); // read text format
	void read_unv (const std::string &); // read unv format // IT HAS SOME BUGS
	void read_vtk (const std::string &); // read vtk format
//	void read_iges (); // read iges format
//	void read_stl (); // read stl format

	void make_grid (); // contains the faces neccesary to check
										 // make_grid has to be called after domain determination

	void lowest_highest_coord(); // calculates gxlo, gxhi, gylo...

	void make_normal (); // after reading unv file, it calculates normal vectors
	void correct_normals (); // 
	void merge_vertices (); // It checks if the two vertices are similar.Then makes a map of all vertices to the similar ones with the lower index
	void invert_normals (); // multiply all the normal Vectors with -1
	void check_inside (const Vector<Real_t> &); // different algorithms

	void pre_execute(); // call some functions and pre-calculate grids and so...

	private:
//	class Parser *parser;

	std::vector<Vector<double>> vertex;	// contains cartesian coordinates
	std::vector<std::vector<int>> vertex_map;	// made in "merge_vertices()" it's a map to the index of possible similar vertex with the lower index
//	std::vector<std::vector<std::pair<int, int>>> edge;		// contains vertex indices
	std::vector<std::vector<int>> face;	// contains vertex indices of ngons
	std::vector<Vector<double>> normal; // normal of faces (inward or outward?)
	std::vector<std::vector<int>> faces_of_vertex; // contains the face index which share one specific vectex;
//	std::vector<std::vector<int>> faces_of_edge; // contains the face index which share one specific edge;
	std::map<std::vector<int>,std::vector<int>> edges;
	std::map<std::vector<int>,std::vector<int>>::iterator it_edges;
	std::vector<std::vector<std::vector<std::vector<int>>>> grid; // contains face indices within the grid;

	double gxlo, gylo, gzlo, gxhi, gyhi, gzhi; // highest and lowest coordinates of vertices;

	double dx_part, dy_part, dz_part; // used in grid
	int nx_part, ny_part, nz_part;   // used in grid;
};

#endif
