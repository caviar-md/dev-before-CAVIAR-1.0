#ifdef DATA_READER_CLASS

DataReaderStyle(Morad,Data_reader_Morad)

#else

#ifndef DATA_READER_Morad_H
#define DATA_READER_Morad_H

#include "pointers.h"

#include <random>
#include <vector>
#include <map>
#include <string>

#include "vector.h"

class Data_reader_Morad : protected Pointers {
public:
  Data_reader_Morad (class MD *, const std::string &);
  ~Data_reader_Morad ();
  
  bool read ();
private:
	bool execute ();

	const static std::map<std::string,CommandFunc> commands_map;

	void read_random_generator ();
	void read_simulation_box ();
	void read_position ();
	void read_velocity ();
	void read_mass ();
	void read_overlap_radius ();
	void read_charge ();
	void read_type_of_index ();
	void read_sub_lattice ();
	void read_no_overlap ();
	void read_constant ();
	void read_make_output ();
	void read_geometry_check ();
	void read_list_priority ();
	void read_grid ();
	void read_list_values ();
	void read_random ();
	void read_add_atom ();


	std::string give_data_structure_type (std::map<int,std::string> &ppxyz, const int atom_type, int &data_type);
	int give_data_structure_length (std::string data_name, const int data_type);
	Real_t make_value (std::string data_name, const int data_type, const int i_n);
	
	bool calculate_list_priority ();
	bool calculate_positions ();
	bool add_atom (int, Real_t, Real_t, Real_t, Real_t, Real_t, Real_t); 

	bool contact_check (int, Real_t, Real_t, Real_t, Real_t);// index, radius, x, y, z
	bool geometry_check;	
  bool verify_and_set_header ();
	bool assign_to_atom_data ();
  
	bool make_output ();
  class Parser *parser;
	class Output *output;
//	std::string filename;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;

	Real_t xlo, xhi, ylo, yhi, zlo, zhi;


	std::map <int,Real_t> map_charge, map_mass; // charge and mass of atom_type
	int atom_type_max;
	std::map <int,Real_t> map_overlap_radius; // radius of atom_index

	std::vector <std::vector<int>> no_overlap;

	std::map <std::string,std::pair<int,std::pair<int,int>>> map_rnd_gen; // first one is the name, second.first:(index of generator)   second.second.first:(type of distribution)   second.second.second:(index of distribution)
	std::vector <std::mt19937> rnd_gen; // rnd_maps.second.first = index of this
	std::vector <std::uniform_real_distribution<>> rnd_dist_uniform; 	// rnd_maps.second.second.first == 1 and sec.sec.sec = index
	std::vector <std::normal_distribution<>> rnd_dist_normal; 				// rnd_maps.second.second.first == 2 and sec.sec.sec = index


	std::vector <int> all_types;

	std::map <int,std::string> ppx,ppy,ppz; // <atom_index,<type_of_generator,index_of_generator>>  type_of_generator:0,1,2,3;v
	std::map <int,std::string> pvx,pvy,pvz; // <atom_index,<type_of_generator,index_of_generator>>  type_of_generator:0,1,2,3;v

	std::map <std::string,Real_t> map_constants;

	std::vector<std::vector<Real_t>> list_values; // contains list of real numbers
	std::map <std::string,int> map_list_values; // the second contains the index of "lists"

	std::vector<std::pair<Real_t,Real_t>> grid_min_max;
	std::vector<int> grid_partitions;
	std::map <std::string,int> map_grid; // the second contains the index of "lists"

	std::map <std::string,std::pair<std::string,int>> map_random; // f:name.  s.f:name of rnd_maps  s:s: num of values

	std::map <std::string,int> var_names_index; // contains all the variables and its index. 4:rnd_gens 3:list_random  2:list_grid  1:list_values  0:list_const

	std::vector<int> list_priority; // the list 

	std::map <int,int> map_type_of_index; // atom_type to atom_index
	std::map <int,int> map_tag_of_index; // not working yet

	std::map <int,std::string> map_sub_lattice; // if doesn't exist, the atom will be created in the center. if "fcc" fcc will be created/ if "bcc" bcc will be created.

	std::vector<int> add_atom_index; //
	std::vector<Vector<Real_t>> add_atom_pos, add_atom_vel; // used in 

	bool make_output_index, make_output_index_all;
	bool make_output_type, make_output_type_all;
	std::vector<int> make_output_index_list;
	std::vector<int> make_output_type_list;

	//   NAME CONFLICT check maybe by set

//	variables: 	charge, mass
//							overlap_radius 
//  						constants_map
//  						list_values, list_values_map
//  						list_radom, list_random_map
//
//
};

#endif
#endif
