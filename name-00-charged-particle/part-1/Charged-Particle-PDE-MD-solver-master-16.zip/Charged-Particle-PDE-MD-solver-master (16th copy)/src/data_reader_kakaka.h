#ifdef DATA_READER_CLASS

DataReaderStyle(Kakaka,Data_reader_Kakaka)

#else

#ifndef DATA_READER_Kakaka_H
#define DATA_READER_Kakaka_H

#include "pointers.h"

#include <random>
#include <vector>
#include <map>
#include <string>

#include "vector.h"

inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

class Type_Definition {
	public:
	Type_definition();
	int type;
	Real_t mass, radius, charge;
};

class Atom {
	public:
	Atom();
	Vector<Real_t> p; // position
	Real_t type;
};

class Molecule {
	public:
	Molecule();
	vector <Atom> a; 
	vector<Vector<Real_t>> p; // position of atoms with respect to molecule centre
	Vector<Real_t> p; // position of the molecule
};

class Boundary {
	public:
	Boundary ();

};

class Shape_Closed_2D_Line_in_3D {
public:
	Shape_Closed_2D_Line_in_3D ();	
	vector<Vector<Real_t>> p_3D; // vertex points of the shape in 3D space
	Vector<Real_t> n_vector, u_vector, v_vector; //  basis vectors of the plane: normal and (u,v)
	vector<Real_t> u_list, v_list; // array containing u and v coordinates of the vertices in the plane
	Real_t mat_inv[3][3]; // inverse of the transformation matrix;
	void make_basis_vectors() {
		if (p_3D.size() > 1) {
			Vector<Real_t> vec1 = p_3D[1] - p_3D[0];
			Vector<Real_t> vec2 = p_3D[2] - p_3D[0];
			vector<vector<Real_t>> mat_inv;
			n_vector = cross_product (vec1, vec2);
			u_vector = vec1;
			v_vector = cross_product (n_vector, u_vector);
			normalize(u_vector);
			normalize(v_vector);
			normalize(n_vector);
		}
	}
	void make_uv_vectors() {
		for (int i = 0; i<p_3D.size(); ++i) {
			Vector<Real_t> dp = p_3D[i] - p_3D[0];
			Real_t u_i = u_vector * dp;
			Real_t v_i = v_vector * dp;
			u_list.push_back (u_i);
			v_list.push_back (v_i);
		}
	}
	void make_transform_matrix() {
		Real_t m[3][3];
		m[0][0] = u_vector.x;	m[0][1] = u_vector.y;	m[0][2] = u_vector.z;
		m[1][0] = v_vector.x;	m[1][1] = v_vector.y;	m[1][2] = v_vector.z;
		m[2][0] = n_vector.x;	m[2][1] = n_vector.y;	m[2][2] = n_vector.z;

		Real_t det =  m[0][0] * (m[1][1] * m[2][2] - m[2][1] * m[1][2]) -
			            m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
	              	m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);

		Real_t invdet = 1. / det;

		mat_inv[0][0] = (m[1][1] * m[2][2] - m[2][1] * m[1][2]) * invdet;
		mat_inv[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * invdet;
		mat_inv[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * invdet;
		mat_inv[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * invdet;
		mat_inv[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * invdet;
		mat_inv[1][2] = (m[1][0] * m[0][2] - m[0][0] * m[1][2]) * invdet;
		mat_inv[2][0] = (m[1][0] * m[2][1] - m[2][0] * m[1][1]) * invdet;
		mat_inv[2][1] = (m[2][0] * m[0][1] - m[0][0] * m[2][1]) * invdet;
		mat_inv[2][2] = (m[0][0] * m[1][1] - m[1][0] * m[0][1]) * invdet;
	}
	void uv_to_xyz (Real_t u_i, Real_t v_i, Vector<Real_t> &p_i) {
		Real_t p_i.x = mat_inv[0][0]*u_i + mat_inv[0][1]*v_i + p_3D[0].x;
		Real_t p_i.y = mat_inv[1][0]*u_i + mat_inv[1][1]*v_i + p_3D[0].y;
		Real_t p_i.z = mat_inv[2][0]*u_i + mat_inv[2][1]*v_i + p_3D[0].z;
	}
	void xyz_to_uv (const Vector<Real_t> &p_i, Real_t &u_i, Real_t &v_i) {
		Vector<Real_t> dp = p_i - p_3D[0];
		u_i = u_vector * dp;
		v_i = v_vector * dp;
	}

	bool is_inside (double u_i, double v_i) // using Jordan curve theorem,
			// checks whether the point is inside the curve or not;
			// it has a bug when (v_list[i] == v_list[j])
	{
		bool c = false;
		int nvert = p_3D.size();
  	for (int i = 0, int j = nvert-1; i < nvert; j = i++) {
			if ( ((v_list[i]>v_i) != (v_list[j]>v_i)) &&
	      		(u_i < (u_list[j]-u_list[i]) * (v_i-v_list[i]) / (v_list[j]-v_list[i]) + u_list[i]) )
	      c = !c;
  	}
  	return c;
	}
	

}



class Lattice {
	public:
	Lattice ();
};

class Random {
	public:
	Random ();
};

class Data_reader_Kakaka : protected Pointers {
public:
  Data_reader_Kakaka (class MD *, const std::string &);
  ~Data_reader_Kakaka ();

	bool read ();
private:
	bool execute ();
	
	
	bool calculate_list_priority ();
	bool calculate_positions ();
	bool add_atom (int, Real_t, Real_t, Real_t, Real_t, Real_t, Real_t); 

	bool contact_check (int, Real_t, Real_t, Real_t, Real_t);// index, radius, x, y, z
	bool geometry_check;	
  bool verify_and_set_header ();
	bool assign_to_atom_data ();
  
	bool make_output ();
  class Parser *parser;
	class Output *output;
//	std::string filename;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;

	Real_t xlo, xhi, ylo, yhi, zlo, zhi;


};

#endif
#endif
 
