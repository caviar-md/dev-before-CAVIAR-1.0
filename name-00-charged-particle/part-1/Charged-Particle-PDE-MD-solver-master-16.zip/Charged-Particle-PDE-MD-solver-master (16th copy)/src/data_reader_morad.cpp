#include "data_reader_morad.h"

//#include <set>
#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"

Data_reader_Morad::Data_reader_Morad (MD *md, const std::string &file) : Pointers{md}, parser{new Parser{md, file}}, num_total_atoms{0}, num_atom_types{0}, atom_type_max{0}, xlo{-.5}, xhi{.5}, ylo{-.5}, yhi{.5}, zlo{-.5}, zhi{.5},geometry_check{false}, output{md->output} {}

Data_reader_Morad::~Data_reader_Morad () {
  delete parser;
}




const std::map<std::string,CommandFunc> Data_reader_Morad::commands_map = {
 	{"random_generator", &Data_reader_Morad::read_random_generator},
 	{"simulation_box", &Data_reader_Morad::read_simulation_box},
 	{"position", &Data_reader_Morad::read_position},
 	{"velocity", &Data_reader_Morad::read_velocity},
	{"mass", &Data_reader_Morad::read_mass},
 	{"radius", &Data_reader_Morad::read_overlap_radius},
 	{"charge", &Data_reader_Morad::read_charge},
 	{"type_of_index", &Data_reader_Morad::read_type_of_index},
 	{"sub_lattice", &Data_reader_Morad::read_sub_lattice},
 	{"no_overlap", &Data_reader_Morad::read_no_overlap},
 	{"constant", &Data_reader_Morad::read_constant},
 	{"make_output", &Data_reader_Morad::read_make_output},
 	{"geometry_check", &Data_reader_Morad::read_geometry_check},
 	{"list_priority", &Data_reader_Morad::read_list_priority},
 	{"grid", &Data_reader_Morad::read_grid},
 	{"list_values", &Data_reader_Morad::read_list_values},
 	{"random", &Data_reader_Morad::read_random},
 	{"add_atom", &Data_reader_Morad::read_add_atom}
};

bool Data_reader_Morad::read () {
  bool in_file = true;
  while (in_file) {
    auto token = parser->get_val_token();
    switch (token.kind) {
      case Kind::eof: {
				in_file = false;
				output->info ("data reader Morad: reading file finished.");
				
			}	break;
      
      case Kind::eol:
        continue;
      
      case Kind::identifier: {
  			if (commands_map.count (command) == 0) error->all (FILE_LINE_FUNC, "Invalid command");
  			*commands_map.at(command) ();
				/*
				if (token.string_value == "random_generator") { 

				} else if (token.string_value == "simulation_box") { 

				} else if (token.string_value == "position") { 

				} else if (token.string_value == "velocity") {  

				} else if (token.string_value == "mass") {  

				} else if (token.string_value == "overlap_radius") {  

				} else if (token.string_value == "charge") { 

				} else if (token.string_value == "type_of_index") {  

				} else if (token.string_value == "sub_lattice") {  

				} else if (token.string_value == "no_overlap")  {  

				} else if (token.string_value == "constant") { 

				} else if (token.string_value == "list_values") {  

				} else if (token.string_value == "random") {  

				} else if (token.string_value == "grid") {  

				} else if (token.string_value == "list_priority") {  

				} else if (token.string_value == "geometry_check") { 

				} else if (token.string_value == "make_output") { 

				} else if (token.string_value == "add_atom") {  

				} else {
        	error->all (FILE_LINE_FUNC, "Invalid syntax. Unknown identifier.");
				} */
			}
		}
	}
	execute ();
}

void Data_reader_Morad::read_random_generator () {
					auto t1 = parser->get_val_token (); // random generator name
					int randseed = 1;
					int dist_type = 1;
					Real_t dist_uniform_min = -1.0, dist_uniform_max = 1.0; // used in uniform
					Real_t dist_normal_std = 1.0, dist_normal_mean = 0.0;
					while(true) {
						auto t2 = parser->get_val_token ();
						if (t2.kind == Kind::eol) {
							break;
						} else if (t2.string_value == "seed") {
							randseed = parser->get_literal_int ();
						} else if (t2.string_value == "uniform") {
							dist_type = 1;
						} else if (t2.string_value == "normal") {
							dist_type = 2;
						} else if (t2.string_value == "std") {
							dist_normal_std = parser->get_literal_real ();
						} else if (t2.string_value == "mean") {
							dist_normal_mean = parser->get_literal_real ();
						} else if (t2.string_value == "min_max") {
							dist_uniform_min = parser->get_literal_real ();
							dist_uniform_max = parser->get_literal_real ();
						}
					}

					std::mt19937 current_rand_gen (randseed);
					rnd_gen.push_back (current_rand_gen);
					if (dist_type == 1) {
						std::uniform_real_distribution<> dist (dist_uniform_min, dist_uniform_max);
						rnd_dist_uniform.push_back (dist);
						map_rnd_gen.insert (std::make_pair (t1.string_value, std::make_pair (rnd_gen.size()-1, std::make_pair (dist_type, rnd_dist_uniform.size()-1))));
					} else if (dist_type == 2) {
						std::normal_distribution<> dist (dist_normal_mean, dist_normal_std); // ************ check this
//						std::cout << dist.min() << " " << dist.max() << " " << dist.mean() << " " << dist.stddev() << "\n";
						rnd_dist_normal.push_back (dist);
						map_rnd_gen.insert (std::make_pair (t1.string_value, std::make_pair (rnd_gen.size()-1, std::make_pair (dist_type, rnd_dist_normal.size()-1))));
					}
					var_names_index.insert (std::make_pair(t1.string_value,4));

}

void Data_reader_Morad::read_simulation_box () {
					auto t1 = parser->get_val_token ();
					if (t1.string_value == "x") {
						xlo = parser->get_literal_real ();
						xhi = parser->get_literal_real ();
					} else if (t1.string_value == "y") {
						ylo = parser->get_literal_real ();
						yhi = parser->get_literal_real ();
					} else if (t1.string_value == "z") {
						zlo = parser->get_literal_real ();
						zhi = parser->get_literal_real ();
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");


}

void Data_reader_Morad::read_position () {
					auto type = parser->get_literal_int (); // particle type
					auto t2 = parser->get_val_token (); // "x" or "y" or "z"
					auto t3 = parser->get_val_token (); // list_names

					if (t2.string_value == "x") {
						ppx.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "y") {
						ppy.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "z") {
						ppz.insert (std::make_pair (type, t3.string_value));
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");


}

void Data_reader_Morad::read_velocity () {
					auto type = parser->get_literal_int (); // particle type
					auto t2 = parser->get_val_token (); // "x" or "y" or "z"
					auto t3 = parser->get_val_token (); // list_names

					if (t2.string_value == "x") {
						pvx.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "y") {
						pvy.insert (std::make_pair (type, t3.string_value));
					} else if (t2.string_value == "z") {
						pvz.insert (std::make_pair (type, t3.string_value));
					} else {
        		error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'x', 'y' or 'z'.");
					}
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_mass () {
					auto type1 = parser->get_literal_int (); // atom_type
					if (atom_type_max<type1) atom_type_max = type1;
					auto val1 = parser->get_literal_real (); // mass
					map_mass.insert (std::make_pair (type1,val1));
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_overlap_radius () {
					auto type1 = parser->get_literal_int ();	// atom_index
					auto val1 = parser->get_literal_real (); // radius
					map_overlap_radius.insert (std::make_pair (type1,val1));
					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_charge () {
					auto type1 = parser->get_literal_int (); // atom_type
					if (atom_type_max<type1) atom_type_max = type1;
					auto val1 = parser->get_literal_real (); // charge
					map_charge.insert (std::make_pair (type1,val1));
					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_type_of_index () {
					auto index1 = parser->get_literal_int (); // atom_index
					auto type1 = parser->get_literal_int (); // atom_type
					if (atom_type_max<type1) atom_type_max = type1;
					map_type_of_index.insert (std::make_pair (index1, type1));
					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_sub_lattice () {
					auto index1 = parser->get_literal_int (); // atom_index
					auto subtype1 = parser->get_val_token(); // sub_lattice_type
					map_sub_lattice.insert(make_pair(index1,subtype1.string_value));

					if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_no_overlap () {
					std::vector<int> val1;
					while (true) {
						auto t1 = parser->get_val_token ();
						if (t1.kind == Kind::int_number) {
							val1.push_back (t1.int_value);
						} else if (t1.kind == Kind::eol || t1.kind == Kind::eof) {
							if (val1.size() == 0)
								error->all (FILE_LINE_FUNC, "Invalid syntax. Expected integer values.");
							break;
						} else {
							if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected integer values.");
						}
					}


}


void Data_reader_Morad::read_make_output () {
						auto t1 = parser->get_val_token ();
						if (t1.string_value == "index") {
							make_output_index = true;
							while (true) {
								auto t2 = parser->get_val_token ();
								if (t2.kind == Kind::identifier) {
									if (t2.string_value == "all") {
										make_output_index_all = true;
					  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
										break;
									}
								} else	if (t2.kind == Kind::int_number) {
									make_output_index_list.push_back (t2.int_value);
								} else if (t2.kind == Kind::eol) {
									break;
								}
							}
						} else if (t1.string_value == "type" ) {
							make_output_type = true;
							while (true) {
								auto t2 = parser->get_val_token ();
								if (t2.kind == Kind::identifier) {
									if (t2.string_value == "all") {
										make_output_type_all = true;
					  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
										break;
									}
								} else	if (t2.kind == Kind::int_number) {
									make_output_type_list.push_back (t2.int_value);
								} else if (t2.kind == Kind::eol) {
									break;
								}
							}
						} else {
  						if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected 'type' or 'index'.");
						}

}

void Data_reader_Morad::read_geometry_check () {
					geometry_check = true;
}

void Data_reader_Morad::read_list_priority () {

					while (true) {
						auto t1 = parser->get_val_token ();
						if (t1.kind == Kind::eol) {
							break;
						} else {
							list_priority.push_back (t1.int_value);
						}
					}


}

void Data_reader_Morad::read_grid () {
					auto t1 = parser->get_val_token (); // name of grid
					auto val1 = parser->get_literal_real (); // length of the list
					auto val2 = parser->get_literal_real (); // length of the list
					auto val3 = parser->get_literal_int (); // length of the list
					Real_t val_cor = 0 ;//= (val2 - val1)/val3;
					grid_min_max.push_back(std::make_pair(val1, val2 + val_cor));
					grid_partitions.push_back (val3);
					map_grid.insert (std::make_pair(t1.string_value,grid_partitions.size()-1));
					var_names_index.insert (std::make_pair(t1.string_value,2));	
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_list_values () {
					auto t1 = parser->get_val_token ();
					std::vector <Real_t> vals;
					while (true) {
						auto t2 = parser->get_val_token ();
						if (t2.kind == Kind::eol) {
							break;
						} else {
							vals.push_back (t2.real_value);
						}
					}
					list_values.push_back (vals);
					map_list_values.insert (std::make_pair(t1.string_value, list_values.size()-1));
					var_names_index.insert (std::make_pair(t1.string_value, 1));				


}

void Data_reader_Morad::read_constant () {
					auto t1 = parser->get_val_token (); // name of constant
					auto val1 = parser->get_literal_real (); // value of constant
					map_constants.insert (std::make_pair (t1.string_value, val1));
					var_names_index.insert (std::make_pair(t1.string_value,0));				
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_random () {
					auto t1 = parser->get_val_token (); // name of list
					auto t2 = parser->get_val_token (); // name of random generator
					auto val1 = parser->get_literal_int (); // length of the list
					map_random.insert (std::make_pair(t1.string_value, std::make_pair(t2.string_value, val1) ));
					var_names_index.insert (std::make_pair(t1.string_value,3));
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");

}

void Data_reader_Morad::read_add_atom () {
					auto val_type = parser->get_literal_int ();
					auto val_x = parser->get_literal_int ();
					auto val_y = parser->get_literal_int ();
					auto val_z = parser->get_literal_int ();
					auto val_vx = parser->get_literal_int ();
					auto val_vy = parser->get_literal_int ();
					auto val_vz = parser->get_literal_int ();
					add_atom (val_type, val_x, val_y, val_z, val_vx, val_vy, val_vz);
  				if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
}




bool Data_reader_Morad::execute () {
	calculate_list_priority ();
	calculate_positions ();
	verify_and_set_header ();
	make_output ();
	assign_to_atom_data ();
}


std::string Data_reader_Morad::give_data_structure_type (std::map<int,std::string> &ppxyz, const int atom_index, int &data_type) {

	std::map <int,std::string>::iterator it_pp; // <atom type, data structure name>         ppx, ppy, ppz
	std::map <std::string,int> ::iterator it_vnt; // <data structure name, data structure type>      var_names_index
	it_pp = ppxyz.find (atom_index);
	if (it_pp == ppxyz.end()) {
		error->all (FILE_LINE_FUNC, "data reader Morad: Undefined atom type.");
	} else {
		it_vnt = var_names_index.find (it_pp->second);
		if (it_vnt == var_names_index.end() ) {
			error->all (FILE_LINE_FUNC, "data reader Morad: Undefined data structure name.");
		} else {
			data_type = it_vnt->second; // data structure type
			return it_pp->second;  // data structure name
		}
	}
}

int Data_reader_Morad::give_data_structure_length (std::string data_name, const int data_type) {
	switch (data_type) {
		case 0: 
		return 1;						
		
		
		case 1: {
			std::map <std::string,int>::iterator it;
			it = map_list_values.find (data_name);
			if (it == map_list_values.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				int list_values_index = it->second;
				return list_values [list_values_index].size();
			}
		}
		
		case 2: {
			std::map <std::string,int>::iterator it;
			it = map_grid.find (data_name);
			if (it == map_grid.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return grid_partitions[it->second];
			}
		}


		case 3:{
			std::map <std::string,std::pair<std::string,int>>::iterator it; // map_random; // f:name.  s.f:name of rnd_maps  s:s: num of values
			it = map_random.find (data_name);
			if (it == map_random.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return it->second.second;// data length
			}
		}
	}
}

Real_t Data_reader_Morad::make_value (std::string data_name, const int data_type, const int i_n) {
	switch (data_type) {
		case 0: {
			std::map <std::string,Real_t>::iterator it;
			it = map_constants.find (data_name);
			if (it == map_constants.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return it->second;
			}
		}
		
		case 1: {
			std::map <std::string,int>::iterator it;
			it = map_list_values.find (data_name);
			if (it == map_list_values.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				return list_values [it->second][i_n];
			}
		}
		
		case 2: {
			std::map <std::string,int>::iterator it;
			it = map_grid.find (data_name);
			if (it == map_grid.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				int gp = grid_partitions[it->second];
				Real_t min = grid_min_max[it->second].first;
				Real_t max = grid_min_max[it->second].second;
				return min + i_n*(max - min)/gp; //**** check this
			}
		}


		case 3:{
			std::map <std::string,std::pair<std::string,int>>::iterator it; // map_random; // f:name.  s.f:name of rnd_maps  s:s: num of values
			it = map_random.find (data_name);
			if (it == map_random.end() ) {
				error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
			} else {
				std::map <std::string,std::pair<int,std::pair<int,int>>>::iterator it2;// map_rnd; // first one is the name, second.first:(index of generator)   second.second.first:(type of distribution)   second.second.second:(index of distribution)
				it2 = map_rnd_gen.find (it->second.first);
				if (it2 == map_rnd_gen.end() ) {
					error->all (FILE_LINE_FUNC, "data reader Morad: Undefined variable name.");
				} else {
					int dist_type = it2->second.second.first;//.first;
					if (dist_type == 1) {
						return rnd_dist_uniform[it2->second.second.second](rnd_gen[it2->second.first]);
					} else if (dist_type == 2){
						return rnd_dist_normal[it2->second.second.second](rnd_gen[it2->second.first]);
					}
				}
			}
		}
	}
}


bool Data_reader_Morad::calculate_positions () {
		
	for (auto atom_index : list_priority) {
		int data_type_x, data_type_y, data_type_z;
		int data_type_vx, data_type_vy, data_type_vz;

		std::map<int,Real_t>::iterator it_r; // used in geometry
		it_r = map_overlap_radius.find (atom_index);

		std::string data_name_x = give_data_structure_type ( ppx, atom_index, data_type_x );
		std::string data_name_y = give_data_structure_type ( ppy, atom_index, data_type_y );
		std::string data_name_z = give_data_structure_type ( ppz, atom_index, data_type_z );

		std::string data_name_vx = give_data_structure_type ( pvx, atom_index, data_type_vx );
		std::string data_name_vy = give_data_structure_type ( pvy, atom_index, data_type_vy );
		std::string data_name_vz = give_data_structure_type ( pvz, atom_index, data_type_vz );

		int data_length_x = give_data_structure_length (data_name_x, data_type_x);
		int data_length_y = give_data_structure_length (data_name_y, data_type_y);
		int data_length_z = give_data_structure_length (data_name_z, data_type_z);

		std::map<int,std::string>::iterator it_sl;
		it_sl = map_sub_lattice.find (atom_index);

		int ix = 0 ,iy = 0 ,iz = 0;
		int ix_f = data_length_x , iy_f = data_length_y, iz_f = data_length_z;
		int tot_atoms = ix_f * iy_f * iz_f;
		int num_atoms = 0, n_contacts = 0;
		int n_contacts_limit = 1000; // a limit of tries to make contactless particles in random generating
//		std::cout << "ix_f: " << ix_f << " iy_f: " << iy_f << " iz_f: " << iz_f <<"\n";


		while (n_contacts < n_contacts_limit) {

				Real_t x = make_value (data_name_x, data_type_x, ix);
				Real_t y = make_value (data_name_y, data_type_y, iy);
				Real_t z = make_value (data_name_z, data_type_z, iz);
				if (it_sl == map_sub_lattice.end() ) {
					if (contact_check (atom_index, it_r->second, x, y, z)) { ++n_contacts; continue;}
					if (geometry_check) 
						if (md->geometry->check_inside (Vector<Real_t>{x,y,z}, it_r->second)) { ++n_contacts; continue;}

					Real_t vx = make_value (data_name_vx, data_type_vx, ix);
					Real_t vy = make_value (data_name_vy, data_type_vy, iy);
					Real_t vz = make_value (data_name_vz, data_type_vz, iz);

					add_atom (atom_index, x, y, z, vx, vy, vz);

					++num_atoms;
				} else if (it_sl->second == "fcc") {

				} else if (it_sl->second == "bcc") {
//					Real_t x2 = x +

				} else {
       		error->all (FILE_LINE_FUNC, "Unknown sub_lattice type.");				
				}


				++ix;
				if (ix == ix_f) { ix = 0; ++iy;}
				if (iy == iy_f) { iy = 0; ++iz;}
				if (iz == iz_f) { break;}
//				std::cout << " ixiyiz " <<ix << " " << iy << " " << iz << "\n";
		}
		std::cout << "info: data reader Morad: " << num_atoms << " atoms of index " << atom_index << " is made. requested " << tot_atoms <<" atoms.\n";
	}
}

bool Data_reader_Morad::calculate_list_priority () {

}

bool Data_reader_Morad::add_atom (int atom_index, Real_t x, Real_t y, Real_t z, Real_t vx, Real_t vy, Real_t vz) {
//	std::cout << atom_index << " \t" << x << " \t" << y << " \t" << z << " \t" << vx << " \t" << vy << " \t" << vz << " \n";
	add_atom_index.push_back (atom_index);
	add_atom_pos.push_back (Vector<Real_t> {x,y,z});
	add_atom_vel.push_back (Vector<Real_t> {vx,vy,vz});
}

bool Data_reader_Morad::contact_check (int atom_index, Real_t rad1, Real_t x, Real_t y, Real_t z) {
	std::map<int,Real_t>::iterator it_r2;
//	it_r1 = map_overlap_radius.find (atom_index);
	for (int i=0;i<add_atom_index.size(); ++i) {
		it_r2 = map_overlap_radius.find (add_atom_index[i]);
		Real_t dis2 = (x-add_atom_pos[i].x)*(x-add_atom_pos[i].x)
			          + (y-add_atom_pos[i].y)*(y-add_atom_pos[i].y) 
								+ (z-add_atom_pos[i].z)*(z-add_atom_pos[i].z);
		Real_t rad2 = (rad1 + it_r2->second)*(rad1 + it_r2->second);

		if (dis2<rad2) return true;
	}
	return false;
}


bool Data_reader_Morad::verify_and_set_header () {
  domain->x_lower_global = xlo;
  domain->x_upper_global = xhi;
  domain->y_lower_global = ylo;
  domain->y_upper_global = yhi;
  domain->z_lower_global = zlo;
  domain->z_upper_global = zhi;

	comm->calculate_procs_grid ();

	domain->calculate_local_domain ();
}

bool Data_reader_Morad::assign_to_atom_data () {
	num_total_atoms = add_atom_index.size();
	num_atom_types = atom_type_max+1; // +1 is added for type 0
	std::cout << "atom_type_max "<< atom_type_max << "\n";
	atom_data->set_num_atom_types (num_atom_types);
  atom_data->set_num_total_atoms (num_total_atoms);

	std::map<int,int>::iterator it_type;
	for (int i=0;i<add_atom_index.size();++i) {
		int id = 0;
		it_type = map_type_of_index.find (add_atom_index[i]);
	 	int atom_type = it_type->second;	
	 	Real_t charge_atom = 0.0;	
		atom_data->add_atom (id, atom_type, charge_atom, add_atom_pos[i], add_atom_vel[i]);
	}

	std::map<int,Real_t>::iterator it; // assign mass
	for (int i=0; i<=atom_type_max;++i) {
		it = map_mass.find (i);
		if (it == map_mass.end()) {
			std::cout << "warning: data reader Morad: mass type " << i << " is not defined but called. Value 1.0 is used.\n";
			atom_data->add_masses (i, 1.0);
		} else {
			atom_data->add_masses (i, it->second);
		}
	}

//	std::map<int,int>::iterator it; // assign charge
	for (int i=0; i<=atom_type_max;++i) {
		it = map_charge.find (i);
		if (it == map_charge.end()) {
			std::cout << "warning: data reader Morad: charge type " << i << " is not defined but called. Value 0.0 is used.\n";
			atom_data->add_charges (i, 0.0);
		} else {
			atom_data->add_charges (i, it->second);
		}
	}

}

bool Data_reader_Morad::make_output () {
	if (make_output_index) {
		std::ofstream file_out;
		file_out.open ("o_xyz_init_index.xyz");

		int make_output_no_index = 0;
		if (make_output_index_all) {
			make_output_no_index = add_atom_index.size();
		}
		else {
			for (auto i : make_output_index_list) {
				for (auto j : add_atom_index) {
					if (i==j) ++make_output_no_index;
				}
			}
		}
		file_out << make_output_no_index << "\nAtom\n";
		if (make_output_index_all) {
			for (int j=0; j<add_atom_index.size(); ++j) {
				file_out << add_atom_index[j] <<  " " << add_atom_pos[j].x << " " <<  add_atom_pos[j].y << " " << add_atom_pos[j].z << "\n";
			}
		}
		else {
			for (auto i : make_output_index_list) {
				for (int j=0; j<add_atom_index.size(); ++j) {
					if (i == add_atom_index[j]) 
						file_out << i <<  " " << add_atom_pos[j].x << " " <<  add_atom_pos[j].y << " " << add_atom_pos[j].z << "\n";
				}
			}
		}
	

		file_out.close ();
	}

	if (make_output_type) {
		std::ofstream file_out;
		file_out.open ("o_xyz_init_type.xyz");
		int make_output_no_type = 0;

		if (make_output_type_all) {
			make_output_no_type = add_atom_index.size();
		}
		else {
			for (auto i : make_output_type_list) {
				for (auto j : add_atom_index) {
					if (i==j) ++make_output_no_type;
				}
			}
		}
		file_out << make_output_no_type << "\nAtom\n";
		std::map<int,int>::iterator it;
		if (make_output_type_all) {
			for (int j=0; j<add_atom_index.size(); ++j) {
				it = map_type_of_index.find (add_atom_index[j]);
				file_out << it->second <<  " " << add_atom_pos[j].x << " " <<  add_atom_pos[j].y << " " << add_atom_pos[j].z << "\n";
			}
		}
		else {
			for (auto i : make_output_type_list) {
				for (int j=0; j<add_atom_index.size(); ++j) {
					if (i == add_atom_index[j]) 
						file_out << i <<  " " << add_atom_pos[j].x << " " <<  add_atom_pos[j].y << " " << add_atom_pos[j].z << "\n";
				}
			}
		}

		file_out.close ();
	}



}
