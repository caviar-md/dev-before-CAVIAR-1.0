#include "force_field_lj.h"

#include <cmath>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"

Force_field_lj::Force_field_lj (MD *md, Parser *parser) : Force_field {md, parser},
epsilon (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
sigma (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) {
  cutoff = parser->get_literal_real ();
	if (cutoff < 0.0)
    error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");
	output->info ("A Lennard-Jones force field is made.");
	kinetic_energy=0.0; potential_energy=0.0;
}

bool Force_field_lj::set_parameters (Parser *parser) {
  int type_i = parser->get_literal_int ();
  
  if (type_i < 0 || type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be non-negative and smaller than number of the atom types.");
  
  int type_j = parser->get_literal_int ();
  if (type_j < 0 || type_j > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be non-negative and smaller than number of the atom types.");


  Real_t eps_ij = parser->get_literal_real ();
  if (eps_ij < 0)
  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");
  epsilon [type_i][type_j] = epsilon [type_j][type_i] = eps_ij;
  
  Real_t sigma_ij = parser->get_literal_real ();
  if (sigma_ij <= 0)
  error->all (FILE_LINE_FUNC, "Sigma have to be larger than 0 .");
  sigma [type_i][type_j] = sigma [type_j][type_i] = sigma_ij;
	output->info ("Force field parameter set.");
}

void Force_field_lj::calculate_acceleration () {
	potential_energy = 0.0;
	auto cutoff_sq = cutoff * cutoff;
  const auto &neighbor_list = neighbor -> neighlist;
  for (auto i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
  	const auto type_i = atom_data -> owned.type [i];
    const auto mass_i = atom_data -> owned.mass [ type_i ];
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j;
			Real_t type_j, mass_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
      	pos_j = atom_data->ghost.position [j];
      	type_j = atom_data->ghost.type [j];
			} else {
      	pos_j = atom_data->owned.position [j];
      	type_j = atom_data->owned.type [j];
			}
      mass_j = atom_data->owned.mass [ type_j ];
		
      auto dr = pos_j - pos_i; 
      auto r_sq = dr*dr;
      if (r_sq > cutoff_sq) continue;
      const auto eps_ij = epsilon [type_i] [type_j];
      const auto sigma_ij =  sigma [type_i] [type_j];
//      auto rho_c_inv = sigma_ij / cutoff;
//      auto rho_c_6_inv = ipow (rho_c_inv, 6);
//      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
//      auto rho_c_18_inv = rho_c_12_inv*rho_c_6_inv;
      auto r_c_sq_inv = 1/(cutoff*cutoff);
      auto rho_c_sq_inv = sigma_ij*sigma_ij*r_c_sq_inv;
      auto rho_c_6_inv = rho_c_sq_inv*rho_c_sq_inv*rho_c_sq_inv;
      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
      auto r_sq_inv = 1/r_sq;
      auto rho_sq_inv = sigma_ij*sigma_ij*r_sq_inv;
      auto rho_6_inv = rho_sq_inv*rho_sq_inv*rho_sq_inv;
      auto rho_12_inv = rho_6_inv*rho_6_inv;
//      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + (2*rho_c_18_inv - rho_c_12_inv) * r_sq*r_sq/ipow (sigma_ij, 6) ) * dr;
      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + 
														 +12*rho_c_12_inv*r_c_sq_inv - 6*rho_c_6_inv*r_c_sq_inv 	) * dr;
			auto dr_norm = std::sqrt(r_sq);
			auto r_m_rc = dr_norm-cutoff;
			potential_energy += 4*eps_ij*(+rho_12_inv - rho_6_inv 
														 				-rho_c_12_inv + rho_c_6_inv 
																		+4.0*eps_ij*(-12*rho_c_12_inv*r_c_sq_inv +6*rho_c_6_inv*r_c_sq_inv )*r_m_rc*dr_norm);
			atom_data -> owned.acceleration [i] += force / mass_i;
			if (!is_ghost)
      	atom_data -> owned.acceleration [j] -= force / mass_j;
			 
		}
  }

}


