#ifndef ATOM_DATA_H
#define ATOM_DATA_H

#include "pointers.h"

#include <vector>

#include "vector.h"

class Atom_data : protected Pointers {
public:
  Atom_data (class MD *);
  virtual ~Atom_data ();
  
  void set_num_total_atoms (GlobalID_t);
  void set_num_atom_types (AtomType_t n) {num_atom_types = n;}
  
  LocalID_t num_local_atoms, num_local_atoms_est;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;
  
  virtual bool add_atom (GlobalID_t, AtomType_t, Real_t, const Vector<Real_t> &, const std::vector<Real_t> &other_real = std::vector<Real_t>{}, const std::vector<int> &other_int = std::vector<int>{});
   virtual bool add_atom (GlobalID_t, AtomType_t, Real_t, const Vector<Real_t> &, const Vector<Real_t> &, const std::vector<Real_t> &other_real = std::vector<Real_t>{}, const std::vector<int> &other_int = std::vector<int>{});

  virtual bool add_masses (int, Real_t);	
  virtual bool add_charges (int, Real_t);	

  struct {
    std::vector<GlobalID_t> id;
    std::vector<AtomType_t> type;
    std::vector<Real_t> mass;
//    std::vector<Real_t> charge_atom; // Can be changed in simulation (it is needed to be sent in MPI)
    std::vector<Real_t> charge_type; // Constant over simulation.
    std::vector<Vector<Real_t>> position, velocity, acceleration;
//    std::vector<Vector<Real_t>> pos_3dot, pos_4dot; // will be used in predictor-corrector integration scheme. not implemented yet.
  } owned, ghost;
	std::vector<int> ghost_rank; // the rank of the domain in which the owned counterpart exists
	int x_bc,y_bc,z_bc; // boundary condition in different direction 
  std::vector<Vector<Real_t>> last_reneighbor_pos;
	bool exchange_owned ();
	void exchange_ghost ();
	Vector<Real_t> periodic_distance (Vector<Real_t>, const int, const int, const int);
protected:
  virtual void allocate ();
private:
  double cutoff;

};

#endif
