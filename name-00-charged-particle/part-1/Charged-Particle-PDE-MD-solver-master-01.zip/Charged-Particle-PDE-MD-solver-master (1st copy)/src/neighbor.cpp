#include "neighbor.h"

#include "force_field.h"
#include "atom_data.h"

//Neighbor::Neighbor (MD *md) : Pointers{md}, cutoff{force_field->cutoff} {}
Neighbor::Neighbor (MD *md) : Pointers{md} {}

void Neighbor::init () {
	force_field = md->force_field;
	cutoff = force_field->cutoff;
	cutoff_extra = 0.01; // check this. cutoff_extera is used as a criteria for making a new neigbor list.
	std::cout << "Neighbor: " << cutoff<<"\n";
  auto &old_pos = atom_data->last_reneighbor_pos;
  const auto &pos = atom_data->owned.position;
	old_pos.resize (pos.size());
}

bool Neighbor::rebuild_neighlist () {
  bool result = false;
  const auto &pos = atom_data->owned.position, &old_pos = atom_data->last_reneighbor_pos;
  for (auto i=0; i<old_pos.size(); ++i) {
    auto disp = pos[i] - old_pos[i];
    result |= (disp*disp > cutoff_extra*cutoff_extra/4);
  }
#ifdef USE_MPI
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Neighbor::build_neighlist () {
//	std::cout <<"new_neighbor\n"<<std::flush;
  const auto &pos = atom_data->owned.position, & pos_ghost = atom_data -> ghost.position;
  auto cutoff_sq = (cutoff + cutoff_extra)*(cutoff + cutoff_extra);
  neighlist.clear ();
  neighlist.resize (pos.size());
																		// what to do with ghosts?
  for (auto i=0; i<pos.size(); ++i) {
    for (auto j=i+1; j<pos.size(); ++j) {
//      auto dr = pos[j] - pos[i];
      auto dr = atom_data->periodic_distance (pos[j] - pos[i], 1, 1, 1);
      if (dr*dr < cutoff_sq)
        neighlist[i].push_back (j);
    }
    for (auto j=0; j<pos_ghost.size(); ++j) {
      auto dr = pos_ghost[j] - pos[i]; // periodic boundary place?
      if (dr*dr < cutoff_sq)
        neighlist[i].push_back (j + pos.size());
    }
  }

  auto &old_pos = atom_data->last_reneighbor_pos;
  for (auto i=0; i<pos.size(); ++i) {
		old_pos[i] = pos[i];
	}

}
