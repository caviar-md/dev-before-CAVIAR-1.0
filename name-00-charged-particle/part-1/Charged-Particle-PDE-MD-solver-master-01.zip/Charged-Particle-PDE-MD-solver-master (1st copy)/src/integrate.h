#ifndef INTEGRATE_H
#define INTEGRATE_H

#include "pointers.h"

class Integrate : protected Pointers {
public:
  Integrate (class MD *);
 	 
  bool run (int);
private:
	class Output *output;

  void step ();
  void setup ();
  void cleanup ();
  void velocity_verlet ();
	void boundary_condition ();
};

#endif
