#ifndef ATOM_DATA_H
#define ATOM_DATA_H

#include "pointers.h"

#include <vector>

#include "vector.h"

class Atom_data : protected Pointers {
public:
  Atom_data (class MD *);
  virtual ~Atom_data ();
  
  void set_num_total_atoms (GlobalID_t);
  void set_num_atom_types (AtomType_t n) {num_atom_types = n;}
  
  LocalID_t num_local_atoms, num_local_atoms_est;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;
  
  virtual bool add_atom (GlobalID_t, AtomType_t, Real_t, const Vector<Real_t> &, const std::vector<Real_t> &other_real = std::vector<Real_t>{}, const std::vector<int> &other_int = std::vector<int>{});
 
  virtual bool add_masses (int, Real_t);	

  struct {
    std::vector<GlobalID_t> id;
    std::vector<AtomType_t> type;
    std::vector<Real_t> charge, mass;
    std::vector<Vector<Real_t>> position, velocity, acceleration;
    std::vector<Vector<Real_t>> pos_3dot, pos_4dot;
  } owned, ghost;
  
  std::vector<Vector<Real_t>> last_reneighbor_pos;
	void boundary_condition (const int, const int, const int);
	Vector<Real_t> periodic_distance (Vector<Real_t>, const int, const int, const int);
protected:
  virtual void allocate ();
private:
  
};

#endif
