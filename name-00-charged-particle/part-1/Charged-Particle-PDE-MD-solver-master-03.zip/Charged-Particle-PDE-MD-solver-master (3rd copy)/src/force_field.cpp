#include "force_field.h"

Force_field::Force_field (MD *md, Parser *parser) : Pointers{md} {}
