#ifndef UPDATE_H
#define UPDATE_H

#include "pointers.h"

class Update : protected Pointers {
public:
  Update (class MD *);
 	~Update ( );

  bool run (int);
  void verify_settings ();
  void setup ();
  void cleanup ();
	double dt;
private:
  class Integrate *integrate;
	class Output *output;
//	bool self_ghost ();
};

#endif
