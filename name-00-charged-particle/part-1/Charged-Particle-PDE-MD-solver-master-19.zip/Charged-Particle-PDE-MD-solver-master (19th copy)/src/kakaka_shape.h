#ifndef KAKAKA_SHAPE_H
#define KAKAKA_SHAPE_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"

namespace kkk {

	class All_objects;

namespace shape {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

// ========================
// ========================
// ========================

class Shape {
	public:
		Shape ();	
		virtual ~Shape();
		int dimension;
		virtual bool read(Parser *);
		virtual bool is_inside (Vector<double> );
		virtual bool is_valid();
		virtual bool Shape::U_min_max() (double &, double &);
		virtual bool Shape::V_min_max() (double &, double &);
		virtual bool Shape::W_min_max() (double &, double &);
		double U_min,U_max,V_min,V_max,W_min,W_max;
		Output * output;
		Error * error;
		All_objects * all_objects;
};
// ========================
// ========================
// ========================
class Circle : public Shape {
public:
	Circle (Output * , Error *, All_objects *) ;
	~Circle ();

	bool read(Parser *); // there are different ways to define a circle: 3 points on it, centre and one point on it, centre and radius and normal,...

	double RADIUS;
	double FLATNESS_TOLL;
	Vector<double> CENTER;
	Vector<double> NORMAL;
	bool on_the_plane(Vector<double> v);
	bool is_inside(Vector<double> v);
	bool make_basis_vectors();
		Output * output;
		Error * error;
		All_objects * all_objects;

};

// ========================
// ========================
// ========================


class Closed_lines : public Shape {
public:
	Closed_lines (Output * , Error *, All_objects *) ;
	~Closed_lines ();	

	std::vector<Vector<Real_t>> p_3D; // vertex points of the shape in 3D space
	Vector<Real_t> n_vector, u_vector, v_vector; //  basis vectors of the plane: normal and (u,v)
	std::vector<Real_t> u_list, v_list; // array containing u and v coordinates of the vertices in the plane
	Real_t mat_inv[3][3]; // inverse of the transformation matrix;

	double FLATNESS_TOLL;
		Output * output;
		Error * error;
		All_objects * all_objects;

	void make_basis_vectors() ;
	void make_uv_vectors() ; 
	void make_transform_matrix();
	void uv_to_xyz (Real_t u_i, Real_t v_i, Vector<Real_t> &p_i);
	void xyz_to_uv (const Vector<Real_t> &p_i, Real_t &u_i, Real_t &v_i) ;
	bool is_inside (double u_i, double v_i); // using Jordan curve theorem,
			// checks whether the point is inside the curve or not;
			// it has a bug when (v_list[i] == v_list[j]);

};


// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

} // namespace shape finished
} // NAMESPACE KKK finished


#endif
 
