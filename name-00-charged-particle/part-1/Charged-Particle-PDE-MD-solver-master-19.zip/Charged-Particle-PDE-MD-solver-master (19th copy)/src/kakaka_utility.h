#ifndef KAKAKA_UTILITY_H
#define KAKAKA_UTILITY_H

//#include "data_reader_kakaka.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
#include "kakaka_shape.h"

namespace kkk {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::map<std::string,int> dictionary_second_type = {
	{"ELEMENT",1},
	{"ATOM",2},
	{"MOLECULE",3},	
	{"RANDOM_GENERATOR",4},	
	{"BOUNDARY",5},	
	{"SHAPE",6},	
	{"INT_CONSTANT",-1},	
	{"REAL_CONSTANT",-2},	
	{"INT_2D_VECTOR",-3},	
	{"REAL_2D_VECTOR",-4},	
	{"INT_3D_VECTOR",-5},	
	{"REAL_3D_VECTOR",-6},
};


class Molecule;
class Atom;
class Dictionary;
class All_objects;

class Element {
	public:
		Element () ;
		Element (Output * , Error *, All_objects *, double m, double r, double ch, int t);
		~Element ();

		bool read (Parser *);
	private:
		class Output * output;
		class Error * error;
		class All_objects * all_objects;

		int type_number;
		double MASS, RADIUS, CHARGE;
};

// ========================
// ========================
// ========================

class Molecule {
	public:
		Molecule ();
		Molecule (Output * , Error *, All_objects *, class Molecule *,  Vector<double>, Vector<double>);
		~Molecule ();

		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const;	
		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}

		bool read (Parser *);

		bool add_atom (Atom &);	
		bool add_molecule (Molecule &);	
	
		Molecule * FATHER;

	private:
	Vector<double> POSITION, VELOCITY;
	std::vector<Atom> atoms;
	std::vector<Molecule> molecules;
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};

// ========================
// ========================
// ========================

class Atom {
	public:
		Atom ();
		Atom (Output * , Error *,All_objects *, class Molecule *,  Vector<double>, Vector<double>);
		~Atom () ;


		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const; 

		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}

		bool read (Parser *);
		Molecule * FATHER;
	private:
	Vector<double> POSITION, VELOCITY;

	int type;
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};

// ========================
// ========================
// ========================

class Random {
	public:
		Random () ;
		~Random () ;
		int num; // number of random atoms or molecules to be created
		bool read(Parser *);
		double X_min,X_max,Y_min,Y_max,Z_min,Z_max;
		int seed_x, seed_y, seed_z;
		bool linked_to_object;
		Shape * shape;
		Boundary * boundary;
		std::mt19937 *ran_x, *ran_y, *ran_z;
		std::uniform_real_distribution<> *u_dis_x, *u_dis_y, *u_dis_z;
		std::normal_distribution<> *n_dis_x, *n_dis_y, *n_dis_z;

	private:
};
// ========================
// ========================
// ========================

class Boundary {
	public:
		Boundary () {};
		~Boundary () {};
};
// ========================
// ========================
// ========================

class Dictionary {
	public:
	Dictionary () { };
	Dictionary (int t, int i) : type(t), index(i){ };
	~Dictionary () {};
	int type; // type of the vector
	int index; // index of the vector
//	string object_type ; // the same as int type
};


class Molecule_distribution {
	public:
		Molecule_distribution () ;
		~Molecule_distribution () ;
/*	
	Random *;
	Grid *;
	Boundary *;
	Molecule*;
	Atom *;*/
	void distribute();

};

class All_objects {
	public:
	All_objects () {};

	std::map<std::string,kkk::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<Element> elements; // 1
	std::vector<Atom> atoms; // 2
	std::vector<Molecule> molecules; // 3
	std::vector<Boundary> boundaries; // 4
	std::vector<Random_generator> random_generators; // 5
	std::vector<int> int_constants; // -1
	std::vector<double> real_constants; // -2
	std::vector<Vector2D<int>> int_2d_vectors; // -3
	std::vector<Vector2D<double>> real_2d_vectors; // -4
	std::vector<Vector<int>> int_3d_vectors; // -5
	std::vector<Vector<double>> real_3d_vectors; // -6
	std::vector<shape::Shape> shapes;
} ;//all_objects;

} // NAMESPACE KKK finished


#endif
 
