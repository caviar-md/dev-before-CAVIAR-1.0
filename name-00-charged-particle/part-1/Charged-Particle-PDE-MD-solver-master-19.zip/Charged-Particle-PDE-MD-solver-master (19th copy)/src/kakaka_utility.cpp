#include "data_reader_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"

//====================================
//====================================
//====================================


int kkk::gdst (const std::string & t) { //get_dictionary_second_type 
	std::map<std::string,int>::const_iterator it;
	it = kkk::dictionary_second_type.find(t);
	if (it == kkk::dictionary_second_type.end()) return 0;
	else return it->second;
}



// =============================
// =============================
// =============================

bool kkk::Element::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Element");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(RADIUS,"ELEMENT READ: ","")
		else ASSIGN_REAL(MASS,"ELEMENT READ: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT READ","")
		else {
				error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: Unknown variable or command");
		}
	}
	
	return in_file;;
}

// =============================
// =============================
// =============================

bool kkk::Atom::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Atom");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM READ: ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: read: Unknown variable or command");
	}
	
	return in_file;;
}
// =============================
// =============================
// =============================

bool kkk::Molecule::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Atom");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"MOLECULE READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"MOLECULE READ: ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Molecule: read: Unknown variable or command");
	}
	
	return in_file;;
}
//====================================
//====================================
//====================================
	kkk::Element::Element () {} ;
	kkk::Element::Element (Output * out, Error * err, All_objects * all_obj, double m, double r, double ch, int t) :
	output{out}, error{err},all_objects{all_obj}, MASS{m}, RADIUS{r}, CHARGE{ch}, type_number{t} {}; 

	kkk::Element::~Element () {};
//====================================
//====================================
//====================================

	kkk::Atom::Atom () : POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}},FATHER{0} {};
	kkk::Atom::Atom (Output * out, Error * err, All_objects * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel) : 
		 output{out}, error{err},all_objects{all_obj},POSITION{pos}, VELOCITY{vel},FATHER{f}  {}
	
 	kkk::Atom::~Atom () {};

//====================================
//====================================
//====================================

	kkk::Molecule::Molecule () : POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}},FATHER{0} {};
	kkk::Molecule::Molecule (Output * out, Error * err, All_objects * all_obj,class Molecule * f, Vector<double> pos, Vector<double> vel) : 
		 output{out}, error{err},all_objects{all_obj}, POSITION{pos}, VELOCITY{vel},FATHER{f}  {}
		
 	kkk::Molecule::~Molecule () {};


//====================================
//====================================
//====================================



Vector<double> kkk::Atom::pos_tot () const {
	if (FATHER == 0) return POSITION;
 	else return POSITION + FATHER->pos();	
}
Vector<double> kkk::Atom::vel_tot () const {
	if (FATHER == 0) return VELOCITY;
 	else return VELOCITY + FATHER->vel();	
}

Vector<double> kkk::Molecule::pos_tot () const {
	if (FATHER == 0) return POSITION;
 	else return POSITION + FATHER->pos();	
}
Vector<double> kkk::Molecule::vel_tot () const {
	if (FATHER == 0) return VELOCITY;
 	else return VELOCITY + FATHER->vel();	
}



bool kkk::Molecule::add_atom (kkk::Atom & a){
	Atom a_ = a;
	a_.FATHER = this;
	atoms.push_back(a_);	
}

bool kkk::Molecule::add_molecule (kkk::Molecule & a){
	Molecule a_ = a;
	a_.FATHER = this;
	molecules.push_back(a_);	
}

//====================================
//====================================
//====================================

namespace kkk {

	Random::Random () {};
	Random::~Random () {
			delete ran_x,ran_y,ran_z;
			delete n_dis_x,n_dis_y,n_dis_z;
			delete u_dis_x,u_dis_y,u_dis_z;
		};
	Random::read(Parser* parser) {
		output->info("Data_reader_Kakaka: Random Read: ");
		bool in_file = true;

		while(true) {
			GET_A_TOKEN_FOR_CREATION
			ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM READ: ","")
			else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM READ: ","")
			else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: read: Unknown variable or command");
		}
	
		return in_file;;


	}
}
