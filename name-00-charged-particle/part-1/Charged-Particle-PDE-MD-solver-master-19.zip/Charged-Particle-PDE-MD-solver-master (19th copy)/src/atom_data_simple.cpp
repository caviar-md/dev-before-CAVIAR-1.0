#include "atom_data_simple.h"

Atom_data_simple::Atom_data_simple (MD *md) : Atom_data{md} {}

void Atom_data_simple::allocate () {
  
}
