#include "error.h"

Error::Error (MD *md) : Pointers{md} {}

// All procs must call this else there would be a deadlock

void Error::all (const char *file, int line, const char *func, const std::string &parsing_line, unsigned int col, const char *str) {
  int me = 0;
#ifdef USE_MPI
  MPI_Comm_rank (mpi_comm, &me);
  MPI_Barrier (mpi_comm);
#endif
  
  if (me == 0) {
    if (err_flag) {
      err << "ERROR: " << str << " (at " << file << ':' << line << " in " << func << ')' << std::endl;
      err << parsing_line << std::endl;
      for (int i=0; i<col; ++i) err << ' ';
      err << '^' << std::endl;
    }
    if (log_flag) {
      log << "ERROR: " << str << " (at " << file << ':' << line << " in " << func << ')' << std::endl;
      log << parsing_line << std::endl;
      for (int i=0; i<col; ++i) log << ' ';
      log << '^' << std::endl;
    }
    if (log_flag) log.close();
  }
  
#ifdef USE_MPI
  MPI_Finalize ();
#endif
  exit (1);
}

// One proc calling this will abort all

void Error::one (const char *file, int line, const char *func, const std::string &parsing_line, unsigned int col, const char *str) {
#ifdef USE_MPI
  int me;
  MPI_Comm_rank (mpi_comm, &me);
  if (err_flag) {
    err << "ERROR on proc " << me << ": " << str << 
    " (at " << file << ':' << line << " in " << func << ')' << std::endl;
    err << parsing_line << std::endl;
    for (int i=0; i<col; ++i) err << ' ';
    err << '^' << std::endl;
  }
  if (log_flag) {
    log << "ERROR on proc " << me << ": " << str << 
    " (at " << file << ':' << line << " in " << func << ')' << std::endl;
    log << parsing_line << std::endl;
    for (int i=0; i<col; ++i) log << ' ';
    log << '^' << std::endl;
  }
  MPI_Abort (mpi_comm, 1);
#else
  all (file, line, func, parsing_line, col, str);
#endif
}

void Error::all (const char *file, int line, const char *func, const std::string &parsing_line, unsigned int col, const std::string &str) {
  int me = 0;
#ifdef USE_MPI
  MPI_Comm_rank (mpi_comm, &me);
  MPI_Barrier (mpi_comm);
#endif
  
  if (me == 0) {
    if (err_flag) {
      err << "ERROR: " << str << " (at " << file << ':' << line << " in " << func << ')' << std::endl;
      err << parsing_line << std::endl;
      for (int i=0; i<col; ++i) err << ' ';
      err << '^' << std::endl;
    }
    if (log_flag) {
      log << "ERROR: " << str << " (at " << file << ':' << line << " in " << func << ')' << std::endl;
      log << parsing_line << std::endl;
      for (int i=0; i<col; ++i) log << ' ';
      log << '^' << std::endl;
    }
    if (log_flag) log.close();
  }
  
#ifdef USE_MPI
  MPI_Finalize ();
#endif
  exit (1);
}

void Error::one (const char *file, int line, const char *func, const std::string &parsing_line, unsigned int col, const std::string &str) {
#ifdef USE_MPI
  int me;
  MPI_Comm_rank (mpi_comm, &me);
  if (err_flag) {
    err << "ERROR on proc " << me << ": " << str << 
    " (at " << file << ':' << line << " in " << func << ')' << std::endl;
    err << parsing_line << std::endl;
    for (int i=0; i<col; ++i) err << ' ';
    err << '^' << std::endl;
  }
  if (log_flag) {
    log << "ERROR on proc " << me << ": " << str << 
    " (at " << file << ':' << line << " in " << func << ')' << std::endl;
    log << parsing_line << std::endl;
    for (int i=0; i<col; ++i) log << ' ';
    log << '^' << std::endl;
  }
  MPI_Abort (mpi_comm, 1);
#else
  all (file, line, func, parsing_line, col, str);
#endif
}
