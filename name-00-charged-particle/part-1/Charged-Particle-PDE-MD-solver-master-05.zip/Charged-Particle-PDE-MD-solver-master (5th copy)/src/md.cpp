#include "md.h"

#include "communicator.h"
#include "input.h"
#include "output.h"
#include "error.h"
#include "atom_data.h"
#include "atom_data_simple.h"
#include "domain.h"
#include "update.h"
#include "force_field_lj.h"
#include "neighbor.h"
#include "writer.h"

#ifdef USE_MPI
MD::MD (int argc, char **argv, MPI_Comm mpi_comm) :
  mpi_comm {mpi_comm},
#else
MD::MD (int argc, char **argv) :
#endif
  comm {new Communicator {this}},
  error {new Error {this}},
  output {new Output {this}},
  input {new Input {this}},
  domain {new Domain {this}},
  atom_data {new Atom_data_simple {this}},
  update {new Update {this}},
  neighbor {new Neighbor {this}},
  writer {new Writer {this}},
  in {std::cin.rdbuf()},
  out {std::cout.rdbuf()},
  err {std::cerr.rdbuf()},
	force_field_made {false},
  log_flag {true},
  out_flag {true},
  err_flag {true} {
    if (comm->me == 0) log.open ("log");
}

MD::~MD () {

	delete writer;
  delete neighbor;
  if (force_field_made) delete force_field; 
  delete update;
  delete atom_data;
  delete domain;
  delete input;
  delete output;
  delete error;
  delete comm;
	
}

void MD::execute () {
  input->read ();
}
