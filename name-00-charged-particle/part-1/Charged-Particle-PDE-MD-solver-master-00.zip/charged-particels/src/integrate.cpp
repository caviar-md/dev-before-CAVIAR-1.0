#include "integrate.h"

#include "neighbor.h"
#include "atom_data.h"
#include "force_field.h"
#include "output.h"

Integrate::Integrate (MD *md) : Pointers{md}, output{md->output} {}

bool Integrate::run (int num_steps) {
  setup();
	output->dump_data (0);
  for (int i = 1; i < num_steps+1; i++) {
    step ();
		boundary_condition ();
		if (i%1000 == 0) {
			output->dump_data (i);
			std::cout<<"i:"<<i<<" "<<std::flush;
		}
    if ( neighbor -> rebuild_neighlist () )
      neighbor -> build_neighlist();
  } 
  cleanup(); 
}

void Integrate::step () {

  velocity_verlet (); // we can devide it into three steps;

}

void Integrate::boundary_condition () {
	atom_data -> boundary_condition (1,1,1);
}

void Integrate::setup () {
	std::cout << "integrate:" <<force_field->cutoff<<"\n";
	neighbor -> init ();
  neighbor -> build_neighlist ();
  force_field -> calculate_acceleration ();
}

void Integrate::cleanup () {

}

void Integrate::velocity_verlet () {

  Real_t dt = 1E-4; //= ??? -> dt(); // ?? //

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();

  for (auto i=0; i<psize; i++) { 
    vel [i] += 0.5 * acc [i] * dt;
    pos [i] += 0.5 * vel [i] * dt;
		acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

  force_field -> calculate_acceleration ();
 
  for (auto i=0; i<psize; i++) {
    vel [i] += 0.5 * acc [i] * dt;
  }
//	std::cout<<"A: " << pos[0]<< " B: "<< pos[1] <<"\n";

}


