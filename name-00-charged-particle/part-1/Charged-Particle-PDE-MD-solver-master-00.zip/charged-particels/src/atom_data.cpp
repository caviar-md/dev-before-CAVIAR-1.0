#include "atom_data.h"

#include "communicator.h"
#include "domain.h"

constexpr auto expected_imbalance_factor = 1.1;

Atom_data::Atom_data (MD *md) : Pointers{md}, num_local_atoms{0}, num_total_atoms{0}, num_atom_types{0} {}

Atom_data::~Atom_data () {
  
}

void Atom_data::set_num_total_atoms (GlobalID_t n) {
  num_total_atoms = n;
  num_local_atoms_est = n * expected_imbalance_factor / comm->nprocs;
}

void Atom_data::allocate () {
  owned.id.reserve (num_local_atoms_est);
  owned.charge.reserve (num_local_atoms_est);
  owned.position.reserve (num_local_atoms_est);
  owned.velocity.reserve (num_local_atoms_est);
  owned.acceleration.reserve (num_local_atoms_est);
}

bool Atom_data::add_atom (GlobalID_t id, AtomType_t type, Real_t ch, const Vector<Real_t> &pos, const std::vector<Real_t> &, const std::vector<int> &) {
  if (pos.x > domain->x_lower_local && pos.x < domain->x_upper_local &&
      pos.y > domain->y_lower_local && pos.y < domain->y_upper_local &&
      pos.z > domain->z_lower_local && pos.z < domain->z_upper_local) {
    owned.type.push_back (type);
    owned.position.push_back (pos);
		owned.charge.push_back (ch);
		owned.id.push_back ( id );
		owned.velocity.push_back (Vector<Real_t> {0,0,0});
		owned.acceleration.push_back (Vector<Real_t> {0,0,0});
    ++num_local_atoms;
    return true;
  }
  else return false;
}

bool Atom_data::add_masses ( int type, Real_t m ) {
	owned.mass.push_back (m); 
}

void Atom_data::boundary_condition (int x_c, int y_c, int z_c) {
	auto &pos = owned.position;
	
	auto x_width = domain->x_upper_local - domain->x_lower_local;
	auto y_width = domain->y_upper_local - domain->y_lower_local;
	auto z_width = domain->z_upper_local - domain->z_lower_local;

#ifdef USE_MPI
	if (comm->nprocs_x == 1) {
		if (x_c == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (pos[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
					pos[i].x += x_width;
				}
				while (pos[i].x > domain->x_upper_local) {
					pos[i].x -= x_width;
				}
			}
		}
	} else {
					//send the atom to the other domain
					//--num_local_atoms;
	}

	if (comm->nprocs_y == 1) {
		if (y_c == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (pos[i].y < domain->y_lower_local) {
					pos[i].y += y_width;
				}
				while (pos[i].y > domain->y_upper_local) {
					pos[i].y -= y_width;
				}
			}
		}
	} else {
					//send the atom to the other domain
					//--num_local_atoms;
	}

	if (comm->nprocs_z == 1) {
		if (z_c == 1) {
			for (auto i = 0 ; i < num_local_atoms; ++i) {
				while (pos[i].z < domain->z_lower_local) {
					pos[i].z += z_width;
				}
				while (pos[i].z > domain->z_upper_local) {
					pos[i].z -= z_width;
				}
			}
		}
	} else {
					//send the atom to the other domain
					//--num_local_atoms;
	}
#else
	if (x_c == 1) {
		for (auto i = 0 ; i < num_local_atoms; ++i) {
			while (pos[i].x < domain->x_lower_local) {//using "while"instead of "if"... why "if" isn't enough?
				pos[i].x += x_width;
			}
			while (pos[i].x > domain->x_upper_local) {
				pos[i].x -= x_width;
			}
		}
	}
	if (y_c == 1) {
		for (auto i = 0 ; i < num_local_atoms; ++i) {
			while (pos[i].y < domain->y_lower_local) {
				pos[i].y += y_width;
			}
			while (pos[i].y > domain->y_upper_local) {
				pos[i].y -= y_width;
			}
		}
	}
	if (z_c == 1) {
		for (auto i = 0 ; i < num_local_atoms; ++i) {
			while (pos[i].z < domain->z_lower_local) {
				pos[i].z += z_width;
			}
			while (pos[i].z > domain->z_upper_local) {
				pos[i].z -= z_width;
			}
		}
	}
#endif
}

Vector<Real_t> Atom_data::periodic_distance ( Vector<Real_t> dr, int x_c, int y_c, int z_c) {
	auto x_width = domain->x_upper_local - domain->x_lower_local;
	auto y_width = domain->y_upper_local - domain->y_lower_local;
	auto z_width = domain->z_upper_local - domain->z_lower_local;
#ifdef USE_MPI
	if (comm->nprocs_x == 1) {
		if (x_c == 1) {
			while (dr.x < -0.5*x_width) {//using "while"instead of "if"... why "if" isn't enough?
				dr.x += x_width;
			}
			while (dr.x >= 0.5*x_width) {
				dr.x -= x_width;
			}			
		}
	}
	if (comm->nprocs_y == 1) {
		if (y_c == 1) {
			while (dr.y < -0.5*y_width) {
				dr.y += y_width;
			}
			while (dr.y >= 0.5*y_width) {
				dr.y -= y_width;
			}
		}
	}
	if (comm->nprocs_z == 1) {
		if (z_c == 1) {
			while (dr.z < -0.5*z_width){
				dr.z += z_width;
			}
			while (dr.z >= 0.5*z_width) {
				dr.z -= z_width;
			}
		}
	}
#else
	if (x_c == 1) {
		while (dr.x < -0.5*x_width) {//using "while"instead of "if"... why "if" isn't enough?
			dr.x += x_width;
		}
		while (dr.x >= 0.5*x_width) {
			dr.x -= x_width;
		}			
	}
	if (y_c == 1) {
		while (dr.y < -0.5*y_width) {
			dr.y += y_width;
		}
		while (dr.y >= 0.5*y_width) {
			dr.y -= y_width;
		}
	}
	if (z_c == 1) {
		while (dr.z < -0.5*z_width){
			dr.z += z_width;
		}
		while (dr.z >= 0.5*z_width) {
			dr.z -= z_width;
		}
	}
#endif
	return dr;
}


