#include "domain.h"

#include "communicator.h"

Domain::Domain (MD *md) : Pointers{md} {}

void Domain::calculate_local_domain () {
  x_lower_local = x_lower_global + (x_upper_global - x_lower_global) * comm->grid_index_x / comm->nprocs_x;
  y_lower_local = y_lower_global + (y_upper_global - y_lower_global) * comm->grid_index_y / comm->nprocs_y;
  z_lower_local = z_lower_global + (z_upper_global - z_lower_global) * comm->grid_index_z / comm->nprocs_z;
  
  x_upper_local = x_lower_global + (x_upper_global - x_lower_global) * (comm->grid_index_x+1) / comm->nprocs_x;
  y_upper_local = y_lower_global + (y_upper_global - y_lower_global) * (comm->grid_index_y+1) / comm->nprocs_y;
  z_upper_local = z_lower_global + (z_upper_global - z_lower_global) * (comm->grid_index_z+1) / comm->nprocs_z;
}
