#ifndef COMMUNICATOR_H
#define COMMUNICATOR_H

#include "pointers.h"

class Communicator : protected Pointers {
public:
  Communicator (MD *);
  
  void calculate_procs_grid ();
  
  void broadcast (bool &);
  void broadcast (size_t &);
  void broadcast (size_t &, char *);
  void broadcast (std::string &);
  
  int me, nprocs;
  int nprocs_x, nprocs_y, nprocs_z;
  int grid_index_x, grid_index_y, grid_index_z;
  int left, right, down, up, bottom, top;
private:
  inline int grid2rank (int x, int y, int z) const {return x + y*nprocs_x + z*nprocs_x*nprocs_y;}
  void find_best_grid ();
};

#endif
