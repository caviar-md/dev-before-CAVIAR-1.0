#include "output.h"

#include "atom_data.h"
#include "communicator.h"

Output::Output (MD *md) : Pointers{md}, atom_data{md->atom_data}, comm{md->comm} {}

void Output::dump_data (int i) {
	atom_data = md->atom_data;
#ifdef USE_MPI
	int nprocs = comm->nprocs;
	int me = comm->me;

  auto &pos = atom_data -> owned.position;

	const auto nla = atom_data -> num_local_atoms;
	const auto nta = atom_data -> num_total_atoms;

  std::vector<Vector<Real_t>> all_pos;
	all_pos.resize (nta);

	int nla_list [ nprocs ];

	if (nprocs > 1) {
		if (me != 0) {
			MPI_Send (&nla, 1, MPI_INT, 0, 0, mpi_comm);
		} else {
			nla_list[0]=nla;
			for (int i=1; i < nprocs; ++i) {
				MPI_Recv (&nla_list[i], 1, MPI_INT, 0, 0, mpi_comm, MPI_STATUS_IGNORE);
			}
		}

		MPI_Barrier (mpi_comm);	

		if (me != 0) {
			MPI_Send (&pos[0], 3*nla, MPI_DOUBLE, 0, 0, mpi_comm);
		} else {
			int n_recv = 0;
			for (int i=0; i < nla; ++i) {
				all_pos[i].x = pos[i].x;	all_pos[i].y = pos[i].y;	all_pos[i].z = pos[i].z;
			}
			n_recv += 3*nla_list[0];
			for (int i=1; i < nprocs; ++i) {
				MPI_Recv (&all_pos[n_recv], 3*nla_list[i], MPI_DOUBLE, 0, 0, mpi_comm, MPI_STATUS_IGNORE);
				n_recv += 3*nla_list[i];
			}
		}

		MPI_Barrier (mpi_comm);	
	} else {
		for (auto i = 0; i < nta; ++i) {
			all_pos[i].x = pos[i].x; all_pos[i].y = pos[i].y; all_pos[i].z = pos[i].z;
		}
	}

	if (me == 0) {
		ofs_positions << nla << "\nAtom\n";
		for (auto i = 0; i < nta; ++i) {
			ofs_positions << "1" << " " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n" << std::flush; // remove flush
		}
	}
#else
  auto &all_pos = atom_data -> owned.position;
	int nta = atom_data -> num_total_atoms;
	ofs_positions << nta << "\nAtom\n";
	for (auto i = 0; i < nta; ++i) {
		ofs_positions << "1" <<" " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n" << std::flush; // remove flush
	}
#endif

}

void Output::close_files () {
#ifdef USE_MPI
	if (comm->me == 0) {
		close_them ();
	}
#else
	close_them ();
#endif
}


void Output::open_files () {
#ifdef USE_MPI
	if (comm->me ==0){
		open_them ();
	}
#else
	open_them ();
#endif
}


void Output::close_them () {
	ofs_energy.close ();
	ofs_positions.close	();
	ofs_velocities.close ();
}


void Output::open_them () {

	std::string str_energy = "o_e",
							str_positions	= "o_p",
							str_velocities = "o_v";		

	std::string str_filename = "";
	char buffer[50] = "";

/*
#ifdef USE_MPI
	sprintf ( buffer, "_me%u", comm->me );
	str_filename.append ( buffer);
#endif
*/

/*
 	sprintf ( buffer, "_n%u", G_no_grains );
	str_filename.append ( buffer);
*/
	str_positions.append ( str_filename);
	str_positions.append ( ".xyz");

	str_filename.append ( ".txt" );

	str_energy.append (str_filename);
//	str_positions.append (str_filename);
	str_velocities.append (str_filename);

	const char * char_energy = str_energy.c_str ();
	const char * char_positions = str_positions.c_str ();
	const char * char_velocities	= str_velocities.c_str ();

	ofs_energy.open	(char_energy);
	ofs_positions.open (char_positions);
	ofs_velocities.open	(char_velocities);
}

void Output::print_hello () {
	for (int i = 1; i<5; i++) {
		ofs_energy << i <<" hello\n";
		ofs_positions << i <<" hello\n"<<std::flush;
		ofs_velocities << i <<" hello\n"<<std::flush;
	}
}
