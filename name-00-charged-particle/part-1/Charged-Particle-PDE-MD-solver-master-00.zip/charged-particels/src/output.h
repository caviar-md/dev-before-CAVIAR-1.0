#ifndef OUTPUT_H
#define OUTPUT_H

#include "pointers.h"

class Output : protected Pointers {
public:
  Output (class MD *);
	void open_files ();
	void close_files ();
	void print_hello ();
	void dump_data (int);
private:
	class Atom_data *atom_data;
	class Communicator *comm;

	void open_them ();
	void close_them ();

	std::ofstream ofs_energy,  ofs_positions, ofs_velocities;
  
};

#endif
