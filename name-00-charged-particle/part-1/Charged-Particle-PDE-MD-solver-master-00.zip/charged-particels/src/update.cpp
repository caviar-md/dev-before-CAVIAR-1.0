#include "update.h"

#include "output.h"
#include "integrate.h"

Update::Update (MD *md) : Pointers{md}, integrate{new Integrate{md}}, output{md->output} {}

Update::~Update () {
	delete integrate;
}

bool Update::run (int nsteps) {
	std::cout << "Simulation started.\n"<< std::flush;
  verify_settings ();
  setup ();

  integrate->run (nsteps);
  
  cleanup ();
	std::cout << "Simulation finished.\n"<< std::flush;
}

void Update::verify_settings () {
  
}

void Update::setup () {
	output->open_files ();
}

void Update::cleanup () {
	output->close_files ();
}
