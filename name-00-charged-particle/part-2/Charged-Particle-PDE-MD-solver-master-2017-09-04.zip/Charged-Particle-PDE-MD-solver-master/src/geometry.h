#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "pointers.h"

#include <vector>
#include <map>

#include "vector.h"

namespace Namespace_Geometry {
struct Shape {

	Shape () : invert_normals{false}, young_modulus{100.0}, thickness{1.0}, grid_toll{0.0}, nx_part{1}, ny_part{1}, nz_part{1} {}

	std::vector<Vector<Real_t>> vertex;	// contains cartesian coordinates
	std::vector<std::vector<int>> vertex_map;	// made in "merge_vertices()" it's a map to the index of possible similar vertex with the lower index

	std::vector<std::vector<int>> face;	// contains vertex indices of ngons
	std::vector<Vector<Real_t>> normal; // normal of faces (inward or outward?)
//	Locally Defined // std::vector<std::vector<Vector<Real_t>>> edge_norms1; // addition of normals of neighbor faces for each edge
//	Locally Defined // std::vector<std::vector<Vector<Real_t>>> edge_norms2; // face[][j]-face[][j+1]
	std::vector<std::vector<Vector<Real_t>>> edge_norms3; // edge_norms1 cross edge_norms2

	std::map<std::vector<int>,std::vector<int>> edges; // first: the edge that has vertex[i],vertex[j] ... second: face[m],face[n] that has this edge

	std::vector<std::vector<std::vector<std::vector<int>>>> grid; // contains face indices within the grid;
	Real_t xlo, ylo, zlo, xhi, yhi, zhi; // highest and lowest coordinates of vertices; used in grid;
	Real_t dx_part, dy_part, dz_part; // used in grid;
	int nx_part, ny_part, nz_part;   // used in grid;

	Real_t thickness; // it defines the maximum thickness of each surface. If a particle go farther than it inside, it won't be inside anymore.
	Real_t young_modulus;
	std::vector<Real_t> radius; // it is public in order to be used at "output.cpp"
	bool invert_normals;
	Real_t grid_toll;

};
}
class Geometry : protected Pointers {
	public:
	Geometry (class MD *);
	~Geometry ();

//	void read_unv (const std::string &); // read unv format // IT HAS SOME BUGS
	void read_vtk (const std::string &); // read vtk format // There's many unneeded points. 

	void make_grid (int); // contains the faces neccesary to check
										 // make_grid has to be called after lowest_highest_coord()

	void lowest_highest_coord (int); // calculates gxlo, gxhi, gylo...

	void make_normal (int); // after reading unv file, it calculates normal vectors
	void make_edge_norms (int); // makes normals of faces made of edges and other normals used in check_inside() algorithm. 
	void pre_correct_normals (int); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.
	void merge_vertices (int); // It checks if the two vertices are similar.Then makes a map of all vertices to the similar ones with the lower index
	void invert_normals (int); // multiply all the normal Vectors with -1

	void check_inside (const Vector<Real_t> &, const Real_t, Vector<Real_t> &, int); // different algorithms
	bool check_inside (const Vector<Real_t> &, const Real_t); // different algorithms // true or false
	bool check_inside_ray (const Vector<Real_t> &v1, const int ray_axis, const Real_t perturb_1, const Real_t perturb_2);
	void calculate_acceleration ();
//	void invert_normals (); // invert all the normals in case needed

	void pre_execute (); // call some functions and pre-calculate grids and so...
	bool set_parameters (class Parser *); //called by command script
	bool geometry_force;
	bool make_invert_normals;

	void output_mesh_povray (); // povray output mesh ".pov"
	void output_mesh_vmd (); // vmd output mesh ".tcl"
	void output_normals_vmd (); // vmd output normals ".tcl"
	void output_edges_vmd (); // vmd output edges  ".tcl"


	std::vector<Namespace_Geometry::Shape> shapes; // include imported shapes.  // it is public in order to be used at "output.cpp"

	private:

//	std::vector<std::vector<std::vector<std::vector<int>>>> grid; // contains face indices within the grid;
//	Real_t gxlo, gylo, gzlo, gxhi, gyhi, gzhi; // highest and lowest coordinates of vertices;
//	Real_t grid_toll; // used in gridding; if zero, makes bugs in cases when grid is on a face.
//	bool g_coordinates_init;



};

#endif
