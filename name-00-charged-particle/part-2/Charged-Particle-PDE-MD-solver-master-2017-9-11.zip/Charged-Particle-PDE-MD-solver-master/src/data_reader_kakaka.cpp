#include "data_reader_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"


Data_reader_Kakaka::Data_reader_Kakaka (MD *md, const std::string &file) : Pointers{md}, parser{new Parser{md, file}},
	all_objects{new kkk::All_objects}, num_total_atoms{0}, num_atom_types{0}, output{md->output} 
	{ all_objects->parser = parser;}

Data_reader_Kakaka::~Data_reader_Kakaka () {
  delete parser;
}

//const std::map<std::string,kkk::CommandFunc> Data_reader_Kakaka::commands_map = {
const std::map<std::string,CommandFuncKKK> Data_reader_Kakaka::commands_map = {
		{	"READ_FILE", &Data_reader_Kakaka::READ_FILE},
 		{	"ELEMENT", &Data_reader_Kakaka::ELEMENT},
		{	"ATOM", &Data_reader_Kakaka::ATOM},
		{	"MOLECULE", &Data_reader_Kakaka::MOLECULE},
		{	"RANDOM_1D", &Data_reader_Kakaka::RANDOM_1D},
		{	"GRID_1D", &Data_reader_Kakaka::GRID_1D},		
		{	"BOUNDARY", &Data_reader_Kakaka::BOUNDARY},
		{	"SHAPE", &Data_reader_Kakaka::SHAPE},
		{	"DISTRIBUTION", &Data_reader_Kakaka::DISTRIBUTION},
		{	"OUTPUT_XYZ", &Data_reader_Kakaka::OUTPUT_XYZ},		
		{	"ADD_ATOM", &Data_reader_Kakaka::ADD_ATOM},
		{	"ADD_MOLECULE", &Data_reader_Kakaka::ADD_MOLECULE},
		{	"INT_CONSTANT", &Data_reader_Kakaka::INT_CONSTANT},
		{	"REAL_CONSTANT", &Data_reader_Kakaka::REAL_CONSTANT},//{"CONSTANT", &Data_reader_Kakaka::REAL_CONSTANT},
		{	"INT_2D_VECTOR", &Data_reader_Kakaka::INT_2D_VECTOR},
		{	"REAL_2D_VECTOR", &Data_reader_Kakaka::REAL_2D_VECTOR},
		{	"INT_3D_VECTOR", &Data_reader_Kakaka::INT_3D_VECTOR},
		{	"REAL_3D_VECTOR", &Data_reader_Kakaka::REAL_3D_VECTOR}//,{"VECTOR", &Data_reader_Kakaka::REAL_3D_VECTOR}

};

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::read () {
	bool in_file = true;
	while (in_file) {
		auto token = parser->get_val_token();
		if (token.kind == Kind::eof) break;
		if (token.kind == Kind::eol) continue;
		auto command = token.string_value;

		std::map<std::string,kkk::Dictionary>::iterator it;
		if (commands_map.count (command) == 0) {
			it = all_objects->dictionary.find(command);
			if (it == all_objects->dictionary.end())
				error->all (FILE_LINE_FUNC, "Data_reader_Kakaka : read : Invalid Kakaka command or object NAME");
			if (it->second.type == kkk::gdst("ELEMENT")) 
				in_file = all_objects->elements[it->second.index].read(parser);
			if (it->second.type == kkk::gdst("ATOM")) 
				in_file = all_objects->atoms[it->second.index].read(parser);
			if (it->second.type == kkk::gdst("MOLECULE")) 
				in_file = all_objects->molecules[it->second.index].read(parser);
			if (it->second.type == kkk::gdst("SHAPE")) 
				in_file = all_objects->shapes[it->second.index]->read(parser);
      if (it->second.type == kkk::gdst("RANDOM_1D")) 
				in_file = all_objects->random_1ds[it->second.index].read(parser);
      if (it->second.type == kkk::gdst("GRID_1D")) 
				in_file = all_objects->grid_1ds[it->second.index].read(parser);
      if (it->second.type == kkk::gdst("BOUNDARY")) 
				in_file = all_objects->boundaries[it->second.index].read(parser);													
      if (it->second.type == kkk::gdst("DISTRIBUTION")) 
				in_file = all_objects->distributions[it->second.index].read(parser);
		} else {
			in_file = (this->*commands_map.at(command)) ();
		}
	}
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::READ_FILE () {

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::ELEMENT () {
	output->info("Data_reader_Kakaka: Element creation");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double MASS = 0, RADIUS = 0, CHARGE = 0;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL(RADIUS,"ELEMENT: ","")
		else ASSIGN_REAL(MASS,"ELEMENT: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT: ","")
	}



	int index = all_objects->elements.size ();
	kkk::Element e_ (output, error,all_objects, MASS, RADIUS, CHARGE, index);
	all_objects->elements.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("ELEMENT"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"r: "<<RADIUS <<" m: " << MASS << "  ch: " << CHARGE << std::endl;
	return in_file;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::ATOM () {
	output->info("Data_reader_Kakaka: Atom creation");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> POSITION{0,0,0},VELOCITY{0,0,0};
	kkk::Molecule * FATHER = 0;
  int element_index = 0;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM: ","")
		if (token.string_value=="ELEMENT") {
		  std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,"Atom creation: "," expected an ELEMENT NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "Atom creation: ","")
		  if (it_1->second.type == kkk::gdst("ELEMENT")) {
		    element_index = it_1->second.index;
		  }	else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: Atom creation: undefined an ELEMENT NAME.. ");
		} 	
	}



	int index = all_objects->atoms.size ();
	kkk::Atom a_ (output, error, all_objects, FATHER, POSITION, VELOCITY, element_index);
	all_objects->atoms.push_back ( a_ );
	
	kkk::Dictionary dict (kkk::gdst("ATOM"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"p: "<<POSITION <<" v: " << VELOCITY <<  std::endl;
	return in_file;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::MOLECULE () {
	output->info("Data_reader_Kakaka: MOLECULE creation");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> POSITION{0,0,0},VELOCITY{0,0,0};
	kkk::Molecule * FATHER = 0;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL_3D_VECTOR(POSITION,"MOLECULE: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"MOLECULE: ","")
	}



	int index = all_objects->molecules.size ();
	kkk::Molecule M_ (output, error, all_objects, FATHER, POSITION, VELOCITY);
	all_objects->molecules.push_back ( M_ );
	
	kkk::Dictionary dict (kkk::gdst("MOLECULE"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"p: "<<POSITION <<" v: " << VELOCITY <<  std::endl;
	return in_file;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::ADD_ATOM () {
	output->info("Data_reader_Kakaka: ADD ATOM");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_ATOM: "," expected an atom or molecule NAME: ")

	std::map<std::string,kkk::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_ATOM: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_ATOM: "," Expected middle command: ")

	if (middle_command_1 == "TO_MOLECULE") {
		GET_A_STRING(name_2,"ADD_ATOM: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_ATOM: ","")
	}

  if (it_1->second.type != kkk::gdst("ATOM"))
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: ADD ATOM: expected an ATOM NAME: ");

  if (it_2->second.type != kkk::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: ADD ATOM: expected an MOLECULE NAME: ");
      
	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
		if (token.string_value == "AT_POSITION") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD ATOM: ","")\
		} else if (token.string_value == "AT_VELOCITY") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD ATOM: ","")\
		}
	}

	kkk::Atom a_new = all_objects->atoms[it_1->second.index];
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	all_objects->molecules[it_2->second.index].add_atom (a_new);
	return in_file;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::ADD_MOLECULE () {
	output->info("Data_reader_Kakaka: ADD MOLECULE");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_MOLECULE: "," expected an atom or molecule NAME: ")

	std::map<std::string,kkk::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_ATOM: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_MOLECULE: "," Expected middle command: ")

	if (middle_command_1 == "TO_MOLECULE") {
		GET_A_STRING(name_2,"ADD_ATOM: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_ATOM: ","")
	}

  if (it_1->second.type != kkk::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: ADD MOLECULE: expected an MOLECULE NAME: ");

  if (it_2->second.type != kkk::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: ADD MOLECUE: expected an MOLECULE NAME: ");


	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
		if (token.string_value == "AT_POSITION") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD MOLECULE: ","")\
		} else if (token.string_value == "AT_VELOCITY") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD MOLECULE: ","")\
		}
	}

	kkk::Molecule a_new = all_objects->molecules[it_1->second.index];	
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	all_objects->molecules[it_2->second.index].add_molecule(a_new);
	return in_file;
}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::INT_CONSTANT () {
	output->info("Data_reader_Kakaka: INT_CONSTANT creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double r;

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_NNT(r,"INT_CONSTANT: ","")
	}


	int index = all_objects->int_constants.size ();
	all_objects->int_constants.push_back (r);

	kkk::Dictionary dict (kkk::gdst("INT_CONSTANT"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	
	//std::cout <<"r: " << r << std::endl;
	return true;

}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::REAL_CONSTANT () {
	output->info("Data_reader_Kakaka: REAL_CONSTANT creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double r;

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_NNT(r,"REAL_CONSTANT: ","")
	}


	int index = all_objects->real_constants.size ();
	all_objects->real_constants.push_back (r);

	kkk::Dictionary dict (kkk::gdst("REAL_CONSTANT"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	
	//std::cout <<"r: " << r << std::endl;
	return true;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::INT_2D_VECTOR () {
	output->info("Data_reader_Kakaka: INT_2D_VECTOR creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<int> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_2D_VECTOR_NNT(v,"INT_2D_VECTOR: ","")
	}


	int index = all_objects->int_2d_vectors.size ();
	all_objects->int_2d_vectors.push_back (v);

	kkk::Dictionary dict (kkk::gdst("INT_2D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"i2d: " << v << std::endl;
	return true;
}

// ========================
// ========================
// ========================

bool Data_reader_Kakaka::REAL_2D_VECTOR () {
	output->info("Data_reader_Kakaka: REAL_2D_VECTOR creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<double> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_2D_VECTOR_NNT(v,"REAL_2D_VECTOR: " ,"")
	}


	int index = all_objects->real_2d_vectors.size ();
	all_objects->real_2d_vectors.push_back (v);

	kkk::Dictionary dict (kkk::gdst("REAL_2D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"r2d: " << v << std::endl;
	return true;
}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::INT_3D_VECTOR () {
	output->info("Data_reader_Kakaka: INT_3D_VECTOR creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<int> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_3D_VECTOR_NNT(v,"INT_3D_VECTOR: ","")
	}


	int index = all_objects->int_3d_vectors.size ();
	all_objects->int_3d_vectors.push_back (v);

	kkk::Dictionary dict (kkk::gdst("INT_3D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"i3d: " << v << std::endl;
	return true;
}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::REAL_3D_VECTOR () {
	output->info("Data_reader_Kakaka: REAL_3D_VECTOR creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_3D_VECTOR_NNT(v,"REAL_3D_VECTOR: ","")\

	}

	int index = all_objects->real_3d_vectors.size ();
	all_objects->real_3d_vectors.push_back (v);

	kkk::Dictionary dict (kkk::gdst("REAL_3D_VECTOR"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"r3d: " << v << std::endl;
	return true;
}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::RANDOM_1D () {
	output->info("Data_reader_Kakaka: Random_1D creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string TYPE;
	double MIN=0.0, MAX=1.0, STDDEV=1.0, MEAN=1.0;
	int SEED = 1;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_STRING(TYPE,"Random_1D creation: ","")
		else ASSIGN_REAL(MIN,"Random_1D creation: ","")
		else ASSIGN_REAL(MAX,"Random_1D creation: ","")
		else ASSIGN_REAL(STDDEV,"Random_1D creation: ","")
		else ASSIGN_REAL(MEAN,"Random_1D creation: ","")
		else ASSIGN_INT(SEED,"Random_1D creation: ","")	
		else error->all(FILE_LINE_FUNC,"Random_1D creation: Unknown variable or command ");
	}
	
  
	int e_type = all_objects->random_1ds.size ();
	kkk::Random_1D e_ (output, error, all_objects, TYPE, MIN, MAX, STDDEV, MEAN, SEED);
	all_objects->random_1ds.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("RANDOM_1D"), all_objects->random_1ds.size()-1);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	
	return in_file;

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::GRID_1D () {
	output->info("Data_reader_Kakaka: GRID_1D creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double MIN=0.0, MAX=1.0, INCREMENT=-1.0;
	int SEGMENT = -1;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL(MIN,"GRID_1D creation: ","")
		else ASSIGN_REAL(MAX,"GRID_1D creation: ","")
		else ASSIGN_REAL(INCREMENT,"GRID_1D creation: ","")
		else ASSIGN_INT(SEGMENT,"GRID_1D creation: ","")	
		else error->all(FILE_LINE_FUNC,"GRID_1D creation: Unknown variable or command ");
	}
	
  
	int e_type = all_objects->grid_1ds.size ();
	kkk::Grid_1D e_ (output, error, all_objects, MIN, MAX, INCREMENT, SEGMENT);
	all_objects->grid_1ds.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("GRID_1D"), all_objects->grid_1ds.size()-1);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));
	
	return in_file;

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::SHAPE () {
	output->info("Data_reader_Kakaka: Shape creation ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string shape_type = "";
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_A_STRING_NNT(shape_type,"Shape: ","")
	}

	kkk::shape::Shape * p_sh;	
	if (shape_type == "CIRCLE") {
		p_sh = new kkk::shape::Circle (output, error,all_objects); 
	} else if (shape_type == "SPHERE") {
		p_sh = new kkk::shape::Sphere (output, error,all_objects); 
	} else	if (shape_type == "CLOSED_LINES") {
		p_sh = new kkk::shape::Closed_lines (output, error,all_objects); 
	} else	if (shape_type == "VTK_FILE") {
		p_sh = new kkk::shape::Vtk_file (output, error,all_objects, md); 
	} else {
		error->all(FILE_LINE_FUNC,"NOT defined shape");
	}
	

	int index = all_objects->shapes.size ();
	all_objects->shapes.push_back (p_sh);

	kkk::Dictionary dict (kkk::gdst("SHAPE"), index);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	
	return in_file;

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::BOUNDARY () {
	output->info("Data_reader_Kakaka: Boundary creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
	}

	int e_type = all_objects->boundaries.size ();
	kkk::Boundary e_ (output, error,all_objects);

	all_objects->boundaries.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("BOUNDARY"), e_type);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::DISTRIBUTION () {
	output->info("Data_reader_Kakaka: Molecule distribution: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double MASS = 0, RADIUS = 0, CHARGE = 0;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
	}


	int e_type = all_objects->distributions.size ();
	kkk::Distribution e_ (output, error,all_objects);

	all_objects->distributions.push_back ( e_);
	
	kkk::Dictionary dict (kkk::gdst("DISTRIBUTION"), e_type);	
	all_objects->dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}

// ========================
// ========================
// ========================


bool Data_reader_Kakaka::OUTPUT_XYZ () {
	output->info("Data_reader_Kakaka: OUTPUT_XYZ: ");
  std::ofstream out_file;
  out_file.open("o_kakaka.xyz");

	bool in_file = true;
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;  	 
 		if (t=="MOLECULE") {
		  std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,"OUTPUT_XYZ: "," expected an MOLECULE or ATOM NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
		  if (it_1->second.type == kkk::gdst("ATOM")) {
		    all_objects->atoms[it_1->second.index].output_xyz (out_file);
		  }	else if (it_1->second.type == kkk::gdst("MOLECULE")) {
		    all_objects->molecules[it_1->second.index].output_xyz (out_file);
		  }	else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: OUTPUT_XYZ: expected an MOLECULE or ATOM NAME. ");
		} else  error->all(FILE_LINE_FUNC,"OUTPUT_XYZ: Unknown variable or command ");
  
  }
  
  out_file.close ();

  
	return in_file;

}
// ========================
// ========================
// ========================

