#include "data_reader_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"

//====================================
//====================================
//====================================


int kkk::gdst (const std::string & t) { //get_dictionary_second_type 
	std::map<std::string,int>::const_iterator it;
	it = kkk::dictionary_second_type.find(t);
	if (it == kkk::dictionary_second_type.end()) return 0;
	else return it->second;
}



// =============================
// =============================
// =============================

bool kkk::Element::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(RADIUS,"ELEMENT READ: ","")
		else ASSIGN_REAL(MASS,"ELEMENT READ: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT READ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: Unknown variable or command");		
	}
	
	return in_file;;
}

// =============================
// =============================
// =============================

bool kkk::Atom::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Atom read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM READ: ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: read: Unknown variable or command");
	}
	
	return in_file;;
}
// =============================
// =============================
// =============================

double kkk::Atom::get_radius () const {
  return all_objects->elements[element_index].get_radius();
}
// =============================
// =============================
// =============================

bool kkk::Molecule::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Molecule read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"MOLECULE READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"MOLECULE READ: ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Molecule: read: Unknown variable or command");
	}
	
	return in_file;;
}
//====================================
//====================================
//====================================
void kkk::Molecule::give_position_and_radius (std::vector<Vector<double>> &p_vector, std::vector<double> &r_vector) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].give_position_and_radius (p_vector, r_vector);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    r_vector.push_back (atoms[i].get_radius());
    p_vector.push_back (atoms[i].pos_tot());
  }  
}
//====================================
//====================================
//====================================
	kkk::Element::Element () {} ;
	kkk::Element::Element (Output * out, Error * err, All_objects * all_obj, double m, double r, double ch, int t) :
	output{out}, error{err},all_objects{all_obj}, MASS{m}, RADIUS{r}, CHARGE{ch}, type_number{t} {}; 

	kkk::Element::~Element () {};
//====================================
//====================================
//====================================

	kkk::Atom::Atom () : POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}},
	has_father{false}, FATHER{0} {};	
	kkk::Atom::Atom (Output * out, Error * err, All_objects * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel, int el_indx) : 
		 output{out}, error{err},all_objects{all_obj},POSITION{pos}, VELOCITY{vel},FATHER{f}, element_index{el_indx}  {}
	
 	kkk::Atom::~Atom () {};

	kkk::Atom::Atom (const Atom & a) : POSITION{a.POSITION}, VELOCITY{a.VELOCITY},
  has_father{false}, FATHER{0},
	element_index{a.element_index}, output{a.output}, error{a.error}, all_objects{a.all_objects} {};
	
//====================================
//====================================
//====================================

	kkk::Molecule::Molecule () : POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}},
	 has_father{false}, FATHER{0} {};
	kkk::Molecule::Molecule (Output * out, Error * err, All_objects * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel) : 
		 output{out}, error{err},all_objects{all_obj}, POSITION{pos}, VELOCITY{vel},FATHER{f}  {}
		
 	kkk::Molecule::~Molecule () {};
 	
	kkk::Molecule::Molecule (const Molecule & a) : POSITION{a.POSITION}, VELOCITY{a.VELOCITY},
  has_father{false}, FATHER{0},	
	output{a.output}, error{a.error}, all_objects{a.all_objects} 
	{
	  for (auto i : a.molecules) {
	    Molecule a_new (i);
	    a_new.has_father = true;
	    a_new.FATHER = this;
	    molecules.push_back (a_new);
	  }
	  for (auto i : a.atoms) {
	    Atom a_new (i);
	    a_new.has_father = true;
	    a_new.FATHER = this;	    
	    atoms.push_back (a_new);
	  }
	  	  
	};

// =============================
// =============================
// =============================
void kkk::Molecule::correct_heritage () {
	for (unsigned int i = 0; i < molecules.size(); ++i) {
	  molecules[i].FATHER = this;
	  molecules[i].has_father = true;
	  molecules[i].correct_heritage ();
	}	
	for (unsigned int i = 0; i < atoms.size(); ++i) {
	  atoms[i].FATHER = this;
	  atoms[i].has_father = true; 
	}
}

// =============================
// =============================
// =============================

void kkk::Molecule::output_xyz (std::ofstream & out_file) {

  for (unsigned int i = 0; i < molecules.size(); ++i) {
	  molecules[i].output_xyz (out_file);
	}
	for (unsigned int i = 0; i < atoms.size(); ++i) {
	  atoms[i].output_xyz (out_file);
	}
}

void kkk::Atom::output_xyz (std::ofstream & out_file) {

	const auto p = pos_tot();
	out_file << element_index << " " << p.x << " " << p.y << " " << p.z << std::endl;	

}
//====================================
//====================================
//====================================

Vector<double> kkk::Atom::pos_tot () const {
	if (has_father) return POSITION + FATHER->pos_tot();
 	else return POSITION;	 
}

Vector<double> kkk::Atom::vel_tot () const {
	if (has_father) return VELOCITY + FATHER->vel_tot();
	else return VELOCITY;		
}

Vector<double> kkk::Molecule::pos_tot () const {
	if (has_father) return POSITION + FATHER->pos_tot();
 	else return POSITION;	
}
Vector<double> kkk::Molecule::vel_tot () const {
	if (has_father) return VELOCITY + FATHER->vel_tot();
  else return VELOCITY;	
}

//====================================
//====================================
//====================================

bool kkk::Molecule::add_atom (const kkk::Atom &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].FATHER = this;
  atoms[i].has_father = true;
 	atoms[i].pos() = p;
	atoms[i].vel() = v;
}

bool kkk::Molecule::add_molecule (const kkk::Molecule &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].FATHER = this;
  molecules[i].has_father = true;
  molecules[i].pos() = p;
  molecules[i].vel() = v;  
}

bool kkk::Molecule::add_atom (const kkk::Atom & a){
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].FATHER = this;
  atoms[i].has_father = true;
}

bool kkk::Molecule::add_molecule (const kkk::Molecule & a){
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].FATHER = this;
  molecules[i].has_father = true;
}

//====================================
//====================================
//====================================

namespace kkk {

//====================================
//====================================
//====================================

	Random_1D::Random_1D () {};
  Random_1D::Random_1D (Output * out, Error * err, All_objects * all_obj, std::string type, double min, double max, double stddev, double mean, int seed) : 
  output{out}, error{err}, all_objects{all_obj}, MIN{min}, MAX{max}, STDDEV{stddev}, MEAN{mean}, TYPE{type}, SEED{seed}, generated{false} {
    type_int = 0;
    parser = all_objects->parser;
  }
  
	Random_1D::~Random_1D () {
//			delete ran_x,ran_y,ran_z;
//			delete n_dis_x,n_dis_y,n_dis_z;
//			delete u_dis_x,u_dis_y,u_dis_z;
		};
	bool Random_1D::read(Parser* parser) {
		output->info("Data_reader_Kakaka: Random Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="GENERATE") {generate(); break;}
      else ASSIGN_STRING(TYPE,"Random_1D creation: ","")
		  else ASSIGN_REAL(MIN,"Random_1D creation: ","")
		  else ASSIGN_REAL(MAX,"Random_1D creation: ","")
		  else ASSIGN_REAL(STDDEV,"Random_1D creation: ","")
		  else ASSIGN_REAL(MEAN,"Random_1D creation: ","")
		  else ASSIGN_INT(SEED,"Random_1D creation: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D creation: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Random_1D::generate () {
		output->info("Data_reader_Kakaka: Random Generate: ");	
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Random_1D: cannot be generated twice. ");
	  generated = true;
	  ran_gen = new std::mt19937 (SEED);
	  if (TYPE=="UNIFORM") {
	    type_int = 1;
    	u_dist = new std::uniform_real_distribution<> (MIN, MAX) ;
    } else if (TYPE=="NORMAL") {
      type_int = 2;
    	n_dist = new std::normal_distribution<> (MEAN, STDDEV);
    } else error->all (FILE_LINE_FUNC, "RANDOM_1D generate: Expected NORMAL or UNIFORM for the type. ");
	}
	

//====================================
//====================================
//====================================

	Grid_1D::Grid_1D () {};
  Grid_1D::Grid_1D (Output * out, Error * err, All_objects * all_obj, double min, double max, double increment, int segment) : 
  output{out}, error{err}, all_objects{all_obj}, MIN{min}, MAX{max}, INCREMENT{increment}, SEGMENT{segment}, generated{false},by_increment{false}, by_segment{false}, no_given_points{0} {
    parser = all_objects->parser;
  }
  
	Grid_1D::~Grid_1D () {
		};
	bool Grid_1D::read(Parser* parser) {
		output->info("Data_reader_Kakaka: GRID_1D Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="GENERATE") {generate(); break;}		  
		  else ASSIGN_REAL(MIN,"GRID_1D Read: ","")
		  else ASSIGN_REAL(MAX,"GRID_1D Read: ","")
		  else ASSIGN_REAL(INCREMENT,"GRID_1D Read: ","")
		  else ASSIGN_INT(SEGMENT,"GRID_1D Read: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D Read: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Grid_1D::generate () {
		output->info("Data_reader_Kakaka: Grid_1d Generate: ");		
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Grid_1D: cannot be generated twice. ");
	  generated = true;
    if (SEGMENT>0 && INCREMENT>0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assigning both SEGMENT and INCREMENT is not possible. ");
    if (SEGMENT<0 && INCREMENT<0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assign one of SEGMENT or INCREMENT. ");
	  if (MIN > MAX)
	    error->all(FILE_LINE_FUNC,"Grid_1D: MIN has to be smaller than MAX. ");	  
	  if (SEGMENT<0) {
	    by_increment = true;
	    SEGMENT = int ((MAX-MIN)/INCREMENT);
	  }
	  if (INCREMENT<0) {
	    by_segment = true;
	    INCREMENT = (MAX - MIN)/double(SEGMENT);
	  }
	}
	
	int Grid_1D::no_points () {
	
	  if (by_segment)
	    return SEGMENT + 1;
	  else
	    return SEGMENT;
	}
	
	double Grid_1D::give_point () {
    double val = MIN + no_given_points * INCREMENT;
	  ++no_given_points;    
	  if (by_segment) {
	    if (no_given_points > SEGMENT) return MAX;
	    else return val;
	  } else {
      return val;	  
	  }
	}
	
  double Grid_1D::give_point (int i) {
    double val = MIN + i * INCREMENT;  
	  if (by_segment) {
	    if (i == SEGMENT) return MAX;
	    else return val;
	  } else {
      return val;	  
	  }
	}
//====================================
//====================================
//====================================

  Boundary::Boundary () {};
  Boundary::Boundary (Output * out, Error * err, All_objects * all_obj) :
   output{out}, error{err}, all_objects{all_obj}
  {
    parser = all_objects->parser;
  };
    
  Boundary::~Boundary () {};	
  
  bool Boundary::read (Parser* parser) {

		output->info("Data_reader_Kakaka: BOUNDARY Read: ");
		bool in_file = true;

#define AND_OR_INSIDE_OUTSIDE \
if (shapes.size() == 0) {\
  if (t=="INSIDE") inside_check = true;\
  else if (t=="OUTSIDE") inside_check = false;\
  else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected 'INSIDE' or 'OUTSIDE': ");\
} else if (t=="INSIDE" || t=="OUTSIDE")\
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected 'AND_INSIDE','AND_OUTSIDE', 'OR_INSIDE','OR_OUTSIDE': ");\
std::map<std::string,kkk::Dictionary>::iterator it_1;\
std::string name_1;\
GET_A_STRING(name_1,"BOUNDARY Read: "," expected an BOUNDARY or SHAPE NAME: ")\
CHECK_NAME_EXISTANCE(name_1, it_1, "BOUNDARY Read: ","")\
if (it_1->second.type == kkk::gdst("BOUNDARY"))\
	shapes.push_back(&all_objects->boundaries[it_1->second.index]);\
else if (it_1->second.type == kkk::gdst("SHAPE"))\
	shapes.push_back(all_objects->shapes[it_1->second.index]);\
else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected an BOUNDARY or SHAPE NAME: ");
		  	  
		while(true) {
		
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="INSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0);  //inside_check = true	 	
		  } else if (t=="OUTSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0); //inside_check = flase	 	 	 	
		  } else if (t=="AND_INSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (1);  	 	
		  } else if (t=="AND_OUTSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-1);
		  }	else if (t=="OR_INSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (2);
		  }	else if (t=="OR_OUTSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-2);
		  }		  	  	  
		  else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: Unknown variable or command ");
	  }
		return in_file;;
#undef AND_OR_INSIDE_OUTSIDE
	}
  
  bool Boundary::is_inside (const Vector<double> &v) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v);
    else tmp = !shapes[0]->is_inside(v);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  bool Boundary::is_inside (const Vector<double> &v, const double r) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v, r);
    else tmp = !shapes[0]->is_inside(v, r);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v, r) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v, r) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v, r) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v, r) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  
  bool Boundary::is_outside (const Vector<double> &v) {
    return !is_inside(v);
  }
  
    bool Boundary::is_outside (const Vector<double> &v, const double r) {
    return !is_inside(v, r);
  }
	//bool Boundary::is_all (const Vector<double> &v) {
	//  return is_inside (v);
	/*
	  if (inside_check)
	    return is_inside (v);
	  else
	    return is_outside (v);*/
	//}
	
//====================================
//====================================
//====================================
  Distribution::Distribution () {};	
  
  Distribution::Distribution (Output * out, Error * err, All_objects * all_obj) :
   output{out}, error{err}, all_objects{all_obj},boundary_check{false},
    a_object_check{false}, m_object_check{false}, container_check{false}
  {
    parser = all_objects->parser;
  };
  
  Distribution::~Distribution () {};		
  
  bool Distribution::read (Parser* parser) {
		output->info("Data_reader_Kakaka: DISTRIBUTION Read: ");
		bool in_file = true;
		

		
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="BOUNDARY") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an BOUNDARY NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type != kkk::gdst("BOUNDARY"))
          error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined BOUNDARY NAME. ");
        boundary = &all_objects->boundaries[it_1->second.index];
        boundary_check = true;
		  }	
		  else if (t=="OBJECT") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an MOLECULE or ATOM NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("ATOM")) {
          a_object_check = true;        
          a_object = &all_objects->atoms[it_1->second.index];          
        } else if (it_1->second.type == kkk::gdst("MOLECULE")) {
          m_object_check = true;
          m_object = &all_objects->molecules[it_1->second.index];                            
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined MOLECULE or ATOM NAME. ");

		  }			  
		  else if (t=="CONTAINER") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an MOLECULE NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("MOLECULE")) {
          container = &all_objects->molecules[it_1->second.index];        
          container_check = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined MOLECULE NAME. ");
		  }			  		  
		  else if (t=="DISTRIBUTE_GRID_3D") {distribute_grid_3D(); break;}		  
		  else if (t=="DISTRIBUTE_RANDOM_3D") {distribute_random_3D(); break;}		  		  
		  else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	bool Distribution::distribute_grid_3D() {
	  output->info("Data_reader_Kakaka: DISTRIBUTE_GRID_3D: ");
		bool in_file = true;

		kkk::Grid_1D   *pos_grid_X, *pos_grid_Y, *pos_grid_Z;
		
		bool pos_grid_check_X=false, pos_grid_check_Y=false, pos_grid_check_Z=false;

		
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="POSITION_X") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_GRID_3D: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_X = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_X = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined  GRID_1D NAME. ");
		  } else if (t=="POSITION_Y") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_Y = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_Y = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined  GRID_1D NAME. ");
		  }	 else  if (t=="POSITION_Z") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_Z = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_Z = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined GRID_1D NAME. ");
		  } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: Unknown variable or command ");
		}
		
		std::vector<double> r_vector; // radius of atoms
		std::vector<Vector<double>> p_vector; // total positions of atoms
	  if (a_object_check) {
	    r_vector.push_back (a_object->get_radius());
	    p_vector.push_back (a_object->pos_tot());
	  }
	  if (m_object_check) {
	    m_object->give_position_and_radius (p_vector, r_vector);
	  }

	    
		for (unsigned int i = 0; i < pos_grid_X->no_points(); ++i) {
		  double x = pos_grid_X->give_point(i);
		  for (unsigned int j = 0; j < pos_grid_Y->no_points(); ++j) {
		    double y = pos_grid_Y->give_point(j);		  
		    for (unsigned int k = 0; k < pos_grid_Z->no_points(); ++k) {	
		      double z = pos_grid_Z->give_point(k);		      
		      const Vector<double> p {x,y,z}, v{0,0,0};
		      
		      /* // simple method - just center is inside condition
		      if (boundary->is_inside(p)) {
            if (a_object_check)
              container->add_atom (*a_object, p, v);
            if (m_object_check)
              container->add_molecule (*m_object, p, v);
          }*/
          
          // 
          bool inside_flag = true;
          for (unsigned int m = 0; m<r_vector.size(); ++m)
            if (!boundary->is_inside(p + p_vector[m], r_vector[m])) {
              inside_flag = false;
              continue;
            }
            
		      if (inside_flag) {
            if (a_object_check)
              container->add_atom (*a_object, p, v);
            if (m_object_check)
              container->add_molecule (*m_object, p, v);
          }
          
		    }
		  }
		}
		
		container -> correct_heritage ();
		
		return in_file;
	}
	



	
	bool Distribution::distribute_random_3D() {
	  output->info("Data_reader_Kakaka: DISTRIBUTE_RANDOM_3D: ");
		bool in_file = true;

		kkk::Random_1D *pos_rand_X, *pos_rand_Y, *pos_rand_Z;		
		
		bool pos_rand_check_X=false, pos_rand_check_Y=false, pos_rand_check_Z=false;		
		
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="POSITION_X") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_X = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_X = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
		  } else if (t=="POSITION_Y") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_Y = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_Y = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D NAME. ");
		  }	 else  if (t=="POSITION_Z") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_Z = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_Z = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
		  } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: Unknown variable or command ");
		}
		
		
		

		  
		return in_file;
	}
	



}


//====================================
//====================================
//====================================

  kkk::All_objects::~All_objects () {
    for (auto i :shapes)
      delete i;
  }


