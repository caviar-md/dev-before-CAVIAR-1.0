#ifndef WRITER_H
#define WRITER_H

#include "pointers.h"

class Writer : protected Pointers {
public:
  Writer (class MD *);
private:
  
};

#endif
