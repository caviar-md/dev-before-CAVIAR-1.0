#ifndef KAKAKA_SHAPE_VTK_H
#define KAKAKA_SHAPE_VTK_H

#include "pointers.h"

#include <vector>
#include <map>

#include "vector.h"
#include "polyhedron.h"
#include "kakaka_shape.h"
#include "output.h"
#include "error.h"

#include "md.h"

namespace kkk {

	class All_objects;

namespace shape {


class Vtk_file : public Shape {
	public:
	Vtk_file (Output * , Error *, All_objects *, MD *);
	~Vtk_file ();

	bool is_inside (const Vector<double> &v);
	bool read(Parser *);	

//	void read_unv (const std::string &); // read unv format // IT HAS SOME BUGS
	void read_vtk (const std::string &); // read vtk format // There's many unneeded points. 

	void make_grid (int); // contains the faces neccesary to check
										 // make_grid has to be called after lowest_highest_coord()

	void lowest_highest_coord (int); // calculates gxlo, gxhi, gylo...

	void make_normal (int); // after reading unv file, it calculates normal vectors
	void make_edge_norms (int); // makes normals of faces made of edges and other normals used in check_inside() algorithm. 
	void pre_correct_normals (int); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.
	void merge_vertices (int); // It checks if the two vertices are similar.Then makes a map of all vertices to the similar ones with the lower index
	void invert_normals (int); // multiply all the normal Vectors with -1

	void check_inside (const Vector<Real_t> &, const Real_t, Vector<Real_t> &, int); // different algorithms
	bool check_inside (const Vector<Real_t> &, const Real_t); // different algorithms // true or false
	bool check_inside_ray (const Vector<Real_t> &v1, const int ray_axis);

//	void invert_normals (); // invert all the normals in case needed

	void pre_execute (); // call some functions and pre-calculate grids and so...
	bool set_parameters (class Parser *); //called by command script
	bool Vtk_file_force;
	bool make_invert_normals;

	void output_mesh_povray (); // povray output mesh ".pov"
	void output_mesh_vmd (); // vmd output mesh ".tcl"
	void output_normals_vmd (); // vmd output normals ".tcl"
	void output_edges_vmd (); // vmd output edges  ".tcl"


	std::vector<Namespace_Geometry::Polyhedron> shapes; // include imported shapes.  // it is public in order to be used at "output.cpp"
		Output * output;
		Error * error;
		All_objects * all_objects;
		MD * md;
	  private:




};
}
}
#endif
