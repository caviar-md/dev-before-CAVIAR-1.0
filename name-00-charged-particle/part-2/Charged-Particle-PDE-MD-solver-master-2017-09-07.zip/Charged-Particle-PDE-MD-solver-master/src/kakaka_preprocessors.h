// used in data_reader_kakaka.cpp

#define GET_A_TOKEN_FOR_CREATION \
	auto token = parser->get_val_token(); \
	if (token.kind == Kind::eol) break; \
	if (token.kind == Kind::eof) {in_file = false; break;} 

// ==================== 
// ==================== NAME ASSIGN
// ====================


#define NAME_ASSIGN_CHECK(VARIABLE) \
{\
	if (VARIABLE.kind != Kind::identifier)  \
		error->all (FILE_LINE_FUNC, "expected string for NAME");\
	auto name = VARIABLE.string_value;\
	if (commands_map.count (name) == 1) \
		error->all (FILE_LINE_FUNC, "This NAME is reserved as Kakaka command");\
	if (all_objects->all_names.count (name) == 1) \
		error->all (FILE_LINE_FUNC, "This NAME is used before and cannot be re-assigned to other objects");\
}

#define ASSIGN_NAME \
	if (!name_called) {\
		name_called = true;\
		NAME_ASSIGN_CHECK(token)\
		NAME = token.string_value;\
		all_objects->all_names.insert(NAME);\
	}

#define ASSIGN_NAME_WITHOUT_KEYWORD \
	if (name_called==false) { \
		NAME_ASSIGN_CHECK(token)	\
		NAME = token.string_value; \
		name_called = true; \
	} else { \
		error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Unknown variable or command"); \
	} 

// ===========================
// ===========================
// ===========================

#define GET_A_STRING_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.kind != Kind::identifier) {\
		std::string error_massage = "Data_reader_Kakaka: ";\
		error_massage.append(FUNCTION_NAME);	\
		error_massage.append(ERROR_MASSAGE); \
		error_massage.append(#VARIABLE);	\
		error->all (FILE_LINE_FUNC, error_massage );\
	}\
	VARIABLE = token.string_value; \

#define GET_A_STRING(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
{\
	auto token = parser->get_val_token(); \
	GET_A_STRING_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
}


#define CHECK_NAME_EXISTANCE(VARIABLE,ITERATOR,FUNCTION_NAME,ERROR_MASSAGE) \
{ \
	ITERATOR = all_objects->dictionary.find(VARIABLE); \
	if (ITERATOR == all_objects->dictionary.end()) 	{\
		std::string error_massage = "Data_reader_Kakaka: ";\
		error_massage.append(FUNCTION_NAME);	\
		error_massage.append(ERROR_MASSAGE); \
		error_massage.append("Undefined object NAME: ");	\
		error_massage.append(VARIABLE);	\
		error->all (FILE_LINE_FUNC, error_massage );\
	}\
}
// NNT : NO_NEW_TOKEN

#define GET_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
if (token.kind == Kind::real_number)\
	VARIABLE = token.real_value;\
else if (token.kind == Kind::int_number)\
	VARIABLE = token.int_value;\
else {\
		std::string error_massage = "Data_reader_Kakaka: ";\
		error_massage.append(FUNCTION_NAME);	\
		error_massage.append(ERROR_MASSAGE); \
		error_massage.append("Expected a real number as ");	\
		error_massage.append(#VARIABLE);	\
		error->all (FILE_LINE_FUNC, error_massage );\
	}\



#define GET_A_REAL(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
{\
	auto token = parser->get_val_token(); \
	GET_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}

#define GET_OR_CHOOSE_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("INT_CONSTANT")) { \
				VARIABLE = all_objects->int_constants[it->second.index];\
			} else if (it->second.type == kkk::gdst("REAL_CONSTANT")) { \
				VARIABLE = all_objects->real_constants[it->second.index];\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(token.string_value);\
				error_massage.append(" is not referred to a real or int number ");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
	GET_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	}

#define GET_OR_CHOOSE_A_REAL(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}


#define GET_A_INT_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind != Kind::int_number) {\
		std::string error_massage = "Data_reader_Kakaka: ";\
		error_massage.append(FUNCTION_NAME);	\
		error_massage.append(ERROR_MASSAGE); \
		error_massage.append("Expected an int number as ");	\
		error_massage.append(#VARIABLE);	\
		error->all (FILE_LINE_FUNC, error_massage );\
	}\
	VARIABLE = token.int_value; 


#define GET_A_INT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_A_INT_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}



#define GET_OR_CHOOSE_A_INT_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("INT_CONSTANT")) { \
				VARIABLE = all_objects->int_constants[it->second.index];\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(token.string_value);\
				error_massage.append(" is not referred to a int number ");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
		GET_A_INT_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	}

#define GET_OR_CHOOSE_A_INT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_REAL_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}


// ======================================
// ======================================  2D VECTORS
// ======================================

#define GET_OR_CHOOSE_A_REAL_2D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("REAL_2D_VECTOR")) { \
				VARIABLE = all_objects->real_2d_vectors[it->second.index];\
			} else if (it->second.type == kkk::gdst("INT_CONSTANT") || it->second.type == kkk::gdst("REAL_CONSTANT")){ \
				auto &vx = VARIABLE.x;\
				auto &vy = VARIABLE.y;\
				GET_OR_CHOOSE_A_REAL_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_REAL(vy,FUNCTION_NAME,ERROR_MASSAGE)\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(" expected real number or a 2D vector NAME");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
		auto &vx = VARIABLE.x;\
		auto &vy = VARIABLE.y;\
		GET_OR_CHOOSE_A_REAL_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_REAL(vy,FUNCTION_NAME,ERROR_MASSAGE)\
	}



#define GET_OR_CHOOSE_A_REAL_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_REAL_2D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}


#define GET_OR_CHOOSE_A_INT_2D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("INT_2D_VECTOR")) { \
				VARIABLE = all_objects->int_2d_vectors[it->second.index];\
			} else if (it->second.type == kkk::gdst("INT_CONSTANT") ){ \
				auto &vx = VARIABLE.x;\
				auto &vy = VARIABLE.y;\
				GET_OR_CHOOSE_A_INT_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_INT(vy,FUNCTION_NAME,ERROR_MASSAGE)\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(" expected int number or a 2D vector NAME");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
		auto &vx = VARIABLE.x;\
		auto &vy = VARIABLE.y;\
		GET_OR_CHOOSE_A_INT_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_INT(vy,FUNCTION_NAME,ERROR_MASSAGE)\
	}


#define GET_OR_CHOOSE_A_INT_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_INT_2D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}


// ======================================
// ======================================  3D VECTORS
// ======================================

#define GET_OR_CHOOSE_A_REAL_3D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("REAL_3D_VECTOR")) { \
				VARIABLE = all_objects->real_3d_vectors[it->second.index];\
			} else if (it->second.type == kkk::gdst("INT_CONSTANT") || it->second.type == kkk::gdst("REAL_CONSTANT")){ \
				auto &vx = VARIABLE.x;\
				auto &vy = VARIABLE.y;\
				auto &vz = VARIABLE.z;\
				GET_OR_CHOOSE_A_REAL_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_REAL(vy,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_REAL(vz,FUNCTION_NAME,ERROR_MASSAGE)\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(" expected real number or a 3D vector NAME");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
		auto &vx = VARIABLE.x;\
		auto &vy = VARIABLE.y;\
		auto &vz = VARIABLE.z;\
		GET_OR_CHOOSE_A_REAL_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_REAL(vy,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_REAL(vz,FUNCTION_NAME,ERROR_MASSAGE)\
	}



#define GET_OR_CHOOSE_A_REAL_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_REAL_3D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}


#define GET_OR_CHOOSE_A_INT_3D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
	if (token.kind == Kind::identifier) {\
		std::map<std::string,kkk::Dictionary>::iterator it;\
		it = all_objects->dictionary.find(token.string_value);\
		if (it == all_objects->dictionary.end()) { \
			std::string error_massage = "Data_reader_Kakaka: ";\
			error_massage.append(FUNCTION_NAME);	\
			error_massage.append(ERROR_MASSAGE); \
			error_massage.append("Invalid object NAME ");	\
			error_massage.append(#VARIABLE);	\
			error->all (FILE_LINE_FUNC, error_massage );\
		} else {\
			if (it->second.type == kkk::gdst("INT_3D_VECTOR")) { \
				VARIABLE = all_objects->int_3d_vectors[it->second.index];\
			} else if (it->second.type == kkk::gdst("INT_CONSTANT") ){ \
				auto &vx = VARIABLE.x;\
				auto &vy = VARIABLE.y;\
				auto &vz = VARIABLE.z;\
				GET_OR_CHOOSE_A_INT_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_INT(vy,FUNCTION_NAME,ERROR_MASSAGE)\
				GET_OR_CHOOSE_A_INT(vz,FUNCTION_NAME,ERROR_MASSAGE)\
			} else {\
				std::string error_massage = "Data_reader_Kakaka: ";\
				error_massage.append(FUNCTION_NAME);	\
				error_massage.append(ERROR_MASSAGE); \
				error_massage.append(" expected int number or a 3D vector NAME");	\
				error->all (FILE_LINE_FUNC, error_massage );\
			}\
		}\
	} else {\
		auto &vx = VARIABLE.x;\
		auto &vy = VARIABLE.y;\
		auto &vz = VARIABLE.z;\
		GET_OR_CHOOSE_A_INT_NNT(vx,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_INT(vy,FUNCTION_NAME,ERROR_MASSAGE)\
		GET_OR_CHOOSE_A_INT(vz,FUNCTION_NAME,ERROR_MASSAGE)\
	}


#define GET_OR_CHOOSE_A_INT_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
{\
	auto token = parser->get_val_token(); \
	GET_OR_CHOOSE_A_INT_3D_VECTOR_NNT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE)\
}

//===========
//=========== VARIABLE ASSIGN
//===========
#define ASSIGN_STRING(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_A_STRING(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 
	
#define ASSIGN_REAL(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_REAL(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 

#define ASSIGN_INT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_INT(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 

#define ASSIGN_REAL_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_REAL_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 

#define ASSIGN_INT_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_INT_2D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 



#define ASSIGN_REAL_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_REAL_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 

#define ASSIGN_INT_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	if (token.string_value == #VARIABLE) { \
		GET_OR_CHOOSE_A_INT_3D_VECTOR(VARIABLE,FUNCTION_NAME,ERROR_MASSAGE) \
	} 
// ======================
