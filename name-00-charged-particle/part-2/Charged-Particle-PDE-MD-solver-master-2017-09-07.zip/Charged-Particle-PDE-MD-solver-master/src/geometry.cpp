#include "geometry.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"

Geometry::Geometry (MD *md) : Pointers{md}, geometry_force{false}{}

Geometry::~Geometry () { }

bool Geometry::set_parameters (Parser *parser) {
	int shape_index = shapes.size() - 1;
	if (shape_index < 0) 
		error->all(FILE_LINE_FUNC, "no geometry is imported yet.");
	auto param_ident = parser->get_identifier();
	if (param_ident == "thickness") {
		auto thickness_ = parser->get_literal_real();
		shapes[shape_index].thickness = thickness_;
		std::cout << "info: geometry: parameters: shape " << shape_index << " : thickness = " << thickness_ << std::endl;
	} else if (param_ident == "young_modulus") {
		auto young_modulus_ = parser->get_literal_real();
		shapes[shape_index].young_modulus = young_modulus_;
		std::cout << "info: geometry: parameters: shape " << shape_index << " : young_modulus = " << young_modulus_ << std::endl;
	} else if (param_ident == "radius") {
		auto radius_ = parser->get_literal_real();
		shapes[shape_index].radius.push_back (radius_);
		if (shapes[shape_index].grid_toll<radius_) shapes[shape_index].grid_toll = radius_;
		std::cout << "info: geometry: parameters: shape " << shape_index << " : radius = " << radius_ << " for atom type " << shapes[shape_index].radius.size() << std::endl;
	} else if (param_ident == "invert_normals") {
		shapes[shape_index].invert_normals = true;
		std::cout << "info: geometry: parameters: shape " << shape_index << " : invert_normals " << std::endl;
	} else if (param_ident == "grid") {
		auto nx_ = parser->get_literal_int();
		auto ny_ = parser->get_literal_int();
		auto nz_ = parser->get_literal_int();
		if (nx_ < 1 || ny_ < 1 || nz_ < 1) error->all(FILE_LINE_FUNC, "grids has to be larger than 1");
		shapes[shape_index].nx_part = nx_; 
		shapes[shape_index].nx_part = ny_;
		shapes[shape_index].nx_part = nz_;
		std::cout << "info: geometry: parameters: shape " << shape_index << " : grid " << nx_ << " " << ny_ << " " << nz_ << std::endl;
	} else {
  	error->all (FILE_LINE_FUNC, "invalid syntax: this geometry parameter does not exists");
	}
}

void  Geometry::pre_execute () {
	geometry_force = true;
	for (int i = 0; i < shapes.size(); ++i) { 
		output->info_ne("geometry: pre_execute : preprocessing shape ");
		output->comment(i);
		output->comment(" ...\n");
		output->info_ne("geometry: pre_execute : lowest_highest_coord : ");
		lowest_highest_coord (i);

		output->info("geometry: pre_execute : pre_correct_normals");
		pre_correct_normals (i);

		output->info("geometry: pre_execute : make_normal");
		make_normal (i);

		output->info("geometry: pre_execute : make_edge_norms");
		make_edge_norms (i);

		if (shapes[i].invert_normals) {
			output->info("geometry: pre_execute : invert_normals");
			invert_normals (i);
		}
		output->info("geometry: pre_execute : make_grid");
		make_grid (i);

		output->info_ne("geometry: pre_execute : preprocessing shape ");
		output->comment(i);
		output->comment(" finished.\n");
	}

	output->info_ne("geometry: pre_execute : output-> ");

	output->comment("mesh_povray, ");
	output_mesh_povray (); // povray output mesh

	output->comment("mesh_vmd, ");
	output_mesh_vmd (); // vmd output mesh

	output->comment("normals_vmd, ");
	output_normals_vmd ();

	output->comment("edges_vmd\n");
	output_edges_vmd ();

}

void Geometry::output_mesh_povray () {
	std::ofstream pov_file ("o_mesh.pov");
	for (int shape_index=0; shape_index < shapes.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;


		pov_file <<"\nmesh {\n";
		for (int i=0;i<face.size();++i) {
			pov_file << "\ttriangle { ";
			pov_file << "<" << vertex[face[i][0]].x << "," << vertex[face[i][0]].y  << "," << vertex[face[i][0]].z << ">," ;
			pov_file << "<" << vertex[face[i][1]].x << "," << vertex[face[i][1]].y  << "," << vertex[face[i][1]].z << ">,";
			pov_file << "<" << vertex[face[i][2]].x << "," << vertex[face[i][2]].y  << "," << vertex[face[i][2]].z << "> }\n";
		}
		pov_file << "\ttexture {\n\t\tpigment { color rgb<0.9, 0.9, 0.9> }";
		pov_file << "\n\t\tfinish { ambient 0.2 diffuse 0.7 }\n\t}\n";	
		pov_file << "}";
		pov_file << std::flush;
	}
	pov_file.close ();
}

void Geometry::output_normals_vmd () {
	std::ofstream vmd_file ("o_normals.tcl");
	for (int shape_index=0; shape_index < shapes.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;
		const auto & normal = shapes[shape_index].normal;

		Real_t vec_length = 5.0;
		Real_t vec_rad = 1.5;

		for (int i=0;i<face.size();++i) {
			Vector<Real_t> cr = {(vertex[face[i][0]].x + vertex[face[i][1]].x + vertex[face[i][2]].x)/3.0, 
														(vertex[face[i][0]].y + vertex[face[i][1]].y + vertex[face[i][2]].y)/3.0,
														(vertex[face[i][0]].z + vertex[face[i][1]].z + vertex[face[i][2]].z)/3.0};

			Vector<Real_t> di = cr + vec_length*normal[i];
			cr -=  (vec_length/10.0) * normal[i];

			vmd_file << "graphics top cone ";
			vmd_file << "{" << cr.x << " " << cr.y  << " " << cr.z << "} ";
			vmd_file << "{" << di.x << " " << di.y  << " " << di.z << "} ";
			vmd_file << "radius " << vec_rad << " resolution 5\n";
		}
		vmd_file << std::flush;
	}
	vmd_file.close ();
}

void Geometry::output_edges_vmd () {
	std::ofstream vmd_file ("o_edges.tcl");
	for (int shape_index=0; shape_index < shapes.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & edges = shapes[shape_index].edges;

		Real_t frame_rad = 0.5;
		std::map<std::vector<int>,std::vector<int>>::const_iterator it;
		for (it = edges.begin(); it != edges.end(); ++it) {

			vmd_file << "graphics top cylinder ";
			vmd_file << "{" << vertex[it->first[0]].x << " " << vertex[it->first[0]].y  << " " << vertex[it->first[0]].z << "} " ;
			vmd_file << "{" << vertex[it->first[1]].x << " " << vertex[it->first[1]].y  << " " << vertex[it->first[1]].z << "} " ;
			vmd_file << "radius " << frame_rad << " resolution " << 5 << " filled yes\n";
		}
		vmd_file << std::flush;
	}
	vmd_file.close ();
}


void Geometry::output_mesh_vmd () {
	std::ofstream vmd_file ("o_mesh.tcl");
	for (int shape_index=0; shape_index < shapes.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;

		for (int i=0;i<face.size();++i) {
			vmd_file << "graphics top triangle ";
			vmd_file << "{" << vertex[face[i][0]].x << " " << vertex[face[i][0]].y  << " " << vertex[face[i][0]].z << "} " ;
			vmd_file << "{" << vertex[face[i][1]].x << " " << vertex[face[i][1]].y  << " " << vertex[face[i][1]].z << "} ";
			vmd_file << "{" << vertex[face[i][2]].x << " " << vertex[face[i][2]].y  << " " << vertex[face[i][2]].z << "}\n";
		}

		vmd_file << std::flush;
	}
	vmd_file.close ();
}


void Geometry::invert_normals (int shape_index) {
	auto & normal = shapes[shape_index].normal;
	for (int i=0;i<normal.size();++i)
		normal[i] *= -1;
}

void Geometry::calculate_acceleration () {
	if (!geometry_force) return;
  const auto &pos = atom_data -> owned.position;
	auto &acc = atom_data -> owned.acceleration;
	for (int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] - 1;	
	  const auto mass_i = atom_data -> owned.mass [ type_i ];	
		for (int j=0; j<shapes.size();++j) {
			Vector <Real_t> f {0,0,0};
			const auto rad = shapes[j].radius [type_i];
			check_inside (pos[i], rad, f, j);
			acc[i] -= f*shapes[j].young_modulus/mass_i;
		}
	}
}

void Geometry::make_edge_norms (int shape_index) {
	const auto & vertex = shapes[shape_index].vertex;
	const auto & face = shapes[shape_index].face;
	const auto & edges = shapes[shape_index].edges;
	const auto & normal = shapes[shape_index].normal;
	auto & edge_norms3 = shapes[shape_index].edge_norms3;

	std::vector<std::vector<Vector<Real_t>>> edge_norms1, edge_norms2;
	std::map<std::vector<int>,std::vector<int>>::const_iterator it_edges; 
	const int fsize = face.size();
	edge_norms1.resize (fsize);	
	edge_norms2.resize (fsize);	
	edge_norms3.resize (fsize);
	for (int i=0;i<fsize;++i) {
		for (int j=0;j<face[i].size();++j) {
			Vector<Real_t> n1 = normal[i];
			int k0 = j; int k1 = (j==face[i].size()-1) ? 0 : j+1;
			int v0 = face[i][k0]; int v1 = face[i][k1];
			if (v0<v1) 
				it_edges = edges.find (std::vector<int>{v0,v1});
			else
				it_edges = edges.find (std::vector<int>{v1,v0});
			if (it_edges->second.size() == 2) {
				if (it_edges->second[0] != i )
					n1 += normal [it_edges->second[0]];
				else
					n1 += normal [it_edges->second[1]];
			}
			n1 /= std::sqrt (n1*n1); // it is not necessary
			edge_norms1[i].push_back (n1);
//-------
			Vector<Real_t> n2 = vertex[face[i][k1]] - vertex[face[i][k0]];		
			n2 /= std::sqrt (n2*n2); // it is not necessary
			edge_norms2[i].push_back (n2);
//-------
			Vector<Real_t> n3 = cross_product (n1,n2);
			n3 /= std::sqrt (n3*n3); // it is not necessary
			edge_norms3[i].push_back (n3);		
		}
	}


}

void Geometry::lowest_highest_coord (int shape_index) {
	const auto & vertex = shapes[shape_index].vertex;
	const auto & toll = shapes[shape_index].grid_toll;
	auto & xlo = shapes[shape_index].xlo;
	auto & xhi = shapes[shape_index].xhi;
	auto & ylo = shapes[shape_index].ylo;
	auto & yhi = shapes[shape_index].yhi;
	auto & zlo = shapes[shape_index].zlo;
	auto & zhi = shapes[shape_index].zhi;
	
/*
	if (!g_coordinates_init) {
		g_coordinates_init = true;
		gxlo = vertex[0].x;	gylo = vertex[0].y;
		gzlo = vertex[0].z;	gxhi = vertex[0].x;
		gyhi = vertex[0].y;	gzhi = vertex[0].z;
	}
	*/
		xlo = vertex[0].x;	ylo = vertex[0].y;
		zlo = vertex[0].z;	xhi = vertex[0].x;
		yhi = vertex[0].y;	zhi = vertex[0].z;

	for (auto v : vertex) {
		if (xlo > v.x) xlo = v.x;		if (ylo > v.y) ylo = v.y;		if (zlo > v.z) zlo = v.z;
		if (xhi < v.x) xhi = v.x;		if (yhi < v.y) yhi = v.y;		if (zhi < v.z) zhi = v.z;
	}

	xlo -= toll; xhi += toll;
	ylo -= toll; yhi += toll;
	zlo -= toll; zhi += toll;

	{
//		if (gxlo > xlo) gxlo = xlo;		if (gylo > ylo) gylo = ylo;		if (gzlo > zhi) gzlo = zlo;
//		if (gxhi < xhi) gxhi = xhi;		if (gyhi < yhi) gyhi = yhi;		if (gzhi < zlo) gzhi = zhi;
	}

	std::cout << " min. and max. of geometry shape " << shape_index << " coordinates:"
						<< " xlo: " << xlo << " xhi: "	 << xhi \
						<< " ylo: " << ylo << " yhi: "	 << yhi \
						<< " zlo: " << zlo << " zhi: "	 << zhi << std::endl;

}

void Geometry::merge_vertices (int shape_index) { // There can be a function that merge vertices which are closer than a small distance.
	const auto & vertex = shapes[shape_index].vertex;
	auto & vertex_map = shapes[shape_index].vertex_map;

	vertex_map.resize (vertex.size());
	for (int i=0;i<vertex.size();++i) {
		for (int j=i+1;j<vertex.size();++j) {
 			if (vertex[i]==vertex[j]) {
				vertex_map[j].push_back(i);
			}
		}
	}
}

void Geometry::read_vtk (const std::string &file) {
	class Parser *parser = new Parser {md, file};
	std::cout << "info: geometry: reading a geometry vtk file: "<< file << std::endl;
	Namespace_Geometry::Polyhedron shape_;
	shapes.push_back(shape_);
	int shape_index = shapes.size() - 1;
 	auto & vertex = shapes[shape_index].vertex;
	auto & face = shapes[shape_index].face;
	auto & edges = shapes[shape_index].edges;
	auto & vertex_map = shapes[shape_index].vertex_map;
	std::cout << "info: geometry: recording vtk file as a 3D shape with index " << shape_index << std::endl;

	while(true) {

		auto t0 = parser->get_val_token ();
		struct Token t1;
		if (t0.kind==Kind::eof) break;

		if (t0.kind==Kind::identifier) {
			if (t0.string_value == "POINTS") {
				output->info("geometry: read vtk: POINTS");
				int no_points = parser->get_literal_int();
				parser->get_val_token ();
				parser->end_of_line();
				int xyz = 0;
				Real_t x,y,z;
				while (true) {
					t1 = parser->get_val_token ();
					if (t1.kind==Kind::identifier) break;
					if (t1.kind==Kind::eol) t1 = parser->get_val_token ();
					if (t1.kind==Kind::identifier) break;
					if (xyz==0) {
						if (t1.kind==Kind::int_number)
							x = t1.int_value;
						else 
							x = t1.real_value;
					} else if (xyz==1) {
						if (t1.kind==Kind::int_number)
							y = t1.int_value;
						else 
							y = t1.real_value;

					} else {
						if (t1.kind==Kind::int_number)
							z = t1.int_value;
						else 
							z = t1.real_value;
						vertex.push_back (Vector<Real_t> {x, y, z});
					}
					++xyz;
					if (xyz==3) xyz=0;
				}
			}
		}
	

		if (t1.string_value=="VERTICES") {
			output->info("geometry: read vtk: VERTICES");
			while(true) {
				t1 = parser->get_val_token ();
				if (t1.kind==Kind::identifier) {
//					std::cout<<"identifier " << t1.string_value<<std::endl;
					merge_vertices(shape_index); // ***** ***** //
					break;
					}
			}
		}
		if (t1.string_value=="LINES") {
			output->info("geometry: read vtk: LINES");
			while(true) {
				t1 = parser->get_val_token ();
				if (t1.kind==Kind::identifier) {
//					std::cout<<"identifier " << t1.string_value<<std::endl;
					break;
					}
			}
		}
		if (t1.string_value=="POLYGONS") {
//			faces_of_vertex.resize (vertex.size());
			output->info("geometry: read vtk: POLYGONS");
			int no_polygons = parser->get_literal_int ();
			int no_something = parser->get_literal_int ();
			parser->end_of_line ();
			for (int i=0;i<no_polygons;++i) {
				int num = parser->get_literal_int ();
				int num1 = parser->get_literal_int ();
				int num2 = parser->get_literal_int ();
				int num3 = parser->get_literal_int ();
//				std::cout << num << " " << num1 << " " << num2 << " " << num3 << "\n";

				num1 = (vertex_map[num1].size()==0)?num1 :vertex_map[num1][1];  // uses vertex_map instead of vertex
				num2 = (vertex_map[num2].size()==0)?num2 :vertex_map[num2][1];  //
				num3 = (vertex_map[num3].size()==0)?num3 :vertex_map[num3][1];	//

				std::vector<int> gons;
				gons.push_back (num1); gons.push_back (num2); gons.push_back (num3);
				face.push_back (gons);			

//				faces_of_vertex[num1].push_back(i); faces_of_vertex[num2].push_back(i); faces_of_vertex[num3].push_back(i);

				std::map<std::vector<int>,std::vector<int>>::iterator it_edges; 
#define ADD_EDGE(NUM1,NUM2)																		\
				{																											\
					std::vector<int> check_face = {i};									\
					std::vector<int> temp_edge; 												\
					if (NUM1<NUM2) temp_edge = {NUM1,NUM2};							\
					else temp_edge = {NUM2,NUM1};												\
					it_edges = edges.find(temp_edge);										\
					if (it_edges == edges.end()) {											\
						edges.insert (make_pair(temp_edge,check_face));		\
					}	else {																						\
						it_edges->second.push_back(i);										\
					}																										\
				}
				ADD_EDGE(num1,num2);
				ADD_EDGE(num2,num3);
				ADD_EDGE(num3,num1);
#undef ADD_EDGE
				parser->end_of_line();
			}
			
			break;
		}

	}
}

void Geometry::make_normal (int shape_index) { // It's supposed here that the vertices are written in order (right-hand rotation)
  const auto & vertex = shapes[shape_index].vertex;
	const auto & face = shapes[shape_index].face;
	auto & normal = shapes[shape_index].normal;

	for (int i=0;i<face.size();++i) {
		if (face[i].size()<3) continue;
		Vector<Real_t> v1 = vertex[face[i][1]] - vertex[face[i][0]];
		Vector<Real_t> v2 = vertex[face[i][2]] - vertex[face[i][0]];
		Vector<Real_t> n = cross_product (v1,v2);
//		std::cout<<"v1: "<<v1 << " v2 :" << v2 << " v1*v2: "<< n <<std::endl;
		Real_t n_lenght = sqrt (n.x*n.x + n.y*n.y + n.z*n.z);
		n /= n_lenght;
		normal.push_back(n);
	}
	/*
	for (int i=0;i<face.size();++i) {
		std::cout<<"normal: " <<normal[i]<<std::endl;
		for (int j=0;j<face[i].size();++j) {
			std::cout<<"\t\t"<< vertex[face[i][j]]<<std::endl;
		}
	}
	*/
}

void Geometry::pre_correct_normals (int shape_index) {
	auto & face = shapes[shape_index].face;
	const auto & edges = shapes[shape_index].edges;

	std::vector<int> face_list; // sequence of faces
	std::vector<int> face_in,face_out; // face index of edge_list
	std::vector<std::vector<int>> edge_list; // sequence of edges

	int start_face = 26;

	face_list.push_back (start_face);
// 	while (face_list.size() != face.size()) 
	{
		for (int i = 0; i<face_list.size(); ++i) {
			std::vector<int> e1,e2,e3;
#define MAKE_EDGE(NUM1,NUM2,EN1)																		\
			{																															\
				int v1 = face[face_list[i]][NUM1];													\
				int v2 = face[face_list[i]][NUM2];													\
				if (v1<v2) {EN1.push_back(v1); EN1.push_back(v2);}				 	\
				else {EN1.push_back(v2); EN1.push_back(v1);} 								\
			}
			MAKE_EDGE(0,1,e1);
			MAKE_EDGE(1,2,e2);
			MAKE_EDGE(2,0,e3);
#undef MAKE_EDGE
		std::map<std::vector<int>,std::vector<int>>::const_iterator it;		
#define MAKE_EDGE_LIST(EN1) 																			\
			{																														\
				it = edges.find (EN1); 																		\
				if (it == edges.end() ) std::cout << "errroe"; \
				int its01;																								\
				if (it->second[0] == face_list[i]) its01 = it->second[1];	\
				else its01 = it->second[0];																\
				bool face_used = false;																		\
				for (int j=0;j<face_list.size();++j) {										\
					if (its01 == face_list[j]) {														\
						face_used = true; break;															\
					}																												\
				}																													\
				if (!face_used) {																					\
					face_list.push_back (its01);														\
					edge_list.push_back (EN1);															\
					face_in.push_back (face_list[i]);												\
					face_out.push_back (its01);															\
				}																													\
			}
		MAKE_EDGE_LIST(e1);
		MAKE_EDGE_LIST(e2);
		MAKE_EDGE_LIST(e3);
#undef MAKE_EDGE_LIST
		}
	}
//	std::cout << "edges.size: "<< edges.size() << "\n";
//	std::cout << "face_list.size: "<< face_list.size() << "\n";
//	std::cout << "face.size: "<< face.size() << "\n";	
//	std::cout << "edge_list.size: "<< edge_list.size() << "\n";

		for (int i=0; i<edge_list.size(); ++i) {

			std::map<std::vector<int>,std::vector<int>>::const_iterator it;		
			it = edges.find (edge_list[i]);	
			if (it == edges.end()) 	{}//error->all (FILE_LINE_FUNC, "a bug in the code1!");	
			if (it->second.size() != 2){}// error->all (FILE_LINE_FUNC, "a bug in the code2!");	

			{
					int v1 = it->first[0]; // vertex index
					int v2 = it->first[1]; // 
					int f1 = it->second[0];// face index
					int f2 = it->second[1];

					bool f1_right,f2_right ; // true or false whether face1 or face2 edges are ordered in a right hand twist order.
					int f1_case=-1,f2_case=-1; // there's three different right hand and three left hand cases in which the vertices are ordered.
					if (v1==face[f1][0]) {
						if (v2==face[f1][1]) {
							f1_right = true;
							f1_case = 1;
						} else { // (v2==face[f1][2]) 
							f1_right = false;
							f1_case = 2;
						}
					} else if (v1==face[f1][1]) {
						if (v2==face[f1][0]) {
							f1_right = false;
							f1_case = 3;
						} else { // (v2==face[f1][2]) 
							f1_right = true;
							f1_case = 4;
						}
					} else { // (v1==face[f1][2])
						if (v2==face[f1][0]) {
							f1_right = true;
							f1_case = 5;
						} else { // (v2==face[f1][1]) 
							f1_right = false;
							f1_case = 6;
						} 
					}

					if (v1==face[f2][0]) {
						if (v2==face[f2][1]) {
							f2_right = true;
							f2_case = 1;
						} else { // (v2==face[f2][2]) 
							f2_right = false;
							f2_case = 2;
						}
					} else if (v1==face[f2][1]) {
							if (v2==face[f2][0]) {
								f2_right = false;
								f2_case = 3;
						} else { // (v2==face[f2][2]) 
							f2_right = true;
							f2_case = 4;
						}
					} else { // (v1==face[f2][2])
						if (v2==face[f2][0]) {
							f2_right = true;
							f2_case = 5;
						} else { // (v2==face[f2][1]) 
							f2_right = false;
							f2_case = 6;
						} 
					}

					if (f1_right==f2_right) { // if two neighbor faces has similar twist order in one edge, 
																		// their normals will be directed differently. so it has to be corrected.
						if (f2 == face_out[i]) { // only change the outer face

							switch (f2_case) {
								case 1: case 3: {
									int tmp = face[f2][0];
									face[f2][0] = face[f2][1];
									face[f2][1] = tmp; 
								}	break;
								case 2: case 5: {
									int tmp = face[f2][0];
									face[f2][0] = face[f2][2];
									face[f2][2] = tmp;
								} break;
								case 4: case 6: {
									int tmp = face[f2][1];
									face[f2][1] = face[f2][2];
									face[f2][2] = tmp;
								}	break;
							}
						} else {

							switch (f1_case) {
								case 1: case 3: {
									int tmp = face[f1][0];
									face[f1][0] = face[f1][1];
									face[f1][1] = tmp; 
								} break;
								case 2: case 5: {
									int tmp = face[f1][0];
									face[f1][0] = face[f1][2];
									face[f1][2] = tmp;
								} break;
								case 4: case 6: {
									int tmp = face[f1][1];
									face[f1][1] = face[f1][2];
									face[f1][2] = tmp;
								}	break;
							}
						}

				}
			}
		}

}

void Geometry::make_grid (int shape_index) {
 	const auto & vertex = shapes[shape_index].vertex;
 	const auto & face = shapes[shape_index].face;
 	auto & grid = shapes[shape_index].grid;
	const auto & xlo = shapes[shape_index].xlo, & xhi = shapes[shape_index].xhi;
	const auto & ylo = shapes[shape_index].ylo, & yhi = shapes[shape_index].yhi;
	const auto & zlo = shapes[shape_index].zlo, & zhi = shapes[shape_index].zhi;
	auto & dx_part = shapes[shape_index].dx_part;
	auto & dy_part = shapes[shape_index].dy_part;
	auto & dz_part = shapes[shape_index].dz_part;
	const auto & nx_part = shapes[shape_index].nx_part;
	const auto & ny_part = shapes[shape_index].ny_part;
	const auto & nz_part = shapes[shape_index].nz_part;
	const auto & toll = shapes[shape_index].grid_toll; // toll==0 makes a bug. I think toll has to be larger than biggest particle radius. or more maybe because of the pointy edges.

	grid.resize(nx_part);
	for (int i=0;i<nx_part;++i)
		grid[i].resize(ny_part);

	for (int i=0;i<nx_part;++i)
		for (int j=0;j<ny_part;++j)
			grid[i][j].resize(nz_part);


	dx_part = (xhi-xlo)/nx_part;
	dy_part = (yhi-ylo)/ny_part;
	dz_part = (zhi-zlo)/nz_part;
//	std::cout << "parts: "<<dx_part << " " << dy_part << " " << dz_part << std::endl;

	for (int i=0;i<face.size();++i) {
		Real_t fxlo = vertex[face[i][0]].x - toll, 
					 fxhi = vertex[face[i][0]].x + toll, 
					 fylo = vertex[face[i][0]].y - toll, 
					 fyhi = vertex[face[i][0]].y + toll, 
					 fzlo = vertex[face[i][0]].z - toll, 
					 fzhi = vertex[face[i][0]].z + toll;
//		std::cout<<fxlo<<" "<<fxhi<<" "<< fylo<<" "<<fyhi<<" "<< fzlo<<" "<<fzhi<<"\n";
		for (int j=1;j<face[i].size();++j) {
			if (fxlo > vertex[face[i][j]].x - toll)
				fxlo = vertex[face[i][j]].x - toll;
			if (fxhi < vertex[face[i][j]].x + toll)
				fxhi = vertex[face[i][j]].x + toll;
			if (fylo > vertex[face[i][j]].y - toll)
				fylo = vertex[face[i][j]].y - toll;
			if (fyhi < vertex[face[i][j]].y + toll)
				fyhi = vertex[face[i][j]].y + toll;
			if (fzlo > vertex[face[i][j]].z - toll)
				fzlo = vertex[face[i][j]].z - toll;
			if (fzhi < vertex[face[i][j]].z + toll)
				fzhi = vertex[face[i][j]].z + toll;
		}
		
		int xindex_lo = int((fxlo-xlo)/dx_part);
		int xindex_hi = int((fxhi-xlo)/dx_part);
		int yindex_lo = int((fylo-ylo)/dy_part);
		int yindex_hi = int((fyhi-ylo)/dy_part);
		int zindex_lo = int((fzlo-zlo)/dz_part);
		int zindex_hi = int((fzhi-zlo)/dz_part);

//		std::cout <<"xyzindex_lo_hi: " <<xindex_lo<<" "<<xindex_hi<<" "<<yindex_lo<<" "<<yindex_hi<<" "<<zindex_lo<<" "<<zindex_hi<<"\n";

		if (xindex_lo<0) xindex_lo = 0;
		if (yindex_lo<0) yindex_lo = 0;
		if (zindex_lo<0) zindex_lo = 0;

		if (xindex_hi>nx_part-1) xindex_hi = nx_part-1;
		if (yindex_hi>ny_part-1) yindex_hi = ny_part-1;
		if (zindex_hi>nz_part-1) zindex_hi = nz_part-1;


		for (int jx=xindex_lo; jx<=xindex_hi; ++jx)
			for (int jy=yindex_lo; jy<=yindex_hi; ++jy)		
				for (int jz=zindex_lo; jz<=zindex_hi; ++jz) {
//					std::cout<<"jx: " << jx << " jy: " << jy << " jz: " << jz << std::endl;
					grid[jx][jy][jz].push_back (i);
				}
	}
//-- 

//-- 

}

void Geometry::check_inside (const Vector<Real_t> &v1, const Real_t radius, Vector <Real_t> &tot_force, int shape_index) {
 	const auto & vertex = shapes[shape_index].vertex;
 	const auto & face = shapes[shape_index].face;
 	const auto & normal = shapes[shape_index].normal;
 	const auto & edge_norms3 = shapes[shape_index].edge_norms3;
 	const auto & thickness = shapes[shape_index].thickness;
 	const auto & grid = shapes[shape_index].grid;
	const auto & xlo = shapes[shape_index].xlo, & xhi = shapes[shape_index].xhi;
	const auto & ylo = shapes[shape_index].ylo, & yhi = shapes[shape_index].yhi;
	const auto & zlo = shapes[shape_index].zlo, & zhi = shapes[shape_index].zhi;
	const auto & dx_part = shapes[shape_index].dx_part;
	const auto & dy_part = shapes[shape_index].dy_part;
	const auto & dz_part = shapes[shape_index].dz_part;
	const auto & nx_part = shapes[shape_index].nx_part;
	const auto & ny_part = shapes[shape_index].ny_part;
	const auto & nz_part = shapes[shape_index].nz_part;
//-- 
	int xindex = int((v1.x-xlo)/dx_part);
	int yindex = int((v1.y-ylo)/dy_part);
	int zindex = int((v1.z-zlo)/dz_part);

	if (xindex<0) return;
	if (yindex<0) return;
	if (zindex<0) return;

	if (xindex>nx_part-1) return;
	if (yindex>ny_part-1) return;
	if (zindex>nz_part-1) return;

	Vector<Real_t> force{0.0,0.0,0.0};

/*
	std::cout << grid.size() << std::endl;

	for (int i=0;i<grid.size();++i)
		std::cout << grid[i].size() << " ";

	std::cout << std::endl;

	for (int i=0;i<grid.size();++i){
		for (int j=0;j<grid.size();++j)
			std::cout << grid[i][j].size() << " ";
		std::cout << std::endl;
	}
*/
 /* 
	std::cout << std::endl;
	for (int i=0;i<grid.size();++i)
		for (int j=0;j<grid.size();++j)
			for (int k=0;k<grid.size();++k)
			std::cout << grid[i][j][k].size() << " ";

	std::cout << std::endl;
	std::cout << std::endl;
 */
//	std::cout << "grid.size(): " <<  grid[xindex][yindex][zindex].size() << std::endl;

	for (auto i : grid[xindex][yindex][zindex]) 
	{
//		std::cout << i << " ";
		Real_t v1_dot_norm = (v1 - vertex[face[i][0]])* normal[i];

//		std::cout<<v1_dot_norm<<"\n";
		bool is_inside = false;
		if (v1_dot_norm-radius<0 && v1_dot_norm+radius > -thickness) {  // if true it may be inside the face //
													// if the particle has radius, we have to put it in	
													// this condition
			is_inside = true;
			for (int j=0; j<face[i].size(); ++j) {
//				int k0 = j; int k1 = (j==face[i].size()-1) ? 0 : j+1;
				Vector<Real_t> v2 = v1- vertex[face[i][j]];

				Real_t dotdot = v2 * edge_norms3[i][j];

				if (dotdot<0) {is_inside=false;break;}
				// note that the polygon need to be convex for this formula to be true.
				// check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). One of them is disasterous
				
			}
		}

		if (is_inside) {
			force += -normal[i]*v1_dot_norm;
			//break; // use this for a faster scheme (!?)
		} 
	}

 	tot_force = force;

}

bool Geometry::check_inside (const Vector<Real_t> &v1, const Real_t radius) { // will be used in random initial position creation of particles
	for (int shape_index = 0; shape_index < shapes.size(); ++shape_index) {
	const auto & vertex = shapes[shape_index].vertex;
 	const auto & face = shapes[shape_index].face;
 	const auto & normal = shapes[shape_index].normal;
 	const auto & edge_norms3 = shapes[shape_index].edge_norms3;
 	const auto & thickness = shapes[shape_index].thickness;
 	const auto & grid = shapes[shape_index].grid;
	const auto & xlo = shapes[shape_index].xlo, & xhi = shapes[shape_index].xhi;
	const auto & ylo = shapes[shape_index].ylo, & yhi = shapes[shape_index].yhi;
	const auto & zlo = shapes[shape_index].zlo, & zhi = shapes[shape_index].zhi;
	const auto & dx_part = shapes[shape_index].dx_part;
	const auto & dy_part = shapes[shape_index].dy_part;
	const auto & dz_part = shapes[shape_index].dz_part;
	const auto & nx_part = shapes[shape_index].nx_part;
	const auto & ny_part = shapes[shape_index].ny_part;
	const auto & nz_part = shapes[shape_index].nz_part;

	//-- 
	int xindex = int((v1.x-xlo)/dx_part);
	int yindex = int((v1.y-ylo)/dy_part);
	int zindex = int((v1.z-zlo)/dz_part);

	if (xindex<0) return false;
	if (yindex<0) return false;
	if (zindex<0) return false;

	if (xindex>nx_part-1) return false;
	if (yindex>ny_part-1) return false;
	if (zindex>nz_part-1) return false;



	for (auto i : grid[xindex][yindex][zindex]) 
	{

		Real_t v1_dot_norm = (v1 - vertex[face[i][0]])* normal[i];

		bool is_inside = false;
		if (v1_dot_norm-radius<0 && v1_dot_norm+radius > -thickness) {  // if true it may be inside the face //
													// if the particle has radius, we have to put it in	
													// this condition
			is_inside = true;
			for (int j=0; j<face[i].size(); ++j) {

				Vector<Real_t> v2 = v1- vertex[face[i][j]];

				Real_t dotdot = v2 * edge_norms3[i][j];

				if (dotdot<0) {is_inside=false;break;}
				// note that the polygon need to be convex for this formula to be true.
				// check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). One of them is disasterous
				
			}
		}
		if (is_inside) {
			return true;
		} 
	}
	}
	return false;
}

bool Geometry::check_inside_ray (const Vector<Real_t> &v1, const int ray_axis=0, const Real_t perturb_1 = 0.0, const Real_t perturb_2 = 0.0) { 

// will be used in random initial position creation of particles
  
  
	for (int shape_index = 0; shape_index < shapes.size(); ++shape_index) {
	  const auto & vertex = shapes[shape_index].vertex;
 	  const auto & face = shapes[shape_index].face;
 	  const auto & normal = shapes[shape_index].normal;
 	  const auto & edge_norms3 = shapes[shape_index].edge_norms3;
 	  const auto & thickness = shapes[shape_index].thickness;
	  const auto & xlo = shapes[shape_index].xlo, & xhi = shapes[shape_index].xhi;
	  const auto & ylo = shapes[shape_index].ylo, & yhi = shapes[shape_index].yhi;
	  const auto & zlo = shapes[shape_index].zlo, & zhi = shapes[shape_index].zhi;
	
    bool inside_shape = false; // inside atleast one of the shapes
  
    for (int i=0;i<face.size();++i) {

      Vector<Real_t> v_pr = v1;
      const auto v0 = vertex[face[i][0]];
      const auto n = normal[i];
      
      if (ray_axis == 0) {
      	if (v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z )
      	  continue;
      	if (n.z == 0) // NOT COMPLETE
      	  continue;    
        v_pr.x = v0.x - (n.y*(v1.y - v0.y) + n.z*(v1.z - v0.z))/n.x;
          
      } else if (ray_axis == 1) {
        if (v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z )
      	  continue;
      	if (n.z == 0) // NOT COMPLETE
      	  continue;
        v_pr.y = v0.y - (n.x*(v1.x - v0.x) + n.z*(v1.z - v0.z))/n.y;
        
      } else if (ray_axis == 2) {
      	if (v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z || v1.z < vertex[face[i][0]].z )
      	  continue;
      	if (n.z == 0) // NOT COMPLETE
      	  continue;
        v_pr.z = v0.z - (n.x*(v1.x - v0.x) + n.y*(v1.y - v0.y))/n.z;
       
      } else std::cout<<"ERROR" << std::endl; //error->all(FILE_LINE_FUNC, "undefined geometry axis."); 
    
      // Cheking if v_pr is inside triangle, using barycentric coordinates.

      const auto AB = vertex[face[i][1]] - vertex[face[i][0]];
      const auto AC = vertex[face[i][2]] - vertex[face[i][0]];
      const auto PA = vertex[face[i][0]] - v_pr;
      const auto PB = vertex[face[i][1]] - v_pr;
      const auto PC = vertex[face[i][2]] - v_pr;   
         
      const auto ABAC = cross_product(AB, AC);
      const auto PBPC = cross_product(PB, PC);
      const auto PCPA = cross_product(PC, PA);
      
      const auto ABAC_norm = std::sqrt (ABAC*ABAC);
      const auto PBPC_norm = std::sqrt (PBPC*PBPC);
      const auto PCPA_norm = std::sqrt (PCPA*PCPA);
      
      const auto ABAC_norm_inv = 1.0/ABAC_norm;
      const auto alpha = PBPC_norm * ABAC_norm_inv;
      const auto beta  = PCPA_norm * ABAC_norm_inv;
      const auto gamma = 1.0 - alpha - beta;
      
      if (  alpha < 0.0 || alpha > 1.0 || 
            beta  < 0.0 || beta  > 1.0 ||
            gamma < 0.0 || gamma > 1.0   )
        continue;
          
      inside_shape = !inside_shape;
				
			// note that the polygon need to be convex for this formula to be true.
			// check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). 
			// One of them is disasterous
			
    }
    
    if (inside_shape) return true; // inside at least one of the shapes
      
  }
  
  return false;
    
}



/* 
 * it needs some debug over the data inputted. you need to compare the inputted data and the expected geometry.
void Geometry::read_unv (const std::string &file) {
	class Parser *parser = new Parser {md, file};
	std::cout << "info: geometry: reading a geometry unv file: "<< file << std::endl;

//   error->all (FILE_LINE_FUNC, "expected '-1' ");

	bool look_for_section = true;
	int section_code = 0;

	while(true) {

		auto token = parser->get_val_token ();
		if (token.kind==Kind::eof) break;

		if (look_for_section) {
			if (token.kind==Kind::int_number) {
				if (token.int_value==-1) {
					parser->end_of_line ();
					section_code = parser->get_literal_int ();
					parser->end_of_line ();
					look_for_section = false;
//					std::cout<<token.int_value<<std::endl;
				} else {
//					std::cout<<token.int_value<<std::endl;			
				}
			}
		}


		if (!look_for_section) {
			switch (section_code) {
				case 2411: {
					output->info("geometry: unv file: reading section 2411");
					auto val1 = parser->get_literal_int ();
					while (true) {
						while(!parser->end_of_line()) {}
						Real_t x = parser->get_literal_real ();
	 					Real_t y = parser->get_literal_real ();
	 					Real_t z = parser->get_literal_real ();
						vertex.push_back (Vector<Real_t> {x, y, z});
						parser->end_of_line ();
						val1 = parser->get_literal_int ();
//					std::cout<< x << " " << y << " " << z << std::endl;
						if (val1 == -1) break;
					}
					look_for_section = true;
					section_code = 0;
					output->info("geometry: unv file: reading section finished.");
				} break;

				case 2412: {
					output->info("geometry: unv file: reading section 2412");
					while (true) {
						auto val1 = parser->get_literal_int ();
						if (val1 == -1) break;
						val1 = parser->get_literal_int ();
						if (val1 == 11) {
							for (int i=0;i<4;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
							for (int i=0;i<3;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
							for (int i=0;i<2;++i) 
								val1 = parser->get_literal_int ();
							parser->end_of_line ();
						}
						else {
							int ngon;
							for (int i=0;i<4;++i)
								ngon = parser->get_literal_int ();
							parser->end_of_line ();		
							std::vector<int> gons;
//						std::cout<<ngon<<std::endl;
							for (int i=0;i<ngon;++i)
								gons.push_back (parser->get_literal_int ());
							face.push_back (gons);
							parser->end_of_line ();
//						for (int i=0;i<ngon;++i)
//							std::cout<<gons[i] << " ";
//						std::cout<< std::endl;
						}
					}
					look_for_section = true;
					section_code = 0;
					output->info("geometry: unv file: reading section finished.");
  			} break;

				case 0: {
				  std::cout<<"info: geometry: unv file : Section code is not found: " << section_code << std::endl;
					look_for_section = true;
					section_code = 0;
				} break;

				default: {
					std::cout<<"info: geometry: unv file: Undefined section code: " << section_code << std::endl;
					while(true) {
						while(!parser->end_of_line ()) {};
						auto t = parser->get_val_token ();
						if (t.kind==Kind::int_number)
							if (t.int_value == -1) {
								look_for_section = true;
								section_code = 0;
								break;
							}
					}
			  } break;

			}
		}

	}
	output->info("geometry: unv file: reading finished.");
	delete parser;
	
//	for (int i=0;i<vertex.size();++i) std::cout<<vertex[i]<<std::endl;
}

*/
