#ifndef KAKAKA_UTILITY_H
#define KAKAKA_UTILITY_H

//#include "data_reader_kakaka.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
#include "kakaka_shape.h"
#include "kakaka_shape_vtk.h"

namespace kkk {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::map<std::string,int> dictionary_second_type = {
	{"ELEMENT",1},
	{"ATOM",2},
	{"MOLECULE",3},	
	{"RANDOM_1D",4},
	{"BOUNDARY",5},	
	{"SHAPE",6},	
	{"GRID_1D",7},
	{"DISTRIBUTION",8},	
	{"INT_CONSTANT",-1},	
	{"REAL_CONSTANT",-2},	
	{"INT_2D_VECTOR",-3},	
	{"REAL_2D_VECTOR",-4},	
	{"INT_3D_VECTOR",-5},	
	{"REAL_3D_VECTOR",-6},
};


class Molecule;
class Atom;
class Dictionary;
class All_objects;

class Element {
	public:
		Element () ;
		Element (All_objects *, double m, double r, double ch, unsigned int i);
		~Element ();
    double get_radius () const {
      return RADIUS;
    }
    double get_mass () const {
      return MASS;
    }
    double get_charge () const {
      return CHARGE;
    }            
    unsigned int get_element_index() const {
      return element_index;
    }
		bool read (Parser *);
	private:
		unsigned int element_index;
		double MASS, RADIUS, CHARGE;
			
		class Output * output;
		class Error * error;
		class All_objects * all_objects;


};

// ========================
// ========================
// ========================

class Atom {
	public:
		Atom ();
		Atom (const Atom &);
		Atom (All_objects *, class Molecule *,  Vector<double>, Vector<double>, unsigned int);
		~Atom () ;


		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const; 

		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}
    double get_radius () const;
    unsigned int get_element_index () const {
      return element_index;
    }
		bool read (Parser *);
		
		void output_xyz (std::ofstream &);	
    void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);		
			
		bool has_father;		
		Molecule * FATHER;
		
	private:
	Vector<double> POSITION, VELOCITY;

	unsigned int element_index;
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};
// ========================
// ========================
// ========================

class Molecule {
	public:
		Molecule ();
		Molecule (const Molecule &);
		Molecule (All_objects *, class Molecule *,  Vector<double>, Vector<double>);
		~Molecule ();

		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const;	
		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}
		void give_position_and_radius (std::vector<Vector<double>>&, std::vector<double>&);
		void correct_heritage ();
  
		bool read (Parser *);

		bool add_atom (const Atom &);
		bool add_atom (const Atom &, const Vector<double> &p, const Vector<double> &v);	
		bool add_molecule (const Molecule &);	
		bool add_molecule (const Molecule &, const Vector<double> &p, const Vector<double> &v);
				
		void output_xyz (std::ofstream &);
    void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);
		
		bool has_father;
		Molecule * FATHER;


	private:
	Vector<double> POSITION, VELOCITY;
	std::vector<Atom> atoms;
	std::vector<Molecule> molecules;
	
	class Output * output;
	class Error * error;
	class All_objects * all_objects;

};



// ========================
// ========================
// ========================

class Random_1D {
	public:
		Random_1D () ;
		Random_1D (All_objects *, std::string TYPE, double MIN, double MAX, double STDDEV, double MEAN, int SEED) ;
		~Random_1D () ;

		bool read(Parser *);
    void generate (); // creates the std::mt19937 with given parameters ...		
		
		double MIN, MAX, STDDEV, MEAN;
		
		std::string TYPE;
		
		int SEED;				
		int num; // number of random atoms or molecules to be created		
		int type_int;
				
		bool generated; // true if generate() has been called.
    
		std::mt19937 *ran_gen;
		std::uniform_real_distribution<> *u_dist;
		std::normal_distribution<> *n_dist;
		
		class Parser * parser;
		class Output * output;
	  class Error * error;
	  class All_objects * all_objects;


	private:
};
// ========================
// ========================
// ========================

class Grid_1D {
	public:
		Grid_1D () ;
		Grid_1D (All_objects *, double MIN, double MAX, double INCREMENT, int SEGMENT) ;
		~Grid_1D () ;
		
		bool read (Parser *);
    void generate (); // calculates the parameters
    unsigned int no_points ();
    double give_point ();
    double give_point (int);
    

		double MIN, MAX, INCREMENT;

		bool generated; // true if generate() has been called.  	
		bool by_increment, by_segment;
		
		int SEGMENT;		
    int no_given_points; 		
		int num; // number of random atoms or molecules to be created				
  	int type_int;
 	
		std::string TYPE;
    
		class Parser * parser;
		class Output * output;
	  class Error * error;
	  class All_objects * all_objects;


	private:
};
// ========================
// ========================
// ========================

class Boundary : public kkk::shape::Shape {
	public:
		Boundary ();
		Boundary (All_objects * all_obj);
		~Boundary ();
	  bool read(Parser *);
		void satisfy_boundary ();
		
		bool inside_check;

		
		bool is_inside (const Vector<double> &);
		bool is_outside (const Vector<double> &);
		bool is_inside (const Vector<double> &, const double r);
		bool is_outside (const Vector<double> &, const double r);
		
		//bool is_all (const Vector<double> &); //checks 'is_inside()' if 'inside_check==true'

		std::vector<kkk::shape::Shape*> shapes;
		std::vector<int> operators; // 1:and_inside, -1:and_outside, 2:or_inside, -2:or_outside

		class Parser * parser;		
		class Output * output;
	  class Error * error;
	  class All_objects * all_objects;

};
// ========================
// ========================
// ========================

class Dictionary {
	public:
	Dictionary () { };
	Dictionary (int t, int i) : type(t), index(i){ };
	~Dictionary () {};
	int type; // type of the vector
	int index; // index of the vector
//	string object_type ; // the same as int type
};

// ========================
// ========================
// ========================

class Distribution {
	public:
	Distribution ();
  Distribution (All_objects * all_obj);
	~Distribution () ;
  bool read (Parser *);		
	
	Boundary *boundary;
	Molecule *m_object, *container;
	Atom * a_object;
	bool boundary_check, a_object_check, m_object_check, container_check;
	
	bool distribute_grid_3D();
	bool distribute_random_3D()	;
	
	class Parser * parser;	
  class Output * output;
  class Error * error;
  class All_objects * all_objects;


};

// ========================
// ========================
// ========================

class All_objects {
	public:
	All_objects () {};
	~All_objects ();
	class Parser * parser;
  class Output * output;
  class Error * error;
	
	std::map<std::string,kkk::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<Element> elements; // 1
	std::vector<Atom> atoms; // 2
	std::vector<Molecule> molecules; // 3
	std::vector<Boundary> boundaries; // 4
	std::vector<Random_1D> random_1ds; // 5
	std::vector<shape::Shape *> shapes; // 6	
	std::vector<Grid_1D> grid_1ds; // 7	
	std::vector<Distribution> distributions; // 8
	std::vector<int> int_constants; // -1
	std::vector<double> real_constants; // -2
	std::vector<Vector2D<int>> int_2d_vectors; // -3
	std::vector<Vector2D<double>> real_2d_vectors; // -4
	std::vector<Vector<int>> int_3d_vectors; // -5
	std::vector<Vector<double>> real_3d_vectors; // -6

} ;//all_objects;

} // NAMESPACE KKK finished


#endif
 
