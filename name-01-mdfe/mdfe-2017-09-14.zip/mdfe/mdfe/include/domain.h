#ifndef DOMAIN_H
#define DOMAIN_H

#include "pointers.h"

#include <valarray>

enum class Boundary {periodic, fixed};

class Domain : protected Pointers {
public:
  Domain (class MD *);
  
  void calculate_local_domain ();
  
  Real_t x_lower_global, y_lower_global, z_lower_global;
  Real_t x_upper_global, y_upper_global, z_upper_global;
  Real_t x_lower_local, y_lower_local, z_lower_local;
  Real_t x_upper_local, y_upper_local, z_upper_local;
private:
  
};

#endif
