#include "force_field.h"

#include "atom_data.h"

Force_field::Force_field (MD *md, Parser *parser) : Pointers{md}, parser{parser} {}

void Force_field::calculate_kinetic_energy () {
	const auto &vel = md->atom_data->owned.velocity;
	const auto &type = md->atom_data->owned.type;
	const auto &mass = md->atom_data->owned.mass;

	kinetic_energy = 0.0;
	for (unsigned int i=0; i<vel.size(); ++i) { 
		kinetic_energy += 0.5*mass[type[i]-1]*(vel[i]*vel[i]);
	}
//	std::cout<<mass[0]<<"\n";
}
