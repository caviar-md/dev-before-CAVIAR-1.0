#include "geometry.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"


Geometry::Geometry (MD *md) : Pointers{md}, 
	polyhedron_handler {new Namespace_Geometry::Polyhedron_Handler{md}},
  geometry_force{false}
{ }

Geometry::~Geometry () { 
	delete polyhedron_handler;
}

bool Geometry::read (const std::string & file_name) {
  parser = new Parser {md, file_name};
  auto t = parser->get_identifier();
	if (t == "POLYHEDRON" || t == "polyhedron") {
    //command_polyhedron (parser);
	} else if (t == "GENERATE" || t == "generate") {
	  //command_generate ();
	} else if (t == "OUTPUT" || t == "output") {
    //command_output (parser);	  
	} else {
  	error->all (FILE_LINE_FUNC, "invalid syntax: this geometry parameter does not exists");
	}
	return true; //WARNING
}
/*
void Geometry::command_output (Parser *parser) {

}
void Geometry::command_polyhedron (Parser *parser) {

}*/



void Geometry::calculate_acceleration () {
	if (!geometry_force) return;
  const auto &pos = atom_data -> owned.position;
	auto &acc = atom_data -> owned.acceleration;
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;//- 1;	
	  const auto mass_i = atom_data -> owned.mass [ type_i ];	
	  /*
		for (unsigned int j=0; j<polyhedron.size();++j) {
			Vector <Real_t> f {0,0,0};
			const auto rad = polyhedron[j].radius [type_i];
			polyhedron_handler -> check_inside (polyhedron[j], pos[i], rad, f);
			acc[i] -= f*polyhedron[j].young_modulus/mass_i;
		}*/
	}
}




