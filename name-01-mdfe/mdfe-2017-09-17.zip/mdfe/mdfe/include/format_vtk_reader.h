#ifndef FORMAT_VTK_READER_h
#define FORMAT_VTK_READER_h


#include <string>
#include <iostream>
#include <fstream>

#include "pointers.h"
#include "parser.h"
#include "polyhedron.h"

class Format_Vtk_Reader : protected Pointers {
public:

  Format_Vtk_Reader (class MD *);
  ~Format_Vtk_Reader();
  
  void read_polyhedron (Namespace_Geometry::Polyhedron &, const std::string &);
  //void merge_vertices (int); // It checks if the two vertices are similar.Then makes a map of all vertices to the similar ones with the lower index
};

#endif
