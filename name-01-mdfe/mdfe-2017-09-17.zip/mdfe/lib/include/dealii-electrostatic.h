#ifndef DEALII_ELECTROSTATIC_H
#define DEALII_ELECTROSTATIC_H

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>

#include <deal.II/numerics/data_out.h>
#include <fstream>
#include <iostream>
#include <cmath>


#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/vector_tools.h>

#include <deal.II/grid/manifold_lib.h>

#include <deal.II/opencascade/boundary_lib.h>
#include <deal.II/opencascade/utilities.h>



#include <deal.II/base/logstream.h>

//==================================================
//==================================================
//==================================================


class Error_calculator
{
public:
  Error_calculator () {}
  Error_calculator (const std::string str) { name = str; }
  
  void add_calculated_value (const double cv) {calculated.push_back (cv);}
  void add_analytic_value (const double an) {analytic.push_back (an);}  
  void calculate_and_output();
  
private:
  std::vector<double> calculated, analytic;
  std::string name;
  
  double err_tot, err_tot_sq, err_tot_abs,
         err_res, err_res_sq, err_res_abs;  
  double err_tot_std, err_tot_sq_std, err_tot_abs_std,
         err_res_std, err_res_sq_std, err_res_abs_std;
};


//==================================================
//==================================================
//==================================================

class All_charges {
public:
  All_charges ();
  ~All_charges ();

  void set_k_coef (double k) {k_coef = k;}
  
  void set_Rad (double r) {Rad = r;}
  double get_Rad () const {return Rad;}  
  
  void set_phi_bc (double phi) {phi_bc = phi;}
  double get_phi_bc () const {return phi_bc;}
  
  unsigned int no_charges () const { return chr.size();}  
  
  dealii::Point<3> get_pos_chr (unsigned int i) const { return pos_chr[i]; }
  double get_chr (unsigned int i) const {return chr[i];}
  
  void calculate_image_charges();

  void add_charge (const double x,const double y,const double z,const double c);
  void add_charge (const dealii::Point<3> p,const double c);

  double potential_chr (const dealii::Point<3> &, unsigned int i);
  double potential_img (const dealii::Point<3> &, unsigned int i);
  
  double potential_tot (const dealii::Point<3> &);// tot. potential at a point due to charge and image
  
  double potential_tot_chr (const dealii::Point<3> &);// tot. potential at a point  due to charge only
  
  double potential_tot (unsigned int i); // tot. potential on a charge from others

  dealii::Point<3> field_chr (const dealii::Point<3> &, unsigned int i);
  dealii::Point<3> field_img (const dealii::Point<3> &, unsigned int i);
  
  dealii::Point<3> field_tot (const dealii::Point<3> &); // tot. field at a point due to real charges and images
  dealii::Point<3> field_tot_chr (const dealii::Point<3> &); // tot. field at a point due to real charges
  
  dealii::Point<3> field_tot_chr (unsigned int i); // tot. field on a charge from others
  dealii::Point<3> field_tot (unsigned int j);

  dealii::Point<3> force_tot (unsigned int i); // tot. force on a charge from others due to other real charges and images

  void velocity_verlet_p1 ();
  void velocity_verlet_p2 ();
  void output_xyz ();
  void add_acceleration (const dealii::Tensor<1, 3, double> &, unsigned int i);  
  void boundary_force ();
  
private:
  std::vector<dealii::Point<3>> pos_chr, pos_img;
  std::vector<dealii::Point<3>> vel_chr, acc_chr;
  std::vector<double> chr, chr_img;
  std::vector<double> mass;
  
  double k_coef, Rad; //k_coef = 1/(4*Pi*e_0)  ; Rad: Radius of the sphere
  double phi_bc; // total potential on the sphere
  double dt;
  std::ofstream ofs_xyz;
  
} all_charges;


//==================================================
//==================================================
//==================================================

using namespace dealii;

//==================================================
//==================================================
//==================================================


template <int dim>
class Step4
{
public:
  Step4 ();
  void run ();

private:
  void make_grid ();
  void setup_system();
  void assemble_system_p1 ();
  void assemble_system_p2 ();
  void solve ();
  void output_results () const;
  void post_process();
  void post_process_charges();
  void calculate_acceleration ();


  void read_domain();
  Triangulation<3, 3>   tria_reserve;
  void set_spherical_manifold();
  int tot_no_matched, tot_no_corrected;

  void rotate_and_add(const double angle, const int axis, const double merge_toll);
  void rotate_and_add_reserve(const double angle, const int axis, const double merge_toll);
  void match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll);
                                               

  Triangulation<dim> triangulation;
  FE_Q<dim> fe;
  DoFHandler<dim> dof_handler;

  SparsityPattern sparsity_pattern;
  SparseMatrix<double> system_matrix;

  Vector<double> solution;
  Vector<double> system_rhs;
};


//==================================================
//==================================================
//==================================================


template <int dim>
class RightHandSide : public Function<dim>
{
public:
  RightHandSide () : Function<dim>() {}

  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;
};


//==================================================
//==================================================
//==================================================



#endif
