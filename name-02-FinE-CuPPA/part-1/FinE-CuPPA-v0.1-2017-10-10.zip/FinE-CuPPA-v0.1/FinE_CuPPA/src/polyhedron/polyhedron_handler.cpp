#include "polyhedron_handler.h"

#include <string>
#include <cmath>
#include <fstream>
#include <boost/algorithm/string.hpp>

#include "object_handler_preprocessors.h"

namespace NS_geometry {

Polyhedron_Handler::Polyhedron_Handler (MD *md) : Pointers{md},
	polyhedron_input {new NS_geometry::Polyhedron_Input{md}},
  polyhedron_preprocess {new NS_geometry::Polyhedron_Preprocess{md}},
	polyhedron_postprocess {new NS_geometry::Polyhedron_Postprocess{md}},
	polyhedron_utility {new NS_geometry::Polyhedron_Utility{md}},
  polyhedron_point_inside {new NS_geometry::Polyhedron_Point_Inside {md}},
  polyhedron_output {new NS_geometry::Polyhedron_Output {md}},  
  polyhedron_read{false},
  output_mesh_tcl{false},
  output_normals_tcl{false},
  output_edges_tcl{false},
  output_mesh_povray{false},
  invert_normals{false},
  correct_normals{false},
  output{md->output},
  error{md->error}
  {}



Polyhedron_Handler::~Polyhedron_Handler () {
	delete polyhedron_input;
	delete polyhedron_preprocess;
	delete polyhedron_postprocess;
	delete polyhedron_utility;
  delete polyhedron_point_inside;
	delete polyhedron_output;	
}

bool Polyhedron_Handler::read(Parser * parser) {
	output->info("Polyhedron read:");
	bool in_file = true;
			
	while(true) {
    GET_A_TOKEN_FOR_CREATION
		const auto t = token.string_value;
    if (boost::iequals(t,"vtk_file_name")) {
		  const auto token = parser->get_val_token();
		  const auto file_name = token.string_value;
	    polyhedron_input -> read_vtk (polyhedron, file_name);
      polyhedron_read = true;
    } else if (boost::iequals(t,"parameter")) {
      command_parameters (parser);
    } else if (boost::iequals(t,"output")) {
		  const auto token = parser->get_val_token();
		  const auto t = token.string_value; 

		  if (boost::iequals(t,"vmd") || boost::iequals(t,"tcl")) {
		    output_mesh_tcl = true;
        output_normals_tcl = true;
        output_edges_tcl = true;
      }
    } else if (boost::iequals(t,"generate")) {
      command_generate ();
    }	else error->all (FILE_LINE_FUNC, "Unknown variable or command");
	}
	
	return in_file;;
}

bool Polyhedron_Handler::is_inside (const Vector<double> &v0) {
  return  polyhedron_point_inside -> is_inside (polyhedron, v0);   
}


bool Polyhedron_Handler::is_inside (const Vector<double> &v, const double r) {
  return polyhedron_point_inside -> is_inside (polyhedron, v, r); 
}

bool Polyhedron_Handler::in_contact (const Vector<double> &v, const double r, Vector<double> & contact_vector) {
  return polyhedron_point_inside -> check_inside (polyhedron, v, r, contact_vector);
}

void Polyhedron_Handler::command_parameters (Parser *parser) {

	if (polyhedron_read == false) error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Polyhedron: read polyhedron before this command.");
  auto token = parser->get_val_token();
  auto t = token.string_value;
  if (boost::iequals(t,"thickness")) {
		auto thickness_ = parser->get_literal_real();
		polyhedron.thickness = thickness_;
	} else if (boost::iequals(t,"young_modulus")) {
		young_modulus = parser->get_literal_real();
	} else if (boost::iequals(t,"radius")) {
		auto r = parser->get_literal_real();
		radius.push_back (r);
		if (polyhedron.grid_toll<r) polyhedron.grid_toll = r;
	} else if (boost::iequals(t,"invert_normals")) {
		invert_normals = true;
	} else if (boost::iequals(t,"correct_normals")) {
		correct_normals = true;
	} else if (boost::iequals(t,"grid")) {
		auto nx_ = parser->get_literal_int();
		auto ny_ = parser->get_literal_int();
		auto nz_ = parser->get_literal_int();
		if (nx_ < 1 || ny_ < 1 || nz_ < 1) error->all(FILE_LINE_FUNC, "grids has to be larger than 1");
		polyhedron.nx_part = nx_; 		polyhedron.nx_part = ny_;		polyhedron.nx_part = nz_;
	} else {
  	error->all (FILE_LINE_FUNC, "invalid syntax: this geometry parameter does not exists");
	}

}

void  Polyhedron_Handler::command_generate () {


	if (correct_normals) {		
	  output->info("polyhedron: generate : correct_normals");
	  polyhedron_preprocess -> pre_correct_normals (polyhedron);
  }
    
	output->info("polyhedron: generate : make_normal");
	polyhedron_utility -> make_normal (polyhedron);

	output->info("polyhedron: generate : make_edge_norms");
	polyhedron_utility -> make_edge_norms (polyhedron);

	if (invert_normals) {
  	output->info("polyhedron: generate : invert_normals");
		polyhedron_utility -> invert_normals (polyhedron);
	}
	
	output->info_ne("polyhedron: generate : lowest_highest_coord : ");
	polyhedron_postprocess -> lowest_highest_coord (polyhedron);
		
	output->info("polyhedron: generate : make_grid");
	polyhedron_postprocess -> make_grid (polyhedron);


  if (output_mesh_povray)	polyhedron_output -> mesh_povray (polyhedron); 
  if (output_mesh_tcl)	polyhedron_output -> mesh_tcl (polyhedron); 
  if (output_normals_tcl)	polyhedron_output -> normals_tcl (polyhedron);
  if (output_edges_tcl)	polyhedron_output -> edges_tcl (polyhedron);

}

} //namespace


