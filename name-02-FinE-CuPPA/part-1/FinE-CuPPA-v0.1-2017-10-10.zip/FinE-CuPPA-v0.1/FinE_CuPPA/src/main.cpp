#ifdef USE_MPI
#include <mpi.h>
#endif

#include "md.h"
//#include <boost/algorithm/string.hpp>
using namespace std;


int main (int argc, char* argv[]) {
/*
std::string str1 = "heLlo, wOrld!";
std::string str2 = "HELLO, WORLD!";

if (boost::iequals(str1, str2))
{
    std::cout << "Strings are identical" << std::endl;
}*/
#ifdef USE_MPI
  MPI_Init (&argc, &argv);
  MD md (argc, argv, MPI::COMM_WORLD);
#else
  MD md (argc, argv);
#endif
  try {  
    md.execute ();
  }
  catch (std::exception &exc) {
    std::cerr << "Exception on processing: " << std::endl
              << exc.what() << std::endl;
  }
  catch (...) {
    std::cerr << "Unknown exception!" << std::endl;  
  } 
#ifdef USE_MPI
  MPI_Barrier (MPI_COMM_WORLD);
  MPI_Finalize ();
#endif
  return 0;
}
