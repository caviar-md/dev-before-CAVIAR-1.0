#include "object_creator.h"
#include "object_handler_all.h"
#include "object_container.h"

#include <fstream>
#include <boost/algorithm/string.hpp>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"




bool Object_creator::force_field (Parser *parser) {
	output->info("force_field creation ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string force_field_type = "";
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_A_STRING_NNT(force_field_type,"force_field: ","")
	}

	Force_field * p_sh;	
	if (boost::iequals(force_field_type, "lj")) {
		p_sh = new Force_field_lj (md); 
	} else if (boost::iequals(force_field_type, "lj_acc")) {
		p_sh = new Force_field_lj_acc (md); 
	} else	if (boost::iequals(force_field_type, "granular")) {
		p_sh = new Force_field_granular (md); 
	} else	if (boost::iequals(force_field_type, "geometry")) {
		p_sh = new Force_field_geometry (md); 
	} else {
		error->all(FILE_LINE_FUNC,"NOT defined force_field");
	}
	

	int index = object_container -> force_field.size ();
	object_container -> force_field.push_back (p_sh);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("force_field"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	
	return in_file;

}

// ========================
// ========================
// ========================


bool Object_creator::shape (Parser *parser) {
	output->info("shape creation ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string shape_type = "";
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_A_STRING_NNT(shape_type,"Shape: ","")
	}

	NS_shape::Shape * p_sh;	
	if (boost::iequals(shape_type, "circle")) {
		p_sh = new NS_shape::Circle (md); 
	} else if (boost::iequals(shape_type, "sphere")) {
		p_sh = new NS_shape::Sphere (md); 
	} else	if (boost::iequals(shape_type, "closed_lines")) {
		p_sh = new NS_shape::Closed_lines (md); 
	} else	if (boost::iequals(shape_type, "polyhedron")) {
		p_sh = new NS_shape::Polyhedron (md); 
	} else {
		error->all(FILE_LINE_FUNC,"NOT defined shape");
	}
	

	int index = object_container -> shape.size ();
	object_container -> shape.push_back (p_sh);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("shape"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	
	return in_file;

}

// ========================
// ========================
// ========================


bool Object_creator::boundary (Parser *parser) {
	output->info("boundary creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
	}

	int index = object_container -> boundary.size ();
	NS_shape::Boundary e_ (md);

	object_container -> boundary.push_back ( e_);
	
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("boundary"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}


















