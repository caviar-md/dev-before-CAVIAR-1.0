#include "object_creator.h"

#include "object_container.h"
#include "object_handler_all.h"
#include "parser.h"

bool Object_creator::int_variable (Parser * parser) {
	output->info("int_constant creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double r = 0;
	
	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_NNT(r,"","")
	}

	int index = object_container->int_variable.size ();
	object_container->int_variable.push_back (r);
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("int_variable"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}

// ========================
// ========================
// ========================

bool Object_creator::real_variable (Parser * parser) {
	output->info("real_constant creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double r;

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_NNT(r,"","")
	}


	int index = object_container->real_variable.size ();
	object_container->real_variable.push_back (r);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("real_variable"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));
	
	//std::cout <<"r: " << r << std::endl;
	return in_file; //WARNING
}

// ========================
// ========================
// ========================

bool Object_creator::int_2d_vector (Parser * parser) {
	output->info("int_2d_vector creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<int> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_2D_VECTOR_NNT(v,"","")
	}


	int index = object_container->int_2d_vector.size ();
	object_container->int_2d_vector.push_back (v);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("int_2d_vector"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"i2d: " << v << std::endl;
	return in_file; //WARNING
}

// ========================
// ========================
// ========================

bool Object_creator::real_2d_vector (Parser * parser) {
	output->info("real_2d_vector creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector2D<double> v{0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_2D_VECTOR_NNT(v,"" ,"")
	}


	int index = object_container->real_2d_vector.size ();
	object_container->real_2d_vector.push_back (v);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("real_2d_vector"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"r2d: " << v << std::endl;
	return in_file; //WARNING
}

// ========================
// ========================
// ========================


bool Object_creator::int_3d_vector (Parser * parser) {
	output->info("int_3d_vector creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<int> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION 
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_INT_3D_VECTOR_NNT(v,"","")
	}


	int index = object_container->int_3d_vector.size ();
	object_container->int_3d_vector.push_back (v);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("int_3d_vector"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"i3d: " << v << std::endl;
	return in_file; //WARNING
}

// ========================
// ========================
// ========================


bool Object_creator::real_3d_vector (Parser * parser) {
	output->info("real_3d_vector creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	Vector<double> v{0,0,0};

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_OR_CHOOSE_A_REAL_3D_VECTOR_NNT(v,"","")\

	}

	int index = object_container->real_3d_vector.size ();
	object_container->real_3d_vector.push_back (v);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("real_3d_vector"), index);	
	object_container->dictionary.insert (std::make_pair(NAME,dict));

	//std::cout <<"r3d: " << v << std::endl;
	return in_file; //WARNING
}

