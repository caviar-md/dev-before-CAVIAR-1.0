#include "shape.h"

#include "object_handler.h"
#include "object_handler_preprocessors.h"
#include "object_handler_dictionary.h"

#include "parser.h"
#include "lexer.h"


namespace NS_shape {

	
// ========================
// ========================
// ========================
//			Shape
// ========================
// ========================
// ========================

		Shape::Shape (MD *md) : Pointers{md},
				output{md->output}, error{md->error} {}
		Shape::~Shape () {}
		
		/*
		bool Shape::read(Parser * parser) {return true;}
		bool Shape::is_inside (const Vector<double> &v) {return true;}
		bool Shape::is_outside (const Vector<double> &v) {return true;}
		bool Shape::is_inside (const Vector<double> &v, const double r) {return true;}
		bool Shape::is_outside (const Vector<double> &v, const double r) {return true;}	
		bool Shape::is_valid () {return true;}
*/

// ========================
// ========================
// ========================


// ========================
// ========================
// ========================


}

