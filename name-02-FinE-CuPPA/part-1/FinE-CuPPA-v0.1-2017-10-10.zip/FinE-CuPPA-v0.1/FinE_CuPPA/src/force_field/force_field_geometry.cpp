#include "force_field_geometry.h"

#include <string>
#include <cmath>
#include <fstream>
#include <boost/algorithm/string.hpp>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
#include "object_handler_all.h"
#include "object_container.h"

Force_field_geometry::Force_field_geometry (MD *md) : Force_field {md}, output{md->output}, error{md->error}
{ 
	output->info ("A geometry force field is created.");
	young_modulus = 100.0;
	dissip_coef = 0.0;
}

Force_field_geometry::~Force_field_geometry () { 

}

bool Force_field_geometry::read (class Parser *parser) {

	output->info("Force_field read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
		if (boost::iequals(t,"cutoff")) {
			error->all (FILE_LINE_FUNC, "cutoff is not implemented in force_field geometry");  
		} else if (boost::iequals(t,"add_boundary")) {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,""," expected an BOUNDARY NAME. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "","")
      if (it_1->second.type != NS_object_handler::gdst("boundary"))
        error->all(FILE_LINE_FUNC,": undefined BOUNDARY NAME. ");
      shape.push_back (&object_container->boundary[it_1->second.index]);
      //boundary_check = true;
	  }	else if (boost::iequals(t,"add_shape")) {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,""," expected an SHAPE NAME. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "","")
      if (it_1->second.type != NS_object_handler::gdst("shape"))
        error->all(FILE_LINE_FUNC,": undefined shape NAME. ");
      shape.push_back (object_container->shape[it_1->second.index]);
      //shape_check = true;
	  } else if (boost::iequals(t,"young_modulus")) {
      GET_OR_CHOOSE_A_REAL(young_modulus,"","")
		} else if (boost::iequals(t,"dissip_coef")) {
      GET_OR_CHOOSE_A_REAL(dissip_coef,"","")
		} else if (boost::iequals(t,"radius")) {
      GET_A_STDVECTOR_REAL_ELEMENT(radius)
      if (vector_value < 0)  error->all (FILE_LINE_FUNC, "radius have to be non-negative.");      
		} else error->all (FILE_LINE_FUNC, "Unknown variable or command");
	}
	
	return in_file;
}


void Force_field_geometry::calculate_acceleration () {
  const auto &pos = atom_data -> owned.position;
  const auto &vel = atom_data -> owned.velocity;  
	auto &acc = atom_data -> owned.acceleration;
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto mass_i = atom_data -> owned.mass [ type_i ];	 
		const auto r = radius [ type_i ];
		for (unsigned int j=0; j<shape.size();++j) {
		  Vector <Real_t> contact_vector {0,0,0};				
      if (shape[j] -> in_contact(pos[i], r, contact_vector)) {
			  acc[i] -= contact_vector*young_modulus/mass_i;
			  acc[i] -= contact_vector*(vel[i]*contact_vector)*dissip_coef/(mass_i*(contact_vector*contact_vector));
			}
		}
	}
}




