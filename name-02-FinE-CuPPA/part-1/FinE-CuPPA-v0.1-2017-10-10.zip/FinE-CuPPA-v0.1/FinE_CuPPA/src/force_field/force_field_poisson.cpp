#include "force_field_poisson.h"

#include <cmath>
#include <boost/algorithm/string.hpp>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "vector.h"
#include "output.h"
#include "object_handler_all.h"
#include "object_container.h"


Force_field_poisson::Force_field_poisson (MD *md) : Force_field {md}, output{md->output}, error{md->error}
{

}

bool Force_field_poisson::read (Parser *parser) {

  return true; // WARNING
}

void Force_field_poisson::calculate_acceleration () {

}


