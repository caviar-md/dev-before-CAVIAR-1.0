#include "force_field_lj.h"

#include <cmath>
#include <boost/algorithm/string.hpp>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"
#include "object_handler_all.h"
#include "object_container.h"

Force_field_lj::Force_field_lj (MD *md) : Force_field{md}, output{md->output}, error{md->error} {
	output->info ("A Lennard-Jones force field is created.");
}

bool Force_field_lj::read (Parser *parser) {
	output->info("Force_field read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
		if (boost::iequals(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
	    if (cutoff < 0.0) error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");		  
		} else if (boost::iequals(t,"epsilon")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(epsilon)
      if (vector_value < 0)  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");      
		}	else if (boost::iequals(t,"sigma")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(sigma)
      if (vector_value < 0)  error->all (FILE_LINE_FUNC, "Sigma have to be non-negative.");            
		} else error->all (FILE_LINE_FUNC, "Molecule: read: Unknown variable or command");
	}
	
	return in_file;
}

void Force_field_lj::calculate_acceleration () {
	potential_energy = 0.0;
	auto cutoff_sq = cutoff * cutoff;
  const auto &neighbor_list = neighbor -> neighlist;
  for (unsigned int i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
  	const auto type_i = atom_data -> owned.type [i];
    const auto mass_i = atom_data -> owned.mass [ type_i ];
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j;
			Real_t type_j, mass_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
      	pos_j = atom_data->ghost.position [j];
      	type_j = atom_data->ghost.type [j];
			} else {
      	pos_j = atom_data->owned.position [j];
      	type_j = atom_data->owned.type [j];
			}
      mass_j = atom_data->owned.mass [ type_j ];
		
      auto dr = pos_j - pos_i; 
      auto r_sq = dr*dr;
      if (r_sq > cutoff_sq) continue;
      const auto eps_ij = epsilon [type_i] [type_j];
      const auto sigma_ij =  sigma [type_i] [type_j];
//      auto rho_c_inv = sigma_ij / cutoff;
//      auto rho_c_6_inv = ipow (rho_c_inv, 6);
//      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
//      auto rho_c_18_inv = rho_c_12_inv*rho_c_6_inv;
      auto r_c_sq_inv = 1/(cutoff*cutoff);
      auto rho_c_sq_inv = sigma_ij*sigma_ij*r_c_sq_inv;
      auto rho_c_6_inv = rho_c_sq_inv*rho_c_sq_inv*rho_c_sq_inv;
      auto rho_c_12_inv = rho_c_6_inv*rho_c_6_inv;
      auto r_sq_inv = 1/r_sq;
      auto rho_sq_inv = sigma_ij*sigma_ij*r_sq_inv;
      auto rho_6_inv = rho_sq_inv*rho_sq_inv*rho_sq_inv;
      auto rho_12_inv = rho_6_inv*rho_6_inv;
//      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + (2*rho_c_18_inv - rho_c_12_inv) * r_sq*r_sq/ipow (sigma_ij, 6) ) * dr;
      auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + 
														 +12*rho_c_12_inv*r_c_sq_inv - 6*rho_c_6_inv*r_c_sq_inv 	) * dr;
			auto dr_norm = std::sqrt(r_sq);
			auto r_m_rc = dr_norm-cutoff;
			potential_energy += 4*eps_ij*(+rho_12_inv - rho_6_inv 
														 				-rho_c_12_inv + rho_c_6_inv 
																		+4.0*eps_ij*(-12*rho_c_12_inv*r_c_sq_inv +6*rho_c_6_inv*r_c_sq_inv )*r_m_rc*dr_norm);
			atom_data -> owned.acceleration [i] += force / mass_i;
			if (!is_ghost)
      	atom_data -> owned.acceleration [j] -= force / mass_j;
			 
		}
  }

}


