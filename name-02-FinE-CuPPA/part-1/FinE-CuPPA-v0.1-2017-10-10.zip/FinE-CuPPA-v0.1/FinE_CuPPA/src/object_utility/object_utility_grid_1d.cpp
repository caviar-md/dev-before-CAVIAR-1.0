#include "object_utility_grid_1d.h"
#include "object_handler_all.h"
#include "object_container.h"

//====================================
//====================================
//====================================

namespace NS_object_utility {

	Grid_1D::Grid_1D () {}
	
  Grid_1D::Grid_1D (Object_container * all_obj) : 
    min{0}, max{0}, increment{-1},
    generated{false}, by_increment{false}, by_segment{false}, segment{-1}, no_given_points{0},
     parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
   { }
   	
  Grid_1D::Grid_1D (Object_container * all_obj, double min, double max, double increment, int segment) : 
    min{min}, max{max}, increment{increment},
    generated{false}, by_increment{false}, by_segment{false}, segment{segment}, no_given_points{0},
     parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
   { }
  
	Grid_1D::~Grid_1D () {
		}
	bool Grid_1D::read(Parser* parser) {
		output->info("GRID_1D Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="generate") {generate(); break;}		  
		  else ASSIGN_REAL(min,"GRID_1D Read: ","")
		  else ASSIGN_REAL(max,"GRID_1D Read: ","")
		  else ASSIGN_REAL(increment,"GRID_1D Read: ","")
		  else ASSIGN_INT(segment,"GRID_1D Read: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D Read: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Grid_1D::generate () {
		output->info("Grid_1d Generate: ");		
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Grid_1D: cannot be generated twice. ");
	  generated = true;
    if (segment>0 && increment>0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assigning both segment and increment is not possible. ");
    if (segment<0 && increment<0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assign one of segment or increment. ");
	  if (min > max)
	    error->all(FILE_LINE_FUNC,"Grid_1D: min has to be smaller than max. ");	  
	  if (segment<0) {
	    by_increment = true;
	    segment = int ((max-min)/increment);
	  }
	  if (increment<0) {
	    by_segment = true;
	    increment = (max - min)/double(segment);
	  }
	}
	
	unsigned int Grid_1D::no_points () {
	
	  if (by_segment)
	    return segment + 1;
	  else
	    return segment;
	}
	
	double Grid_1D::give_point () {
    double val = min + no_given_points * increment;
	  ++no_given_points;    
	  if (by_segment) {
	    if (no_given_points > segment) return max;
	    else return val;
	  } else {
      return val;	  
	  }
	}
	
  double Grid_1D::give_point (int i) {
    double val = min + i * increment;  
	  if (by_segment) {
	    if (i == segment) return max;
	    else return val;
	  } else {
      return val;	  
	  }
	}
}
