#include "object_utility_element.h"
#include "object_handler_all.h"
#include "object_container.h"

namespace NS_object_utility {

//====================================
//====================================
//====================================

Element::Element () {} 

Element::Element (Object_container * all_obj) :
	 element_index{0}, mass{1}, radius{1}, charge{0}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj} {} 
	 
Element::Element (Object_container * all_obj, double m, double r, double ch, unsigned int i) :
	 element_index{i}, mass{m}, radius{r}, charge{ch}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj} {} 

Element::~Element () {}
	
// =============================


bool Element::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(radius,"ELEMENT READ: ","")
		else ASSIGN_REAL(mass,"ELEMENT READ: ","")
		else ASSIGN_REAL(charge,"ELEMENT READ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: Unknown variable or command");		
	}
	
	return in_file;;
}

}
