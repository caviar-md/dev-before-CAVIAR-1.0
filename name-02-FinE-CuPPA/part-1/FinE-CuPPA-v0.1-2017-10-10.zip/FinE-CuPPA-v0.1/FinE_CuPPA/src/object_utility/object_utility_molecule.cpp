#include "object_utility_molecule.h"
#include "object_handler_all.h"
#include "object_container.h"

namespace NS_object_utility {

	Molecule::Molecule () : 
	has_father{false}, FATHER{0}, position{Vector<double>{0,0,0}}, velocity{Vector<double>{0,0,0}}
	  {}
	  
	Molecule::Molecule (Object_container * all_obj) : 
		 FATHER{0},  position{Vector<double>{0,0,0}}, velocity{Vector<double>{0,0,0}},
		 output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
		  {}	  
	  
	Molecule::Molecule (Object_container * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel) : 
		 FATHER{f},  position{pos}, velocity{vel},
		 output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
		  {}
		
 	Molecule::~Molecule () {}
 	
	Molecule::Molecule (const Molecule & a) :
	has_father{false}, FATHER{0}, position{a.position}, velocity{a.velocity},  	
	output{a.output}, error{a.error}, object_container{a.object_container} 
	{
	  for (auto i : a.molecules) {
	    Molecule a_new (i);
	    a_new.has_father = true;
	    a_new.FATHER = this;
	    molecules.push_back (a_new);
	  }
	  for (auto i : a.atoms) {
	    Atom a_new (i);
	    a_new.has_father = true;
	    a_new.FATHER = this;	    
	    atoms.push_back (a_new);
	  }
	  	  
	}


// =============================


bool Molecule::read ( Parser * parser) {
	output->info("Molecule read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(position,"MOLECULE READ: ","")
		else ASSIGN_REAL_3D_VECTOR(velocity,"MOLECULE READ: ","")
		else error->all (FILE_LINE_FUNC, "Molecule: read: Unknown variable or command");
	}
	
	return in_file;
}

//====================================

void Molecule::give_position_and_radius (std::vector<Vector<double>> &p_vector, std::vector<double> &r_vector) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].give_position_and_radius (p_vector, r_vector);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    r_vector.push_back (atoms[i].get_radius());
    p_vector.push_back (atoms[i].pos_tot());
  }  
}

// =============================

void Molecule::correct_heritage () {
	for (unsigned int i = 0; i < molecules.size(); ++i) {
	  molecules[i].FATHER = this;
	  molecules[i].has_father = true;
	  molecules[i].correct_heritage ();
	}	
	for (unsigned int i = 0; i < atoms.size(); ++i) {
	  atoms[i].FATHER = this;
	  atoms[i].has_father = true; 
	}
}

// =============================

void Molecule::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
	  molecules[i].extract_all_e_pos_vel(e, p, v);
	}
	for (unsigned int i = 0; i < atoms.size(); ++i) {
	  atoms[i].extract_all_e_pos_vel(e, p, v);
	}
 }
 

// =============================

void Molecule::output_xyz (std::ofstream & out_file) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
	  molecules[i].output_xyz (out_file);
	}
	for (unsigned int i = 0; i < atoms.size(); ++i) {
	  atoms[i].output_xyz (out_file);
	}
}


//====================================

Vector<double> Molecule::pos_tot () const {
	if (has_father) return position + FATHER->pos_tot();
 	else return position;	
}
Vector<double> Molecule::vel_tot () const {
	if (has_father) return velocity + FATHER->vel_tot();
  else return velocity;	
}

//====================================

bool Molecule::add_atom (const NS_object_utility::Atom &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].FATHER = this;
  atoms[i].has_father = true;
 	atoms[i].pos() = p;
	atoms[i].vel() = v;
	return true; //WARNING
}

bool Molecule::add_molecule (const NS_object_utility::Molecule &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].FATHER = this;
  molecules[i].has_father = true;
  molecules[i].pos() = p;
  molecules[i].vel() = v;
	return true; //WARNING  
}

bool Molecule::add_atom (const NS_object_utility::Atom & a){
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].FATHER = this;
  atoms[i].has_father = true;
	return true; //WARNING  
}

bool Molecule::add_molecule (const NS_object_utility::Molecule & a){
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].FATHER = this;
  molecules[i].has_father = true;
	return true; //WARNING  
}

//====================================
//====================================
//====================================

}
