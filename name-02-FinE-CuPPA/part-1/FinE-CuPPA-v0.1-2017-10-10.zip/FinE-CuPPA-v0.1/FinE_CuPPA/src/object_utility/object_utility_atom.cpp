#include "object_utility_atom.h"

#include <boost/algorithm/string.hpp>

#include "object_handler_all.h"
#include "object_container.h"
#include "error.h"

namespace NS_object_utility {

	Atom::Atom () :  has_father{false}, FATHER{0}, position{Vector<double>{0,0,0}}, velocity{Vector<double>{0,0,0}}
	 {}	
	 
Atom::Atom (Object_container * all_obj) : 
		 FATHER{0}, position{Vector<double>{0,0,0}}, velocity{Vector<double>{0,0,0}}, element_index{0}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}  {}	 
	 
	Atom::Atom (Object_container * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel, unsigned int el_indx) : 
		 FATHER{f}, position{pos}, velocity{vel}, element_index{el_indx}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}  {}
	
 	Atom::~Atom () {}

	Atom::Atom (const Atom & a) : 
  has_father{false}, FATHER{0}, position{a.position}, velocity{a.velocity},
	element_index{a.element_index}, output{a.output}, error{a.error}, object_container{a.object_container} {}
	
// =============================


bool Atom::read ( Parser * parser) {
	output->info("Atom read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(position,"ATOM READ: ","")
		else ASSIGN_REAL_3D_VECTOR(velocity,"ATOM READ: ","")
		else if (boost::iequals(token.string_value,"element")) {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,""," expected an element NAME. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "","")
      if (it_1->second.type != NS_object_handler::gdst("element"))
        error->all(FILE_LINE_FUNC,": undefined element NAME. ");
      element_index = object_container->element[it_1->second.index].get_element_index();
		}
		else error->all (FILE_LINE_FUNC, "ATOM read: Unknown variable or command");
	}

	return in_file;;
}

// =============================

double Atom::get_radius () const {
  return object_container->element[element_index].get_radius();
}

//====================================


Vector<double> Atom::pos_tot () const {
	if (has_father) return position + FATHER->pos_tot();
 	else return position;	 
}

Vector<double> Atom::vel_tot () const {
	if (has_father) return velocity + FATHER->vel_tot();
	else return velocity;		
}

//====================================

void Atom::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  e.push_back (element_index);
  p.push_back (pos_tot());
  v.push_back (vel_tot());
}

void Atom::output_xyz (std::ofstream & out_file) {
	const auto p = pos_tot();
	out_file << element_index << " " << p.x << " " << p.y << " " << p.z << std::endl;	

}


}
