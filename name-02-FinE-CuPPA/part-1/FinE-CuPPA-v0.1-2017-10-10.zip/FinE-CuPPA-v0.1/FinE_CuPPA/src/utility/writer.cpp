#include "writer.h"

Writer::Writer (MD *md) : Pointers{md} {}
