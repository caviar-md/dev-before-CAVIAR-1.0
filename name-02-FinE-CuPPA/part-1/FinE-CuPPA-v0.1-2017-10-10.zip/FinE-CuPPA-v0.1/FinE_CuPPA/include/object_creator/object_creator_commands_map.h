#ifndef OBJECT_CREATOR_COMMANDS_MAP_H
#define OBJECT_CREATOR_COMMANDS_MAP_H
#include "object_creator.h"
//using CommandFunc_object_creator = bool (Object_creator::*) (Parser *); // a pointer to boolean function of ...

const std::map<std::string, CommandFunc_object_creator> Object_creator::commands_map = {
 		{	"element", &Object_creator::element},
		{	"atom", &Object_creator::atom},
		{	"molecule", &Object_creator::molecule},
		{	"random_1d", &Object_creator::random_1d},
		{	"grid_1d", &Object_creator::grid_1d},		
		{	"boundary", &Object_creator::boundary},
		{	"shape", &Object_creator::shape},
		{	"distribution", &Object_creator::distribution},
		{	"force_field", &Object_creator::force_field},		
		{	"int_variable", &Object_creator::int_variable},
		{	"real_variable", &Object_creator::real_variable},
		{	"int_2d_vector", &Object_creator::int_2d_vector},
		{	"real_2d_vector", &Object_creator::real_2d_vector},
		{	"int_3d_vector", &Object_creator::int_3d_vector},
		{	"real_3d_vector", &Object_creator::real_3d_vector},
};
#endif
