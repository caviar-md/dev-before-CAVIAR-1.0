#ifndef POLYHEDRON_POINT_INSIDE_H
#define POLYHEDRON_POINT_INSIDE_H

#include "pointers.h"
#include "polyhedron.h"

namespace NS_geometry {
class Polyhedron_Point_Inside : protected Pointers {
public:
  Polyhedron_Point_Inside (class MD*);
  ~Polyhedron_Point_Inside ();
  

  bool is_inside(NS_geometry::Polyhedron &, const Vector<double> &v0);
  bool is_outside(NS_geometry::Polyhedron &, const Vector<double> &v);
  bool is_inside(NS_geometry::Polyhedron &, const Vector<double> &v, const double r) ;
  bool is_outside(NS_geometry::Polyhedron &, const Vector<double> &v, const double r);
  bool check_inside (NS_geometry::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius, Vector<double> &contact_vector) ;
  
  bool check_inside (NS_geometry::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius);
  
  bool check_inside_ray (NS_geometry::Polyhedron &, const Vector<Real_t> &v1, const int ray_axis);
  class Output *output;
  class Error *error;
};
}
#endif
