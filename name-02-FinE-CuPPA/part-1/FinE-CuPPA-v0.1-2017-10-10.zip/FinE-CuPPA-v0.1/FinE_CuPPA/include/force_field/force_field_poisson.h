#ifndef FORCE_FIELD_POISSON_H
#define FORCE_FIELD_POISSON_H

#include "force_field.h"

#include <vector>
#include "vector.h"

class Force_field_poisson : public Force_field {
public:
  Force_field_poisson (class MD *);
  ~Force_field_poisson () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  class Parser *parser;
	class Output *output;
	class Error *error;

};

#endif
