#ifndef FORCE_FIELD_DPD_H
#define FORCE_FIELD_DPD_H

#include "force_field.h"

#include <vector>
#include <random>

class Force_field_dpd : public Force_field { // there's a numeric error due to using ghost atoms and different random number generated for their owned counterpart atom. // this problem is solved at Force_field_dpd_acc
public:
  Force_field_dpd (class MD*);
  ~Force_field_dpd () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> conserv_coef,dissip_coef;
	Real_t temperature, kBoltzman;
	int rnd_seed;
	std::mt19937 rnd_generator;
	std::normal_distribution<double> rnd_ndist; // stddev() == 1
	
  class Parser *parser;
	class Output *output;
	class Error *error;	
};

#endif

