#ifndef FORCE_FIELD_GEOMETRY_H
#define FORCE_FIELD_GEOMETRY_H

#include "force_field.h"

#include <vector>
#include <map>

#include "polyhedron_handler.h"
#include "shape.h"

class Force_field_geometry : public Force_field {
public:
  Force_field_geometry (class MD *);
  ~Force_field_geometry ();
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:	
  std::vector<NS_shape::Shape *> shape;
  std::vector<double> radius;
  double young_modulus, dissip_coef;

  class Parser *parser;
	class Output *output;
	class Error *error;

};

#endif
