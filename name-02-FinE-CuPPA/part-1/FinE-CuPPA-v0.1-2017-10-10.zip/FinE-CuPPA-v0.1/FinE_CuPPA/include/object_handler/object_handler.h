#ifndef OBJECT_HANDLER_H
#define OBJECT_HANDLER_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>
#include <string>

#include "pointers.h"
#include "parser.h"
#include "output.h"
#include "error.h"
#include "object_utility_all.h"

using CommandFunc_object_handler = bool (Object_handler::*) (Parser *); // a pointer to boolean function of ...

class Object_handler : protected Pointers  {
public:
  Object_handler (class MD *);
  ~Object_handler ();
  
  const static std::map<std::string, CommandFunc_object_handler> commands_map;
  
	bool output_xyz (Parser *);		
	bool add_atom (Parser *);
	bool add_molecule (Parser *);
	bool add_to_simulation (Parser *);
	bool set_simulation_box (Parser *);
	bool read_object (Parser *, const std::string);
	
  bool add_elements_to_simulation ();	
  bool add_atom_to_simulation (NS_object_utility::Atom &) ;
  bool add_molecule_to_simulation (NS_object_utility::Molecule &);  
  class Object_container * object_container;
	class Parser * parser;
  class Output * output;
  class Error * error;
private:

} ;



#endif
 
