#ifndef SHAPE_POLYHEDRON_H
#define SHAPE_POLYHEDRON_H

#include "pointers.h"

#include <vector>
#include <map>

#include "shape.h"
#include "vector.h"
#include "polyhedron.h"
#include "output.h"
#include "error.h"
#include "md.h"
//#include "kakaka_utility.h"
#include "polyhedron_handler.h"




namespace NS_shape {


class Polyhedron : public Shape {
	public:
	Polyhedron (class MD *);
	~Polyhedron ();
	
  bool read(Parser *);
	//bool read (Parser *, class Object_container *);	
	
	bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
	bool is_outside (const Vector<double> &v);
  bool is_outside (const Vector<double> &, const double rad);	
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);  	

//	MD * md;
  class Object_container * object_container;
	Output * output;
	Error * error;



	private:
	void command_parameters (class Parser *);		
	//void command_output (class Parser *);
	void command_generate ();
			
  NS_geometry::Polyhedron_Handler * polyhedron_handler;


};
}

#endif
