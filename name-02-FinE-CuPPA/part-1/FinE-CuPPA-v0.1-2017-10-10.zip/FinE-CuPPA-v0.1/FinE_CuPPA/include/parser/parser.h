#ifndef PARSER_H
#define PARSER_H

#include "pointers.h"

class Parser : protected Pointers {
public:
  Parser (class MD *);
  Parser (class MD *, const std::string &);

  ~Parser ();
  
  bool end_of_line (); // check if it is end of line
  bool assignment (); // check if it is assignment "="
  
  void keep_current_token () {get_new_token = false;}
  struct Token get_raw_token (); // ? //
  struct Token get_val_token (); // use this //
  
  std::ostream & write_to_stream (std::ostream &); // ? //
  
  std::string get_identifier (); // ? //
  std::string get_command_identifier (); // ? //
  
  int get_int (); // ? //
  Real_t get_real (); // ? // 
  std::string get_string (); // ? //
  
  int get_literal_int (); // use this to get a value//
  Real_t get_literal_real (); // //
  std::string get_literal_string (); // //
  
private:
  class Token_stream *token_stream;
  bool get_new_token;
  
  double expression (bool);
  double term (bool);
  double primary (bool);
public:
  std::string &line;
  unsigned int &col;
};

#endif
