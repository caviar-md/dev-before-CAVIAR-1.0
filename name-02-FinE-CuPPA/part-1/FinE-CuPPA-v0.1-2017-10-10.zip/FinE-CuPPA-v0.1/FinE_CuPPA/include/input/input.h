#ifndef INPUT_H
#define INPUT_H

#include <istream>
#include <map>

#include "pointers.h"

using CommandFunc = bool (Input::*) (class Parser *); // a pointer to boolean function of Input class.

class Input : protected Pointers {
public:
  Input (class MD *);
  Input (class MD *, const std::string &);
  ~Input ();
  
  void read ();
private:
  class Parser *parser;
  const static std::map<std::string,CommandFunc> commands_map;
  void read (Parser *); 
  
  bool read_command (Parser *);
  
  bool read_data_with_format (Parser *);
  bool read_script_from_file (Parser *);
  bool run_simulation (Parser *);
	bool time_step (Parser *);
	bool output_step (Parser *);	
	bool periodic_boundary (Parser *);
  bool delete_object (Parser *);	
  bool exit_program (Parser *);
  bool print (Parser *);

};

#endif
