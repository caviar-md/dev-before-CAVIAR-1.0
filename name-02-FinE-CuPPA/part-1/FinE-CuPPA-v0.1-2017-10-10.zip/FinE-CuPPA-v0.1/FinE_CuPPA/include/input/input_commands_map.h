#ifndef INPUT_COMMANDS_MAP_H
#define INPUT_COMMANDS_MAP_H
#include "input.h"
//using CommandFunc = bool (Input::*) (class Parser *); 

const std::map<std::string,CommandFunc> Input::commands_map = {
  

	{"periodic_boundary",&Input::periodic_boundary},
	
	
	{"time_step",&Input::time_step},
	{"timestep",&Input::time_step},	
	
	
	{"output_step",&Input::output_step},
	
	
	{"read",&Input::read_script_from_file},	
	{"read_script",&Input::read_script_from_file},
	{"read_script_from_file",&Input::read_script_from_file},	
	
	
  {"read_data_with_format", &Input::read_data_with_format},
  {"read_data_of_format", &Input::read_data_with_format},
  {"read_data", &Input::read_data_with_format},


  {"delete_object", &Input::delete_object},
  {"delete_instance", &Input::delete_object},
  {"delete", &Input::delete_object},  
 
          
  {"print", &Input::print},
  
  
  {"run_simulation", &Input::run_simulation},
  {"run", &Input::run_simulation},
    
    
  {"exit", &Input::exit_program},
  {"quit", &Input::exit_program}
};
#endif
