#ifndef VECTOR2D_H
#define VECTOR2D_H

#include <iostream>

template <typename T>
struct Vector2D {
  T x, y;
};

template <typename T>
Vector2D<T> operator+ (const Vector2D<T> &lhs) {
  return lhs;
}

template <typename T>
Vector2D<T> operator- (const Vector2D<T> &lhs) {
  return Vector2D<T> {-lhs.x, -lhs.y};
}

template <typename T>
Vector2D<T> operator+ (const Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  return Vector2D<T> {lhs.x+rhs.x, lhs.y+rhs.y};
}

template <typename T>
Vector2D<T> operator- (const Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  return Vector2D<T> {lhs.x-rhs.x, lhs.y-rhs.y};
}

template <typename T>
T operator* (const Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  return lhs.x*rhs.x + lhs.y*rhs.y;
}

template <typename T>
Vector2D<T> operator* (const Vector2D<T> &lhs, const double &rhs) {
  return Vector2D<T> {lhs.x*rhs, lhs.y*rhs};
}

template <typename T>
Vector2D<T> operator/ (const Vector2D<T> &lhs, const double &rhs) {
  return Vector2D<T> {lhs.x/rhs, lhs.y/rhs};
}

template <typename T>
Vector2D<T> operator* (const double &lhs, const Vector2D<T> &rhs) {
  return Vector2D<T> {rhs.x*lhs, rhs.y*lhs};
}

template <typename T>
bool operator== (const Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  return rhs.x==lhs.x && rhs.y==lhs.y;
}

template <typename T>
Vector2D<T> & operator+= (Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  lhs.x += rhs.x;
  lhs.y += rhs.y;
  return lhs;
}

template <typename T>
Vector2D<T> & operator-= (Vector2D<T> &lhs, const Vector2D<T> &rhs) {
  lhs.x -= rhs.x;
  lhs.y -= rhs.y;
  return lhs;
}

template <typename T>
Vector2D<T> & operator*= (Vector2D<T> &lhs, const double &rhs) {
  lhs.x *= rhs;
  lhs.y *= rhs;
  return lhs;
}

template <typename T>
Vector2D<T> & operator/= (Vector2D<T> &lhs, const double &rhs) {
  lhs.x /= rhs;
  lhs.y /= rhs;
  return lhs;
}

template <typename T>
std::ostream & operator<< (std::ostream& out, const Vector2D<T> &rhs) {
  return out << rhs.x << '\t' << rhs.y;
}

template <typename T>
std::istream& operator<< (std::istream& in, Vector2D<T> &rhs) {
  return in >> rhs.x >> rhs.y ;
}


#endif
