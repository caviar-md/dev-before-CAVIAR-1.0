#ifdef USE_MPI
#include <mpi.h>
#endif

//#include "geometry.h"
//#include "dealii-electrostatic.h"
#include "md.h"

using namespace std;


int main (int argc, char* argv[]) {
#ifdef USE_MPI
  MPI_Init (&argc, &argv);
  MD md (argc, argv, MPI::COMM_WORLD);
#else
  MD md (argc, argv);
#endif
  
  md.execute ();
  
#ifdef USE_MPI
  MPI_Barrier (MPI_COMM_WORLD);
  MPI_Finalize ();
#endif
  return 0;
}
