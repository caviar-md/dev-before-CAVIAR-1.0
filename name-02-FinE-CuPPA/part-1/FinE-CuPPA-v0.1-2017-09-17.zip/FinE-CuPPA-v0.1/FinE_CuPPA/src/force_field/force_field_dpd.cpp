#include "force_field_dpd.h"

#include <cmath>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"
#include "update.h"

#define _KB 1.0  // boltzman constant 1.38064852E-23

Force_field_dpd::Force_field_dpd (MD *md, Parser *parser) : Force_field {md, parser},
conserv_coef (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)),
dissip_coef (atom_data->num_atom_types, std::vector<Real_t> (atom_data->num_atom_types)) {
	temperature = parser->get_literal_real ();
	cutoff = parser->get_literal_real ();
	rnd_seed 	= parser->get_literal_int ();

	if (temperature < 0.0)
    error->all (FILE_LINE_FUNC, "DPD temperature have to be non-negative.");

	if (cutoff < 0.0)
    error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");

	rnd_generator.seed(rnd_seed);

	std::cout<<"info: force field DPD: temperature = " << temperature << "\n"; 
	std::cout<<"info: force field DPD: cutoff = " << cutoff << "\n"; 
	std::cout<<"info: force field DPD: random generator seed = " << rnd_seed << "\n"; 

	output->info ("A DPD force field is made.");
	kinetic_energy=0.0; potential_energy=0.0;
}

bool Force_field_dpd::set_parameters (Parser *parser) {
  unsigned int type_i = parser->get_literal_int ();
  
  if (type_i > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be non-negative and smaller than number of the atom types.");
  
  unsigned int type_j = parser->get_literal_int ();
  if (type_j > atom_data->num_atom_types)
    error->all (FILE_LINE_FUNC, "Atom types have to be non-negative and smaller than number of the atom types.");

  Real_t conserv_coef_ij = parser->get_literal_real ();
  if (conserv_coef_ij < 0)
  error->all (FILE_LINE_FUNC, "Conservative force coef. have to be non-negative.");
  conserv_coef [type_i][type_j] = conserv_coef [type_j][type_i] = conserv_coef_ij;
  
  Real_t dissip_coef_ij = parser->get_literal_real ();
  if (dissip_coef_ij <= 0)
  error->all (FILE_LINE_FUNC, "Dissipative force coef. have to be larger than 0 .");
  dissip_coef [type_i][type_j] = dissip_coef [type_j][type_i] = dissip_coef_ij;
//	output->info ("Force field parameter set.");
	std::cout << "info: force field DPD: for atom types " << type_i << " and " << type_j 
						<< " , conservative force coef = " << conserv_coef_ij  
						<< " , dissipative force coef = " << dissip_coef_ij << "\n";
  return true; //WARNING						
}

void Force_field_dpd::calculate_acceleration () {
  auto cutoff_sq = cutoff * cutoff;
	const auto dt = md -> update -> dt; 
	auto dt_sq_inv = 1.0 / std::sqrt(dt);
  const auto &neighbor_list = neighbor -> neighlist;
  for (unsigned int i=0; i<neighbor_list.size (); ++i) {
    const auto &pos_i = atom_data -> owned.position [i];
		const auto &vel_i = atom_data -> owned.velocity [i];
  	const auto type_i = atom_data -> owned.type [i];
    const auto mass_i = atom_data -> owned.mass [ type_i ];
    for (auto j : neighbor_list[i]) {
      bool is_ghost = j >= neighbor_list.size();
			Vector<Real_t> pos_j, vel_j;
			Real_t type_j, mass_j;
      if (is_ghost) {
        j -= neighbor_list.size ();
      	pos_j = atom_data->ghost.position [j];
				vel_j = atom_data -> ghost.velocity [j];
      	type_j = atom_data->ghost.type [j];
			} else {
      	pos_j = atom_data->owned.position [j];
				vel_j = atom_data -> owned.velocity [j];
      	type_j = atom_data->owned.type [j];
			}
      mass_j = atom_data->owned.mass [ type_j ];
      auto dr = pos_j - pos_i;
			auto dv = vel_j - vel_i;
      auto r_sq = dr*dr;
			auto r_sqrt = std::sqrt(r_sq);
      if (r_sq > cutoff_sq) continue;
			auto dr_norm = dr / r_sqrt;
      const auto conserv_coef_ij = conserv_coef [type_i] [type_j];
      const auto dissip_coef_ij =  dissip_coef [type_i] [type_j];
			auto sigma = std::sqrt (2.0 * _KB *temperature*dissip_coef_ij);
			auto w_r = 1.0 - (r_sqrt/cutoff);
			auto alpha = rnd_ndist (rnd_generator); // 
			auto force_conserv = conserv_coef_ij * w_r;
			auto force_dissip = - dissip_coef_ij * w_r * w_r * (dr_norm * dv);
			auto force_rand = sigma * w_r * alpha* dt_sq_inv;
      auto force = -(force_conserv + force_dissip + 0.0*force_rand) * dr_norm;
			atom_data -> owned.acceleration [i] += force / mass_i;
			if (!is_ghost)
      	atom_data -> owned.acceleration [j] -= force / mass_j;
		}
  }
}

