#include "polyhedron_output.h"

#include <string>
#include <cmath>
#include <fstream>


namespace Namespace_Geometry {

Polyhedron_Output::Polyhedron_Output (MD *md) : Pointers{md} {}

Polyhedron_Output::~Polyhedron_Output () {}

void Polyhedron_Output::mesh_povray (const Namespace_Geometry::Polyhedron & p_object, std::string file_name) {
	std::ofstream pov_file (file_name.c_str());

		const auto & vertex = p_object.vertex;
		const auto & face = p_object.face;


		pov_file <<"\nmesh {\n";
		for (unsigned int i=0;i<face.size();++i) {
			pov_file << "\ttriangle { ";
			pov_file << "<" << vertex[face[i][0]].x << "," << vertex[face[i][0]].y  << "," << vertex[face[i][0]].z << ">," ;
			pov_file << "<" << vertex[face[i][1]].x << "," << vertex[face[i][1]].y  << "," << vertex[face[i][1]].z << ">,";
			pov_file << "<" << vertex[face[i][2]].x << "," << vertex[face[i][2]].y  << "," << vertex[face[i][2]].z << "> }\n";
		}
		pov_file << "\ttexture {\n\t\tpigment { color rgb<0.9, 0.9, 0.9> }";
		pov_file << "\n\t\tfinish { ambient 0.2 diffuse 0.7 }\n\t}\n";	
		pov_file << "}";
		pov_file << std::flush;

	pov_file.close ();
}

void Polyhedron_Output::normals_tcl (const Namespace_Geometry::Polyhedron & p_object, std::string file_name) {
	std::ofstream vmd_file (file_name.c_str());

		const auto & vertex = p_object.vertex;
		const auto & face = p_object.face;
		const auto & normal = p_object.normal;

		Real_t vec_length = 5.0;
		Real_t vec_rad = 1.5;

		for (unsigned int i=0;i<face.size();++i) {
			Vector<Real_t> cr = {(vertex[face[i][0]].x + vertex[face[i][1]].x + vertex[face[i][2]].x)/3.0, 
														(vertex[face[i][0]].y + vertex[face[i][1]].y + vertex[face[i][2]].y)/3.0,
														(vertex[face[i][0]].z + vertex[face[i][1]].z + vertex[face[i][2]].z)/3.0};

			Vector<Real_t> di = cr + vec_length*normal[i];
			cr -=  (vec_length/10.0) * normal[i];

			vmd_file << "graphics top cone ";
			vmd_file << "{" << cr.x << " " << cr.y  << " " << cr.z << "} ";
			vmd_file << "{" << di.x << " " << di.y  << " " << di.z << "} ";
			vmd_file << "radius " << vec_rad << " resolution 5\n";
		}
		vmd_file << std::flush;

	vmd_file.close ();
}

void Polyhedron_Output::edges_tcl (const Namespace_Geometry::Polyhedron & p_object, std::string file_name) {
	std::ofstream vmd_file (file_name.c_str());

		const auto & vertex = p_object.vertex;
		const auto & edges = p_object.edges;

		Real_t frame_rad = 0.5;
		std::map<std::vector<unsigned int>,std::vector<unsigned int>>::const_iterator it;
		for (it = edges.begin(); it != edges.end(); ++it) {

			vmd_file << "graphics top cylinder ";
			vmd_file << "{" << vertex[it->first[0]].x << " " << vertex[it->first[0]].y  << " " << vertex[it->first[0]].z << "} " ;
			vmd_file << "{" << vertex[it->first[1]].x << " " << vertex[it->first[1]].y  << " " << vertex[it->first[1]].z << "} " ;
			vmd_file << "radius " << frame_rad << " resolution " << 5 << " filled yes\n";
		}
		vmd_file << std::flush;

	vmd_file.close ();
}


void Polyhedron_Output::mesh_tcl (const Namespace_Geometry::Polyhedron & p_object, std::string file_name) {
	std::ofstream vmd_file (file_name.c_str());

		const auto & vertex = p_object.vertex;
		const auto & face = p_object.face;

		for (unsigned int i=0;i<face.size();++i) {
			vmd_file << "graphics top triangle ";
			vmd_file << "{" << vertex[face[i][0]].x << " " << vertex[face[i][0]].y  << " " << vertex[face[i][0]].z << "} " ;
			vmd_file << "{" << vertex[face[i][1]].x << " " << vertex[face[i][1]].y  << " " << vertex[face[i][1]].z << "} " ;
			vmd_file << "{" << vertex[face[i][2]].x << " " << vertex[face[i][2]].y  << " " << vertex[face[i][2]].z << "}\n";
		}

		vmd_file << std::flush;

	vmd_file.close ();
}

/*
void Polyhedron_Output::mesh_povray (const std::vector<Namespace_Geometry::Polyhedron> & shapes) {
	std::ofstream pov_file ("o_mesh.pov");
	for (unsigned int shape_index=0; shape_index < p_object.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;


		pov_file <<"\nmesh {\n";
		for (unsigned int i=0;i<face.size();++i) {
			pov_file << "\ttriangle { ";
			pov_file << "<" << vertex[face[i][0]].x << "," << vertex[face[i][0]].y  << "," << vertex[face[i][0]].z << ">," ;
			pov_file << "<" << vertex[face[i][1]].x << "," << vertex[face[i][1]].y  << "," << vertex[face[i][1]].z << ">,";
			pov_file << "<" << vertex[face[i][2]].x << "," << vertex[face[i][2]].y  << "," << vertex[face[i][2]].z << "> }\n";
		}
		pov_file << "\ttexture {\n\t\tpigment { color rgb<0.9, 0.9, 0.9> }";
		pov_file << "\n\t\tfinish { ambient 0.2 diffuse 0.7 }\n\t}\n";	
		pov_file << "}";
		pov_file << std::flush;
	}
	pov_file.close ();
}

void Polyhedron_Output::normals_vmd (const std::vector<Namespace_Geometry::Polyhedron> & shapes) {
	std::ofstream vmd_file ("o_normals.tcl");
	for (unsigned int shape_index=0; shape_index < p_object.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;
		const auto & normal = shapes[shape_index].normal;

		Real_t vec_length = 5.0;
		Real_t vec_rad = 1.5;

		for (unsigned int i=0;i<face.size();++i) {
			Vector<Real_t> cr = {(vertex[face[i][0]].x + vertex[face[i][1]].x + vertex[face[i][2]].x)/3.0, 
														(vertex[face[i][0]].y + vertex[face[i][1]].y + vertex[face[i][2]].y)/3.0,
														(vertex[face[i][0]].z + vertex[face[i][1]].z + vertex[face[i][2]].z)/3.0};

			Vector<Real_t> di = cr + vec_length*normal[i];
			cr -=  (vec_length/10.0) * normal[i];

			vmd_file << "graphics top cone ";
			vmd_file << "{" << cr.x << " " << cr.y  << " " << cr.z << "} ";
			vmd_file << "{" << di.x << " " << di.y  << " " << di.z << "} ";
			vmd_file << "radius " << vec_rad << " resolution 5\n";
		}
		vmd_file << std::flush;
	}
	vmd_file.close ();
}

void Polyhedron_Output::edges_vmd (const std::vector<Namespace_Geometry::Polyhedron> & shapes) {
	std::ofstream vmd_file ("o_edges.tcl");
	for (unsigned int shape_index=0; shape_index < p_object.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & edges = shapes[shape_index].edges;

		Real_t frame_rad = 0.5;
		std::map<std::vector<unsigned int>,std::vector<unsigned int>>::const_iterator it;
		for (it = edges.begin(); it != edges.end(); ++it) {

			vmd_file << "graphics top cylinder ";
			vmd_file << "{" << vertex[it->first[0]].x << " " << vertex[it->first[0]].y  << " " << vertex[it->first[0]].z << "} " ;
			vmd_file << "{" << vertex[it->first[1]].x << " " << vertex[it->first[1]].y  << " " << vertex[it->first[1]].z << "} " ;
			vmd_file << "radius " << frame_rad << " resolution " << 5 << " filled yes\n";
		}
		vmd_file << std::flush;
	}
	vmd_file.close ();
}


void Polyhedron_Output::mesh_vmd (const std::vector<Namespace_Geometry::Polyhedron> & shapes) {
	std::ofstream vmd_file ("o_mesh.tcl");
	for (unsigned int shape_index=0; shape_index < p_object.size();++shape_index) {
		const auto & vertex = shapes[shape_index].vertex;
		const auto & face = shapes[shape_index].face;

		for (unsigned int i=0;i<face.size();++i) {
			vmd_file << "graphics top triangle ";
			vmd_file << "{" << vertex[face[i][0]].x << " " << vertex[face[i][0]].y  << " " << vertex[face[i][0]].z << "} " ;
			vmd_file << "{" << vertex[face[i][1]].x << " " << vertex[face[i][1]].y  << " " << vertex[face[i][1]].z << "} " ;
			vmd_file << "{" << vertex[face[i][2]].x << " " << vertex[face[i][2]].y  << " " << vertex[face[i][2]].z << "}\n";
		}

		vmd_file << std::flush;
	}
	vmd_file.close ();
}

*/
} //namespace


