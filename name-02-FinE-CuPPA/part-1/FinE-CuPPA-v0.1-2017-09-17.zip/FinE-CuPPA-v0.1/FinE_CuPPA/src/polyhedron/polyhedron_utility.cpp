#include "polyhedron_utility.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "utility.h"

namespace Namespace_Geometry {


Polyhedron_Utility::Polyhedron_Utility (MD *md) : Pointers{md},
				output{md->output}, error{md->error} {}

Polyhedron_Utility::~Polyhedron_Utility () { }


void Polyhedron_Utility::invert_normals (Namespace_Geometry::Polyhedron & p_object) {
	auto & normal = p_object.normal;
	for (unsigned int i=0;i<normal.size();++i)
		normal[i] *= -1;
}


void Polyhedron_Utility::make_edge_norms (Namespace_Geometry::Polyhedron & p_object) {
	const auto & vertex = p_object.vertex;
	const auto & face = p_object.face;
	const auto & edges = p_object.edges;
	const auto & normal = p_object.normal;
	auto & edge_norms3 = p_object.edge_norms3;

	std::vector<std::vector<Vector<Real_t>>> edge_norms1, edge_norms2;
	std::map<std::vector<unsigned int>,std::vector<unsigned int>>::const_iterator it_edges; 
	const unsigned int fsize = face.size();
	edge_norms1.resize (fsize);	
	edge_norms2.resize (fsize);	
	edge_norms3.resize (fsize);
	for (unsigned int i=0;i<fsize;++i) {
		for (unsigned int j=0;j<face[i].size();++j) {
			Vector<Real_t> n1 = normal[i];
			unsigned int k0 = j; unsigned int k1 = (j==face[i].size()-1) ? 0 : j+1;
			unsigned int v0 = face[i][k0]; unsigned int v1 = face[i][k1];
			if (v0<v1) 
				it_edges = edges.find (std::vector<unsigned int>{v0,v1});
			else
				it_edges = edges.find (std::vector<unsigned int>{v1,v0});
			if (it_edges->second.size() == 2) {
				if (it_edges->second[0] != i )
					n1 += normal [it_edges->second[0]];
				else
					n1 += normal [it_edges->second[1]];
			}
			n1 /= std::sqrt (n1*n1); // it is not necessary
			edge_norms1[i].push_back (n1);
//-------
			Vector<Real_t> n2 = vertex[face[i][k1]] - vertex[face[i][k0]];		
			n2 /= std::sqrt (n2*n2); // it is not necessary
			edge_norms2[i].push_back (n2);
//-------
			Vector<Real_t> n3 = cross_product (n1,n2);
			n3 /= std::sqrt (n3*n3); // it is not necessary
			edge_norms3[i].push_back (n3);		
		}
	}


}



void Polyhedron_Utility::make_normal (Namespace_Geometry::Polyhedron & p_object) { // It's supposed here that the vertices are written in order (right-hand rotation)
  const auto & vertex = p_object.vertex;
	const auto & face = p_object.face;
	auto & normal = p_object.normal;

	for (unsigned int i=0;i<face.size();++i) {
		if (face[i].size()<3) continue;
		Vector<Real_t> v1 = vertex[face[i][1]] - vertex[face[i][0]];
		Vector<Real_t> v2 = vertex[face[i][2]] - vertex[face[i][0]];
		Vector<Real_t> n = cross_product (v1,v2);
//		std::cout<<"v1: "<<v1 << " v2 :" << v2 << " v1*v2: "<< n <<std::endl;
		Real_t n_lenght = sqrt (n.x*n.x + n.y*n.y + n.z*n.z);
		n /= n_lenght;
		normal.push_back(n);
	}

}


} //namespace


