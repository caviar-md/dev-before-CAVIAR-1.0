#ifndef POLYHEDRON_INPUT_H
#define POLYHEDRON_INPUT_H

#include "polyhedron.h"
#include "format_vtk_reader.h"
#include "parser.h"

namespace Namespace_Geometry {
class Polyhedron_Input : protected Pointers {
public:
  Polyhedron_Input (class MD *);
  ~Polyhedron_Input ();
  
	void read_vtk (Namespace_Geometry::Polyhedron&, const std::string &); // read vtk format // There's many unneeded points. 


  class Output * output;
  class Error * error;


};
}
#endif
