#ifndef POLYHEDRON_PREPROCESS_H
#define POLYHEDRON_PREPROCESS_H

#include "polyhedron.h"
#include "parser.h"

namespace Namespace_Geometry {
class Polyhedron_Preprocess : protected Pointers {
public:
  Polyhedron_Preprocess (class MD *);
  ~Polyhedron_Preprocess ();
  

	void pre_correct_normals (Namespace_Geometry::Polyhedron&); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.


  void merge_vertices (Namespace_Geometry::Polyhedron&);
  


  class Output * output;
  class Error * error;


};
}
#endif
