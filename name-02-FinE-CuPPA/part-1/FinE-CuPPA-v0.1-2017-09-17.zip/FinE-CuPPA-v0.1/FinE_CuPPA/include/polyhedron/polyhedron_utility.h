#ifndef POLYHEDRON_UTILITY_H
#define POLYHEDRON_UTILITY_H

#include "pointers.h"
#include "polyhedron.h"

namespace Namespace_Geometry {
class Polyhedron_Utility : protected Pointers {
public:
  Polyhedron_Utility (class MD*);
  ~Polyhedron_Utility ();
  

	void make_normal (Namespace_Geometry::Polyhedron &); // after reading unv file, it calculates normal vectors		
	void make_edge_norms (Namespace_Geometry::Polyhedron &); // makes normals of faces made of edges and other normals used in check_inside() algorithm.
	void invert_normals (Namespace_Geometry::Polyhedron &); // multiply all the normal Vectors with -1

  class Output * output;
  class Error * error;
};
}
#endif
