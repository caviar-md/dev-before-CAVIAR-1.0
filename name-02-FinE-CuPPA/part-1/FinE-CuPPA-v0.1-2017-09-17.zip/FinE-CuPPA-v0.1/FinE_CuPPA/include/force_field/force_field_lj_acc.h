#ifdef FORCE_FIELD_CLASS

ForceFieldStyle(LJ_ACC,Force_field_lj_acc)

#else

#ifndef FORCE_FIELD_LJ_ACC_H
#define FORCE_FIELD_LJ_ACC_H

#include "force_field.h"

#include <vector>

class Force_field_lj_acc : public Force_field {
public:
  Force_field_lj_acc (class MD *, class Parser *);
  ~Force_field_lj_acc () {};
  
  bool set_parameters (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> epsilon,sigma;
};

#endif
#endif
