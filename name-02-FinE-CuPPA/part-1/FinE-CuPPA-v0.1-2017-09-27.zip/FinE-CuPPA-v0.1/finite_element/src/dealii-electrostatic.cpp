
#include "dealii-electrostatic.h"

//==================================================
//==================================================
//==================================================


//==================================================
//==================================================
//==================================================

void Error_calculator::calculate_and_output () {

  const unsigned int no_points = calculated.size();
  
  err_tot = 0; err_tot_sq = 0; err_tot_abs = 0;
  err_res = 0; err_res_sq = 0; err_res_abs = 0;  

  for (unsigned int i = 0; i < no_points; ++i) {
  
    const double v_an = analytic   [i];
    const double v_ca = calculated [i];
    
    const double err   = v_ca - v_an;
    const double err_r = err / v_an;
    
    err_tot       += err;
    err_tot_abs   += std::abs (err);
    err_tot_sq    += err*err;
    err_res       += err_r;
    err_res_abs   += std::abs (err_r);
    err_res_sq    += err_r*err_r;
  
  }
  
  const double no_points_inv = 1.0/no_points;
  
  err_tot     *= no_points_inv;
  err_tot_abs *= no_points_inv;
  err_tot_sq  *= no_points_inv; 
  err_res     *= no_points_inv;  
  err_res_abs *= no_points_inv;  
  err_res_sq  *= no_points_inv;  

  err_tot_std = 0; err_tot_sq_std = 0; err_tot_abs_std = 0;
  err_res_std = 0; err_res_sq_std = 0; err_res_abs_std = 0;  
  
  for (unsigned int i = 0; i < no_points; ++i) {
  
    const double v_an = analytic   [i];
    const double v_ca = calculated [i];
    
    const double err   = v_ca - v_an;
    const double err_r = err / v_an;

    err_tot_std       += (err - err_tot)*(err - err_tot);
    err_tot_abs_std   += (std::abs(err) - err_tot_abs)*(std::abs(err) - err_tot_abs);
    err_tot_sq_std    += (err*err - err_tot_sq)*(err*err - err_tot_sq);
    err_res_std       += (err_r - err_res)*(err_r - err_res);
    err_res_abs_std   += (std::abs(err_r) - err_res_abs)*(std::abs(err_r) - err_res_abs);
    err_res_sq_std    += (err_r*err_r - err_res_sq)*(err_r*err_r - err_res_sq);    
  }         
    
  err_tot_std     *= no_points_inv;
  err_tot_abs_std *= no_points_inv;
  err_tot_sq_std  *= no_points_inv; 
  err_res_std     *= no_points_inv;  
  err_res_abs_std *= no_points_inv;  
  err_res_sq_std  *= no_points_inv;  


  err_tot_std     = std::sqrt( err_tot_std );
  err_tot_abs_std = std::sqrt( err_tot_abs_std );
  err_tot_sq_std  = std::sqrt( err_tot_sq_std );
  err_res_std     = std::sqrt( err_res_std );
  err_res_abs_std = std::sqrt( err_res_abs_std );
  err_res_sq_std  = std::sqrt( err_res_sq_std );
  std::string filename = "e_";
  filename.append(name);
  filename.append(".txt");
  ofstream offile;
  offile.open(filename.c_str());
  
  std::cout << "ERRORS for  \" " << name << " \": "<<std::endl;
  std::cout << "err_tot     : " << err_tot      << " (-+) " << err_tot_std      << std::endl;
  std::cout << "err_tot_abs : " << err_tot_abs  << " (-+) " << err_tot_abs_std  << std::endl;  
//std::cout << "err_tot_sq  : " << err_tot_sq   << " (-+) " << err_tot_sq_std   << std::endl;
  std::cout << "err_res     : " << err_res      << " (-+) " << err_res_std      << std::endl;    
  std::cout << "err_res_abs : " << err_res_abs  << " (-+) " << err_res_abs_std  << std::endl;
//std::cout << "err_res_sq  : " << err_res_sq   << " (-+) " << err_res_sq_std   << std::endl;
  std::cout << std::endl;
  
  offile << "ERRORS for  \" " << name << " \": "<<std::endl;
  offile << "err_tot     : " << err_tot      << " (-+) " << err_tot_std      << std::endl;
  offile << "err_tot_abs : " << err_tot_abs  << " (-+) " << err_tot_abs_std  << std::endl;  
//offile << "err_tot_sq  : " << err_tot_sq   << " (-+) " << err_tot_sq_std   << std::endl;
  offile << "err_res     : " << err_res      << " (-+) " << err_res_std      << std::endl;    
  offile << "err_res_abs : " << err_res_abs  << " (-+) " << err_res_abs_std  << std::endl;
//offile << "err_res_sq  : " << err_res_sq   << " (-+) " << err_res_sq_std   << std::endl;  
  offile.close();
}
//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================

All_charges::All_charges () {
  ofs_xyz.open ( "o.xyz" );
  dt = 0.001;
}

//==================================================
//==================================================
//==================================================

All_charges::~All_charges () {
  ofs_xyz.close ();
}

//==================================================
//==================================================
//==================================================

void All_charges::add_acceleration (const dealii::Tensor<1, 3, double> &p, unsigned int i) {
  acc_chr[i] += p * chr[i] / mass[i];
}
  
//==================================================
//==================================================
//==================================================

void All_charges::output_xyz () {
	int nta = chr.size();
	ofs_xyz << nta << "\nAtom\n";
	for (auto i = 0; i<nta; ++i) {
		ofs_xyz << "1" << " " << pos_chr[i][0] << " " << pos_chr[i][1] << " " << pos_chr[i][2] << std::endl;
	}
}

//==================================================
//==================================================
//==================================================





void All_charges::boundary_force () {
  auto &pos = pos_chr;
  auto &acc = acc_chr;

  const auto psize = chr.size();

  for (unsigned int i=0; i<psize; i++) { 

  	const auto x_sq = pos[i]*pos[i];
    static const double r_sq = 100.0*100.0;
    const auto dx_sq = x_sq - r_sq;
    if (dx_sq>0) {
      const auto x_norm = -pos[i] / std::sqrt(x_sq);
      
      acc[i] += 1000.0 * dx_sq * x_norm / mass[i];     
    }


  }
}

//==================================================
//==================================================
//==================================================



void All_charges::velocity_verlet_p1 () {
  auto &pos = pos_chr;
  auto &vel = vel_chr;
  auto &acc = acc_chr;

  const auto psize = chr.size();

  for (unsigned int i=0; i<psize; i++) { 
    vel [i] += 0.5 * acc [i] * dt;
  	pos [i] += vel [i] * dt;

		acc [i][0] = 0.0;acc [i][1] = 0.0;acc [i][2] = 0.0;
  }
}

//==================================================
//==================================================
//==================================================

void All_charges::velocity_verlet_p2 () {
//  force_field -> calculate_acceleration ();
  auto &vel = vel_chr;
  auto &acc = acc_chr;
  
  const auto psize = chr.size(); 
  
  for (unsigned int i=0; i<psize; i++) {
    vel [i] += 0.5 * acc [i] * dt;
  }
}




//==================================================
//==================================================
//==================================================

void All_charges::add_charge (const dealii::Point<3> p,const double c) {
  chr.push_back (c);
  pos_chr.push_back (p);
  dealii::Point<3> z {0,0,0};
  vel_chr.push_back (z);
  acc_chr.push_back (z);
  mass.push_back (1.0);
}

//==================================================
//==================================================
//==================================================

void All_charges::add_charge (const double x,const double y,const double z,const double c) {
  chr.push_back (c);
  pos_chr.push_back (dealii::Point<3> {x,y,z});
  vel_chr.push_back (dealii::Point<3> {0,0,0});
  acc_chr.push_back (dealii::Point<3> {0,0,0});
  mass.push_back (1.0);  
}

//==================================================
//==================================================
//==================================================

void All_charges::calculate_image_charges() {
  chr_img.clear();
  pos_img.clear();
  for (unsigned int i = 0; i < pos_chr.size(); ++i) {
    dealii::Point<3> pos_img_ = pos_chr[i];
    const double p_sq = pos_chr[i]*pos_chr[i];
    pos_img_ *= Rad*Rad / p_sq;
    double chr_img_ = - chr[i] * Rad / std::sqrt(p_sq);
    pos_img.push_back (pos_img_);
    chr_img.push_back (chr_img_);
  }
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_chr (const dealii::Point<3> &p, unsigned int i) {
  return k_coef * chr[i] / p.distance(pos_chr[i]);
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_img (const dealii::Point<3> &p, unsigned int i) {
  return k_coef * chr_img[i] / p.distance(pos_img[i]);
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_tot_chr (const dealii::Point<3> &p) {
  double p_sum = 0.0;
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (p == pos_chr[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance  
    p_sum += potential_chr (p,i);
  }
  return p_sum;
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_tot (const dealii::Point<3> &p) {
  double p_sum = 0.0;
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (p != pos_chr[i]) p_sum += potential_chr (p,i);  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance  
   
    p_sum += potential_img (p,i);    
  }
  return p_sum;
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_tot (unsigned int j) {
  double p_sum = 0.0;
  const dealii::Point<3> p = pos_chr[j];
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (i != j) p_sum += potential_chr (p,i);
//  it's better to use p.distance(pos_char[i]) < a_tolerance      
    p_sum += potential_img (p,i);    
  }
  return p_sum;
}


//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_chr (const dealii::Point<3> &p, unsigned int i) {
  dealii::Point<3> r_p = p;// - pos_chr[i];
  r_p[0] -=  pos_chr[i][0];r_p[1] -=  pos_chr[i][1];r_p[2] -=  pos_chr[i][2];
//  dealii::Tensor<1, 3, double> r_p = p - pos_chr[i];
  const double r = p.distance(pos_chr[i]);
  const double a = k_coef * chr[i] / (r*r*r);
  return a * r_p;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_img (const dealii::Point<3> &p, unsigned int i) {
  dealii::Point<3> r_p = p ;//- pos_img[i];
  r_p[0] -=  pos_img[i][0];r_p[1] -=  pos_img[i][1];r_p[2] -=  pos_img[i][2];  
  const double r = p.distance(pos_img[i]);
  const double a = k_coef * chr_img[i] / (r*r*r);
  return a * r_p;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_tot_chr (const dealii::Point<3> &p) {
  dealii::Point<3> e_sum {0,0,0};
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (p == pos_chr[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance
    e_sum += field_chr (p,i);  
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_tot (const dealii::Point<3> &p) {
  dealii::Point<3> e_sum {0,0,0};
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (p != pos_chr[i]) e_sum += field_chr (p,i);
//  it's better to use p.distance(pos_char[i]) < a_tolerance
 
    e_sum += field_img (p,i);    
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_tot (unsigned int j) {
  dealii::Point<3> e_sum {0,0,0};
  const dealii::Point<3> p = pos_chr[j];  
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (i != j)       e_sum += field_chr (p,i);
//  if (p == pos_char[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance    

    e_sum += field_img (p,i);    
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_tot_chr (unsigned int j) {
  dealii::Point<3> e_sum {0,0,0};
  const dealii::Point<3> p = pos_chr[j];  
  for (unsigned int i = 0; i< pos_chr.size(); ++i) {
    if (i == j) continue;  
//  if (p == pos_char[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance    
    e_sum += field_chr (p,i);
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================




//==================================================
//==================================================
//==================================================


template <int dim>
double RightHandSide<dim>::value (const Point<dim> &p,
                                  const unsigned int ) const
{

  double return_value = 0.0*p(0);

  return return_value;
}

//==================================================
//==================================================
//==================================================

template <int dim>
class BoundaryValues : public Function<dim>
{
public:
  BoundaryValues () : Function<dim>() {}

  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;
};

//==================================================
//==================================================
//==================================================


template <int dim>
double BoundaryValues<dim>::value (const Point<dim> &p,
                                   const unsigned int ) const
{
/*
  double return_value = 0.0;
  Point<3> p_c {0,0,0};
  p_c(0) = p_x;
  const double dr = p_c.distance(p);
  return_value = phi_bc_tot - kq / dr;  
  
  double return_value2 = all_charges.potential_tot_chr(p);
  std::cout << return_value << " and " << return_value2 << " yes "<<std::endl;
  return return_value;
  */
  return all_charges.get_phi_bc() - all_charges.potential_tot_chr(p);
}

//==================================================
//==================================================
//==================================================


template <int dim>
Step4<dim>::Step4 ()
  :
  fe (1),
  dof_handler (triangulation)
{}





//===================================================
//===================================================
//===================================================
template <int dim>
void Step4<dim>::rotate_and_add_reserve(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (tria_reserve);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }

//===================================================
//===================================================
//===================================================
template <int dim>
void Step4<dim>::rotate_and_add(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (triangulation);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }



//===================================================
//===================================================
//===================================================

template <int dim>
void Step4<dim>::match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll) {
    int no_matched_vertices = 0;
    int no_corrected_vertices = 0;
    
    for (typename Triangulation<3,3>::active_cell_iterator
         cell2=tria2.begin_active(); cell2!=tria2.end(); ++cell2) {
      for (unsigned int f2=0; f2<GeometryInfo<3>::faces_per_cell; ++f2) {
        if (cell2->face(f2)->at_boundary()) {
          
          for (typename Triangulation<3,3>::active_cell_iterator
               cell=triangulation.begin_active();cell!=triangulation.end();++cell) { 
            for (unsigned int f=0; f<GeometryInfo<3>::faces_per_cell; ++f) {
              if (cell->face(f)->at_boundary()) {
      
                for (unsigned int i=0; i<4; ++i)  { 
                  const Point<3> p1 = cell->face(f)->vertex(i);
                  bool point_match_found = false;                             
                  for (unsigned int j=0; j<4; ++j)  {           
                    const Point<3> p2 = cell2->face(f2)->vertex(j);
                    const double distance = p2.distance(p1);
                    
                    if (distance < merge_toll) {
                      ++no_matched_vertices;
                      point_match_found = true;
                      if (distance > 0) {
                        ++no_corrected_vertices;
                        cell2->face(f2)->vertex(j) =  cell->face(f)->vertex(i);
                      }
                      break;                        
                    }
                  }
                  if (!point_match_found) break;
                }
              }
            }
          }           
        }        
      }
    }
    
    tot_no_matched +=  no_matched_vertices;
    tot_no_corrected += no_corrected_vertices;
  }
  
//=========================================================================
//=========================================================================
//=========================================================================
//=========================================================================  
 
//===================================================
//===================================================
//===================================================
template <int dim>
void Step4<dim>::read_domain()
  {

tot_no_matched=0; tot_no_corrected=0;
// /*
      const std::vector<std::string> initial_mesh_filename = {
"../sphere_input_1p/Mesh_1.unv",
"../sphere_input_1p/Mesh_2.unv",
"../sphere_input_1p/Mesh_3.unv",
"../sphere_input_1p/Mesh_4.unv",
//"../sphere_input_1p/Mesh_5.unv",
"../sphere_input_1p/Mesh_6.unv",
"../sphere_input_1p/Mesh_7.unv",
"../sphere_input_1p/Mesh_8_5_rep.unv",
};
// */
/*
      const std::vector<std::string> initial_mesh_filename = {
"../sphere_input_5p/Mesh_1.unv",
"../sphere_input_5p/Mesh_2.unv",
"../sphere_input_5p/Mesh_3.unv",
"../sphere_input_5p/Mesh_4.unv",
"../sphere_input_5p/Mesh_5.unv",
"../sphere_input_5p/Mesh_6.unv",
"../sphere_input_5p/Mesh_7.unv",
};*/  

    std::ifstream in;

    in.open(initial_mesh_filename[0].c_str());

    GridIn<3,3> gi;
    gi.attach_triangulation(triangulation);
    gi.read_unv(in);

    const double merge_toll = 0.1;
    std::cout << "main mesh:\n";
    unsigned int tot_mesh_num = initial_mesh_filename.size();
    for (unsigned int i = 1; i <  tot_mesh_num; ++i) { // BUG
      std::cout << i << " " << std::flush;     
      //std::cout << i << std::endl;
      Triangulation<3,3> tria2;
     
      std::ifstream in;
      
      in.open(initial_mesh_filename[i].c_str());
      
      GridIn<3,3> gi;

      gi.attach_triangulation(tria2);
      
      gi.read_unv(in);
      
      match_boundary_vertices (tria2, merge_toll);  
       
      GridGenerator::merge_triangulations (triangulation, tria2, triangulation);
    
    }
    std::cout << "\n";    
   
    tria_reserve.copy_triangulation (triangulation);
# define M_PI           3.14159265358979323846
  const double rot = 90.0 * M_PI / 180.0;
    std::cout << "muli rotation:\n";      
    
  for (unsigned int i = 1; i < 4; ++i){  
    const double angle = rot * i ;
    std::cout << i << " " << std::flush;    
    rotate_and_add_reserve (angle, 0, merge_toll);
    
  }
    rotate_and_add (M_PI, 2, merge_toll);
    std::cout << "\n";
#undef M_PI
    


    std::cout << "merge_toll:       " << merge_toll << std::endl;
    std::cout << "tot_no_matched:   " << tot_no_matched << std::endl;
    std::cout << "tot_no_corrected: " << tot_no_corrected << std::endl;

 


  }
  
  
//===================================================
//===================================================
//===================================================
template <int dim>
void Step4<dim>::set_spherical_manifold() {
  const Point<3> center (0,0,0);
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (1, manifold_description);
  triangulation.set_all_manifold_ids(1);
}
//===================================================
//===================================================
//===================================================
  
//===================================================
//===================================================
//===================================================



template <int dim>
void Step4<dim>::make_grid ()
{
  if (dim==2) {
    GridGenerator::hyper_cube (triangulation, -1, 1);
    triangulation.refine_global (4);
  } else if (dim==3) {
    read_domain();
    set_spherical_manifold();
   // triangulation.refine_global (1); 
   // triangulation.refine_global (1);            
  }
  std::cout << "   Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl
            << "   Total number of cells: "
            << triangulation.n_cells()
            << std::endl;
}

//==================================================
//==================================================
//==================================================


template <int dim>
void Step4<dim>::setup_system ()
{
  dof_handler.distribute_dofs (fe);

  std::cout << "   Number of degrees of freedom: "
            << dof_handler.n_dofs()
            << std::endl;

  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  DoFTools::make_sparsity_pattern (dof_handler, dsp);
  sparsity_pattern.copy_from(dsp);

  system_matrix.reinit (sparsity_pattern);

  solution.reinit (dof_handler.n_dofs());
  system_rhs.reinit (dof_handler.n_dofs());
}
//==================================================
//==================================================
//==================================================

template <int dim>
void Step4<dim>::assemble_system_p1 ()
{
  QGauss<dim> quadrature_formula(2);





  const RightHandSide<dim> right_hand_side;







  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values | update_gradients |
                           update_quadrature_points | update_JxW_values);





  const unsigned int dofs_per_cell = fe.dofs_per_cell;
  const unsigned int n_q_points = quadrature_formula.size();

  FullMatrix<double> cell_matrix (dofs_per_cell, dofs_per_cell);
  Vector<double> cell_rhs (dofs_per_cell);

  std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);
  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();

  for (; cell!=endc; ++cell)
    {
      fe_values.reinit (cell);
      cell_matrix = 0;
      cell_rhs = 0;
      for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        for (unsigned int i=0; i<dofs_per_cell; ++i)
          {
            for (unsigned int j=0; j<dofs_per_cell; ++j)
              cell_matrix(i,j) += (fe_values.shape_grad (i, q_index) *
                                   fe_values.shape_grad (j, q_index) *
                                   fe_values.JxW (q_index));

            cell_rhs(i) += (fe_values.shape_value (i, q_index) *
                            right_hand_side.value (fe_values.quadrature_point (q_index)) *
                            fe_values.JxW (q_index));
          }
      cell->get_dof_indices (local_dof_indices);
      for (unsigned int i=0; i<dofs_per_cell; ++i)
        {
          for (unsigned int j=0; j<dofs_per_cell; ++j)
            system_matrix.add (local_dof_indices[i],
                               local_dof_indices[j],
                               cell_matrix(i,j));

          system_rhs(local_dof_indices[i]) += cell_rhs(i);
        }
    }

}

//==================================================
//==================================================
//==================================================

template <int dim>
void Step4<dim>::assemble_system_p2 ()
{



  std::map<types::global_dof_index,double> boundary_values;
  VectorTools::interpolate_boundary_values (dof_handler,
                                            0,
                                            BoundaryValues<dim>(),
                                            boundary_values);
  MatrixTools::apply_boundary_values (boundary_values,
                                      system_matrix,
                                      solution,
                                      system_rhs);
}


//==================================================
//==================================================
//==================================================





template <int dim>
void Step4<dim>::solve ()
{
  SolverControl solver_control (1000, 1e-12);
  SolverCG<> solver (solver_control);
  solver.solve (system_matrix, solution, system_rhs,
                PreconditionIdentity());


/*
  std::cout << "   " << solver_control.last_step()
            << " CG iterations needed to obtain convergence."
            << std::endl;*/
}

//==================================================
//==================================================
//==================================================


template <int dim>
void Step4<dim>::output_results () const
{

  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "solution");

  data_out.build_patches ();

  std::ofstream output (dim == 2 ?
                        "solution-2d.vtk" :
                        "solution-3d.vtk");
  data_out.write_vtk (output);
}

//==================================================
//==================================================
//==================================================


template <int dim>
void Step4<dim>::post_process ()
{


  Error_calculator err_p      ("potential");
  Error_calculator err_fx     ("field_x");  
  Error_calculator err_fy     ("field_y");  
  Error_calculator err_fz     ("field_z");
  Error_calculator err_f_norm ("field_norm");  
  
  std::ofstream ofile ("output.txt");

  const double Rad_minus_tol = all_charges.get_Rad() - 5.0;
  const double Rad_minus_tol_sq = Rad_minus_tol * Rad_minus_tol;
  const double dx = 25.0, dy = 25.0, dz = 25.0;
  
  for (double ix = -Rad_minus_tol; ix < Rad_minus_tol; ix += dx) {
  std::cout <<"ix:" <<ix << " " << std::flush;
  for (double iy = -Rad_minus_tol; iy < Rad_minus_tol; iy += dy) { 
  for (double iz = -Rad_minus_tol; iz < Rad_minus_tol; iz += dz) {
//    std::cout<<iz<<std::flush;
    if (ix*ix + iy*iy + iz*iz > Rad_minus_tol_sq) continue;
    Point<3> r {ix, iy, iz};
    
 // for (int i = -118.0; i<118.0; ++i)  {
  //  Point<3> r {1.0*i,0,0}; //    r(0) = 1.0*i;
    
   
    const double v_an = all_charges.potential_tot (r);
    const double v_sm = VectorTools::point_value (dof_handler, solution,r);
    const double v_si = all_charges.potential_tot_chr(r);//kq / r.distance(p_c);
                    
  //  std::cout   << r(0) << " " << v_an << " " << v_sm + v_si << " " << v_sm << " " << v_si << "\n";
    ofile       << r(0) << " " << v_an << " " << v_sm + v_si << " " << v_sm << " " << v_si << "\n";    

    
    err_p.add_analytic_value(v_an);   
    err_p.add_calculated_value(v_sm + v_si);
    

//    dealii::Tensor<1, 3, double> f_sm = - VectorTools::point_gradient (dof_handler, solution,r);

    auto f_an = all_charges.field_tot (r);
    auto f_sm = - VectorTools::point_gradient (dof_handler, solution,r);
    auto f_si = all_charges.field_tot_chr (r);
    
//    std::cout   << r(0) << " " << f_an << " " << f_si + f_sm << "\n";//; << " " << e_sm << " \n";
    
    // << v_sm << " " << v_si << "\n";    
 //   std::cout << p_g[0] << " " << p_g[1] << " " << p_g[2] << std::endl;
 

    err_fx.add_analytic_value (f_an[0]);    
    err_fx.add_calculated_value (f_sm[0] + f_si[0]);
    
    err_fy.add_analytic_value (f_an[1]);    
    err_fy.add_calculated_value (f_sm[1] + f_si[1]);
    
    err_fz.add_analytic_value (f_an[2]);    
    err_fz.add_calculated_value (f_sm[2] + f_si[2]);
    

    err_f_norm.add_analytic_value (std::sqrt(f_an*f_an));    
    err_f_norm.add_calculated_value (std::sqrt((f_sm + f_si)*(f_sm + f_si)));
    

  }}}
  
  err_p.calculate_and_output ();
  err_fx.calculate_and_output ();
  err_fy.calculate_and_output ();
  err_fz.calculate_and_output ();
  err_f_norm.calculate_and_output ();
}
//==================================================
//==================================================
//==================================================

template <int dim>
void Step4<dim>::post_process_charges ()
{
  for (unsigned int i = 0; i < all_charges.no_charges(); ++i) {
    auto r = all_charges.get_pos_chr (i);
    auto f_an = all_charges.field_tot (i);
    auto f_sm = - VectorTools::point_gradient (dof_handler, solution,r);
    auto f_si = all_charges.field_tot_chr (i);
    
    std::cout<<"charge "<< i << " :\n";
    std::cout<< f_an << "\n";
    std::cout<< f_sm + f_si << "\n";
    
    const double f_an_norm = std::sqrt(f_an*f_an);    
    const double f_cal_norm = std::sqrt((f_sm + f_si)*(f_sm + f_si));
    auto err = (f_an_norm - f_cal_norm)/f_an_norm;
    std::cout<< "err: " <<err << "\n\n";
        
  }
}

//==================================================
//==================================================
//==================================================

template <int dim>
void Step4<dim>::run ()
{

  std::cout << "Solving problem in " << dim << " space dimensions." << std::endl;
  const int no_time_steps = 100000;
  make_grid();
  setup_system ();
  assemble_system_p1 ();
  for (unsigned int i = 0; i<no_time_steps; ++i) {

    assemble_system_p2 ();
    all_charges.velocity_verlet_p1 ();
    solve ();
    calculate_acceleration ();
    all_charges.boundary_force ();
    all_charges.velocity_verlet_p2 ();
    if ((i+1)%100==0) 
    {
      all_charges.output_xyz ();    
      std::cout << "time_step " << i << " :" << std::endl;
    }
    //output_results ();
  }
  // post_process ();
  // post_process_charges ();  
}

//==================================================
//==================================================
//==================================================

template <int dim>
void Step4<dim>::calculate_acceleration () {
  for (unsigned int i = 0; i < all_charges.no_charges(); ++i) {
    auto r = all_charges.get_pos_chr (i);
    //auto f_an = all_charges.field_tot (i);
    auto f_sm = - VectorTools::point_gradient (dof_handler, solution,r);
    auto f_si = all_charges.field_tot_chr (i);
    
    all_charges.add_acceleration(f_sm + f_si, i);
 }  
}

//==================================================
//==================================================
//==================================================

/*
int  ()
{
  all_charges.set_Rad(120.0);
  all_charges.set_k_coef(10.0);
  all_charges.set_phi_bc(0.0);

  all_charges.add_charge(10.0, 0.0, 0.0, 10.0);
  all_charges.add_charge(-10.0, 0.0, 0.0, 20.0);
  //all_charges.add_charge(0.0, 0.0, 0.0, -1.0);              
//  all_charges.add_charge(92.67, 0.0, 0.0, 3.0);
 // all_charges.add_charge(0.0, 50.0, -14.0, -5.0);  
//  all_charges.add_charge(-30.0, -15.0, 55.0, -7.0);   
  
  all_charges.calculate_image_charges();
  
  deallog.depth_console (0);
  {
   // Step4<2> laplace_problem_2d;
 //   laplace_problem_2d.run ();
  }

  {
    Step4<3> laplace_problem_3d;
    laplace_problem_3d.run ();
  }

  return 0;
}*/
