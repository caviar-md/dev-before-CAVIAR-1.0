#ifndef POLYHEDRON_PREPROCESS_H
#define POLYHEDRON_PREPROCESS_H

#include "polyhedron.h"
#include "parser.h"

namespace NS_geometry {
class Polyhedron_Preprocess : protected Pointers {
public:
  Polyhedron_Preprocess (class MD *);
  ~Polyhedron_Preprocess ();
  

	void pre_correct_normals (NS_geometry::Polyhedron&); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.


  void merge_vertices (NS_geometry::Polyhedron&);
  


  class Output * output;
  class Error * error;


};
}
#endif
