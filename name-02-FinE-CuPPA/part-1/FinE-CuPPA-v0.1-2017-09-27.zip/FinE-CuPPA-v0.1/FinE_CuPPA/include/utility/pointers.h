#ifndef POINTERS_H
#define POINTERS_H

#ifdef USE_MPI
#include <mpi.h>
#endif

#include "md.h"
#include "utility.h"

class Pointers {
public:
  inline constexpr Pointers (class MD *md) :
    md {md},
#ifdef USE_MPI
    mpi_comm {md->mpi_comm},
#endif
    comm {md->comm},
    error {md->error},
    output {md->output},
    input {md->input},
    domain {md->domain},
    atom_data {md->atom_data},
    update {md->update},
    neighbor {md->neighbor},
    writer {md->writer},
    object_handler {md->object_handler},
    object_container {md->object_container},
    object_creator {md->object_creator},    
    log {md->log},
    in {md->in},
    out {md->out},
    err {md->err},
    log_flag {md->log_flag},
    out_flag {md->out_flag},
    err_flag {md->err_flag},
    int_variables {md->int_variables},
    real_variables {md->real_variables},
    string_variables {md->string_variables} {}

protected:
  inline ~Pointers () = default;  // destructor need not be virtual b/c it is protected
  class MD *md;
#ifdef USE_MPI
  MPI_Comm &mpi_comm;
#endif
  class Communicator *&comm;
  class Error *&error;
  class Output *&output;
  class Input *&input;
  class Domain *&domain;
  class Atom_data *&atom_data;
  class Update *&update;
  class Neighbor *&neighbor;
  class Writer *&writer;
  class Object_handler *&object_handler;
  class Object_container *&object_container;
  class Object_creator *&object_creator;
  
  std::ofstream &log;
  std::istream &in;
  std::ostream &out, &err;
  bool &log_flag, &out_flag, &err_flag;
  
  std::map<std::string,int> &int_variables;
  std::map<std::string,Real_t> &real_variables;
  std::map<std::string,std::string> &string_variables;
};

#endif
