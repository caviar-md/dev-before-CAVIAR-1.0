#ifndef TYPES_H
#define TYPES_H

#include <limits>

using LocalID_t = unsigned int; 	// changing these doesn't affect MPI_SEND and MPI_Recv MPI_DATA_TYPES yet
using GlobalID_t = unsigned int; 	// //
using AtomType_t = unsigned int; 	// //
using Real_t = double; 						// //

constexpr auto max_GlobalID = std::numeric_limits<GlobalID_t>::max();

#endif
