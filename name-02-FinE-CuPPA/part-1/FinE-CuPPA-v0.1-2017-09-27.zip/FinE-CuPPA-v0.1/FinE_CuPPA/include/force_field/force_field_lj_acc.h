#ifndef FORCE_FIELD_LJ_ACC_H
#define FORCE_FIELD_LJ_ACC_H

#include "force_field.h"

#include <vector>

class Force_field_lj_acc : public Force_field {
public:
  Force_field_lj_acc (class MD *, class Parser *);
  ~Force_field_lj_acc () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> epsilon,sigma;
};

#endif
