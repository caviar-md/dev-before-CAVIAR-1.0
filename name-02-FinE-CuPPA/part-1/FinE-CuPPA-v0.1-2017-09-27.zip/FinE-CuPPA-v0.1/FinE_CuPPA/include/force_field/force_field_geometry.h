#ifndef FORCE_FIELD_GEOMETRY_H
#define FORCE_FIELD_GEOMETRY_H

#include "force_field.h"

#include <vector>
#include <map>

#include "polyhedron_handler.h"


class Force_field_geometry : public Force_field {
public:
  Force_field_geometry (class MD *, class Parser *);
  ~Force_field_geometry ();
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:	
	NS_geometry::Polyhedron_Handler * polyhedron_handler;
	void command_polyhedron (class Parser *);		
  class Parser *parser;
	class Output *output;
	class Error *error;

};

#endif
