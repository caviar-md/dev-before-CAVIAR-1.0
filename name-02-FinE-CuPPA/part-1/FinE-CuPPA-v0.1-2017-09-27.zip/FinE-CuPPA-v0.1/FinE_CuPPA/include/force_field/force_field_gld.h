#ifndef FORCE_FIELD_GLD_H
#define FORCE_FIELD_GLD_H

#include "force_field.h"

#include <vector>
#include "vector.h"

class Force_field_gld : public Force_field {
public:
  Force_field_gld (class MD *, class Parser *);
  ~Force_field_gld () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<Real_t> elastic_coef,dissip_coef, radius;
	Vector<Real_t> gravity;
};

#endif
