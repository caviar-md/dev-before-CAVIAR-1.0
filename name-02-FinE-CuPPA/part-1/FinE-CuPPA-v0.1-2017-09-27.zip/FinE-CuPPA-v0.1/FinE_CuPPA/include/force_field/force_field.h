#ifndef FORCE_FIELD_H
#define FORCE_FIELD_H

#include "pointers.h"

class Force_field : protected Pointers {
public:
  Force_field (class MD *, class Parser *);
  virtual ~Force_field () {};
  virtual bool read (class Parser *) = 0;
  virtual void calculate_acceleration () = 0;
	virtual void calculate_kinetic_energy();  
	double kinetic_energy,potential_energy;
  double cutoff;	
private:
  Parser *parser;
  
};

#endif
