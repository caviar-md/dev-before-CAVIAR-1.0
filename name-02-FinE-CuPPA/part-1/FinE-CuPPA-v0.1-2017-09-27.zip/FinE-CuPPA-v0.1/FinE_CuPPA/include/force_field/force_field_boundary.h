#ifndef FORCE_FIELD_BOUNDARY_H
#define FORCE_FIELD_BOUNDARY_H

#include "force_field.h"

#include <vector>
#include <map>


class Force_field_boundary : public Force_field {
public:
  Force_field_boundary (class MD *, class Parser *);
  ~Force_field_boundary () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:	
};

#endif
