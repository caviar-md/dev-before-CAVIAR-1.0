#ifndef SHAPE_CIRCLE_H
#define SHAPE_CIRCLE_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "shape.h"
#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"




namespace NS_shape {


// ========================
// ========================
// ========================
class Circle : public Shape {
public:
	Circle (class MD *) ;
	~Circle ();

	//bool read(Parser *, class Object_container *); // there are different ways to define a circle: 3 points on it, centre and one point on it, centre and radius and normal,...
  bool read(Parser *);
	double RADIUS;
	double FLATNESS_TOLL;
	Vector<double> CENTER;
	Vector<double> NORMAL;
	bool on_the_plane (const Vector<double> &v);
	bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
	bool is_outside (const Vector<double> &v);
  bool is_outside (const Vector<double> &, const double rad);	
  
	bool make_basis_vectors();
	class Object_container * object_container;	
	Output * output;
	Error * error;


};


} // namespace shape finished



#endif
 
