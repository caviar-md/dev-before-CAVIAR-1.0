#ifndef SHAPE_CLOSED_LINES_H
#define SHAPE_CLOSED_LINES_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "shape.h"
#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
//#include "object_container.h"



namespace NS_shape {


// ========================
// ========================
// ========================

// shapes to be added: plane, 3d half space(plane), box, rectangle, triangle, vtk, stl, geometry maniforld, torus, tube

// ========================
// ========================
// ========================



class Closed_lines : public Shape {
public:
	Closed_lines (class MD *) ;
	~Closed_lines ();	
	
	bool read(Parser *);
	//bool read(Parser *, class Object_container *);	

	bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
	bool is_outside (const Vector<double> &v);
  bool is_outside (const Vector<double> &, const double rad);	

	std::vector<Vector<Real_t>> p_3D; // vertex points of the shape in 3D space
	Vector<Real_t> n_vector, u_vector, v_vector; //  basis vectors of the plane: normal and (u,v)
	std::vector<Real_t> u_list, v_list; // array containing u and v coordinates of the vertices in the plane
	Real_t mat_inv[3][3]; // inverse of the transformation matrix;

	double FLATNESS_TOLL;
	
	class Object_container *object_container;
  Output * output;
	Error * error;


	void make_basis_vectors() ;
	void make_uv_vectors() ; 
	void make_transform_matrix();
	void uv_to_xyz (Real_t u_i, Real_t v_i, Vector<Real_t> &p_i);
	void xyz_to_uv (const Vector<Real_t> &p_i, Real_t &u_i, Real_t &v_i) ;
	bool is_inside (double u_i, double v_i); // using Jordan curve theorem,
			// checks whether the point is inside the curve or not;
			// it has a bug when (v_list[i] == v_list[j]);

};


// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

} // namespace shape finished



#endif
 
