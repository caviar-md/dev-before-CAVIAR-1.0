#ifndef SHAPE_H
#define SHAPE_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
//#include "kakaka_utility_all_objects.h"


namespace NS_shape {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}
// ========================
// ========================
// ========================

// shapes to be added: plane, 3d half space(plane), box, rectangle, triangle, vtk, stl, geometry maniforld, torus, tube

// ========================
// ========================
// ========================

class Shape : protected Pointers {
	public:
		Shape (class MD *);
		virtual ~Shape();
		//int dimension;
		//bool inside_check;		
		virtual bool read(Parser *)=0;
		//virtual bool read(Parser *,class Object_handler *)=0;		
		virtual bool is_inside (const Vector<double> &)=0;
		virtual bool is_outside (const Vector<double> &)=0;
		virtual bool is_inside (const Vector<double> &, const double rad)=0;
		virtual bool is_outside (const Vector<double> &, const double rad)=0;		
		//virtual bool is_all ();		
		//virtual bool is_valid ()=0;
	
		
		//virtual bool is_all (const Vector<double> &)=0; //checks 'is_inside()' if 'inside_check==true'
//		virtual bool Shape::U_min_max() (double &, double &);
//		virtual bool Shape::V_min_max() (double &, double &);
//		virtual bool Shape::W_min_max() (double &, double &);
		//double U_min,U_max,V_min,V_max,W_min,W_max;
		Output * output;
		Error * error;
};

// ========================
// ========================
// ========================

} // namespace shape finished



#endif
 
