#ifndef SHAPE_BOUNDARY_H
#define SHAPE_BOUNDARY_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
#include "shape.h"

namespace NS_shape {


class Boundary : public NS_shape::Shape {
	public:
		Boundary (class MD *);
		~Boundary ();
//	  bool read(Parser *, class Object_container *);	  
    bool read(Parser *);
		void satisfy_boundary ();
		
		bool inside_check;

		
		bool is_inside (const Vector<double> &);
		bool is_outside (const Vector<double> &);
		bool is_inside (const Vector<double> &, const double r);
		bool is_outside (const Vector<double> &, const double r);
		
		//bool is_all (const Vector<double> &); //checks 'is_inside()' if 'inside_check==true'

		std::vector<NS_shape::Shape*> shapes;
		std::vector<int> operators; // 1:and_inside, -1:and_outside, 2:or_inside, -2:or_outside

	  class Object_container * object_container;		
		class Output * output;
	  class Error * error;
class Parser * parser;

};
} // NAMESPACE KKK finished


#endif
 
