#ifndef OBJECT_UTILITY_DISTRIBUTION_H
#define OBJECT_UTILITY_DISTRIBUTION_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "parser.h"
#include "output.h"
#include "error.h"
#include "shape_all.h"


namespace NS_object_utility {

class All_objects;
class Molecule;
class Atom;

class Distribution {
	public:
	Distribution ();
  Distribution (class Object_container * all_obj);
	~Distribution () ;
  bool read (Parser *);		
	
	class NS_shape::Boundary *boundary;
	class Molecule *m_object, *container;
	class Atom * a_object;
	bool boundary_check, a_object_check, m_object_check, container_check;
	
	bool distribute_grid_3D();
	bool distribute_random_3D()	;
	
	class Parser * parser;	
  class Output * output;
  class Error * error;
	class Object_container * object_container;


};

} 


#endif
 
