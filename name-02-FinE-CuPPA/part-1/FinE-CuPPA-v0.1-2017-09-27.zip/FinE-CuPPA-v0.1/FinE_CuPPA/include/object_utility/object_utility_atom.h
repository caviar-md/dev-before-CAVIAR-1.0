#ifndef OBJECT_UTILITY_ATOM_H
#define OBJECT_UTILITY_ATOM_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"


namespace NS_object_utility {


class Atom  {
	public:
		Atom ();
		Atom (const Atom &);
		Atom (class Object_container *, class Molecule *,  Vector<double>, Vector<double>, unsigned int);
		~Atom () ;


		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const; 

		Vector<double> pos () const {
		 	return POSITION;	
		}
		Vector<double> & pos ()  {
		 	return POSITION;
		}
		Vector<double> vel () const {
		 	return VELOCITY;	
		}
		Vector<double> & vel ()  {
		 	return VELOCITY;
		}
    double get_radius () const;
    unsigned int get_element_index () const {
      return element_index;
    }
		bool read (Parser *);
		
		void output_xyz (std::ofstream &);	
    void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);		
			
		bool has_father;		
		Molecule * FATHER;
		
	private:
	Vector<double> POSITION, VELOCITY;

	unsigned int element_index;
	class Output * output;
	class Error * error;
	class Object_container * object_container;

};
// NAMESPACE NS_object_utility finished

}
#endif
 
