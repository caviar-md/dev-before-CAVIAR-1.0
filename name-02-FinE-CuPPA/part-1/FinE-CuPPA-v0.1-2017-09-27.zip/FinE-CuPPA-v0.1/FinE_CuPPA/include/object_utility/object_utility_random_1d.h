#ifndef KAKAKA_UTILITY_RANDOM_1D_H
#define KAKAKA_UTILITY_RANDOM_1D_H

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"


namespace NS_object_utility {


class Random_1D {
	public:
		Random_1D () ;
		Random_1D (class Object_container *, std::string TYPE, double MIN, double MAX, double STDDEV, double MEAN, int SEED) ;
		~Random_1D () ;

		bool read(Parser *);
    void generate (); // creates the std::mt19937 with given parameters ...		
		
		double MIN, MAX, STDDEV, MEAN;
		
		std::string TYPE;
		
		int SEED;				
		int num; // number of random atoms or molecules to be created		
		int type_int;
				
		bool generated; // true if generate() has been called.
    
		std::mt19937 *ran_gen;
		std::uniform_real_distribution<> *u_dist;
		std::normal_distribution<> *n_dist;
		
		class Parser * parser;
		class Output * output;
	  class Error * error;
	  class Object_container * object_container;


	private:
};

} 


#endif
 
