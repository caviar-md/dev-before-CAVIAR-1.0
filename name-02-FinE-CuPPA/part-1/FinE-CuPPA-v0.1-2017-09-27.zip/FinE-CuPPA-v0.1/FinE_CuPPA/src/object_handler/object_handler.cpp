#include "object_handler.h"
#include "object_handler_commands_map.h"

Object_handler::Object_handler (MD *md) : Pointers{md} {}

Object_handler::~Object_handler () {

}
/*

bool Object_handler::read () {
	bool in_file = true;
	while (in_file) {
		auto token = parser->get_val_token();
		if (token.kind == Kind::eof) break;
		if (token.kind == Kind::eol) continue;
		auto command = token.string_value;

		std::map<std::string,NS_object_handler::Dictionary>::iterator it;
		if (commands_map.count (command) == 0) {
			it = object_container -> dictionary.find(command);
			if (it == object_container -> dictionary.end())
				error->all (FILE_LINE_FUNC, "Object_handler : read : Invalid Kakaka command or object NAME");
			if (it->second.type == NS_object_handler::gdst("ELEMENT")) 
				in_file = object_container -> element[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("ATOM")) 
				in_file = object_container -> atom[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("MOLECULE")) 
				in_file = object_container -> molecule[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("SHAPE")) 
				in_file = object_container -> shape[it->second.index]->read(parser);
      if (it->second.type == NS_object_handler::gdst("RANDOM_1D")) 
				in_file = object_container -> random_1d[it->second.index].read(parser);
      if (it->second.type == NS_object_handler::gdst("GRID_1D")) 
				in_file = object_container -> grid_1d[it->second.index].read(parser);
      if (it->second.type == NS_object_handler::gdst("BOUNDARY")) 
				in_file = object_container -> boundary[it->second.index].read(parser);													
      if (it->second.type == NS_object_handler::gdst("DISTRIBUTION")) 
				in_file = object_container -> distribution[it->second.index].read(parser);
		} else {
			in_file = (this->*commands_map.at(command)) ();
		}
	}
	return in_file; //WARNING
}

*/


