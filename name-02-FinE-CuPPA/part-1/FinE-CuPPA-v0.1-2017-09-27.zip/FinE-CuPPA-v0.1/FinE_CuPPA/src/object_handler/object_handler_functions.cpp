#include "object_handler_all.h"
#include "object_container.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"





// ========================
// ========================
// ========================

bool Object_handler::add_atom (Parser *parser) {
	output->info("Object_handler: ADD ATOM");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_ATOM: "," expected an atom or molecule NAME: ")

	std::map<std::string,NS_object_handler::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_ATOM: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_ATOM: "," Expected middle command: ")

	if (middle_command_1 == "TO_MOLECULE") {
		GET_A_STRING(name_2,"ADD_ATOM: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_ATOM: ","")
	}

  if (it_1->second.type != NS_object_handler::gdst("ATOM"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD ATOM: expected an ATOM NAME: ");

  if (it_2->second.type != NS_object_handler::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD ATOM: expected an MOLECULE NAME: ");
      
	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
		if (token.string_value == "AT_POSITION") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD ATOM: ","")\
		} else if (token.string_value == "AT_VELOCITY") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD ATOM: ","")\
		}
	}

	NS_object_utility::Atom a_new = object_container -> atom[it_1->second.index];
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	object_container -> molecule[it_2->second.index].add_atom (a_new);
	return in_file;
}

// ========================
// ========================
// ========================

bool Object_handler::add_molecule (Parser *parser) {
	output->info("Object_handler: ADD MOLECULE");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_MOLECULE: "," expected an atom or molecule NAME: ")

	std::map<std::string,NS_object_handler::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_ATOM: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_MOLECULE: "," Expected middle command: ")

	if (middle_command_1 == "TO_MOLECULE") {
		GET_A_STRING(name_2,"ADD_ATOM: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_ATOM: ","")
	}

  if (it_1->second.type != NS_object_handler::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD MOLECULE: expected an MOLECULE NAME: ");

  if (it_2->second.type != NS_object_handler::gdst("MOLECULE"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD MOLECUE: expected an MOLECULE NAME: ");


	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
		if (token.string_value == "AT_POSITION") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD MOLECULE: ","")\
		} else if (token.string_value == "AT_VELOCITY") {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD MOLECULE: ","")\
		}
	}

	NS_object_utility::Molecule a_new = object_container -> molecule[it_1->second.index];	
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	object_container -> molecule[it_2->second.index].add_molecule(a_new);
	return in_file;
}


// ========================
// ========================
// ========================


bool Object_handler::output_xyz (Parser *parser) {
	output->info("Object_handler: OUTPUT_XYZ: ");
 
  std::ofstream out_file;
  out_file.open("o_kakaka.xyz");

	bool in_file = true;
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;  	 
 		if (t=="MOLECULE") {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;
		  std::string name_1;
      GET_A_STRING(name_1,"OUTPUT_XYZ: "," expected an MOLECULE or ATOM NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
		  if (it_1->second.type == NS_object_handler::gdst("ATOM")) {
		    object_container -> atom[it_1->second.index].output_xyz (out_file);
		  }	else if (it_1->second.type == NS_object_handler::gdst("MOLECULE")) {
		    object_container -> molecule[it_1->second.index].output_xyz (out_file);
		  }	else error->all(FILE_LINE_FUNC,"Object_handler: OUTPUT_XYZ: expected an MOLECULE or ATOM NAME. ");
		} else  error->all(FILE_LINE_FUNC,"OUTPUT_XYZ: Unknown variable or command ");
  
  }
  
  out_file.close ();

  
	return in_file;

}

// ========================
// ========================
// ========================

bool Object_handler::add_to_simulation (Parser *parser) {
	output->info("Object_handler: ADD_TO_SIMULATION: ");

	bool in_file = true;
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (t=="ELEMENTS") {
      add_elements_to_simulation ();
    } else if (t=="ATOM" || t=="MOLECULE") {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,"ADD_TO_SIMULATION: "," expected an MOLECULE or ATOM NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "ADD_TO_SIMULATION: ","")
		  if (it_1->second.type == NS_object_handler::gdst("ATOM")) {
		  
		    auto & a = object_container -> atom[it_1->second.index];
		    add_atom_to_simulation (a);
	    
		    
		  }	else if (it_1->second.type == NS_object_handler::gdst("MOLECULE")) {
		  
		    auto & a = object_container -> molecule[it_1->second.index];
		    add_molecule_to_simulation (a);
	    
		    
		  }	else error->all(FILE_LINE_FUNC,"ADD_TO_SIMULATION: expected an MOLECULE or ATOM NAME. ");
		} else  error->all(FILE_LINE_FUNC,"ADD_TO_SIMULATION: Unknown variable or command ");
  
  }
  
 
	return in_file;

}

// ========================
// ========================
// ========================

bool Object_handler::add_atom_to_simulation (NS_object_utility::Atom &a) {
  //auto atom_data = md->atom_data;
  const auto id = atom_data -> get_global_id();
  const auto element_index = a.get_element_index ();
  const auto pos = a.pos_tot ();
  const auto vel = a.vel_tot ();
  
	atom_data->add_atom (id, element_index, pos, vel);	  
	
	return true;//WARNING
}

// ========================
// ========================
// ========================

bool Object_handler::add_molecule_to_simulation (NS_object_utility::Molecule &m) {
  std::vector<int> element_index;
  std::vector<Vector<double>> pos, vel;
  m.extract_all_e_pos_vel (element_index, pos, vel);
  for (unsigned int i = 0; i < element_index.size(); ++i) {
    const auto id = atom_data -> get_global_id();
	  atom_data->add_atom (id, element_index[i], pos[i], vel[i]);	     
  }
  return true;//WARNING
}
// ========================
// ========================
// ========================

bool Object_handler::add_elements_to_simulation () {
  for (auto e : object_container -> element) {
    atom_data->add_masses(e.get_element_index(), e.get_mass());
    atom_data->add_charges(e.get_element_index(), e.get_charge());
//  atom_data->add_masses(e.get_element_index(), e.get_radius());    
  }
	atom_data->set_num_atom_types (object_container -> element.size());  
  return true;//WARNING  
}
// ========================
// ========================
// ========================



bool Object_handler::set_simulation_box (Parser *parser) {
	output->info("Object_handler: ADD_TO_SIMULATION: ");
	
	Real_t XMIN=-1, XMAX=1, YMIN=-1, YMAX=1, ZMIN=-1, ZMAX=1;
	
	bool in_file = true;
	
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		const auto t = token.string_value;
    if (t=="FROM") {
      
    }	else ASSIGN_REAL(XMIN,"Random_1D creation: ","")
		else ASSIGN_REAL(XMAX,"Random_1D creation: ","")		
		else ASSIGN_REAL(YMIN,"Random_1D creation: ","")
		else ASSIGN_REAL(YMAX,"Random_1D creation: ","")				
		else ASSIGN_REAL(ZMIN,"Random_1D creation: ","")
		else ASSIGN_REAL(ZMAX,"Random_1D creation: ","")		
	}
	
  domain->x_lower_global = XMIN;
  domain->x_upper_global = XMAX;
  domain->y_lower_global = YMIN;
  domain->y_upper_global = YMAX;
  domain->z_lower_global = ZMIN;
  domain->z_upper_global = ZMAX;

	comm->calculate_procs_grid ();

	domain->calculate_local_domain ();
	
	/*
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (t=="X") {
      add_elements_to_simulation ();
    } else if (t=="ATOM" || t=="MOLECULE") {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,"ADD_TO_SIMULATION: "," expected an MOLECULE or ATOM NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "ADD_TO_SIMULATION: ","")
		  if (it_1->second.type == NS_object_handler::gdst("ATOM")) {
		  
		    auto & a = object_container -> atom[it_1->second.index];
		    add_atom_to_simulation (a);
	    
		    
		  }	else if (it_1->second.type == NS_object_handler::gdst("MOLECULE")) {
		  
		    auto & a = object_container -> molecule[it_1->second.index];
		    add_molecule_to_simulation (a);
	    
		    
		  }	else error->all(FILE_LINE_FUNC,"ADD_TO_SIMULATION: expected an MOLECULE or ATOM NAME. ");
		} else  error->all(FILE_LINE_FUNC,"ADD_TO_SIMULATION: Unknown variable or command ");
  
  }
  */
  
 
	return in_file;

}




























