#include "object_utility_grid_1d.h"
#include "object_handler_all.h"
#include "object_container.h"

//====================================
//====================================
//====================================

namespace NS_object_utility {

	Grid_1D::Grid_1D () {}
  Grid_1D::Grid_1D (Object_container * all_obj, double min, double max, double increment, int segment) : 
    MIN{min}, MAX{max}, INCREMENT{increment},
    generated{false}, by_increment{false}, by_segment{false}, SEGMENT{segment}, no_given_points{0},
     parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
   { }
  
	Grid_1D::~Grid_1D () {
		}
	bool Grid_1D::read(Parser* parser) {
		output->info("GRID_1D Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="GENERATE") {generate(); break;}		  
		  else ASSIGN_REAL(MIN,"GRID_1D Read: ","")
		  else ASSIGN_REAL(MAX,"GRID_1D Read: ","")
		  else ASSIGN_REAL(INCREMENT,"GRID_1D Read: ","")
		  else ASSIGN_INT(SEGMENT,"GRID_1D Read: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D Read: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Grid_1D::generate () {
		output->info("Grid_1d Generate: ");		
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Grid_1D: cannot be generated twice. ");
	  generated = true;
    if (SEGMENT>0 && INCREMENT>0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assigning both SEGMENT and INCREMENT is not possible. ");
    if (SEGMENT<0 && INCREMENT<0)
	    error->all(FILE_LINE_FUNC,"Grid_1D: Assign one of SEGMENT or INCREMENT. ");
	  if (MIN > MAX)
	    error->all(FILE_LINE_FUNC,"Grid_1D: MIN has to be smaller than MAX. ");	  
	  if (SEGMENT<0) {
	    by_increment = true;
	    SEGMENT = int ((MAX-MIN)/INCREMENT);
	  }
	  if (INCREMENT<0) {
	    by_segment = true;
	    INCREMENT = (MAX - MIN)/double(SEGMENT);
	  }
	}
	
	unsigned int Grid_1D::no_points () {
	
	  if (by_segment)
	    return SEGMENT + 1;
	  else
	    return SEGMENT;
	}
	
	double Grid_1D::give_point () {
    double val = MIN + no_given_points * INCREMENT;
	  ++no_given_points;    
	  if (by_segment) {
	    if (no_given_points > SEGMENT) return MAX;
	    else return val;
	  } else {
      return val;	  
	  }
	}
	
  double Grid_1D::give_point (int i) {
    double val = MIN + i * INCREMENT;  
	  if (by_segment) {
	    if (i == SEGMENT) return MAX;
	    else return val;
	  } else {
      return val;	  
	  }
	}
}
