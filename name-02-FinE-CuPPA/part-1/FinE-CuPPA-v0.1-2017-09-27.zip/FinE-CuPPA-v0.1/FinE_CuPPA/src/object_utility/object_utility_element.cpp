#include "object_utility_element.h"
#include "object_handler_all.h"
#include "object_container.h"

namespace NS_object_utility {

//====================================
//====================================
//====================================

Element::Element () {} 
Element::Element (Object_container * all_obj, double m, double r, double ch, unsigned int i) :
	 element_index{i}, MASS{m}, RADIUS{r}, CHARGE{ch}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj} {} 

Element::~Element () {}
	
// =============================


bool Element::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(RADIUS,"ELEMENT READ: ","")
		else ASSIGN_REAL(MASS,"ELEMENT READ: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT READ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: Unknown variable or command");		
	}
	
	return in_file;;
}

}
