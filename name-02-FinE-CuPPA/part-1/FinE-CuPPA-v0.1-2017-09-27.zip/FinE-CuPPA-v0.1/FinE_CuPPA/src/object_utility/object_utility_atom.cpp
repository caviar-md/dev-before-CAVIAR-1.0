#include "object_utility_atom.h"
#include "object_handler_all.h"
#include "object_container.h"

namespace NS_object_utility {

	Atom::Atom () :  has_father{false}, FATHER{0}, POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}}
	 {}	
	Atom::Atom (Object_container * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel, unsigned int el_indx) : 
		 FATHER{f}, POSITION{pos}, VELOCITY{vel}, element_index{el_indx}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}  {}
	
 	Atom::~Atom () {}

	Atom::Atom (const Atom & a) : 
  has_father{false}, FATHER{0}, POSITION{a.POSITION}, VELOCITY{a.VELOCITY},
	element_index{a.element_index}, output{a.output}, error{a.error}, object_container{a.object_container} {}
	
// =============================


bool Atom::read ( Parser * parser) {
	output->info("Atom read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM READ: ","")
		else error->all (FILE_LINE_FUNC, "ATOM read: Unknown variable or command");
	}
	
	return in_file;;
}

// =============================

double Atom::get_radius () const {
  return object_container->element[element_index].get_radius();
}

//====================================


Vector<double> Atom::pos_tot () const {
	if (has_father) return POSITION + FATHER->pos_tot();
 	else return POSITION;	 
}

Vector<double> Atom::vel_tot () const {
	if (has_father) return VELOCITY + FATHER->vel_tot();
	else return VELOCITY;		
}

//====================================

void Atom::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  e.push_back (element_index);
  p.push_back (pos_tot());
  v.push_back (vel_tot());
}

void Atom::output_xyz (std::ofstream & out_file) {
	const auto p = pos_tot();
	out_file << element_index << " " << p.x << " " << p.y << " " << p.z << std::endl;	

}


}
