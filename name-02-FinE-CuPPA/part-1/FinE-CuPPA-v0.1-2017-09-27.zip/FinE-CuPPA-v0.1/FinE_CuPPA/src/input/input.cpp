#include "input.h"

#include <map>
#include <cmath>

#include "error.h"
#include "parser.h"
#include "update.h"
#include "output.h"
#include "all_data_reader.h"
#include "all_atom_data.h"
#include "input_commands_map.h"
#include "object_handler.h"
#include "object_container.h"
#include "object_creator.h"

Input::Input (MD *md) : Pointers {md}, parser {new Parser{md}} {}

Input::Input (MD *md, const std::string &file) : Pointers {md}, parser {new Parser{md, file}} {}

Input::~Input () {
  delete parser;
}

void Input::read (Parser * parser) {
  while (read_command (parser));
}

void Input::read () {
  while (read_command (parser));
}

bool Input::read_command (Parser * parser) {
  auto command = parser->get_command_identifier();
  if (commands_map.count (command) != 0) 
    return (this->*commands_map.at(command)) (parser);
  else if (object_creator->commands_map.count (command) != 0) {
 //   auto c = object_creator ->commands_map;
  //  bool tmp = (object_creator->*object_creator->commands_map.at(command)) (parser);
   // return tmp;
    return (object_creator->*object_creator->commands_map.at(command)) (parser);
  } else {
    std::map<std::string, NS_object_handler::Dictionary>::iterator it;
    it = object_container->dictionary.find(command);
			if (it == object_container->dictionary.end())
				error->all (FILE_LINE_FUNC, "Invalid command or object NAME");
  }
}

bool Input::read_script_from_file (Parser *) {
  return true;
}
/*
bool Input::atom_style (Parser *) {
  auto atom_style_identifier = parser->get_identifier();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  if (atom_style_identifier != "simple") {
    delete atom_data;
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)     \
    if (reader_identifier == #key) atom_data = new Class {md};
#include "all_atom_data.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  }
  return true;
}
*/

bool Input::read_data_with_format (Parser *) {
	bool correct_read_data_type = false;
  // the following two initialization must be on separate lines to insure correct order
  auto reader_identifier = parser->get_identifier();
  auto file_name = parser->get_string();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)                \
  if (reader_identifier == #key) {                \
    correct_read_data_type = true;                \
    auto data_reader = new Class (md, file_name); \
    auto result = data_reader->read ();           \
    delete data_reader;                           \
    return result;                                \
  }
#include "all_data_reader.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  if (! parser->end_of_line () || !correct_read_data_type ) error->all (FILE_LINE_FUNC, "Invalid syntax. this type of data_reader doesn't exist.");    
  return false;
}



bool Input::periodic_boundary (Parser *) {
  auto xbc = parser->get_int(); atom_data->x_bc = xbc;
  auto ybc = parser->get_int(); atom_data->y_bc = ybc;
  auto zbc = parser->get_int(); atom_data->z_bc = zbc;
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
	return true;
}

bool Input::time_step (Parser *) {
  auto d_t = parser->get_real();	md->update->dt = d_t;
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
	return true;
}
bool Input::output_step (Parser *) {
	output->set_parameters (parser);
	return true;
}

bool Input::run_simulation (Parser *) {
  auto num_steps = parser->get_int();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  return update->run (num_steps);
}

bool Input::print (Parser *) {
  parser->write_to_stream (std::cout);
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  return true;
}

bool Input::exit_program (Parser *) {
  return false;
}

bool Input::delete_object (Parser *) {

}
