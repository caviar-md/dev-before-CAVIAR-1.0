#include "force_field_poisson.h"

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "vector.h"
#include "output.h"

#include <cmath>

Force_field_poisson::Force_field_poisson (MD *md, Parser *parser) : Force_field {md, parser}

{

}

bool Force_field_poisson::read (Parser *parser) {

  return true; // WARNING
}

void Force_field_poisson::calculate_acceleration () {

}


