#include "shape_polyhedron.h"

#include "object_handler_all.h"
#include "object_container.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "output.h"
#include "atom_data.h"

#include "utility.h"

namespace NS_shape {

Polyhedron::Polyhedron (MD *md) : Shape {md},
				object_container{md->object_container}, output{md->output}, error{md->error}, 
  polyhedron_handler {new NS_geometry::Polyhedron_Handler{md}}
  {}

Polyhedron::~Polyhedron () { 
	delete polyhedron_handler;	
}

bool Polyhedron::read(Parser * parser) {
	output->info("Data_reader_Kakaka: Polyhedron read:");
	return polyhedron_handler -> read (parser);
}

bool Polyhedron::is_inside(const Vector<double> &v0) {
  return polyhedron_handler -> is_inside (v0);   
}

bool Polyhedron::is_outside(const Vector<double> &v) {
  return !is_inside (v);
}

bool Polyhedron::is_inside(const Vector<double> &v, const double r) {
  return polyhedron_handler -> is_inside (v, r); 
}

bool Polyhedron::is_outside(const Vector<double> &v, const double r) {
  return !is_inside (v,r);
}






} //namespace


