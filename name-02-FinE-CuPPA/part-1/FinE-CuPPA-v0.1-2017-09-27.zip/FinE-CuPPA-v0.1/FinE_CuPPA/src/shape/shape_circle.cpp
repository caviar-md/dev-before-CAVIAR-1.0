#include "shape_circle.h"

#include "object_handler_all.h"
#include "object_container.h"
#include "parser.h"
#include "lexer.h"


namespace NS_shape {

// ========================
// ========================
// ========================
//			Circle
// ========================
// ========================
// ========================

		Circle::Circle (MD *md) : Shape {md},
		  FLATNESS_TOLL{0.001},	object_container{md->object_container}, output{md->output}, error{md->error} {}
		Circle::~Circle() {}
		
		bool Circle::read(Parser * parser) {
			output->info("Data_reader_Kakaka: CIRCLE read");
			bool in_file = true;
			

			while(true) {
				GET_A_TOKEN_FOR_CREATION
				ASSIGN_REAL_3D_VECTOR(CENTER,"CIRCLE read: ","")
				else ASSIGN_REAL_3D_VECTOR(NORMAL,"CIRCLE read: ","")
				else ASSIGN_REAL(RADIUS,"CIRCLE read:","")
				else ASSIGN_REAL(FLATNESS_TOLL,"CIRCLE read:","")
				else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: CIRCLE read: Unknown variable or command");
			}
	
			return in_file;;

		}

		bool Circle::on_the_plane(const Vector<double> &v) {
			Vector<double> v_1 = v - CENTER;
			if (v_1*NORMAL>FLATNESS_TOLL)
				return false;
			return true;
		}

		bool Circle::is_inside(const Vector<double> &v) {
			if (!on_the_plane(v))
				return false;
			Vector<double> v_1 = v - CENTER;
			if (v_1*v_1 > RADIUS*RADIUS)
				return false;
			return true;
		}
		
		bool Circle::is_inside(const Vector<double> &v, const double r) {	
			if (!on_the_plane(v))
				return false;
			Vector<double> v_1 = v - CENTER;
			if (v_1*v_1 > (RADIUS-r)*(RADIUS-r))
				return false;
			return true;
		}		
		bool Circle::is_outside(const Vector<double> &v) {		
		  return !is_inside(v);
		}
		
		bool Circle::is_outside(const Vector<double> &v, const double r) {		
		  return !is_inside(v,r);
		}

// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

	
}

