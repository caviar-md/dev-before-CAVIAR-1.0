#include "object_creator.h"
#include "object_handler_all.h"
#include "object_container.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"





// ========================
// ========================
// ========================
/*

bool Object_creator::random_1d (Parser *parser) {
	output->info("Object_creator: Random_1D creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string TYPE;
	double MIN=0.0, MAX=1.0, STDDEV=1.0, MEAN=1.0;
	int SEED = 1;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_STRING(TYPE,"Random_1D creation: ","")
		else ASSIGN_REAL(MIN,"Random_1D creation: ","")
		else ASSIGN_REAL(MAX,"Random_1D creation: ","")
		else ASSIGN_REAL(STDDEV,"Random_1D creation: ","")
		else ASSIGN_REAL(MEAN,"Random_1D creation: ","")
		else ASSIGN_INT(SEED,"Random_1D creation: ","")	
		else error->all(FILE_LINE_FUNC,"Random_1D creation: Unknown variable or command ");
	}
	
  
	int index = object_container -> random_1d.size ();
	NS_object_utility::Random_1D e_ (object_container, TYPE, MIN, MAX, STDDEV, MEAN, SEED);
	object_container -> random_1d.push_back ( e_);
	
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("RANDOM_1D"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));
	
	return in_file;

}

// ========================
// ========================
// ========================


bool Object_creator::grid_1d (Parser *parser) {
	output->info("Object_creator: GRID_1D creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	double MIN=0.0, MAX=1.0, INCREMENT=-1.0;
	int SEGMENT = -1;
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else ASSIGN_REAL(MIN,"GRID_1D creation: ","")
		else ASSIGN_REAL(MAX,"GRID_1D creation: ","")
		else ASSIGN_REAL(INCREMENT,"GRID_1D creation: ","")
		else ASSIGN_INT(SEGMENT,"GRID_1D creation: ","")	
		else error->all(FILE_LINE_FUNC,"GRID_1D creation: Unknown variable or command ");
	}
	
  
	int index = object_container -> grid_1d.size ();
	NS_object_utility::Grid_1D e_ (object_container, MIN, MAX, INCREMENT, SEGMENT);
	object_container -> grid_1d.push_back ( e_);
	
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("GRID_1D"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));
	
	return in_file;

}
*/
// ========================
// ========================
// ========================


bool Object_creator::force_field (Parser *parser) {
	output->info("Object_creator: force_field creation ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string force_field_type = "";
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_A_STRING_NNT(force_field_type,"force_field: ","")
	}

	Force_field * p_sh;	
	if (force_field_type == "LJ") {
		p_sh = new Force_field_lj (md, parser); 
	} else if (force_field_type == "LJ_ACC") {
		p_sh = new Force_field_lj_acc (md, parser); 
	} else	if (force_field_type == "GLD") {
		p_sh = new Force_field_gld (md, parser); 
	} else	if (force_field_type == "GEOMETRY") {
		p_sh = new Force_field_geometry (md, parser); 
	} else {
		error->all(FILE_LINE_FUNC,"NOT defined force_field_");
	}
	

	int index = object_container -> force_field.size ();
	object_container -> force_field.push_back (p_sh);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("force_field"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	
	return in_file;

}

// ========================
// ========================
// ========================


bool Object_creator::shape (Parser *parser) {
	output->info("Object_creator: Shape creation ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;
	std::string shape_type = "";
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
		else GET_A_STRING_NNT(shape_type,"Shape: ","")
	}

	NS_shape::Shape * p_sh;	
	if (shape_type == "CIRCLE") {
		p_sh = new NS_shape::Circle (md); 
	} else if (shape_type == "SPHERE") {
		p_sh = new NS_shape::Sphere (md); 
	} else	if (shape_type == "CLOSED_LINES") {
		p_sh = new NS_shape::Closed_lines (md); 
	} else	if (shape_type == "POLYHEDRON") {
		p_sh = new NS_shape::Polyhedron (md); 
	} else {
		error->all(FILE_LINE_FUNC,"NOT defined shape");
	}
	

	int index = object_container -> shape.size ();
	object_container -> shape.push_back (p_sh);

	NS_object_handler::Dictionary dict (NS_object_handler::gdst("SHAPE"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	
	return in_file;

}

// ========================
// ========================
// ========================


bool Object_creator::boundary (Parser *parser) {
	output->info("Object_creator: Boundary creation: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
	}

	int index = object_container -> boundary.size ();
	NS_shape::Boundary e_ (md);

	object_container -> boundary.push_back ( e_);
	
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("BOUNDARY"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}

// ========================
// ========================
// ========================

/*
bool Object_creator::distribution (Parser *parser) {
	output->info("Object_creator: Molecule distribution: ");
	std::string NAME = "";
	bool name_called = false;
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_NAME
	}


	int index = object_container -> distribution.size ();
	NS_object_utility::Distribution e_ (object_container);

	object_container -> distribution.push_back ( e_);
	
	NS_object_handler::Dictionary dict (NS_object_handler::gdst("DISTRIBUTION"), index);	
	object_container -> dictionary.insert (std::make_pair(NAME,dict));

	return in_file;

}

*/

	/*
bool Object_creator::read (Parser *parser) {
	bool in_file = true;

	while (in_file) {
		auto token = parser->get_val_token();
		if (token.kind == Kind::eof) break;
		if (token.kind == Kind::eol) continue;
		auto command = token.string_value;

		std::map<std::string,NS_object_handler::Dictionary>::iterator it;
		if (commands_map.count (command) == 0) {
			it = object_container -> dictionary.find(command);
			if (it == object_container -> dictionary.end())
				error->all (FILE_LINE_FUNC, "Object_creator : read : Invalid Kakaka command or object NAME");
			if (it->second.type == NS_object_handler::gdst("ELEMENT")) 
				in_file = object_container -> element[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("ATOM")) 
				in_file = object_container -> atom[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("MOLECULE")) 
				in_file = object_container -> molecule[it->second.index].read(parser);
			if (it->second.type == NS_object_handler::gdst("SHAPE")) 
				in_file = object_container -> shape[it->second.index]->read(parser);
      if (it->second.type == NS_object_handler::gdst("RANDOM_1D")) 
				in_file = object_container -> random_1d[it->second.index].read(parser);
      if (it->second.type == NS_object_handler::gdst("GRID_1D")) 
				in_file = object_container -> grid_1d[it->second.index].read(parser);
      if (it->second.type == NS_object_handler::gdst("BOUNDARY")) 
				in_file = object_container -> boundary[it->second.index].read(parser);													
      if (it->second.type == NS_object_handler::gdst("DISTRIBUTION")) 
				in_file = object_container -> distribution[it->second.index].read(parser);
		} else {
			in_file = (this->*commands_map.at(command)) ();
		}
	}
	return in_file; //WARNING
}
*/



















