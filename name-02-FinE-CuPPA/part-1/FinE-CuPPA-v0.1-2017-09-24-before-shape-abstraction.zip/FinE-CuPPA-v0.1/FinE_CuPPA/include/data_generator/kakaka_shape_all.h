#include "kakaka_shape_circle.h"
#include "kakaka_shape_sphere.h"
#include "kakaka_shape_closed_lines.h"
#include "kakaka_shape_polyhedron.h"
