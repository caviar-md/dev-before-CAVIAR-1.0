#ifndef KAKAKA_UTILITY_ALL_OBJECTS_H
#define KAKAKA_UTILITY_ALL_OBJECTS_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
#include "kakaka_shape_all.h"
#include "kakaka_utility_all.h"

namespace kkk {


class All_objects {
	public:
	All_objects () {};
	~All_objects ();
	class Parser * parser;
  class Output * output;
  class Error * error;
	
	std::map<std::string,kkk::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<Element> elements; // 1
	std::vector<Atom> atoms; // 2
	std::vector<Molecule> molecules; // 3
	std::vector<Boundary> boundaries; // 4
	std::vector<Random_1D> random_1ds; // 5
	std::vector<shape::Shape *> shapes; // 6	
	std::vector<Grid_1D> grid_1ds; // 7	
	std::vector<Distribution> distributions; // 8
	std::vector<int> int_constants; // -1
	std::vector<double> real_constants; // -2
	std::vector<Vector2D<int>> int_2d_vectors; // -3
	std::vector<Vector2D<double>> real_2d_vectors; // -4
	std::vector<Vector<int>> int_3d_vectors; // -5
	std::vector<Vector<double>> real_3d_vectors; // -6

} ;//all_objects;

} // NAMESPACE KKK finished


#endif
 
