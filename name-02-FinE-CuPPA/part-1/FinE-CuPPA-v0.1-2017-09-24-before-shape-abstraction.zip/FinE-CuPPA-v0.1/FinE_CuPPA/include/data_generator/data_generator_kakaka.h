#ifdef DATA_GENERATOR_CLASS

DataGeneratorStyle(Kakaka,Data_generator_Kakaka)

#else

#ifndef DATA_GENERATOR_KAKAKA_H
#define DATA_GENERATOR_KAKAKA_H

#include "pointers.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "kakaka_utility_all.h"
#include "atom_data.h"

class Data_generator_Kakaka;

//namespace kkk {
using CommandFuncKKK = bool (Data_generator_Kakaka::*)(); // a pointer to boolean function of Kakaka class.
//}

class Data_generator_Kakaka : protected Pointers {
public:
  Data_generator_Kakaka (class MD *, const std::string &);
  ~Data_generator_Kakaka ();

	bool read ();

private:
	bool execute ();
	GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;
	

	class kkk::All_objects *all_objects;
  class Parser *parser;
	class Output *output;


//	const static std::map<std::string,kkk::CommandFunc> commands_map;
	const static std::map<std::string,CommandFuncKKK> commands_map;

	bool READ_FILE () ;
	bool ELEMENT () ;
	bool ATOM () ;
	bool MOLECULE () ;
	bool RANDOM_1D () ;
	bool GRID_1D () ;
	bool SHAPE ();
	bool BOUNDARY ();
	bool ADD_ATOM ();
	bool ADD_MOLECULE ();
	bool INT_CONSTANT ();
	bool REAL_CONSTANT ();
	bool INT_2D_VECTOR ();
	bool REAL_2D_VECTOR ();
	bool INT_3D_VECTOR ();
	bool REAL_3D_VECTOR ();
	bool DISTRIBUTION ();
  bool OUTPUT_XYZ ();
  bool ADD_TO_SIMULATION ();
  bool SET_SIMULATION_BOX ();

  bool add_elements_to_simulation ();  
  bool add_atom_to_simulation (kkk::Atom &);
  bool add_molecule_to_simulation (kkk::Molecule &);

};




#endif
#endif
 
