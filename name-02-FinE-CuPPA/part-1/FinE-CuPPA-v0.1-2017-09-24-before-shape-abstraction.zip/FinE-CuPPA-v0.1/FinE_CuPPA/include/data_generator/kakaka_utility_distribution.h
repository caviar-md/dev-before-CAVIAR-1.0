#ifndef KAKAKA_UTILITY_DISTRIBUTION_H
#define KAKAKA_UTILITY_DISTRIBUTION_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

//#include "vector.h"
//#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
//#include "kakaka_shape_all.h"
#include "kakaka_utility_boundary.h"

namespace kkk {

class All_objects;
//class Boundary;
class Molecule;
class Atom;

class Distribution {
	public:
	Distribution ();
  Distribution (class All_objects * all_obj);
	~Distribution () ;
  bool read (Parser *);		
	
	class Boundary *boundary;
	class Molecule *m_object, *container;
	class Atom * a_object;
	bool boundary_check, a_object_check, m_object_check, container_check;
	
	bool distribute_grid_3D();
	bool distribute_random_3D()	;
	
	class Parser * parser;	
  class Output * output;
  class Error * error;
  class All_objects * all_objects;


};

} // NAMESPACE KKK finished


#endif
 
