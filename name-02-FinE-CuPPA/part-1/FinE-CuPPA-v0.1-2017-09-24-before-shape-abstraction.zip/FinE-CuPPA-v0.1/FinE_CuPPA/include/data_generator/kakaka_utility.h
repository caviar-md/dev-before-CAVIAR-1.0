#ifndef KAKAKA_UTILITY_H
#define KAKAKA_UTILITY_H


#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "parser.h"
#include "output.h"
#include "error.h"
#include "vector.h"

namespace kkk {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::map<std::string,int> dictionary_second_type = {
	{"ELEMENT",1},
	{"ATOM",2},
	{"MOLECULE",3},	
	{"RANDOM_1D",4},
	{"BOUNDARY",5},	
	{"SHAPE",6},	
	{"GRID_1D",7},
	{"DISTRIBUTION",8},	
	{"INT_CONSTANT",-1},	
	{"REAL_CONSTANT",-2},	
	{"INT_2D_VECTOR",-3},	
	{"REAL_2D_VECTOR",-4},	
	{"INT_3D_VECTOR",-5},	
	{"REAL_3D_VECTOR",-6},
};


} // NAMESPACE KKK finished


#endif
 
