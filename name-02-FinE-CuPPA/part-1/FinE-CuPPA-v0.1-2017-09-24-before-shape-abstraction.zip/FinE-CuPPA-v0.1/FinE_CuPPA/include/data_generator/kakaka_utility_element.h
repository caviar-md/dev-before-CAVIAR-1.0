#ifndef KAKAKA_UTILITY_ELEMENT_H
#define KAKAKA_UTILITY_ELEMENT_H

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

//#include "vector.h"
//#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"
//#include "kakaka_shape_all.h"

namespace kkk {

class Element {
	public:
		Element () ;
		Element (class All_objects *, double m, double r, double ch, unsigned int i);
		~Element ();
    double get_radius () const {
      return RADIUS;
    }
    double get_mass () const {
      return MASS;
    }
    double get_charge () const {
      return CHARGE;
    }            
    unsigned int get_element_index() const {
      return element_index;
    }
		bool read (Parser *);
	private:
		unsigned int element_index;
		double MASS, RADIUS, CHARGE;
			
		class Output * output;
		class Error * error;
		class All_objects * all_objects;


};

} // NAMESPACE KKK finished


#endif
 
