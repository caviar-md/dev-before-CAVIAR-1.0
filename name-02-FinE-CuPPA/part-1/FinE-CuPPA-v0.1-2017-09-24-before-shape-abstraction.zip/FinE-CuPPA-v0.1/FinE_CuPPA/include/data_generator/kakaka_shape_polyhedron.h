#ifndef KAKAKA_SHAPE_POLYHEDRON_H
#define KAKAKA_SHAPE_POLYHEDRON_H

#include "pointers.h"

#include <vector>
#include <map>

#include "kakaka_shape.h"
#include "vector.h"
#include "polyhedron.h"
#include "output.h"
#include "error.h"
#include "md.h"
#include "kakaka_utility.h"
#include "polyhedron_handler.h"

namespace kkk {


namespace shape {


class Polyhedron : public Shape {
	public:
	Polyhedron (All_objects *, MD *);
	~Polyhedron ();

	bool read (Parser *);	
	
	bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
	bool is_outside (const Vector<double> &v);
  bool is_outside (const Vector<double> &, const double rad);	
  	

	MD * md;
	Output * output;
	Error * error;
	All_objects * all_objects;


	private:
	void command_parameters (class Parser *);		
	//void command_output (class Parser *);
	void command_generate ();
			
  Namespace_Geometry::Polyhedron_Handler * polyhedron_handler;


};
}
}
#endif
