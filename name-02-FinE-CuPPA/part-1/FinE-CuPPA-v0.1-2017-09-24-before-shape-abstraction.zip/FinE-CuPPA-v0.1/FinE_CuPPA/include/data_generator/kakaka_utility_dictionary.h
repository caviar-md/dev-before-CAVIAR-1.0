#ifndef KAKAKA_UTILITY_DICTIONARY_H
#define KAKAKA_UTILITY_DICTIONARY_H

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"

namespace kkk {


class Dictionary {
	public:
	Dictionary () { };
	Dictionary (int t, int i) : type(t), index(i){ };
	~Dictionary () {};
	int type; // type of the vector
	int index; // index of the vector
//	string object_type ; // the same as int type
};

} // NAMESPACE KKK finished


#endif
 
