#ifdef ATOM_DATA_CLASS

AtomDataStyle(simple,Atom_data_simple)

#else

#ifndef ATOM_DATA_SIMPLE_H
#define ATOM_DATA_SIMPLE_H

#include "atom_data.h"

class Atom_data_simple : public Atom_data {
public:
  Atom_data_simple (class MD *);
private:
  void allocate ();
};

#endif
#endif
