#ifndef POLYHEDRON_POSTPROCESS_H
#define POLYHEDRON_POSTPROCESS_H

#include "polyhedron.h"
#include "pointers.h"

namespace Namespace_Geometry {
class Polyhedron_Postprocess : protected Pointers{
public:
  Polyhedron_Postprocess (class MD *);
  ~Polyhedron_Postprocess ();
  

	void make_grid (Namespace_Geometry::Polyhedron&); // contains the faces neccesary to check
									      // make_grid has to be called after lowest_highest_coord()
	void lowest_highest_coord (Namespace_Geometry::Polyhedron&); // calculates gxlo, gxhi, gylo...


};
}
#endif
