#ifndef POLYHEDRON_HANDLER_H
#define POLYHEDRON_HANDLER_H

#include "polyhedron.h"
#include "pointers.h"
#include "output.h"
#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "polyhedron.h"
#include "polyhedron_input.h"
#include "polyhedron_utility.h"
#include "polyhedron_preprocess.h"
#include "polyhedron_postprocess.h"
#include "polyhedron_point_inside.h"
#include "polyhedron_output.h"

namespace Namespace_Geometry {
class Polyhedron_Handler : protected Pointers{
public:
  Polyhedron_Handler (class MD *);
  ~Polyhedron_Handler ();
  
  bool read (Parser *);
  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
   
private:
  void  command_parameters (Parser *);
  void  command_generate ();

	class Namespace_Geometry::Polyhedron_Input * polyhedron_input;
	class Namespace_Geometry::Polyhedron_Preprocess * polyhedron_preprocess;
	class Namespace_Geometry::Polyhedron_Postprocess * polyhedron_postprocess;
	class Namespace_Geometry::Polyhedron_Utility * polyhedron_utility;	
	class Namespace_Geometry::Polyhedron_Point_Inside * polyhedron_point_inside;	
	class Namespace_Geometry::Polyhedron_Output * polyhedron_output;
	
	
  Namespace_Geometry::Polyhedron polyhedron; 	

	Real_t young_modulus;
	std::vector<Real_t> radius;
	
	bool polyhedron_read, output_mesh_tcl, output_normals_tcl, output_edges_tcl, output_mesh_povray;
	bool invert_normals, correct_normals;	
	
  class Parser *parser;
	class Output *output;
	class Error *error;
};
}
#endif
