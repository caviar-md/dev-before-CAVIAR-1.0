#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "pointers.h"

#include <vector>
#include <map>

#include "vector.h"
#include "polyhedron_handler.h"


class Geometry : protected Pointers {
	public:
	Geometry (class MD *);
	~Geometry ();
	
	bool read (const std::string &);	
	void calculate_acceleration ();	
	
	private:	
	Namespace_Geometry::Polyhedron_Handler * polyhedron_handler;
	void command_polyhedron (class Parser *);		
  class Parser *parser;
	class Output *output;
	class Error *error;

	bool geometry_force;
//  std::map<std::string,int> //assign a name to each polyhedron

};

#endif
