#include "polyhedron_handler.h"

#include <string>
#include <cmath>
#include <fstream>


namespace Namespace_Geometry {

Polyhedron_Handler::Polyhedron_Handler (MD *md) : Pointers{md},
	polyhedron_input {new Namespace_Geometry::Polyhedron_Input{md}},
  polyhedron_preprocess {new Namespace_Geometry::Polyhedron_Preprocess{md}},
	polyhedron_postprocess {new Namespace_Geometry::Polyhedron_Postprocess{md}},
	polyhedron_utility {new Namespace_Geometry::Polyhedron_Utility{md}},
  polyhedron_point_inside {new Namespace_Geometry::Polyhedron_Point_Inside {md}},
  polyhedron_output {new Namespace_Geometry::Polyhedron_Output {md}},  
  polyhedron_read{false},
  output_mesh_tcl{false},
  output_normals_tcl{false},
  output_edges_tcl{false},
  output_mesh_povray{false},
  invert_normals{false},
  correct_normals{false},
  output{md->output},
  error{md->error}
  {}



Polyhedron_Handler::~Polyhedron_Handler () {
	delete polyhedron_input;
	delete polyhedron_preprocess;
	delete polyhedron_postprocess;
	delete polyhedron_utility;
  delete polyhedron_point_inside;
	delete polyhedron_output;	
}

bool Polyhedron_Handler::read(Parser * parser) {
	output->info("Data_reader_Kakaka: Polyhedron read:");
	bool in_file = true;
			
	while(true) {
		const auto token = parser->get_val_token();
		const auto t = token.string_value;
    if (t=="VTK_FILE_NAME") {
		  const auto token = parser->get_val_token();
		  const auto t = token.string_value;
		  const auto file_name = token.string_value;
	    polyhedron_input -> read_vtk (polyhedron, file_name);
    } else if (t=="PARAMETERS") {
      //command_parameters (parser);
    } else if (t=="OUTPUT") {
		const auto token = parser->get_val_token();
		const auto t = token.string_value; 

		  if (t == "VMD" || t == "TCL") {
		    output_mesh_tcl = true;
        output_normals_tcl = true;
        output_edges_tcl = true;
      }
    } else if (t=="GENERATE") {
      command_generate ();
    }	else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Polyhedron read: Unknown variable or command");
	}
	
	return in_file;;
}

bool Polyhedron_Handler::is_inside (const Vector<double> &v0) {
  return  polyhedron_point_inside -> is_inside (polyhedron, v0);   
}


bool Polyhedron_Handler::is_inside (const Vector<double> &v, const double r) {
  return polyhedron_point_inside -> is_inside (polyhedron, v, r); 
}



void Polyhedron_Handler::command_parameters (Parser *parser) {

	if (polyhedron_read == false) error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: Polyhedron: read polyhedron before this command.");
  auto token = parser->get_val_token();
  auto t = token.string_value;
  if (t == "THICKNESS" || t == "thickness") {
		auto thickness_ = parser->get_literal_real();
		polyhedron.thickness = thickness_;
	} else if (t == "YOUNG_MODULUS" || t == "young_modulus") {
		young_modulus = parser->get_literal_real();

	} else if (t == "RADIUS" || t == "radius") {
		auto r = parser->get_literal_real();
		radius.push_back (r);
		if (polyhedron.grid_toll<r) polyhedron.grid_toll = r;
	} else if (t == "INVERT_NORMALS" || t == "invert_normals") {
		invert_normals = true;
	} else if (t == "CORRECT_NORMALS" || t == "correct_normals") {
		correct_normals = true;
	} else if (t == "GRID" || t == "grid") {
		auto nx_ = parser->get_literal_int();
		auto ny_ = parser->get_literal_int();
		auto nz_ = parser->get_literal_int();
		if (nx_ < 1 || ny_ < 1 || nz_ < 1) error->all(FILE_LINE_FUNC, "grids has to be larger than 1");
		polyhedron.nx_part = nx_; 		polyhedron.nx_part = ny_;		polyhedron.nx_part = nz_;
	} else {
  	error->all (FILE_LINE_FUNC, "invalid syntax: this geometry parameter does not exists");
	}

}

void  Polyhedron_Handler::command_generate () {


	if (correct_normals) {		
	  output->info("polyhedron: generate : correct_normals");
	  polyhedron_preprocess -> pre_correct_normals (polyhedron);
  }
    
	output->info("polyhedron: generate : make_normal");
	polyhedron_utility -> make_normal (polyhedron);

	output->info("polyhedron: generate : make_edge_norms");
	polyhedron_utility -> make_edge_norms (polyhedron);

	if (invert_normals) {
  	output->info("polyhedron: generate : invert_normals");
		polyhedron_utility -> invert_normals (polyhedron);
	}
	
	output->info_ne("polyhedron: generate : lowest_highest_coord : ");
	polyhedron_postprocess -> lowest_highest_coord (polyhedron);
		
	output->info("polyhedron: generate : make_grid");
	polyhedron_postprocess -> make_grid (polyhedron);


  if (output_mesh_povray)	polyhedron_output -> mesh_povray (polyhedron); 
  if (output_mesh_tcl)	polyhedron_output -> mesh_tcl (polyhedron); 
  if (output_normals_tcl)	polyhedron_output -> normals_tcl (polyhedron);
  if (output_edges_tcl)	polyhedron_output -> edges_tcl (polyhedron);

}

} //namespace


