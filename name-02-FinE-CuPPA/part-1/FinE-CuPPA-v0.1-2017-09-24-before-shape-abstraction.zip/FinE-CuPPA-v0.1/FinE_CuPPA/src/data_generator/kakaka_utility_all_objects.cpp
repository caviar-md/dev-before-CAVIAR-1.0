#include "kakaka_utility_all_objects.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/

kkk::All_objects::~All_objects () {
  for (auto i :shapes)
    delete i;
}


