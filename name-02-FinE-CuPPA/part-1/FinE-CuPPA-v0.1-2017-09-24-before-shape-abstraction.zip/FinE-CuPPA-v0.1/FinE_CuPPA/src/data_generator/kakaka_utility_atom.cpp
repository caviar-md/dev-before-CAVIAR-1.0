#include "kakaka_utility_atom.h"
#include "kakaka_utility_all_objects.h"
#include "kakaka_preprocessors.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/

	kkk::Atom::Atom () :  has_father{false}, FATHER{0}, POSITION{Vector<double>{0,0,0}}, VELOCITY{Vector<double>{0,0,0}}
	 {}	
	kkk::Atom::Atom (All_objects * all_obj, class Molecule * f, Vector<double> pos, Vector<double> vel, unsigned int el_indx) : 
		 FATHER{f}, POSITION{pos}, VELOCITY{vel}, element_index{el_indx}, output{all_obj->output}, error{all_obj->error}, all_objects{all_obj}  {}
	
 	kkk::Atom::~Atom () {}

	kkk::Atom::Atom (const Atom & a) : 
  has_father{false}, FATHER{0}, POSITION{a.POSITION}, VELOCITY{a.VELOCITY},
	element_index{a.element_index}, output{a.output}, error{a.error}, all_objects{a.all_objects} {}
	
// =============================


bool kkk::Atom::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Atom read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL_3D_VECTOR(POSITION,"ATOM READ: ","")
		else ASSIGN_REAL_3D_VECTOR(VELOCITY,"ATOM READ: ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ATOM: read: Unknown variable or command");
	}
	
	return in_file;;
}

// =============================

double kkk::Atom::get_radius () const {
  return all_objects->elements[element_index].get_radius();
}

//====================================


Vector<double> kkk::Atom::pos_tot () const {
	if (has_father) return POSITION + FATHER->pos_tot();
 	else return POSITION;	 
}

Vector<double> kkk::Atom::vel_tot () const {
	if (has_father) return VELOCITY + FATHER->vel_tot();
	else return VELOCITY;		
}


