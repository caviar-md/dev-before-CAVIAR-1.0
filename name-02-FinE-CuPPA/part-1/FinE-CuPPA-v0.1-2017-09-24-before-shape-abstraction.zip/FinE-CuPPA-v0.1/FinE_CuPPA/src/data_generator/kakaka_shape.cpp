#include "kakaka_preprocessors.h"
#include "kakaka_shape.h"
#include "kakaka_utility_all_objects.h"
#include "parser.h"
#include "lexer.h"


namespace kkk {
	namespace shape {
	
// ========================
// ========================
// ========================
//			Shape
// ========================
// ========================
// ========================

		Shape::Shape () {}
		Shape::Shape (All_objects * all_obj) :
				output{all_obj->output}, error{all_obj->error}, all_objects{all_obj} {}
		Shape::~Shape () {}
		
		/*
		bool Shape::read(Parser * parser) {return true;}
		bool Shape::is_inside (const Vector<double> &v) {return true;}
		bool Shape::is_outside (const Vector<double> &v) {return true;}
		bool Shape::is_inside (const Vector<double> &v, const double r) {return true;}
		bool Shape::is_outside (const Vector<double> &v, const double r) {return true;}	
		bool Shape::is_valid () {return true;}
*/

// ========================
// ========================
// ========================


// ========================
// ========================
// ========================

	}
}

