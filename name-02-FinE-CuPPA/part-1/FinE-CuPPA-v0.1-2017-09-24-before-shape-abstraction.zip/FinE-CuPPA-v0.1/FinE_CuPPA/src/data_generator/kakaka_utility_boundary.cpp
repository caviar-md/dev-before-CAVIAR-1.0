#include "kakaka_utility_all_objects.h"
#include "kakaka_utility_boundary.h"
#include "kakaka_preprocessors.h"

/*
#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/
namespace kkk {

//====================================
//====================================
//====================================

  Boundary::Boundary () {}
  Boundary::Boundary (All_objects * all_obj) :
   parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, all_objects{all_obj}
  { }
    
  Boundary::~Boundary () {}	
  
  bool Boundary::read (Parser* parser) {

		output->info("Data_reader_Kakaka: BOUNDARY Read: ");
		bool in_file = true;

#define AND_OR_INSIDE_OUTSIDE \
if (shapes.size() == 0) {\
  if (t=="INSIDE") inside_check = true;\
  else if (t=="OUTSIDE") inside_check = false;\
  else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected 'INSIDE' or 'OUTSIDE': ");\
} else if (t=="INSIDE" || t=="OUTSIDE")\
    error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected 'AND_INSIDE','AND_OUTSIDE', 'OR_INSIDE','OR_OUTSIDE': ");\
std::map<std::string,kkk::Dictionary>::iterator it_1;\
std::string name_1;\
GET_A_STRING(name_1,"BOUNDARY Read: "," expected an BOUNDARY or SHAPE NAME: ")\
CHECK_NAME_EXISTANCE(name_1, it_1, "BOUNDARY Read: ","")\
if (it_1->second.type == kkk::gdst("BOUNDARY"))\
	shapes.push_back(&all_objects->boundaries[it_1->second.index]);\
else if (it_1->second.type == kkk::gdst("SHAPE"))\
	shapes.push_back(all_objects->shapes[it_1->second.index]);\
else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: expected an BOUNDARY or SHAPE NAME: ");
		  	  
		while(true) {
		
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="INSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0);  //inside_check = true	 	
		  } else if (t=="OUTSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0); //inside_check = flase	 	 	 	
		  } else if (t=="AND_INSIDE") {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (1);  	 	
		  } else if (t=="AND_OUTSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-1);
		  }	else if (t=="OR_INSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (2);
		  }	else if (t=="OR_OUTSIDE") { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-2);
		  }		  	  	  
		  else error->all(FILE_LINE_FUNC,"Data_reader_Kakaka: BOUNDARY Read: Unknown variable or command ");
	  }
		return in_file;;
#undef AND_OR_INSIDE_OUTSIDE
	}
  
  bool Boundary::is_inside (const Vector<double> &v) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v);
    else tmp = !shapes[0]->is_inside(v);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  bool Boundary::is_inside (const Vector<double> &v, const double r) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v, r);
    else tmp = !shapes[0]->is_inside(v, r);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v, r) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v, r) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v, r) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v, r) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  
  bool Boundary::is_outside (const Vector<double> &v) {
    return !is_inside(v);
  }
  
    bool Boundary::is_outside (const Vector<double> &v, const double r) {
    return !is_inside(v, r);
  }
	//bool Boundary::is_all (const Vector<double> &v) {
	//  return is_inside (v);
	/*
	  if (inside_check)
	    return is_inside (v);
	  else
	    return is_outside (v);*/
	//}
	



}


