#include "kakaka_utility_element.h"
#include "kakaka_utility_all_objects.h"
#include "kakaka_preprocessors.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"

*/

//====================================
//====================================
//====================================

	kkk::Element::Element () {} 
	kkk::Element::Element (All_objects * all_obj, double m, double r, double ch, unsigned int i) :
	 element_index{i}, MASS{m}, RADIUS{r}, CHARGE{ch}, output{all_obj->output}, error{all_obj->error}, all_objects{all_obj} {} 

	kkk::Element::~Element () {}
	
// =============================


bool kkk::Element::read ( Parser * parser) {
	output->info("Data_reader_Kakaka: Element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(RADIUS,"ELEMENT READ: ","")
		else ASSIGN_REAL(MASS,"ELEMENT READ: ","")
		else ASSIGN_REAL(CHARGE,"ELEMENT READ","")
		else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: ELEMENT: Unknown variable or command");		
	}
	
	return in_file;;
}

