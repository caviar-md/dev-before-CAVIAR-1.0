#include "kakaka_utility_distribution.h"
#include "kakaka_utility_all_objects.h"
#include "kakaka_preprocessors.h"
//#include "kakaka_utility_boundary.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/

namespace kkk {

//====================================
//====================================
//====================================

  Distribution::Distribution () {}	
  
  Distribution::Distribution (All_objects * all_obj) :
   boundary_check{false}, a_object_check{false}, m_object_check{false}, container_check{false},
    parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, all_objects{all_obj}
  { }
  
  Distribution::~Distribution () {}	
  
  bool Distribution::read (Parser* parser) {
		output->info("Data_reader_Kakaka: DISTRIBUTION Read: ");
		bool in_file = true;
		

		
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="BOUNDARY") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an BOUNDARY NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type != kkk::gdst("BOUNDARY"))
          error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined BOUNDARY NAME. ");
        boundary = &all_objects->boundaries[it_1->second.index];
        boundary_check = true;
		  }	
		  else if (t=="OBJECT") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an MOLECULE or ATOM NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("ATOM")) {
          a_object_check = true;        
          a_object = &all_objects->atoms[it_1->second.index];          
        } else if (it_1->second.type == kkk::gdst("MOLECULE")) {
          m_object_check = true;
          m_object = &all_objects->molecules[it_1->second.index];                            
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined MOLECULE or ATOM NAME. ");

		  }			  
		  else if (t=="CONTAINER") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTION Read: "," expected an MOLECULE NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("MOLECULE")) {
          container = &all_objects->molecules[it_1->second.index];        
          container_check = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: undefined MOLECULE NAME. ");
		  }			  		  
		  else if (t=="DISTRIBUTE_GRID_3D") {distribute_grid_3D(); break;}		  
		  else if (t=="DISTRIBUTE_RANDOM_3D") {distribute_random_3D(); break;}		  		  
		  else error->all(FILE_LINE_FUNC,"DISTRIBUTION Read: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	bool Distribution::distribute_grid_3D() {
	  output->info("Data_reader_Kakaka: DISTRIBUTE_GRID_3D: ");
		bool in_file = true;

		kkk::Grid_1D   *pos_grid_X, *pos_grid_Y, *pos_grid_Z;
    kkk::Grid_1D pg; pos_grid_X = &pg; pos_grid_Y = &pg; pos_grid_Z = &pg; // JUST TO SHUT UP THE WARNING
    		
		bool pos_grid_check_X=false, pos_grid_check_Y=false, pos_grid_check_Z=false;

		
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="POSITION_X") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_GRID_3D: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_X = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_X = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined  GRID_1D NAME. ");
		  } else if (t=="POSITION_Y") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_Y = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_Y = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined  GRID_1D NAME. ");
		  }	 else  if (t=="POSITION_Z") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_GRID_3D: "," expected a GRID_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
        if (it_1->second.type == kkk::gdst("GRID_1D")) {
          pos_grid_Z = &all_objects->grid_1ds[it_1->second.index];
          pos_grid_check_Z = true;        
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: undefined GRID_1D NAME. ");
		  } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_GRID_3D: Unknown variable or command ");
		}
		
		if (!(pos_grid_check_X && pos_grid_check_Y && pos_grid_check_Z))
		  error->all(FILE_LINE_FUNC," three GRID_1D is needed for distribution ");
		  
		std::vector<double> r_vector; // radius of atoms
		std::vector<Vector<double>> p_vector; // total positions of atoms
	  if (a_object_check) {
	    r_vector.push_back (a_object->get_radius());
	    p_vector.push_back (a_object->pos_tot());
	  }
	  if (m_object_check) {
	    m_object->give_position_and_radius (p_vector, r_vector);
	  }

	    
		for (unsigned int i = 0; i < pos_grid_X->no_points(); ++i) {
		  double x = pos_grid_X->give_point(i);
		  for (unsigned int j = 0; j < pos_grid_Y->no_points(); ++j) {
		    double y = pos_grid_Y->give_point(j);		  
		    for (unsigned int k = 0; k < pos_grid_Z->no_points(); ++k) {	
		      double z = pos_grid_Z->give_point(k);		      
		      const Vector<double> p {x,y,z}, v{0,0,0};

		      /* // simple method - just center is inside condition
		      if (boundary->is_inside(p)) {
            if (a_object_check)
              container->add_atom (*a_object, p, v);
            if (m_object_check)
              container->add_molecule (*m_object, p, v);
          }*/
          
          // 
          bool inside_flag = true;
          for (unsigned int m = 0; m<r_vector.size(); ++m)
            if (!boundary->is_inside(p + p_vector[m], r_vector[m])) {
              inside_flag = false;
              continue;
            }
            
		      if (inside_flag) {
            if (a_object_check)
              container->add_atom (*a_object, p, v);
            if (m_object_check)
              container->add_molecule (*m_object, p, v);              
          }
          
		    }
		  }
		}
		
		container -> correct_heritage ();
		
		return in_file;
	}
	



	
	bool Distribution::distribute_random_3D() {
	  output->info("Data_reader_Kakaka: DISTRIBUTE_RANDOM_3D: ");
	 
		bool in_file = true;
 
		
		bool pos_rand_check_X=false, pos_rand_check_Y=false, pos_rand_check_Z=false;		
		/*
		kkk::Random_1D *pos_rand_X, *pos_rand_Y, *pos_rand_Z;				
		while(true){
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (t=="POSITION_X") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_X = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_X = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
		  } else if (t=="POSITION_Y") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_Y = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_Y = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D NAME. ");
		  }	 else  if (t=="POSITION_Z") {
		    std::map<std::string,kkk::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == kkk::gdst("RANDOM_1D")) {
          pos_rand_Z = &all_objects->random_1ds[it_1->second.index];
          pos_rand_check_Z = true;
        } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
		  } else error->all(FILE_LINE_FUNC,"DISTRIBUTE_RANDOM_3D: Unknown variable or command ");
		}
		*/
		
		if (!(pos_rand_check_X && pos_rand_check_Y && pos_rand_check_Z))
		  error->all(FILE_LINE_FUNC," three GRID_1D is needed for distribution ");
		

		  
		return in_file;
	}
	



}


