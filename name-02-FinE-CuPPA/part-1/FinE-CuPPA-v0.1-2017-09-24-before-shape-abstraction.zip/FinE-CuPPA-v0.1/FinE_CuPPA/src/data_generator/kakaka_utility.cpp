#include "kakaka_utility.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"
#include "kakaka_preprocessors.h"

#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/
//====================================
//====================================
//====================================


int kkk::gdst (const std::string & t) { //get_dictionary_second_type 
	std::map<std::string,int>::const_iterator it;
	it = kkk::dictionary_second_type.find(t);
	if (it == kkk::dictionary_second_type.end()) return 0;
	else return it->second;
}



