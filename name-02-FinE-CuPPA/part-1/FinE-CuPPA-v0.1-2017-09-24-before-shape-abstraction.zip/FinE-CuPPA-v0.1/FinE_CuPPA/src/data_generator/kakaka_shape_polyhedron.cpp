#include "kakaka_shape_polyhedron.h"
#include "kakaka_utility_all_objects.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
#include "kakaka_preprocessors.h"
#include "utility.h"

namespace kkk {

namespace shape {


Polyhedron::Polyhedron (All_objects * all_obj, MD * md) : md{md},
	output{all_obj->output}, error{all_obj->error}, all_objects{all_obj},
  polyhedron_handler {new Namespace_Geometry::Polyhedron_Handler{md}}
  {}

Polyhedron::~Polyhedron () { 
	delete polyhedron_handler;	
}

bool Polyhedron::read(Parser * parser) {
	output->info("Data_reader_Kakaka: Polyhedron read:");
	return polyhedron_handler -> read (parser);
}

bool Polyhedron::is_inside(const Vector<double> &v0) {
  return polyhedron_handler -> is_inside (v0);   
}

bool Polyhedron::is_outside(const Vector<double> &v) {
  return !is_inside (v);
}

bool Polyhedron::is_inside(const Vector<double> &v, const double r) {
  return polyhedron_handler -> is_inside (v, r); 
}

bool Polyhedron::is_outside(const Vector<double> &v, const double r) {
  return !is_inside (v,r);
}





} //namespace
} //namespace


