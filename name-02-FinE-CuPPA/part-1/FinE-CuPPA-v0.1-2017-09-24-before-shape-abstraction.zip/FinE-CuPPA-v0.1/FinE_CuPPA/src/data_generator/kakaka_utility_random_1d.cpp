#include "kakaka_utility_random_1d.h"
#include "kakaka_preprocessors.h"
#include "kakaka_utility_all_objects.h"
/*
#include "data_generator_kakaka.h"
#include "kakaka_utility.h"


#include <fstream>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"
#include "geometry.h"
*/

namespace kkk {

//====================================
//====================================
//====================================

	Random_1D::Random_1D () {}
  Random_1D::Random_1D (All_objects * all_obj, std::string type, double min, double max, double stddev, double mean, int seed) : 
   MIN{min}, MAX{max}, STDDEV{stddev}, MEAN{mean}, TYPE{type}, SEED{seed}, generated{false},
   parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, all_objects{all_obj}
  {
    type_int = 0;
  }
  
	Random_1D::~Random_1D () {
//			delete ran_x,ran_y,ran_z;
//			delete n_dis_x,n_dis_y,n_dis_z;
//			delete u_dis_x,u_dis_y,u_dis_z;
		}
	bool Random_1D::read(Parser* parser) {
		output->info("Data_reader_Kakaka: Random Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="GENERATE") {generate(); break;}
      else ASSIGN_STRING(TYPE,"Random_1D creation: ","")
		  else ASSIGN_REAL(MIN,"Random_1D creation: ","")
		  else ASSIGN_REAL(MAX,"Random_1D creation: ","")
		  else ASSIGN_REAL(STDDEV,"Random_1D creation: ","")
		  else ASSIGN_REAL(MEAN,"Random_1D creation: ","")
		  else ASSIGN_INT(SEED,"Random_1D creation: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D creation: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Random_1D::generate () {
		output->info("Data_reader_Kakaka: Random Generate: ");	
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Random_1D: cannot be generated twice. ");
	  generated = true;
	  ran_gen = new std::mt19937 (SEED);
	  if (TYPE=="UNIFORM") {
	    type_int = 1;
    	u_dist = new std::uniform_real_distribution<> (MIN, MAX) ;
    } else if (TYPE=="NORMAL") {
      type_int = 2;
    	n_dist = new std::normal_distribution<> (MEAN, STDDEV);
    } else error->all (FILE_LINE_FUNC, "RANDOM_1D generate: Expected NORMAL or UNIFORM for the type. ");
	}
	
}
