#ifndef FE_DEALII_POISSON_H
#define FE_DEALII_POISSON_H

#include "fine_cuppa_config.h"

#include "finite_element.h"

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_bicgstab.h>
#include <deal.II/lac/precondition.h>

#include <deal.II/numerics/data_out.h>
#include <fstream>
#include <iostream>
#include <cmath>


#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/vector_tools.h>

#include <deal.II/grid/manifold_lib.h>

#include <deal.II/opencascade/boundary_lib.h>
#include <deal.II/opencascade/utilities.h>



#include <deal.II/base/logstream.h>

#include <deal.II/grid/grid_refinement.h>
#include <deal.II/numerics/error_estimator.h>



FINE_CUPPA_NAMESPACE_OPEN

namespace NS_finite_element {

//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================
class All_charges {
public:
All_charges () {};



  void set_k_coef (double k) {k_coef = k;}
  double get_k_coef () const {return k_coef;}
  
  void set_Radius (double r) {Rad = r;}
  double get_Radius () const {return Rad;}  
  
  void set_phi_bc (double phi) {phi_bc = phi;}
  double get_phi_bc () const {return phi_bc;}
  
  unsigned int no_charges () const { return charge_of_charge.size();}  
  
  dealii::Point<3> get_charge_position (unsigned int i) const { return charge_position[i]; }
  double get_charge_of_charge (unsigned int i) const {return charge_of_charge[i];}
  
  void calculate_image_charges();
  void clear_image_charges ();
  
  void add_charge (const double x,const double y,const double z,const double c);
  void add_charge (const dealii::Point<3> p,const double c);
  
  void set_charge_position (const unsigned int,const dealii::Point<3> &);

  double potential_of_charge (const dealii::Point<3> &, unsigned int i);
  double potential_of_image (const dealii::Point<3> &, unsigned int i);
  
  double total_potential (unsigned int i);          // tot. potential at a point due to charge and image
  double total_potential (const dealii::Point<3> &);// tot. potential at a point due to charge and image
  
  double total_potential_of_charges (const dealii::Point<3> &);// tot. potential at a point  due to charge only
  double total_potential_of_charges (unsigned int i);          // tot. potential at a point  due to charge only
  

  dealii::Point<3> field_of_charge (const dealii::Point<3> &, unsigned int i);
  dealii::Point<3> field_of_image (const dealii::Point<3> &, unsigned int i);
  
  dealii::Point<3> total_field (unsigned int i);
  dealii::Point<3> total_field (const dealii::Point<3> &); // tot. field at a point due to real charges and images
  
  dealii::Point<3> total_field_of_charges (const dealii::Point<3> &); // tot. field at a point due to real charges
  dealii::Point<3> total_field_of_charges (unsigned int i); // tot. field on a charge from others



  dealii::Point<3> force_tot (unsigned int i); // tot. force on a charge from others due to other real charges and images


private:
  std::vector<dealii::Point<3>> charge_position, image_position;
  std::vector<double> charge_of_charge, charge_of_image;

  double k_coef, Rad;
  double phi_bc;
  
}; 

//==================================================
//==================================================
//==================================================


//==================================================
//==================================================
//==================================================

using namespace dealii;

template <int dim>
class FE_dealii_poisson : public Finite_element<dim>
{
public:
  FE_dealii_poisson (class MD *);
  ~FE_dealii_poisson ();

  void calculate_acceleration ();  
  bool read(Parser *);
  	  
private:

  void run ();
  void read_domain();
  void make_grid ();
  
  void setup_system();
  void assemble_system();
  void solve ();

  void output_results (const int) const;

  void refine_grid_adaptive ();
  void refine_boundary (const unsigned int);

  
  
  Triangulation<dim>   tria_reserve;
  
  void set_spherical_manifold();
  
  int tot_no_matched, tot_no_corrected;

  void rotate_and_add(const double angle, const int axis, const double merge_toll);
  void rotate_and_add_reserve(const double angle, const int axis, const double merge_toll);
  void match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll);
                                               

  
  Triangulation<dim> triangulation;
  FE_Q<dim> fe;
  DoFHandler<dim> dof_handler;

  SparsityPattern sparsity_pattern;
  SparseMatrix<double> system_matrix;
  
  ConstraintMatrix     constraints;
  
  dealii::Vector<double> solution;
  dealii::Vector<double> system_rhs;
  
  class All_charges * all_charges;
  class Atom_data * atom_data;
  class Output * output;
	class Error * error;
};


//==================================================
//==================================================
//==================================================


template <int dim>
class RightHandSide : public Function<dim>
{
public:
  RightHandSide () : Function<dim>() {}

  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;
};


//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================


template <int dim>
class BoundaryValues : public Function<dim>
{
public:
  BoundaryValues () : Function<dim>() {}

  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;                    
};

} //NS_finite_element

FINE_CUPPA_NAMESPACE_CLOSE

#endif
