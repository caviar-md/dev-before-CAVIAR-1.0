#ifndef FINE_CUPPA_CONFIG_H
#define FINE_CUPPA_CONFIG_H

#define FINE_CUPPA_NAMESPACE_OPEN namespace fine_cuppa {
#define FINE_CUPPA_NAMESPACE_CLOSE }

#endif
