#ifndef INTEGRATE_H
#define INTEGRATE_H

#include "fine_cuppa_config.h"

#include "pointers.h"

FINE_CUPPA_NAMESPACE_OPEN

class Integrate : protected Pointers {
public:
  Integrate (class MD *);
 	 
  bool run (unsigned int, double);
private:
	class Output *output;

  void step ();
  void setup ();
  void cleanup ();
  void velocity_verlet ();
	bool boundary_condition ();
	Real_t dt;
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
