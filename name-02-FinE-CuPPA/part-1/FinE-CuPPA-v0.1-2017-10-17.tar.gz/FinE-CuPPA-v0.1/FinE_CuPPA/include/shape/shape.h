#ifndef SHAPE_H
#define SHAPE_H

#include "fine_cuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_shape {


inline void normalize (Vector<Real_t> & v) {
	v /= std::sqrt(v*v);
}
// ========================
// ========================
// ========================

// shapes to be added: plane, 3d half space(plane), box, rectangle, triangle, vtk, stl, geometry maniforld, torus, tube

// ========================
// ========================
// ========================

class Shape : protected Pointers {
	public:
		Shape (class MD *);
		virtual ~Shape();

		virtual bool read(Parser *)=0;
	
		virtual bool is_inside (const Vector<double> &)=0;
		virtual bool is_outside (const Vector<double> &)=0;
		virtual bool is_inside (const Vector<double> &, const double rad)=0;
		virtual bool is_outside (const Vector<double> &, const double rad)=0;
    virtual bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector)=0;

		Output * output;
		Error * error;
};

// ========================
// ========================
// ========================

} // namespace shape finished

FINE_CUPPA_NAMESPACE_CLOSE

#endif
 
