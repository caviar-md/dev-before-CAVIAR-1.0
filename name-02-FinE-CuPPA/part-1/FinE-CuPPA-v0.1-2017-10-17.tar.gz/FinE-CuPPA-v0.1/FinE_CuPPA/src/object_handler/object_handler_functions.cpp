#include "object_handler_all.h"

#include "fine_cuppa_config.h"

#include "object_container.h"

#include <fstream>
#include <boost/algorithm/string.hpp>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"

FINE_CUPPA_NAMESPACE_OPEN


bool Object_handler::add_atom (Parser *parser) {

	output->info("add_atom");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_atom: "," expected an atom or molecule NAME: ")

	std::map<std::string,NS_object_handler::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_atom: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_atom: "," Expected middle command: ")

	if (boost::iequals(middle_command_1,"to_molecule")) {
		GET_A_STRING(name_2,"ADD_atom: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_atom: ","")
	}

  if (it_1->second.type != NS_object_handler::gdst("atom"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD atom: expected an atom NAME: ");

  if (it_2->second.type != NS_object_handler::gdst("molecule"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD atom: expected an molecule NAME: ");
      
	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;		
		if (boost::iequals(t,"at_position")) {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD atom: ","")\
		} else if (boost::iequals(t,"at_velocity")) {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD atom: ","")\
		}
	}

	NS_object_utility::Atom a_new = object_container -> atom[it_1->second.index];
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	object_container -> molecule[it_2->second.index].add_atom (a_new);
	return in_file;
}

// ========================
// ========================
// ========================

bool Object_handler::add_molecule (Parser *parser) {
	output->info("add_molecule");
	std::string name_1, name_2;
	GET_A_STRING(name_1,"ADD_molecule: "," expected an atom or molecule NAME: ")

	std::map<std::string,NS_object_handler::Dictionary>::iterator it_1, it_2;
 	CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_atom: ","")

	std::string middle_command_1;
	GET_A_STRING(middle_command_1,"ADD_molecule: "," Expected middle command: ")

	if (boost::iequals(middle_command_1,"to_molecule")) {
		GET_A_STRING(name_2,"ADD_atom: "," expected an atom or molecule NAME: ")
 		CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_atom: ","")
	}

  if (it_1->second.type != NS_object_handler::gdst("molecule"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD molecule: expected an molecule NAME: ");

  if (it_2->second.type != NS_object_handler::gdst("molecule"))
    error->all(FILE_LINE_FUNC,"Object_handler: ADD MOLECUE: expected an molecule NAME: ");


	Vector<double> pos_ = {0,0,0};
	Vector<double> vel_ = {0,0,0};
	bool position_called = false;
	bool velocity_called = false;
	bool in_file = true;
	while (true) {
		GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;
		if (boost::iequals(t,"at_position")) {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD molecule: ","")\
		} else if (boost::iequals(t,"at_velocity")) {
			position_called = true;
			GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD molecule: ","")\
		}
	}

	NS_object_utility::Molecule a_new = object_container -> molecule[it_1->second.index];	
	if (position_called) {
		a_new.pos() = pos_;
	}
	if (velocity_called) {
		a_new.vel() = vel_;
	}
	object_container -> molecule[it_2->second.index].add_molecule(a_new);
	return in_file;
}


// ========================
// ========================
// ========================


bool Object_handler::output_xyz (Parser *parser) {
	output->info("output_xyz: ");
 
  std::ofstream out_file;
  out_file.open("o_kakaka.xyz");

	bool in_file = true;
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;  	 
 		if (boost::iequals(t,"molecule")) {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;
		  std::string name_1;
      GET_A_STRING(name_1,"OUTPUT_XYZ: "," expected an molecule or atom NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
		  if (it_1->second.type == NS_object_handler::gdst("atom")) {
		    object_container -> atom[it_1->second.index].output_xyz (out_file);
		  }	else if (it_1->second.type == NS_object_handler::gdst("molecule")) {
		    object_container -> molecule[it_1->second.index].output_xyz (out_file);
		  }	else error->all(FILE_LINE_FUNC,"Object_handler: OUTPUT_XYZ: expected an molecule or atom NAME. ");
		} else  error->all(FILE_LINE_FUNC,"OUTPUT_XYZ: Unknown variable or command ");
  
  }
  
  out_file.close ();

  
	return in_file;

}

// ========================
// ========================
// ========================

bool Object_handler::add_to_simulation (Parser *parser) {
	output->info("add_to_simulation: ");

	bool in_file = true;
  while(true) {
  	GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (boost::iequals(t,"elements")) {
      add_elements_to_simulation ();
    } else if (boost::iequals(t,"atom") || boost::iequals(t,"molecule")) {
		  std::map<std::string,NS_object_handler::Dictionary>::iterator it_1;std::string name_1;
      GET_A_STRING(name_1,"ADD_TO_SIMULATION: "," expected an molecule or atom NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "ADD_TO_SIMULATION: ","")
		  if (it_1->second.type == NS_object_handler::gdst("atom")) {
		  
		    auto & a = object_container -> atom[it_1->second.index];
		    add_atom_to_simulation (a);
	    
		    
		  }	else if (it_1->second.type == NS_object_handler::gdst("molecule")) {
		  
		    auto & a = object_container -> molecule[it_1->second.index];
		    add_molecule_to_simulation (a);
	    
		    
		  }	else error->all(FILE_LINE_FUNC,"expected an molecule or atom NAME. ");
		} else  error->all(FILE_LINE_FUNC,"Unknown variable or command ");
  
  }
  
 
	return in_file;

}

// ========================
// ========================
// ========================

bool Object_handler::add_atom_to_simulation (NS_object_utility::Atom &a) {
  //auto atom_data = md->atom_data;
  const auto id = atom_data -> get_global_id();
  const auto element_index = a.get_element_index ();
  const auto pos = a.pos_tot ();
  const auto vel = a.vel_tot ();
  
	atom_data->add_atom (id, element_index, pos, vel);	  
	
	return true;//WARNING
}

// ========================
// ========================
// ========================

bool Object_handler::add_molecule_to_simulation (NS_object_utility::Molecule &m) {
  std::vector<int> element_index;
  std::vector<Vector<double>> pos, vel;
  m.extract_all_e_pos_vel (element_index, pos, vel);
  for (unsigned int i = 0; i < element_index.size(); ++i) {
    const auto id = atom_data -> get_global_id();
	  atom_data->add_atom (id, element_index[i], pos[i], vel[i]);	     
  }
  return true;//WARNING
}
// ========================
// ========================
// ========================

bool Object_handler::add_elements_to_simulation () {
  for (auto e : object_container -> element) {
    atom_data->add_masses(e.get_element_index(), e.get_mass());
    atom_data->add_charges(e.get_element_index(), e.get_charge());
//  atom_data->add_masses(e.get_element_index(), e.get_radius());    
  }
	atom_data->set_num_atom_types (object_container -> element.size());  
  return true;//WARNING  
}
// ========================
// ========================
// ========================



bool Object_handler::set_simulation_box (Parser *parser) {
	output->info("set_simulation_box: ");
	
	Real_t xmin=0, xmax=0, ymin=0, ymax=0, zmin=0, zmax=0;
	
	bool in_file = true;
	
	while(true) {
		GET_A_TOKEN_FOR_CREATION
		const auto t = token.string_value;
    if (boost::iequals(t,"xmin") || boost::iequals(t,"x_min")) {
      GET_OR_CHOOSE_A_REAL(xmin,"","")
      domain->x_lower_global = xmin;      
		}else if (boost::iequals(t,"xmax") || boost::iequals(t,"x_max")) {
      GET_OR_CHOOSE_A_REAL(xmax,"","")
      domain->x_upper_global = xmax;      
		}else if (boost::iequals(t,"ymin") || boost::iequals(t,"y_min")) {
      GET_OR_CHOOSE_A_REAL(ymin,"","")
      domain->y_lower_global = ymin;      
		}else if (boost::iequals(t,"ymax") || boost::iequals(t,"y_max")) {
      GET_OR_CHOOSE_A_REAL(ymax,"","")
      domain->y_upper_global = ymax;      
		}else if (boost::iequals(t,"zmin") || boost::iequals(t,"z_min")) {
      GET_OR_CHOOSE_A_REAL(zmin,"","")
      domain->z_lower_global = zmin;      
		}else if (boost::iequals(t,"zmax") || boost::iequals(t,"z_max")) {
      GET_OR_CHOOSE_A_REAL(zmax,"","")
      domain->z_upper_global = zmax;      
		}	else if (boost::iequals(t,"generate")) {
	    comm->calculate_procs_grid ();
	    domain->calculate_local_domain ();  
		} else error->all(FILE_LINE_FUNC,"Unknown variable or command ");
	}
	
 
	return in_file;

}

FINE_CUPPA_NAMESPACE_CLOSE

