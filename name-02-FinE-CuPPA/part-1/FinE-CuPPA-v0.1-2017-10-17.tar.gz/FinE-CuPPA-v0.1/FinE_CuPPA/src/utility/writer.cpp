#include "writer.h"

#include "fine_cuppa_config.h"

FINE_CUPPA_NAMESPACE_OPEN

Writer::Writer (MD *md) : Pointers{md} {}

FINE_CUPPA_NAMESPACE_CLOSE
