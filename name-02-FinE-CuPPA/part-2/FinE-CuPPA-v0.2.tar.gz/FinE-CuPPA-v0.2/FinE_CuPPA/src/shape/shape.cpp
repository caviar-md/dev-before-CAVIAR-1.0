#include "shape.h"

#include "fine_cuppa_config.h"

#include "object_handler.h"
#include "object_handler_preprocessors.h"
#include "object_handler_dictionary.h"

#include "parser.h"
#include "lexer.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_shape {


  Shape::Shape (MD *md) : Pointers{md},
		output{md->output}, error{md->error} {}
	Shape::~Shape () {}
		

}

FINE_CUPPA_NAMESPACE_CLOSE

