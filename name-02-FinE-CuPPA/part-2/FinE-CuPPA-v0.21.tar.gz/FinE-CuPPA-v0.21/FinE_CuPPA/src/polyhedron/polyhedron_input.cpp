#include "polyhedron_input.h"

#include "fine_cuppa_config.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
//#include "kakaka_preprocessors.h"
#include "utility.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_geometry {



Polyhedron_Input::Polyhedron_Input (MD *md) : Pointers{md}, 
				output{md->output}, error{md->error} {}

Polyhedron_Input::~Polyhedron_Input () { }


void Polyhedron_Input::read_vtk (NS_geometry::Polyhedron & p_object, const std::string &file_name) {
  class Format_Vtk_Reader fvr (md);
  fvr.read_polyhedron (p_object, file_name);
}



} //namespace

FINE_CUPPA_NAMESPACE_CLOSE

