#ifdef USE_DEALII

#include "fe_dealii_poisson_finite_pore.h"

#include "fine_cuppa_config.h"

#include <boost/algorithm/string.hpp>

#include "parser.h"
#include "object_handler_all.h"
#include "object_container.h"
#include "atom_data.h"
#include "error.h"
#include "output.h"

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_bicgstab.h>
#include <deal.II/lac/precondition.h>

#include <deal.II/numerics/data_out.h>
#include <fstream>
#include <iostream>
#include <cmath>

#include <deal.II/lac/vector_memory.h>
#include <deal.II/lac/filtered_matrix.h>

#include <deal.II/numerics/data_out.h>


#include <deal.II/grid/manifold_lib.h>

#include <deal.II/opencascade/boundary_lib.h>
#include <deal.II/opencascade/utilities.h>



#include <deal.II/base/logstream.h>

#include <deal.II/grid/grid_refinement.h>
#include <deal.II/numerics/error_estimator.h>

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_finite_element {

//==================================================
//==================================================
//==================================================



//==================================================
//==================================================
//==================================================


template <int dim>
double RightHandSide1<dim>::value (const Point<dim> &p,
                                  const unsigned int ) const
{

  double return_value = 0.0*p(0);

  return return_value;
}



//==================================================
//==================================================
//==================================================

template <int dim>
double BoundaryValues1<dim>::potential_of_charges (const dealii::Point<3> &p) const
{
  const auto &pos = atom_data -> owned.position;
  double total_potential = 0;
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto charge_i = atom_data -> owned.charge [ type_i ];
	  const dealii::Point<3> c_pos = {pos[i].x, pos[i].y, pos[i].z};
	  double c_dist = p.distance(c_pos);
	  total_potential += charge_i / c_dist;
	} 	
	total_potential *= k_electrostatic;
	return total_potential;
}
//--------------------------------------------------

template <int dim>
double BoundaryValues1<dim>::value (const Point<dim> &p,
                                   const unsigned int ) const
{
  return total_potential - potential_of_charges (p);    
}



//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson_finite_pore<dim>::FE_dealii_poisson_finite_pore(MD * md) : NS_finite_element::Finite_element<dim>{md},
  fe (2),
  dof_handler (triangulation),
  atom_data{md->atom_data}, output{md->output}, error{md->error}, initialized{false}, k_electrostatic{1.0},
  time_step_jump{1}, time_step_count{0}
{}

//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson_finite_pore<dim>::~FE_dealii_poisson_finite_pore() {}
//==================================================
//==================================================
//==================================================

template <int dim>
bool FE_dealii_poisson_finite_pore<dim>::read (Parser *parser) {
	output->info("FE_dealii_poisson_finite_pore: read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
    if (boost::iequals(t,"make_grid")) {
      make_grid();
		} else if (boost::iequals(t,"refine_global")) {		
      int n = parser->get_literal_int();//0;      
      refine_sequence_type.push_back (0);
      refine_sequence_value.push_back (n);
		} else if (boost::iequals(t,"refine_boundary")) {
      int n = parser->get_literal_int();    
      refine_sequence_type.push_back (1);
      refine_sequence_value.push_back (n);
		} else if (boost::iequals(t,"boundary_id_value")) {
      int id = parser->get_literal_int();
      double value = parser->get_literal_real();
      boundary_id_value.push_back(std::make_pair(id, value));
		} else if (boost::iequals(t,"k_electrostatic")) {
      k_electrostatic = parser->get_literal_real();
		} else if (boost::iequals(t,"add_unv_mesh")) {
		  auto token = parser->get_val_token();
		  auto file_name = token.string_value;
      unv_mesh_filename.push_back(file_name);
		} else if (boost::iequals(t,"read_unv_mesh")) {
  		read_domain();
		} else if (boost::iequals(t,"time_step_jump")) {
      time_step_jump = parser->get_literal_int();    
		}
		
		else error->all (FILE_LINE_FUNC, "Unknown variable or command");
	}
	
	return in_file;
  return true; // WARNING
}

//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson_finite_pore<dim>::rotate_and_add_reserve(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (tria_reserve);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }

//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson_finite_pore<dim>::rotate_and_add(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (triangulation);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }



//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll) {
    int no_matched_vertices = 0;
    int no_corrected_vertices = 0;
    
    for (typename Triangulation<3,3>::active_cell_iterator
         cell2=tria2.begin_active(); cell2!=tria2.end(); ++cell2) {
      for (unsigned int f2=0; f2<GeometryInfo<3>::faces_per_cell; ++f2) {
        if (cell2->face(f2)->at_boundary()) {
          
          for (typename Triangulation<3,3>::active_cell_iterator
               cell=triangulation.begin_active();cell!=triangulation.end();++cell) { 
            for (unsigned int f=0; f<GeometryInfo<3>::faces_per_cell; ++f) {
              if (cell->face(f)->at_boundary()) {
      
                for (unsigned int i=0; i<4; ++i)  { 
                  const Point<3> p1 = cell->face(f)->vertex(i);
                  bool point_match_found = false;                             
                  for (unsigned int j=0; j<4; ++j)  {           
                    const Point<3> p2 = cell2->face(f2)->vertex(j);
                    const double distance = p2.distance(p1);
                    
                    if (distance < merge_toll) {
                      ++no_matched_vertices;
                      point_match_found = true;
                      if (distance > 0) {
                        ++no_corrected_vertices;
                        cell2->face(f2)->vertex(j) =  cell->face(f)->vertex(i);
                      }
                      break;                        
                    }
                  }
                  if (!point_match_found) break;
                }
              }
            }
          }           
        }        
      }
    }
    
    tot_no_matched +=  no_matched_vertices;
    tot_no_corrected += no_corrected_vertices;
  }
  
//=========================================================================
//=========================================================================
//=========================================================================
//=========================================================================  
 
//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson_finite_pore<dim>::read_domain()
  {

  if (unv_mesh_filename.size()==0) {
    //error->all (FILE_LINE_FUNC, "unv_mesh_filename is empty. Add a file to the list.");
    std::cout << "unv_mesh_filename is empty. Add a file to the list." << std::endl;
    return;
  }
  tot_no_matched=0; tot_no_corrected=0;


  std::ifstream in;

  in.open(unv_mesh_filename[0].c_str());

  GridIn<3,3> gi;
  gi.attach_triangulation(triangulation);
  gi.read_unv(in);

  const double merge_toll = 1e-4;
  std::cout << "read_domain: " << unv_mesh_filename[0] << std::endl;
  unsigned int tot_mesh_num = unv_mesh_filename.size();
  for (unsigned int i = 1; i <  tot_mesh_num; ++i) { // BUG
    std::cout << "read_domain: " << unv_mesh_filename[i] << std::endl;

      Triangulation<3,3> tria2;
     
      std::ifstream in;
      
      in.open(unv_mesh_filename[i].c_str());
      
      GridIn<3,3> gi;

      gi.attach_triangulation(tria2);
      
      gi.read_unv(in);
      
      match_boundary_vertices (tria2, merge_toll);  
       
      GridGenerator::merge_triangulations (triangulation, tria2, triangulation);
    
  }
    

  std::cout << "merge_tollerance_of_vertices:       " << merge_toll << std::endl;
  std::cout << "total_no_matched_vertices:   " << tot_no_matched << std::endl;
  std::cout << "total_no_corrected_vertices: " << tot_no_corrected << std::endl;

  unv_mesh_filename.clear();


  }
  
  
//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::set_spherical_manifold() {
  const Point<3> center (0,0,0);
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (1, manifold_description);
  triangulation.set_all_manifold_ids(1);
}

//===================================================
//===================================================
//===================================================
  

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::make_grid ()
{

  const Point<3> center (0,0,0); 
  const double  radius = 1.0;
  GridGenerator::hyper_ball 	(triangulation, center,		radius);
 
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (0, manifold_description);

  std::cout << "   Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl
            << "   Total number of cells: "
            << triangulation.n_cells()
            << std::endl;
}

//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson_finite_pore<dim>::setup_system ()
{
  
    dof_handler.distribute_dofs (fe);
  
    std::cout << "   Number of degrees of freedom: "
              << dof_handler.n_dofs()
              << std::endl;
                      
    solution.reinit (dof_handler.n_dofs());

 
  
  system_rhs.reinit (dof_handler.n_dofs());


  constraints.clear ();
  DoFTools::make_hanging_node_constraints (dof_handler,
                                           constraints);

  constraints.close ();
  


  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  DoFTools::make_sparsity_pattern(dof_handler,
                                  dsp,
                                  constraints,
                                  /*keep_constrained_dofs = */ false);

  
  sparsity_pattern.copy_from(dsp);
  system_matrix.reinit (sparsity_pattern);
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::assemble_system ()
{
  const QGauss<dim> quadrature_formula(3);

  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values | update_gradients |
                           update_quadrature_points | update_JxW_values);

//  FEValues<dim> fe_values (fe, quadrature_formula,
//                           update_gradients |
//                           update_quadrature_points | update_JxW_values);

  //FEValues<dim> fe_values (fe, quadrature_formula,
 //                          update_gradients |  update_JxW_values);
                           
  const RightHandSide1<dim> right_hand_side; // copied
  
  const unsigned int dofs_per_cell = fe.dofs_per_cell;
  const unsigned int n_q_points = quadrature_formula.size();

  FullMatrix<double> cell_matrix (dofs_per_cell, dofs_per_cell);
  dealii::Vector<double> cell_rhs (dofs_per_cell);
  cell_rhs = 0;
      
  std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();
  for (; cell!=endc; ++cell)
    {
 
      fe_values.reinit (cell);
      cell_matrix = 0;

      for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        for (unsigned int i=0; i<dofs_per_cell; ++i)
          {
            for (unsigned int j=0; j<dofs_per_cell; ++j)
              cell_matrix(i,j) += (fe_values.shape_grad (i, q_index) *
                                   fe_values.shape_grad (j, q_index) *
                                   fe_values.JxW (q_index));


          }


      cell->get_dof_indices (local_dof_indices);

      constraints.distribute_local_to_global (cell_matrix,
                                              cell_rhs,
                                              local_dof_indices,
                                              system_matrix,
                                              system_rhs);
                                              
    }

                                                  
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::solve ()
{

  std::map<types::global_dof_index,double> boundary_values;
  
  for (auto i : boundary_id_value) {
    VectorTools::interpolate_boundary_values (dof_handler,
                                              i.first,
                                              BoundaryValues1<dim>(i.second, k_electrostatic, atom_data),
                                              boundary_values);
  }                                            
                                            

                  // matrix and boundary value constraints
  FilteredMatrix<dealii::Vector<double> > filtered_A (system_matrix);
  filtered_A.add_constraints (boundary_values);


                  // set up a linear solver
  SolverControl solver_control (1000, 1.e-6, false, false);
  //SolverControl solver_control (1000, 1.e-10);  
  GrowingVectorMemory<dealii::Vector<double> > mem;
  SolverCG<dealii::Vector<double> > solver (solver_control, mem);

 
  
                  // set up a preconditioner object
  PreconditionJacobi<SparseMatrix<double> > prec;
  prec.initialize (system_matrix, 1.2);
  FilteredMatrix<dealii::Vector<double> > filtered_prec (prec);
  filtered_prec.add_constraints (boundary_values);
  
  
                  // compute modification of right hand side
  auto system_rhs_tmp = system_rhs;
  filtered_A.apply_constraints (system_rhs_tmp);
                  // solve for solution vector x
  solver.solve (filtered_A, solution, system_rhs_tmp, filtered_prec);


  constraints.distribute (solution);
  /*
  std::cout << "   " << solver_control.last_step()
            << " CG iterations needed to obtain convergence."
            << std::endl;
            */
}
//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson_finite_pore<dim>::output_results (const int cycle) const
{
  std::string filename ("solotion" + std::to_string(cycle) + ".vtk");

  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "solution");

  data_out.build_patches ();
  
  std::ofstream output (filename.c_str());
  data_out.write_vtk (output);
}


//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::set_boundary ()
{

  const double sn = 0.001;
      
  Triangulation<3>::active_cell_iterator cell = triangulation.begin_active();
  Triangulation<3>::active_cell_iterator endc = triangulation.end();    
  for (; cell!=endc; ++cell) {    
    for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f) {
      if (cell->face(f)->at_boundary()) {
          auto p = cell->face(f)->center();
 ///*
          if (p[0] < -8 +sn && p[0] > -13 - sn) {
            cell->face(f)->set_boundary_id (110);
            //std::cout << "id 110" << std::endl;
          } else if (p[0] < -13 +sn && p[0] > -19 - sn) {
            cell->face(f)->set_boundary_id (111);
           //std::cout << "id 111" << std::endl;
          } else if (p[0] < -19 +sn) {
            cell->face(f)->set_boundary_id (110);
            //std::cout << "id 110" << std::endl;
          } else if (p[0] > +8  -sn && p[0] < +13 + sn) {
            cell->face(f)->set_boundary_id (120);
            //std::cout << "id 120" << std::endl;            
          } else if (p[0] > +13 -sn && p[0] < +19 + sn) {
            cell->face(f)->set_boundary_id (121);
            //std::cout << "id 121" << std::endl;           
          } else if (p[0] > +19 -sn) {
            cell->face(f)->set_boundary_id (120);   
            //std::cout << "id 120" << std::endl;                     
          } else {
            cell->face(f)->set_boundary_id (0); 
           // std::cout << "id 0" << std::endl;            
          }
         //  */
/*
          if (p[2] > 3.0 - sn || p[2] < -3 +sn)  {
            if (p[0] < -8 +sn || p[0] > 8 - sn) {
             cell->face(f)->set_boundary_id (130); 
             std::cout << "id corrected 0" << std::endl;
            }
          }*/
      }          
    }
  }

}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::refine_boundary (const unsigned int refine_levels)
{

    for (unsigned int j = 1; j <= refine_levels; ++j) {
      std::cout << "refine level " << j << std::endl;
      Triangulation<3>::active_cell_iterator cell = triangulation.begin_active();
      Triangulation<3>::active_cell_iterator endc = triangulation.end();
    
      for (; cell!=endc; ++cell) {    
        for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
          if (cell->face(f)->at_boundary()) {
            if (cell->face(f)->boundary_id()!=0)
              cell->set_refine_flag ();          


          }          
      }
      triangulation.execute_coarsening_and_refinement ();   
    }
}
//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson_finite_pore<dim>::refine_grid_adaptive ()
{

  dealii::Vector<float> estimated_error_per_cell (triangulation.n_active_cells());
  KellyErrorEstimator<dim>::estimate (dof_handler,
                                      QGauss<dim-1>(3),
                                      typename FunctionMap<dim>::type(),
                                      solution,
                                      estimated_error_per_cell);
  GridRefinement::refine_and_coarsen_fixed_number (triangulation,
                                                   estimated_error_per_cell,
                                                   0.3, 0.03);
  triangulation.execute_coarsening_and_refinement ();
  
  
}
//==================================================
//==================================================
//==================================================


//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::calculate_acceleration () {

  const auto &pos = atom_data -> owned.position;
   
  run ();
    

	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto mass_i = atom_data -> owned.mass [ type_i ];
	  const auto charge_i = atom_data -> owned.charge [ type_i ];
	  for (unsigned int j=i+1;j<pos.size();++j) {
 		  const auto type_j = atom_data -> owned.type [j] ;
	    const auto mass_j = atom_data -> owned.mass [ type_j ];
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	    
      const auto dr = pos[j] - pos[i]; 
      const auto dr_sq = dr*dr;
      const auto dr_norm = std::sqrt(dr_sq);      
	    const auto force = k_electrostatic * charge_i * charge_j * dr / (dr_sq*dr_norm);
			atom_data -> owned.acceleration [i] -= force / mass_i;
      atom_data -> owned.acceleration [j] += force / mass_j; // no periodic boundary condition yet
	  }
	  

	  const dealii::Point<3> r = {pos[i].x, pos[i].y, pos[i].z};
    
    const double inc = 1e-6;
    auto rx = r + dealii::Point<3> (inc,0,0);
    auto ry = r + dealii::Point<3> (0,inc,0);
    auto rz = r + dealii::Point<3> (0,0,inc);
    
    auto f_sm_r0 = VectorTools::point_value (dof_handler, solution,r);
    auto f_sm_rx = VectorTools::point_value (dof_handler, solution,rx);
    auto f_sm_ry = VectorTools::point_value (dof_handler, solution,ry);
    auto f_sm_rz = VectorTools::point_value (dof_handler, solution,rz);
    
    auto f_sm_gx = -(f_sm_rx - f_sm_r0)/inc;
    auto f_sm_gy = -(f_sm_ry - f_sm_r0)/inc;
    auto f_sm_gz = -(f_sm_rz - f_sm_r0)/inc;   

    
    auto field = fine_cuppa::Vector<double> {f_sm_gx, f_sm_gy , f_sm_gz };
    auto force = field * charge_i;

		atom_data -> owned.acceleration [i] += force / mass_i;    
	}
}
//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_finite_pore<dim>::run ()
{
  if (!initialized) {
    initialized = true;
    //read_domain ();    
    set_boundary ();
    for (unsigned int i=0; i < refine_sequence_type.size(); ++i) {
      if (refine_sequence_type[i]==0)
        triangulation.refine_global (refine_sequence_value[i]);
      if (refine_sequence_type[i]==1) 
        refine_boundary (refine_sequence_value[i]);
    }
    
    setup_system ();
    assemble_system ();
    solve ();	    
    output_results(0);  
  } else {
    time_step_count++;
    if (time_step_count%time_step_jump==0) {
      solve ();
    }
  }

}

//==================================================
//==================================================
//==================================================



} //NS_finite_element

FINE_CUPPA_NAMESPACE_CLOSE
template class fine_cuppa::NS_finite_element::FE_dealii_poisson_finite_pore<3>;
template class fine_cuppa::NS_finite_element::BoundaryValues1<3>;
template class fine_cuppa::NS_finite_element::RightHandSide1<3>;

#endif
