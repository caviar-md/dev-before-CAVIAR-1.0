#include "neighbor.h"

#include "fine_cuppa_config.h"

#include <cmath>

#include "object_container.h"
#include "atom_data.h"
#include "update.h"

FINE_CUPPA_NAMESPACE_OPEN

Neighbor::Neighbor (MD *md) : Pointers{md} {}

void Neighbor::init () {
  cutoff = 0.0;
  for (auto f : object_container->force_field)
    if (cutoff < f->cutoff)
      cutoff = f->cutoff;
	cutoff_extra = 0.0; // check this. cutoff_extera is used as a criteria for making a new neigbor list.
  auto &old_pos = atom_data->last_reneighbor_pos;
  const auto &pos = atom_data->owned.position;
	old_pos.resize (pos.size());
}

bool Neighbor::rebuild_neighlist () {
  bool result = false;
  const auto &pos = atom_data->owned.position, &old_pos = atom_data->last_reneighbor_pos;
  for (unsigned int i=0; i<old_pos.size(); ++i) {
    auto disp = pos[i] - old_pos[i];
    result |= (disp*disp > cutoff_extra*cutoff_extra/4);
  }
#ifdef USE_MPI
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Neighbor::build_neighlist () {
  double max_vel_sq=0.0;//,max_vel_sq_all=0.0;
	for (const auto v:atom_data->owned.velocity) {// Any faster scheme using <algorithm>?
		double vel_sq_temp = v*v; 
 		if (max_vel_sq<vel_sq_temp) max_vel_sq = vel_sq_temp;
	}
#ifdef USE_MPI
	MPI_Allreduce (&max_vel_sq,&max_vel_sq_all, 1, MPI_DOUBLE, MPI_MAX, mpi_comm); // What if every domain have their own cutoff_extra ?any problem with ghosts?
	double max_vel_all = std::sqrt(max_vel_sq_all);
#else
	double max_vel_all = std::sqrt(max_vel_sq);
#endif
	auto dt = md->update->dt;
	cutoff_extra = 30.0*dt*max_vel_all; // the coefficient can change the efficiency- it shouldn't change the results- it doesn't in MPI=NO

  const auto &pos = atom_data->owned.position, & pos_ghost = atom_data -> ghost.position;
  auto cutoff_sq = (cutoff + cutoff_extra)*(cutoff + cutoff_extra);
  neighlist.clear ();
  neighlist.resize (pos.size());
	//int gc=0;
  for (unsigned int i=0; i<pos.size(); ++i) {
    for (unsigned int j=i+1; j<pos.size(); ++j) {
      auto dr = pos[j] - pos[i];
      if (dr*dr < cutoff_sq)
        neighlist[i].push_back (j);
    }
		for (unsigned int j=0; j<pos_ghost.size(); ++j) {
      auto dr = pos_ghost[j] - pos[i];
      if (dr*dr < cutoff_sq)
        neighlist[i].push_back (j + pos.size());
    }
	}
	
  auto &old_pos = atom_data->last_reneighbor_pos;
	old_pos.clear ();
  for (unsigned int i=0; i<pos.size(); ++i) {
		old_pos.push_back (pos[i]);
	}
}

FINE_CUPPA_NAMESPACE_CLOSE

