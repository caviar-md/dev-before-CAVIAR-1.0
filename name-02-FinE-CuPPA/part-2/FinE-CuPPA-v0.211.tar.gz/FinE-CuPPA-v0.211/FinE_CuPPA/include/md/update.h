#ifndef UPDATE_H
#define UPDATE_H

#include "fine_cuppa_config.h"

#include "pointers.h"

FINE_CUPPA_NAMESPACE_OPEN

class Update : protected Pointers {
public:
  Update (class MD *);
 	~Update ( );

  bool run (int);
  void verify_settings ();
  void setup ();
  void cleanup ();
	double dt;
private:
  class Integrate *integrate;
	class Output *output;
	clock_t t_start, t_end;
	double tot_time;
//	bool self_ghost ();
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
