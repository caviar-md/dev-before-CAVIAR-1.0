#ifndef UTILITY_H
#define UTILITY_H

#include "fine_cuppa_config.h"

#ifdef NO_PARSER
#define FILE_LINE_FUNC __FILE__,__LINE__,__func__,line,col
#else
#define FILE_LINE_FUNC __FILE__,__LINE__,__func__,parser->line,parser->col
#endif

FINE_CUPPA_NAMESPACE_OPEN

template <typename T>
constexpr T min (T a, T b) {
  return a < b ? a : b;
}

template <typename T>
constexpr T max (T a, T b) {
  return a > b ? a : b;
}

template <typename T>
constexpr T ipow (T num, unsigned pow) {
  return pow ? num*ipow(num, pow-1) : 1;
}

FINE_CUPPA_NAMESPACE_CLOSE

#endif
