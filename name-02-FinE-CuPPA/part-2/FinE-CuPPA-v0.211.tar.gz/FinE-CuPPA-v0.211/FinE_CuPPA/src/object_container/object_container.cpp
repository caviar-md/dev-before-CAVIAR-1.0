#include "object_container.h"

#include "fine_cuppa_config.h"

FINE_CUPPA_NAMESPACE_OPEN

Object_container::Object_container (MD *md) : Pointers{md} {
}

Object_container::~Object_container () {
  for (auto i : shape)
    delete i;
  for (auto i : force_field)
    delete i;
//  for (auto i : finite_element)
//    delete i;    
}

FINE_CUPPA_NAMESPACE_CLOSE

