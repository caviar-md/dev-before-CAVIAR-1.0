#ifdef ATOM_DATA_CLASS

AtomDataStyle(simple,Atom_data_simple)

#else

#ifndef ATOM_DATA_SIMPLE_H
#define ATOM_DATA_SIMPLE_H

#include "fine_cuppa_config.h"

#include "atom_data.h"

FINE_CUPPA_NAMESPACE_OPEN

class Atom_data_simple : public Atom_data {
public:
  Atom_data_simple (class MD *);
private:
  void allocate ();
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
#endif
