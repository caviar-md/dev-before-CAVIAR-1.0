#ifndef ERROR_H
#define ERROR_H

#include "fine_cuppa_config.h"

#include "pointers.h"

FINE_CUPPA_NAMESPACE_OPEN

class Error : protected Pointers {
public:
  Error (MD *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const char *);
  void one (const char *, int, const char *, const std::string &, unsigned int, const char *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
  void one (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
