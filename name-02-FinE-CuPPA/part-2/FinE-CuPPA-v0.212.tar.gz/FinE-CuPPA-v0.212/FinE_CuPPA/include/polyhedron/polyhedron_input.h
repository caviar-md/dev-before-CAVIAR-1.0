#ifndef POLYHEDRON_INPUT_H
#define POLYHEDRON_INPUT_H

#include "fine_cuppa_config.h"

#include "polyhedron.h"
#include "format_vtk_reader.h"
#include "parser.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_geometry {
class Polyhedron_Input : protected Pointers {
public:
  Polyhedron_Input (class MD *);
  ~Polyhedron_Input ();
  
	void read_vtk (NS_geometry::Polyhedron&, const std::string &); // read vtk format // There's many unneeded points. 


  class Output * output;
  class Error * error;


};
}

FINE_CUPPA_NAMESPACE_CLOSE

#endif
