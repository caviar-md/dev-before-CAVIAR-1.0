#ifndef OBJECT_CREATOR_H
#define OBJECT_CREATOR_H

#include "fine_cuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "pointers.h"
#include "parser.h"
#include "output.h"
#include "error.h"

FINE_CUPPA_NAMESPACE_OPEN

using CommandFunc_object_creator = bool (Object_creator::*) (Parser *); // a pointer to boolean function of ...

class Object_creator : protected Pointers  {
public:
  Object_creator (class MD *);
  ~Object_creator ();
  
  const static std::map<std::string, CommandFunc_object_creator> commands_map;
  
  
  bool element (Parser *);
  bool atom (Parser *);
  bool molecule (Parser *);
  bool random_1d (Parser *);
  bool grid_1d (Parser *);		
  bool boundary (Parser *);
  bool shape (Parser *);
  bool distribution (Parser *);
  bool force_field (Parser *);	
  bool finite_element (Parser *);	  
  bool int_variable (Parser *);
  bool real_variable (Parser *);
  bool int_2d_vector (Parser *);
  bool real_2d_vector (Parser *);
  bool int_3d_vector (Parser *);
  bool real_3d_vector (Parser *);
  
	
	class Object_container * object_container;	
	class Parser * parser;
  class Output * output;
  class Error * error;
private:

} ;

FINE_CUPPA_NAMESPACE_CLOSE

#endif
 
