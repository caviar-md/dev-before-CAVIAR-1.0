#ifndef OBJECT_UTILITY_MOLECULE_H
#define OBJECT_UTILITY_MOLECULE_H

#include "fine_cuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "vector.h"
#include "vector2D.h"
#include "parser.h"
#include "output.h"
#include "error.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_object_utility {


class Molecule {
	public:
		Molecule ();
		Molecule (class Object_container *);		
		Molecule (const Molecule &);
		Molecule (class Object_container *, class Molecule *,  Vector<double>, Vector<double>);
		~Molecule ();

		Vector<double> pos_tot () const;
		Vector<double> vel_tot () const;	
		Vector<double> pos () const {
		 	return position;	
		}
		Vector<double> & pos ()  {
		 	return position;
		}
		Vector<double> vel () const {
		 	return velocity;	
		}
		Vector<double> & vel ()  {
		 	return velocity;
		}
		void give_position_and_radius (std::vector<Vector<double>>&, std::vector<double>&);
		void correct_heritage ();
  
		bool read (Parser *);

		bool add_atom (const class Atom &);
		bool add_atom (const class Atom &, const Vector<double> &p, const Vector<double> &v);	
		bool add_molecule (const Molecule &);	
		bool add_molecule (const Molecule &, const Vector<double> &p, const Vector<double> &v);
				
		void output_xyz (std::ofstream &);
    void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);
		
		bool has_father;
		Molecule * FATHER;


	private:
	Vector<double> position, velocity;
	std::vector<Atom> atoms;
	std::vector<Molecule> molecules;
	
	class Output * output;
	class Error * error;
  class Object_container * object_container;

};

} 

FINE_CUPPA_NAMESPACE_CLOSE

#endif
 
