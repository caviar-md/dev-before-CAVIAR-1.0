#ifndef FORCE_FIELD_ELECTROSTATIC_H
#define FORCE_FIELD_ELECTROSTATIC_H

#include "fine_cuppa_config.h"

#include "force_field.h"

#include <vector>

#include "vector.h"

FINE_CUPPA_NAMESPACE_OPEN

class Force_field_electrostatic : public Force_field {
public:
  Force_field_electrostatic (class MD *);
  ~Force_field_electrostatic () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  //std::vector<std::vector<Real_t>> epsilon,sigma;
  double k_electrostatic;
  Vector<double> external_field;
  
  class Parser *parser;
	class Output *output;
	class Error *error;  
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
