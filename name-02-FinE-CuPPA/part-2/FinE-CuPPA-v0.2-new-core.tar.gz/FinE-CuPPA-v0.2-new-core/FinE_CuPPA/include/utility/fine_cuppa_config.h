#ifndef FINE_CUPPA_CONFIG_H
#define FINE_CUPPA_CONFIG_H

#define FINE_CUPPA_NAMESPACE_OPEN namespace fine_cuppa {
#define FINE_CUPPA_NAMESPACE_CLOSE }

#define FINE_CUPPA_MAJOR_VERSION 0
#define FINE_CUPPA_MINOR_VERSION 2


// #ifndef USE_MPI
/* #undef USE_MPI */
// #endif


// #ifndef USE_DEALII
/* #undef USE_DEALII */
// #endif

#endif
