#include "object_handler_dictionary.h"

#include "fine_cuppa_config.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_object_handler {


}

FINE_CUPPA_NAMESPACE_CLOSE
