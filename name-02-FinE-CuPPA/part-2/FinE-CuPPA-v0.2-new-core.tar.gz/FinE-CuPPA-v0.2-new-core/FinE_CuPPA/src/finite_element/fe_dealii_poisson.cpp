#ifdef USE_DEALII

#include "fe_dealii_poisson.h"

#include "fine_cuppa_config.h"

#include <boost/algorithm/string.hpp>

#include "parser.h"
#include "object_handler_all.h"
#include "object_container.h"
#include "atom_data.h"
#include "error.h"
#include "output.h"

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_bicgstab.h>
#include <deal.II/lac/precondition.h>

#include <deal.II/numerics/data_out.h>
#include <fstream>
#include <iostream>
#include <cmath>


#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/vector_tools.h>

#include <deal.II/grid/manifold_lib.h>

#include <deal.II/opencascade/boundary_lib.h>
#include <deal.II/opencascade/utilities.h>



#include <deal.II/base/logstream.h>

#include <deal.II/grid/grid_refinement.h>
#include <deal.II/numerics/error_estimator.h>

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_finite_element {

//==================================================
//==================================================
//==================================================


void All_charges::set_charge_position (const unsigned int i, const dealii::Point<3> & p){
  charge_position[i] = p;
}

//==================================================
//==================================================
//==================================================

void All_charges::clear_image_charges () {
  image_position.clear();
  charge_of_image.clear();
}
//==================================================
//==================================================
//==================================================

void All_charges::add_charge (const dealii::Point<3> p,const double c) {
  charge_of_charge.push_back(c);
  charge_position.push_back (p);
}

//==================================================
//==================================================
//==================================================

void All_charges::add_charge (const double x,const double y,const double z,const double c) {
  charge_of_charge.push_back(c);
  charge_position.push_back (dealii::Point<3> {x,y,z});
}

//==================================================
//==================================================
//==================================================

void All_charges::calculate_image_charges() {
  clear_image_charges ();
  for (unsigned int i = 0; i < charge_position.size(); ++i) {
    dealii::Point<3> image_position_ = charge_position[i];
    const double p_sq = charge_position[i]*charge_position[i];
    image_position_ *= Rad*Rad / p_sq;
    double charge_of_image_ = - charge_of_charge[i] * Rad / std::sqrt(p_sq);
    //double charge_of_image_ = - charge_of_charge[i] *  std::sqrt(p_sq)/Rad;    
    image_position.push_back (image_position_);
    charge_of_image.push_back (charge_of_image_);
  }
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_of_charge (const dealii::Point<3> &p, unsigned int i) {
  return k_coef * charge_of_charge[i] / p.distance(charge_position[i]);
}

//==================================================
//==================================================
//==================================================

double All_charges::potential_of_image (const dealii::Point<3> &p, unsigned int i) {
  return k_coef * charge_of_image[i] / p.distance(image_position[i]);
}

//==================================================
//==================================================
//==================================================

double All_charges::total_potential_of_charges (const dealii::Point<3> &p) {
  double p_sum = 0.0;
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (p == charge_position[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance  
    p_sum += potential_of_charge (p,i);
  }
  return p_sum;
}

//==================================================
//==================================================
//==================================================

double All_charges::total_potential_of_charges (unsigned int j) {
  double p_sum = 0.0;
  const dealii::Point<3> p = charge_position[j];  
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (i == j) continue;  
//  it's better to use p.distance(pos_char[i]) < a_tolerance  
    p_sum += potential_of_charge (p,i);
  }
  return p_sum;
}
//==================================================
//==================================================
//==================================================

double All_charges::total_potential (const dealii::Point<3> &p) {
  double p_sum = 0.0;
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (p != charge_position[i]) p_sum += potential_of_charge (p,i);  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance  
   
    p_sum += potential_of_image (p,i);    
  }
  return p_sum;
}

//==================================================
//==================================================
//==================================================

double All_charges::total_potential (unsigned int j) {
  double p_sum = 0.0;
  const dealii::Point<3> p = charge_position[j];
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (i != j) p_sum += potential_of_charge (p,i);
//  it's better to use p.distance(pos_char[i]) < a_tolerance      
    p_sum += potential_of_image (p,i);    
  }
  return p_sum;
}


//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_of_charge (const dealii::Point<3> &p, unsigned int i) {
  dealii::Point<3> r_p = p;// - charge_position[i];
  r_p[0] -=  charge_position[i][0];r_p[1] -=  charge_position[i][1];r_p[2] -=  charge_position[i][2];
//  dealii::Tensor<1, 3, double> r_p = p - charge_position[i];
  const double r = p.distance(charge_position[i]);
  const double a = k_coef * charge_of_charge[i] / (r*r*r);
  return a * r_p;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::field_of_image (const dealii::Point<3> &p, unsigned int i) {
  dealii::Point<3> r_p = p ;//- image_position[i];
  r_p[0] -=  image_position[i][0];r_p[1] -=  image_position[i][1];r_p[2] -=  image_position[i][2];  
  const double r = p.distance(image_position[i]);
  const double a = k_coef * charge_of_image[i] / (r*r*r);
  return a * r_p;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::total_field_of_charges (const dealii::Point<3> &p) {
  dealii::Point<3> e_sum {0,0,0};
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (p == charge_position[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance
    e_sum += field_of_charge (p,i);  
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::total_field (const dealii::Point<3> &p) {
  dealii::Point<3> e_sum {0,0,0};
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (p != charge_position[i]) e_sum += field_of_charge (p,i);
//  it's better to use p.distance(pos_char[i]) < a_tolerance
 
    e_sum += field_of_image (p,i);    
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::total_field (unsigned int j) {
  dealii::Point<3> e_sum {0,0,0};
  const dealii::Point<3> p = charge_position[j];  
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (i != j)       e_sum += field_of_charge (p,i);
//  if (p == pos_char[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance    

    e_sum += field_of_image (p,i);    
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

dealii::Point<3> All_charges::total_field_of_charges (unsigned int j) {
  dealii::Point<3> e_sum {0,0,0};
  const dealii::Point<3> p = charge_position[j];  
  for (unsigned int i = 0; i< charge_position.size(); ++i) {
    if (i == j) continue;  
//  if (p == pos_char[i]) continue;  // or 
//  it's better to use p.distance(pos_char[i]) < a_tolerance    
    e_sum += field_of_charge (p,i);
  }
  return e_sum;
}

//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================


template <int dim>
double RightHandSide<dim>::value (const Point<dim> &p,
                                  const unsigned int ) const
{

  double return_value = 0.0*p(0);

  return return_value;
}

//==================================================
//==================================================
//==================================================

class All_charges *all_charges_ptr;

//--------------------------------------------------

template <int dim>
double BoundaryValues<dim>::value (const Point<dim> &p,
                                   const unsigned int ) const
{

  return all_charges_ptr->get_phi_bc() - all_charges_ptr->total_potential_of_charges(p);  
}



//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson<dim>::FE_dealii_poisson(MD * md) : NS_finite_element::Finite_element<dim>{md},// (All_charges * all_charges)
  fe (2),
  dof_handler (triangulation),
  atom_data{md->atom_data}, output{md->output}, error{md->error}
//  ,all_charges{all_charges}
{}

//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson<dim>::~FE_dealii_poisson() {}
//==================================================
//==================================================
//==================================================
template <int dim>
bool FE_dealii_poisson<dim>::read (Parser *parser) {
	output->info("fe_dealii_poisson element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
    if (boost::iequals(t,"make_grid")) {
      make_grid();
		} else if (boost::iequals(t,"refine_global")) {		
      int n = parser->get_literal_int();//0;      
      //GET_OR_CHOOSE_AN_INT(n,"","")      
      triangulation.refine_global(n);
		} else if (boost::iequals(t,"refine_boundary")) {
      int n = parser->get_literal_int();
      
      //GET_OR_CHOOSE_AN_INT(n,"","")
      
      refine_boundary(n); 
		} else error->all (FILE_LINE_FUNC, "Unknown variable or command");
	}
	
	return in_file;
  return true; // WARNING
}

//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson<dim>::rotate_and_add_reserve(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (tria_reserve);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }

//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson<dim>::rotate_and_add(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (triangulation);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }



//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson<dim>::match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll) {
    int no_matched_vertices = 0;
    int no_corrected_vertices = 0;
    
    for (typename Triangulation<3,3>::active_cell_iterator
         cell2=tria2.begin_active(); cell2!=tria2.end(); ++cell2) {
      for (unsigned int f2=0; f2<GeometryInfo<3>::faces_per_cell; ++f2) {
        if (cell2->face(f2)->at_boundary()) {
          
          for (typename Triangulation<3,3>::active_cell_iterator
               cell=triangulation.begin_active();cell!=triangulation.end();++cell) { 
            for (unsigned int f=0; f<GeometryInfo<3>::faces_per_cell; ++f) {
              if (cell->face(f)->at_boundary()) {
      
                for (unsigned int i=0; i<4; ++i)  { 
                  const Point<3> p1 = cell->face(f)->vertex(i);
                  bool point_match_found = false;                             
                  for (unsigned int j=0; j<4; ++j)  {           
                    const Point<3> p2 = cell2->face(f2)->vertex(j);
                    const double distance = p2.distance(p1);
                    
                    if (distance < merge_toll) {
                      ++no_matched_vertices;
                      point_match_found = true;
                      if (distance > 0) {
                        ++no_corrected_vertices;
                        cell2->face(f2)->vertex(j) =  cell->face(f)->vertex(i);
                      }
                      break;                        
                    }
                  }
                  if (!point_match_found) break;
                }
              }
            }
          }           
        }        
      }
    }
    
    tot_no_matched +=  no_matched_vertices;
    tot_no_corrected += no_corrected_vertices;
  }
  
//=========================================================================
//=========================================================================
//=========================================================================
//=========================================================================  
 
//===================================================
//===================================================
//===================================================
template <int dim>
void FE_dealii_poisson<dim>::read_domain()
  {

tot_no_matched=0; tot_no_corrected=0;

      const std::vector<std::string> initial_mesh_filename = {
"../sphere_input_1p/Mesh_1.unv",
"../sphere_input_1p/Mesh_2.unv",
"../sphere_input_1p/Mesh_3.unv",
"../sphere_input_1p/Mesh_4.unv",
"../sphere_input_1p/Mesh_6.unv",
"../sphere_input_1p/Mesh_7.unv",
"../sphere_input_1p/Mesh_8_5_rep.unv",
};


    std::ifstream in;

    in.open(initial_mesh_filename[0].c_str());

    GridIn<3,3> gi;
    gi.attach_triangulation(triangulation);
    gi.read_unv(in);

    const double merge_toll = 0.1;
    std::cout << "main mesh:\n";
    unsigned int tot_mesh_num = initial_mesh_filename.size();
    for (unsigned int i = 1; i <  tot_mesh_num; ++i) { // BUG
      std::cout << i << " " << std::flush;     
      //std::cout << i << std::endl;
      Triangulation<3,3> tria2;
     
      std::ifstream in;
      
      in.open(initial_mesh_filename[i].c_str());
      
      GridIn<3,3> gi;

      gi.attach_triangulation(tria2);
      
      gi.read_unv(in);
      
      match_boundary_vertices (tria2, merge_toll);  
       
      GridGenerator::merge_triangulations (triangulation, tria2, triangulation);
    
    }
    std::cout << "\n";    
   
    tria_reserve.copy_triangulation (triangulation);
# define M_PI  3.14159265358979323846
  const double rot = 90.0 * M_PI / 180.0;
    std::cout << "muli rotation:\n";      
    
  for (unsigned int i = 1; i < 4; ++i){  
    const double angle = rot * i ;
    std::cout << i << " " << std::flush;    
    rotate_and_add_reserve (angle, 0, merge_toll);
    
  }
    rotate_and_add (M_PI, 2, merge_toll);
    std::cout << "\n";
#undef M_PI
    


    std::cout << "merge_toll:       " << merge_toll << std::endl;
    std::cout << "tot_no_matched:   " << tot_no_matched << std::endl;
    std::cout << "tot_no_corrected: " << tot_no_corrected << std::endl;

 


  }
  
  
//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson<dim>::set_spherical_manifold() {
  const Point<3> center (0,0,0);
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (1, manifold_description);
  triangulation.set_all_manifold_ids(1);
}

//===================================================
//===================================================
//===================================================
  

template <int dim>
void FE_dealii_poisson<dim>::make_grid ()
{

  const Point<3> center (0,0,0); 
  const double  radius = 1.0;
  GridGenerator::hyper_ball 	(triangulation, center,		radius);
 
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (0, manifold_description);

  std::cout << "   Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl
            << "   Total number of cells: "
            << triangulation.n_cells()
            << std::endl;
}

//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson<dim>::setup_system ()
{
  dof_handler.distribute_dofs (fe);
  
  std::cout << "   Number of degrees of freedom: "
            << dof_handler.n_dofs()
            << std::endl;
            
  solution.reinit (dof_handler.n_dofs());
  system_rhs.reinit (dof_handler.n_dofs());


  constraints.clear ();
  DoFTools::make_hanging_node_constraints (dof_handler,
                                           constraints);

  VectorTools::interpolate_boundary_values (dof_handler,
                                            0,
                                            BoundaryValues<dim>(), //ZeroFunction<dim>(),
                                            constraints);
//--
/*
  std::map<types::global_dof_index,double> boundary_values;


  VectorTools::interpolate_boundary_values (dof_handler,
                                            0,
                                            BoundaryValues<dim>(),
                                            boundary_values);
  MatrixTools::apply_boundary_values (boundary_values,
                                      system_matrix,
                                      solution,
                                      system_rhs);*/
//--
  
  constraints.close ();

  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  DoFTools::make_sparsity_pattern(dof_handler,
                                  dsp,
                                  constraints,
                                  /*keep_constrained_dofs = */ false);

  
  sparsity_pattern.copy_from(dsp);
  system_matrix.reinit (sparsity_pattern);
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson<dim>::assemble_system ()
{
  const QGauss<dim> quadrature_formula(3);

  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values | update_gradients |
                           update_quadrature_points | update_JxW_values);

  const RightHandSide<dim> right_hand_side; // copied
  
  const unsigned int dofs_per_cell = fe.dofs_per_cell;
  const unsigned int n_q_points = quadrature_formula.size();

  FullMatrix<double> cell_matrix (dofs_per_cell, dofs_per_cell);
  dealii::Vector<double> cell_rhs (dofs_per_cell);

  std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();
  for (; cell!=endc; ++cell)
    {
      cell_matrix = 0;
      cell_rhs = 0;

      fe_values.reinit (cell);
/*
      for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        {
          const double current_coefficient = coefficient<dim>
                                             (fe_values.quadrature_point (q_index));
          for (unsigned int i=0; i<dofs_per_cell; ++i)
            {
              for (unsigned int j=0; j<dofs_per_cell; ++j)
                cell_matrix(i,j) += (current_coefficient *
                                     fe_values.shape_grad(i,q_index) *
                                     fe_values.shape_grad(j,q_index) *
                                     fe_values.JxW(q_index));

              cell_rhs(i) += (fe_values.shape_value(i,q_index) *
                              1.0 *
                              fe_values.JxW(q_index));
            }
        }*/


      fe_values.reinit (cell);
      cell_matrix = 0;
      cell_rhs = 0;
      for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        for (unsigned int i=0; i<dofs_per_cell; ++i)
          {
            for (unsigned int j=0; j<dofs_per_cell; ++j)
              cell_matrix(i,j) += (fe_values.shape_grad (i, q_index) *
                                   fe_values.shape_grad (j, q_index) *
                                   fe_values.JxW (q_index));

            cell_rhs(i) += (fe_values.shape_value (i, q_index) *
                            right_hand_side.value (fe_values.quadrature_point (q_index)) *
                            fe_values.JxW (q_index));
          }


      cell->get_dof_indices (local_dof_indices);
      constraints.distribute_local_to_global (cell_matrix,
                                              cell_rhs,
                                              local_dof_indices,
                                              system_matrix,
                                              system_rhs);
    }

                                  
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson<dim>::solve ()
{
//  SolverControl solver_control (1000, 1e-12*system_rhs.l2_norm());
  SolverControl solver_control (1000, 1e-12*system_rhs.l2_norm());
  SolverCG<> solver (solver_control);

  PreconditionSSOR<> preconditioner;
  preconditioner.initialize(system_matrix, 1.2);

  solver.solve (system_matrix, solution, system_rhs,
                preconditioner);

  constraints.distribute (solution);
}
//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson<dim>::output_results (const int cycle) const
{
/* // without cycle number
  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "solution");

  data_out.build_patches ();
  
  std::ofstream output (dim == 2 ?
                        "solution-2d.vtk" :
                        "solution-3d.vtk");
  data_out.write_vtk (output);
  */

  std::string filename ("solotion" + std::to_string(cycle) + ".vtk");

  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "solution");

  data_out.build_patches ();
  
  std::ofstream output (filename.c_str());
  data_out.write_vtk (output);
}



//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson<dim>::refine_boundary (const unsigned int refine_levels)
{

    for (unsigned int j = 1; j <= refine_levels; ++j) {
      std::cout << "refine level " << j << std::endl;
      Triangulation<3>::active_cell_iterator cell = triangulation.begin_active();
      Triangulation<3>::active_cell_iterator endc = triangulation.end();
    
      for (; cell!=endc; ++cell) {    
        for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
          if (cell->face(f)->at_boundary()) {
              cell->set_refine_flag ();

          }          
      }
      triangulation.execute_coarsening_and_refinement ();   
    }
}
//==================================================
//==================================================
//==================================================


template <int dim>
void FE_dealii_poisson<dim>::refine_grid_adaptive ()
{

  dealii::Vector<float> estimated_error_per_cell (triangulation.n_active_cells());
  KellyErrorEstimator<dim>::estimate (dof_handler,
                                      QGauss<dim-1>(3),
                                      typename FunctionMap<dim>::type(),
                                      solution,
                                      estimated_error_per_cell);
  GridRefinement::refine_and_coarsen_fixed_number (triangulation,
                                                   estimated_error_per_cell,
                                                   0.3, 0.03);
  triangulation.execute_coarsening_and_refinement ();
  
  
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson<dim>::calculate_acceleration () {
  const auto &pos = atom_data -> owned.position;
  //const auto &vel = atom_data -> owned.velocity;
  //const auto &chr = atom_data -> owned.charge;
 
  All_charges all_charges;    
  all_charges_ptr = & all_charges;
    
  all_charges_ptr -> set_Radius(1.0);
  all_charges_ptr -> set_k_coef(1.0);
  all_charges_ptr -> set_phi_bc(0.0);
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto charge_i = atom_data -> owned.charge [ type_i ];	  
    all_charges.add_charge(pos[i].x, pos[i].y, pos[i].z, charge_i);
  }

  run ();
  
  const auto k_coef = all_charges_ptr -> get_k_coef();
  
	//auto &acc = atom_data -> owned.acceleration;
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto mass_i = atom_data -> owned.mass [ type_i ];
	  const auto charge_i = atom_data -> owned.charge [ type_i ];
	  for (unsigned int j=i+1;j<pos.size();++j) {
 		  const auto type_j = atom_data -> owned.type [j] ;
	    const auto mass_j = atom_data -> owned.mass [ type_j ];
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	    
      const auto dr = pos[j] - pos[i]; 
      const auto dr_sq = dr*dr;
      const auto dr_norm = std::sqrt(dr_sq);      
	    const auto force = k_coef * charge_i * charge_j * dr / (dr_sq*dr_norm);
			atom_data -> owned.acceleration [i] += force / mass_i;
      atom_data -> owned.acceleration [j] -= force / mass_j; // no periodic boundary condition yet
	  }
	  

    auto r = all_charges_ptr -> get_charge_position (i);
    // auto f_sm = - VectorTools::point_gradient (dof_handler, solution,r);
    // auto f_si = all_charges->total_field_of_charges (i);
    
    const double inc = 1e-6;
    auto rx = r + dealii::Point<3> (inc,0,0);
    auto ry = r + dealii::Point<3> (0,inc,0);
    auto rz = r + dealii::Point<3> (0,0,inc);
    
    auto f_sm_r0 = VectorTools::point_value (dof_handler, solution,r);
    auto f_sm_rx = VectorTools::point_value (dof_handler, solution,rx);
    auto f_sm_ry = VectorTools::point_value (dof_handler, solution,ry);
    auto f_sm_rz = VectorTools::point_value (dof_handler, solution,rz);
    
    auto f_sm_gx = -(f_sm_rx - f_sm_r0)/inc;
    auto f_sm_gy = -(f_sm_ry - f_sm_r0)/inc;
    auto f_sm_gz = -(f_sm_rz - f_sm_r0)/inc;
    
   // auto f_sm_me = dealii::Point<3> (f_sm_gx,f_sm_gy,f_sm_gz);
    
    auto force = Vector<double> {f_sm_gx, f_sm_gy, f_sm_gz};
    
		atom_data -> owned.acceleration [i] += force / mass_i;    
	}
}
//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson<dim>::run ()
{
    setup_system ();
    assemble_system ();
    solve ();	  
}

//==================================================
//==================================================
//==================================================

/* dont delete

int main ()
{

  std::ofstream error_file;
  error_file.open ("error_file");

  All_charges all_charges;
    
  all_charges_ptr = & all_charges;
    
  all_charges.set_Radius(1.0);
  all_charges.set_k_coef(1.0);
  all_charges.set_phi_bc(0.0);
  
  all_charges.add_charge(0.0, 0.0, 0.0, 1.0);  
  //all_charges.add_charge(0.543, 4.0, -5.0, -4.0);  
    
  all_charges.calculate_image_charges();
  
  deallog.depth_console (0);
  
  FE_dealii_poisson<3> laplace_problem_3d (&all_charges);
  laplace_problem_3d.run (error_file);  

  error_file.close ();
  
  return 0;
}

*/

} //NS_finite_element

FINE_CUPPA_NAMESPACE_CLOSE
template class fine_cuppa::NS_finite_element::FE_dealii_poisson<3>;
template class fine_cuppa::NS_finite_element::BoundaryValues<3>;
template class fine_cuppa::NS_finite_element::RightHandSide<3>;

#endif
