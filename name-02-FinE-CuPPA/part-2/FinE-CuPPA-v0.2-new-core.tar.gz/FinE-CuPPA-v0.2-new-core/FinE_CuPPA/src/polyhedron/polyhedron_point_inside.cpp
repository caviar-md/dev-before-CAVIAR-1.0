#include "polyhedron_point_inside.h"

#include "fine_cuppa_config.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
//#include "kakaka_preprocessors.h"
#include "utility.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_geometry {


Polyhedron_Point_Inside::Polyhedron_Point_Inside (MD *md) : Pointers{md},
				output{md->output}, error{md->error} {}

Polyhedron_Point_Inside::~Polyhedron_Point_Inside () { }


bool Polyhedron_Point_Inside::is_inside(NS_geometry::Polyhedron & p_object, const Vector<double> &v0) {

 Vector<double> v3 = {1e-5,3e-5,25e-6};
 Vector<double> v4 = {-1e-5,2e-5,-3e-5};
 
  const auto r0 = check_inside_ray (p_object, v0, 0);  
  const auto r1 = check_inside_ray (p_object, v0, 1);  
  const auto r2 = check_inside_ray (p_object, v0, 2); 
  const auto r3 = check_inside_ray (p_object, v0+v3, 0);  
  const auto r4 = check_inside_ray (p_object, v0+v4, 1);     
  const int res = r0 + r1 + r2 + r3 + r4;
  //const int res = r0 + r1 + r2;  
  if (res < 3)
    return false;
  else
    return true;    
}

bool Polyhedron_Point_Inside::is_outside(NS_geometry::Polyhedron & p_object, const Vector<double> &v) {
  return !is_inside (p_object, v);
}

bool Polyhedron_Point_Inside::is_inside(NS_geometry::Polyhedron & p_object, const Vector<double> &v, const double r) {
  if (!is_inside(p_object, v)) return false;
  if (check_inside(p_object, v, r)) return false; 
  return true;
}

bool Polyhedron_Point_Inside::is_outside(NS_geometry::Polyhedron & p_object, const Vector<double> &v, const double r) {
  return !is_inside (p_object, v,r);
}




bool Polyhedron_Point_Inside::check_inside (NS_geometry::Polyhedron & p_object, const Vector<double> &v1, const Real_t radius, Vector<double> &contact_vector) {
  bool contact_flag = false;
 	const auto & vertex = p_object.vertex;
 	const auto & face = p_object.face;
 	const auto & normal = p_object.normal;
 	const auto & edge_norms3 = p_object.edge_norms3;
 	const auto & thickness = p_object.thickness;
 	const auto & grid = p_object.grid;
	const auto & xlo = p_object.xlo;//, & xhi = p_object.xhi;
	const auto & ylo = p_object.ylo;//, & yhi = p_object.yhi;
	const auto & zlo = p_object.zlo;//, & zhi = p_object.zhi;
	const auto & dx_part = p_object.dx_part;
	const auto & dy_part = p_object.dy_part;
	const auto & dz_part = p_object.dz_part;
	const auto & nx_part = p_object.nx_part;
	const auto & ny_part = p_object.ny_part;
	const auto & nz_part = p_object.nz_part;
//-- 
	int xindex = int((v1.x-xlo)/dx_part);
	int yindex = int((v1.y-ylo)/dy_part);
	int zindex = int((v1.z-zlo)/dz_part);

	if (xindex<0) return false;
	if (yindex<0) return false;
	if (zindex<0) return false;

	if (xindex>int(nx_part-1)) return false;
	if (yindex>int(ny_part-1)) return false;
	if (zindex>int(nz_part-1)) return false;

	Vector<Real_t> force{0.0,0.0,0.0};


	//for (auto i : grid[xindex][yindex][zindex]) 
	for (unsigned int i = 0; i< face.size(); ++i)
	{

		Real_t v1_dot_norm = (v1 - vertex[face[i][0]])* normal[i];


		bool is_inside = false;
		if (v1_dot_norm-radius<0 && v1_dot_norm+radius > -thickness) {  // if true it may be inside the face //
													// if the particle has radius, we have to put it in	
													// this condition
			is_inside = true;
			for (unsigned int j=0; j<face[i].size(); ++j) {
//				int k0 = j; int k1 = (j==face[i].size()-1) ? 0 : j+1;
				Vector<Real_t> v2 = v1- vertex[face[i][j]];

				Real_t dotdot = v2 * edge_norms3[i][j];

				if (dotdot<0) {is_inside=false;break;}
				// note that the polygon need to be convex for this formula to be true.
				// check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). One of them is disasterous
				
			}
		}

		if (is_inside) {
			force += -normal[i]*v1_dot_norm;
			contact_flag = true;
			//break; // use this for a faster scheme (!?)
		} 
	}

 	contact_vector = force;
  return contact_flag;
}

bool Polyhedron_Point_Inside::check_inside (NS_geometry::Polyhedron &p_object, const Vector<Real_t> &v1, const Real_t radius) { // will be used in random initial position creation of particles

	
	const auto & vertex = p_object.vertex;
 	const auto & face = p_object.face;
 	const auto & normal = p_object.normal;
 	const auto & edge_norms3 = p_object.edge_norms3;
 	const auto & thickness = p_object.thickness;
 	const auto & grid = p_object.grid;
	const auto & xlo = p_object.xlo;//, & xhi = p_object.xhi;
	const auto & ylo = p_object.ylo;//, & yhi = p_object.yhi;
	const auto & zlo = p_object.zlo;//, & zhi = p_object.zhi;
	const auto & dx_part = p_object.dx_part;
	const auto & dy_part = p_object.dy_part;
	const auto & dz_part = p_object.dz_part;
	const auto & nx_part = p_object.nx_part;
	const auto & ny_part = p_object.ny_part;
	const auto & nz_part = p_object.nz_part;

	//-- 
	int xindex = int((v1.x-xlo)/dx_part);
	int yindex = int((v1.y-ylo)/dy_part);
	int zindex = int((v1.z-zlo)/dz_part);

	if (xindex<0) return false;
	if (yindex<0) return false;
	if (zindex<0) return false;

	if (xindex>int(nx_part-1)) return false;
	if (yindex>int(ny_part-1)) return false;
	if (zindex>int(nz_part-1)) return false;


	for (unsigned int i = 0; i< face.size(); ++i)
	//for (auto i : grid[xindex][yindex][zindex]) 
	{

		Real_t v1_dot_norm = (v1 - vertex[face[i][0]])* normal[i];

		bool is_inside = false;
		if (v1_dot_norm-radius<0 && v1_dot_norm+radius > -thickness) {  // if true it may be inside the face //
													// if the particle has radius, we have to put it in	
													// this condition
			is_inside = true;
			for (unsigned int j=0; j<face[i].size(); ++j) {

				Vector<Real_t> v2 = v1- vertex[face[i][j]];

				Real_t dotdot = v2 * edge_norms3[i][j];

				if (dotdot<0) {is_inside=false;break;}
				// note that the polygon need to be convex for this formula to be true.
				// check whether (v4_dot_norm_line>0) is correct or (v4_dot_norm_line<0). One of them is disasterous
				
			}
		}
		if (is_inside) {
			return true;
		} 
	}

	return false;
}

bool Polyhedron_Point_Inside::check_inside_ray (NS_geometry::Polyhedron &p_object, const Vector<Real_t> &v1, const int ray_axis) { 



	  const auto & vertex = p_object.vertex;
 	  const auto & face = p_object.face;
 	  const auto & normal = p_object.normal;

	
    bool inside_shape = false; // inside atleast one of the shapes
  
    for (unsigned int i=0; i<face.size(); ++i) {

      Vector<Real_t> v_pr = v1;
      const auto v0 = vertex[face[i][0]];
      const auto n = normal[i];

#define VEC_GREATER_THAN_VERTEX(VAR,AXIS) \
 	if (VAR.AXIS > vertex[face[i][0]].AXIS && VAR.AXIS > vertex[face[i][1]].AXIS && VAR.AXIS > vertex[face[i][2]].AXIS ) continue;
#define VEC_LESS_THAN_VERTEX(VAR,AXIS) \
  if (VAR.AXIS < vertex[face[i][0]].AXIS && VAR.AXIS < vertex[face[i][1]].AXIS && VAR.AXIS < vertex[face[i][2]].AXIS ) continue;
      
      VEC_GREATER_THAN_VERTEX(v1,z)
      VEC_GREATER_THAN_VERTEX(v1,x)
      VEC_GREATER_THAN_VERTEX(v1,y)      
      
      if (ray_axis == 0) {
       	if (std::abs(n.x) < 1e-9) continue;        
        v_pr.x = v0.x + (n.z*(-v1.z + v0.z) + n.y*(-v1.y + v0.y))/n.x;
        VEC_LESS_THAN_VERTEX(v1,y)
        VEC_LESS_THAN_VERTEX(v1,z)
        VEC_LESS_THAN_VERTEX(v_pr,x)

        VEC_GREATER_THAN_VERTEX(v_pr,x)        

      } else if (ray_axis == 1) {
       	if (std::abs(n.y) < 1e-9) continue;        
        v_pr.y = v0.y + (n.x*(-v1.x + v0.x) + n.z*(-v1.z + v0.z))/n.y;
        VEC_LESS_THAN_VERTEX(v1,x)
        VEC_LESS_THAN_VERTEX(v1,z)
        VEC_LESS_THAN_VERTEX(v_pr,y)    
        VEC_GREATER_THAN_VERTEX(v_pr,y)        

      } else if (ray_axis == 2) {
       	if (std::abs(n.z) < 1e-9) continue;        
        v_pr.z = v0.z + (n.x*(-v1.x + v0.x) + n.y*(-v1.y + v0.y))/n.z;
        VEC_LESS_THAN_VERTEX(v1,x)
        VEC_LESS_THAN_VERTEX(v1,y)
        VEC_LESS_THAN_VERTEX(v_pr,z)     
        VEC_GREATER_THAN_VERTEX(v_pr,z)        

      } else continue;
      
#undef VEC_LESS_THAN_VERTEX
#undef VEC_GREATER_THAN_VERTEX

      const auto PA = vertex[face[i][0]] - v_pr;  
      const auto PB = vertex[face[i][1]] - v_pr;        
      const auto PC = vertex[face[i][2]] - v_pr;
      
      const auto PAB = cross_product(PA, PB);
      const auto PBC = cross_product(PB, PC);      
      const auto PCA = cross_product(PC, PA);
      
      const auto PABPBC = PAB*PBC;
      const auto PBCPCA = PBC*PCA;
      const auto PCAPAB = PCA*PAB;
      
      if ((PABPBC<0 && PBCPCA<0 && PCAPAB<0) || (PABPBC>0 && PBCPCA>0 && PCAPAB>0)){
        inside_shape = !inside_shape;        
			} 
			
    }
    
  if (inside_shape) return true; // inside at least one of the shapes
   
  return false;
    
}


} //namespace

FINE_CUPPA_NAMESPACE_CLOSE

