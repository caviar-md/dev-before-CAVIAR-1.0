#include "atom_data_simple.h"

#include "fine_cuppa_config.h"

FINE_CUPPA_NAMESPACE_OPEN

Atom_data_simple::Atom_data_simple (MD *md) : Atom_data{md} {}

void Atom_data_simple::allocate () {
  
}

FINE_CUPPA_NAMESPACE_CLOSE

