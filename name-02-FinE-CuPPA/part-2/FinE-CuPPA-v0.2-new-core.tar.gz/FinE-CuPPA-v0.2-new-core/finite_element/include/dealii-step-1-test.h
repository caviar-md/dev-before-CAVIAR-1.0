#ifndef DEALII_STEP_1_TEST_H
#define DEALII_STEP_1_TEST_H

#include <deal.II/grid/tria.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/manifold_lib.h>
#include <deal.II/grid/grid_out.h>
#include <iostream>
#include <fstream>

#include <cmath>
using namespace dealii;


namespace dealii_step_1 {


void first_grid ();

void second_grid ();
}

#endif
