#include "md.h"

#include "fine_cuppa_config.h"

#include <string>

#include "communicator.h"
#include "input.h"
#include "output.h"
#include "error.h"
#include "atom_data.h"
#include "atom_data_simple.h"
#include "domain.h"
#include "update.h"
#include "neighbor.h"
#include "writer.h"
#include "object_handler.h"
#include "object_container.h"
#include "object_creator.h"

FINE_CUPPA_NAMESPACE_OPEN

#ifdef USE_MPI
MD::MD (int argc, char **argv, MPI_Comm mpi_comm) :
  mpi_comm {mpi_comm},
#else
MD::MD (int argc, char **argv) :
#endif
  comm {new Communicator {this}},
  error {new Error {this}},
  output {new Output {this}},
  input {new Input {this}},
  domain {new Domain {this}},
  atom_data {new Atom_data_simple {this}},
  update {new Update {this}},
  neighbor {new Neighbor {this}},
  writer {new Writer {this}},
  object_handler {new Object_handler {this}},
  object_container {new Object_container {this}},
  object_creator {new Object_creator {this}},  
  in {std::cin.rdbuf()},
  out {std::cout.rdbuf()},
  err {std::cerr.rdbuf()},
  log_flag {true},
  out_flag {true},
  err_flag {true},
  argc{argc},
  argv{argv} {
    if (comm->me == 0) log.open ("log");
}

MD::~MD () {
	delete writer;
  delete neighbor;
  delete update;
  delete atom_data;
  delete domain;
  delete input;
  delete output;
  delete error;
  delete comm;
	delete object_handler;	
	delete object_container;		
	delete object_creator;		
}

void MD::execute () {
  std::string greeting = "FinE-CuPPA-";
  greeting += std::to_string (FINE_CUPPA_MAJOR_VERSION);
  greeting += ".";
  greeting += std::to_string (FINE_CUPPA_MINOR_VERSION);
  greeting += ".";
  greeting += std::to_string (FINE_CUPPA_PATCH_VERSION);
    
	output->info(greeting);
		
  input->read ();
}

FINE_CUPPA_NAMESPACE_CLOSE

