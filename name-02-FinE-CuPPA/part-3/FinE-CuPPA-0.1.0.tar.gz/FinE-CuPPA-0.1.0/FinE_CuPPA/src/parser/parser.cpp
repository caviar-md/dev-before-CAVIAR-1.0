#define NO_PARSER

#include "fine_cuppa_config.h"

#include "parser.h"

#include <cmath>

#include "error.h"
#include "lexer.h"

FINE_CUPPA_NAMESPACE_OPEN

Parser::Parser (MD *md) : Pointers{md}, token_stream{new Token_stream{md}}, get_new_token{true}, line{token_stream->line}, col{token_stream->col} {}

Parser::Parser (MD *md, const std::string &file) : Pointers{md}, token_stream{new Token_stream{md, file}}, get_new_token{true}, line{token_stream->line}, col{token_stream->col} {}


Parser::~Parser () {
  delete token_stream;
}

bool Parser::end_of_line () {
  Token token = get_raw_token();
  return token.kind == Kind::eol;
}

bool Parser::assignment () {
  Token token = get_raw_token();
  return token.kind == Kind::assign;
}

Token Parser::get_raw_token () {
  if (get_new_token) return token_stream->get();
  else {
    get_new_token = true;
    return token_stream->current();
  }
}

Token Parser::get_val_token () {
  auto token = get_raw_token ();
  switch (token.kind) {
    case Kind::identifier:
    case Kind::string:
    case Kind::int_number:
    case Kind::real_number:
    case Kind::eol:
    case Kind::eof:
      return token;
    
    case Kind::plus:
      token = get_raw_token ();
      switch (token.kind) {
        case Kind::int_number:
        case Kind::real_number:
          return token;
        default:
          error->all (FILE_LINE_FUNC, "Unexpected token");
      }
    
    case Kind::minus:
      token = get_raw_token ();
      switch (token.kind) {
        case Kind::int_number:
          token.int_value *= -1;
          break;
        case Kind::real_number:
          token.real_value *= -1;
          break;
        default:
          error->all (FILE_LINE_FUNC, "Unexpected token");
      }
      return token;
    
    default:
      error->all (FILE_LINE_FUNC, "Unexpected token");
      return token; // WARNING      
  }

}

std::ostream & Parser::write_to_stream (std::ostream &stream) {
  auto token = get_raw_token();
  if (token.kind == Kind::string) stream << token.string_value << std::endl;
  else if (token.kind == Kind::identifier && string_variables.count (token.string_value))
    stream << string_variables.at(token.string_value) << std::endl;
  else stream << expression(false) << std::endl;
  return stream;
}

std::string Parser::get_command_identifier () {
  Token token;
  do {
    token = get_raw_token();
  } while (token.kind == Kind::eol);
  
  switch (token.kind) {
    case Kind::identifier:
      return token.string_value;
    case Kind::eof:
      return "quit";
    default:
      error->all (FILE_LINE_FUNC, "Expected command identifier");
      return ""; //WARNING
  }  
}

std::string Parser::get_identifier () {
  auto token = get_raw_token();
  if (token.kind == Kind::identifier) return token.string_value;
  else error->all (FILE_LINE_FUNC, "Expected identifier");
  return ""; //WARNING  
}

int Parser::get_int () {
  return int (expression (true)); // the function Parser::expression
}

Real_t Parser::get_real () {
  return expression (true); // the funciton Parser::expression
}

std::string Parser::get_string () {
  auto token = get_raw_token();
  if (token.kind == Kind::string) return token.string_value;
  else if (token.kind == Kind::identifier) {
    auto var_name = token.string_value;
    if (string_variables.count (var_name)) return string_variables.at(var_name);
    else {
      std::string tmp = "String variable '";
      tmp += var_name;
      tmp += "' not defined";
      error->all (FILE_LINE_FUNC, tmp);
    }
  } else error->all (FILE_LINE_FUNC, "Expected string");
  return ""; //WARNING
}

int Parser::get_literal_int () {
  auto token = get_val_token();
  if (token.kind == Kind::int_number) return token.int_value;
  else error->all (FILE_LINE_FUNC, "Expected integer literal");
  return 0;//WARNING  
}

Real_t Parser::get_literal_real () {
  auto token = get_val_token();
  switch (token.kind) {
    case Kind::real_number:
      return token.real_value;
    
    case Kind::int_number:
      return token.int_value;
      
    default:
      error->all (FILE_LINE_FUNC, "Expected real number literal");
  }
  return 0;//WARNING  
}

std::string Parser::get_literal_string () {
  auto token = get_val_token();
  if (token.kind == Kind::string) return token.string_value;
  else error->all (FILE_LINE_FUNC, "Expected string literal");
  return ""; //WARNING
}

double Parser::expression (bool get) {
  double left = term(get);
  for (;;) {
    switch (token_stream->current().kind) {
      case Kind::plus:
        left += term(true);
        break;
      case Kind::minus:
        left -= term(true);
        break;
      default:
        get_new_token = false;
        return left;
    }
  }
  return 0;//WARNING  
}

double Parser::term (bool get) {
  double left = primary(get);
  for (;;) {
    switch (token_stream->current().kind) {
      case Kind::mul:
        left *= primary(true);
        break;
      case Kind::div:
        if (auto d = primary(true)) {
          left /= d;
          break;
        }
        error->all (FILE_LINE_FUNC, "division by zero");
      case Kind::truediv:
        if (auto d = primary(true)) {
          left /= d;
          left = int(left);
          break;
        }
        error->all (FILE_LINE_FUNC, "division by zero");
      case Kind::modulus:
        if (auto d = primary(true)) {
          left = std::fmod (left, d);
          break;
        }
        error->all (FILE_LINE_FUNC, "division by zero");
      default:
        return left;
    }
  }
  return 0;//WARNING  
}

double Parser::primary (bool get) {
  if (get) get_raw_token ();
  switch (token_stream->current().kind) {
    case Kind::int_number: {
      int v = token_stream->current().int_value;
      get_raw_token ();
      return v;
    }
    
    case Kind::real_number: {
      double v = token_stream->current().real_value;
      get_raw_token ();
      return v;
    }
    
    case Kind::identifier: {
      std::string var_name = token_stream->current().string_value;
      get_raw_token ();
      if (int_variables.count (var_name)) return int_variables.at (var_name);
      else if (real_variables.count (var_name)) return real_variables.at (var_name);
      else {
        std::string tmp = "Numeric variable '";
        tmp += var_name;
        tmp += "' not defined";
        error->all (FILE_LINE_FUNC, tmp);
      }
    }
    
    case Kind::minus:
      return -primary(true);
    
    case Kind::lp: {
      auto e = expression(true);
      if (token_stream->current().kind != Kind::rp) error->all (FILE_LINE_FUNC, "')' expected");
      get_raw_token ();
      return e;
    }
    
    default:
      error->all (FILE_LINE_FUNC, "primary expected");
  }
  return 0;//WARNING
}

FINE_CUPPA_NAMESPACE_CLOSE

