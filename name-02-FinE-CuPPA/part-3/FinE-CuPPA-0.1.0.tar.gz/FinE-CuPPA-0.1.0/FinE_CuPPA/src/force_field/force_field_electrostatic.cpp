#include "force_field_electrostatic.h"

#include "fine_cuppa_config.h"

#include <cmath>
#include <boost/algorithm/string.hpp>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "output.h"
#include "object_handler_all.h"
#include "object_container.h"

FINE_CUPPA_NAMESPACE_OPEN

Force_field_electrostatic::Force_field_electrostatic (MD *md) : Force_field{md}, k_electrostatic{1.0}, external_field{Vector<double>{0,0,0}}, output{md->output}, error{md->error} {
	output->info ("A electrostatic force field is created.");
}

bool Force_field_electrostatic::read (Parser *parser) {
	output->info("Force_field electrostatic read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
		if (boost::iequals(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
	    if (cutoff < 0.0) error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");		  
		} else if (boost::iequals(t,"external_field")) {
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(external_field, "", "");
      //if (vector_value < 0)  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");      
		}	else if (boost::iequals(t,"k_electrostatic")) {
      GET_OR_CHOOSE_A_REAL(k_electrostatic,"","")		
      if (k_electrostatic < 0)  error->all (FILE_LINE_FUNC, "k_electrostatic has to be non-negative.");            
		} else error->all (FILE_LINE_FUNC, "Molecule: read: Unknown variable or command");
	}
	
	return in_file;
}

void Force_field_electrostatic::calculate_acceleration () {

 const auto &pos = atom_data -> owned.position;
   

	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto mass_i = atom_data -> owned.mass [ type_i ];
	  const auto charge_i = atom_data -> owned.charge [ type_i ];
	  for (unsigned int j=i+1;j<pos.size();++j) {
 		  const auto type_j = atom_data -> owned.type [j] ;
	    const auto mass_j = atom_data -> owned.mass [ type_j ];
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	    
      const auto dr = pos[j] - pos[i]; 
      const auto dr_sq = dr*dr;
      const auto dr_norm = std::sqrt(dr_sq);      
	    const auto force = k_electrostatic * charge_i * charge_j * dr / (dr_sq*dr_norm);
			atom_data -> owned.acceleration [i] -= force / mass_i;
      atom_data -> owned.acceleration [j] += force / mass_j; // no periodic boundary condition yet
	  }
	  
	  const auto force = external_field * charge_i;
		atom_data -> owned.acceleration [i] += force / mass_i;    
	}  


}

FINE_CUPPA_NAMESPACE_CLOSE

