#include "shape_circle.h"

#include "fine_cuppa_config.h"

#include "object_handler_all.h"
#include "object_container.h"
#include "parser.h"
#include "lexer.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_shape {

		Circle::Circle (MD *md) : Shape {md},
		  flatness_tol{0.001},	object_container{md->object_container}, output{md->output}, error{md->error} {}
		Circle::~Circle() {}
		
		bool Circle::read(Parser * parser) {
			output->info("Data_reader_Kakaka: CIRCLE read");
			bool in_file = true;
			

			while(true) {
				GET_A_TOKEN_FOR_CREATION
				ASSIGN_REAL_3D_VECTOR(center,"CIRCLE read: ","")
				else ASSIGN_REAL_3D_VECTOR(normal,"CIRCLE read: ","")
				else ASSIGN_REAL(radius,"CIRCLE read:","")
				else ASSIGN_REAL(flatness_tol,"CIRCLE read:","")
				else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: CIRCLE read: Unknown variable or command");
			}
	
			return in_file;;

		}

		bool Circle::on_the_plane(const Vector<double> &v) {
			Vector<double> v_1 = v - center;
			if (v_1*normal>flatness_tol)
				return false;
			return true;
		}

		bool Circle::is_inside(const Vector<double> &v) {
			if (!on_the_plane(v))
				return false;
			Vector<double> v_1 = v - center;
			if (v_1*v_1 > radius*radius)
				return false;
			return true;
		}
		
		bool Circle::is_inside(const Vector<double> &v, const double r) {	
			if (!on_the_plane(v))
				return false;
			Vector<double> v_1 = v - center;
			if (v_1*v_1 > (radius-r)*(radius-r))
				return false;
			return true;
		}		
		bool Circle::is_outside(const Vector<double> &v) {		
		  return !is_inside(v);
		}
		
		bool Circle::is_outside(const Vector<double> &v, const double r) {		
		  return !is_inside(v,r);
		}
		
		bool Circle::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
      std::cout << "incomplete function:" << __FILE__<<__LINE__<<__func__  << std::endl;	
      std::cout << "  " << v << r << contact_vector   << std::endl; 		
			return false;
		}
	
}

FINE_CUPPA_NAMESPACE_CLOSE

