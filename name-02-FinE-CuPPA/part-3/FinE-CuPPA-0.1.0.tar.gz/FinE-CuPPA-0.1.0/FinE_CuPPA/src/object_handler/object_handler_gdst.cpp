#include "object_handler_gdst.h"

#include "fine_cuppa_config.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_object_handler {

int gdst (const std::string & t) { //get_dictionary_second_type 
	std::map<std::string,int>::const_iterator it;
	it = NS_object_handler::dictionary_second_type.find(t);
	if (it == NS_object_handler::dictionary_second_type.end()) return 0;
	else return it->second;
}

}

FINE_CUPPA_NAMESPACE_CLOSE

