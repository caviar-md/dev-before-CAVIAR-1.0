#ifndef WRITER_H
#define WRITER_H

#include "fine_cuppa_config.h"

#include "pointers.h"

FINE_CUPPA_NAMESPACE_OPEN

class Writer : protected Pointers {
public:
  Writer (class MD *);
private:
  
};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
