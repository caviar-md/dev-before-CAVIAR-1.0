#ifndef OBJECT_UTILITY_ELEMENT_H
#define OBJECT_UTILITY_ELEMENT_H

#include "fine_cuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "parser.h"
#include "output.h"
#include "error.h"

FINE_CUPPA_NAMESPACE_OPEN

namespace NS_object_utility {

class Element {
	public:
		Element () ;
		Element (class Object_container *) ;		
		//Element (class Object_container *, double m, double r, double ch);
		~Element ();
    double get_radius () const {
      return radius;
    }
    double get_mass () const {
      return mass;
    }
    double get_charge () const {
      return charge;
    }            
    unsigned int get_element_index() const {
      return element_index;
    }
		bool read (Parser *);
	private:
		unsigned int element_index;
		double mass, radius, charge;
			
		class Output * output;
		class Error * error;
	  class Object_container * object_container;


};

} 

FINE_CUPPA_NAMESPACE_CLOSE

#endif
 
