#ifndef FORCE_FIELD_GEOMETRY_LJ_10_4_H
#define FORCE_FIELD_GEOMETRY_LJ_10_4_H

#include "fine_cuppa_config.h"

#include "force_field.h"

#include <vector>
#include <map>

#include "polyhedron_handler.h"
#include "shape.h"

FINE_CUPPA_NAMESPACE_OPEN

class Force_field_geometry_lj_10_4 : public Force_field {
public:
  Force_field_geometry_lj_10_4 (class MD *);
  ~Force_field_geometry_lj_10_4 ();
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:	
  std::vector<NS_shape::Shape *> shape;
  std::vector<std::vector<Real_t>> epsilon, sigma;
  Real_t wall_number_density;
  
  class Parser *parser;
	class Output *output;
	class Error *error;

};

FINE_CUPPA_NAMESPACE_CLOSE

#endif
