#ifndef ERROR_H
#define ERROR_H

#include "finecuppa_config.h"

#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

class Error : protected Pointers {
public:
  Error (MD *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const char *);
  void one (const char *, int, const char *, const std::string &, unsigned int, const char *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
  void one (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
};

FINECUPPA_NAMESPACE_CLOSE

#endif
