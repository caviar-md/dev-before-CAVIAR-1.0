#ifndef FINE_CUPPA_CONFIG_H
#define FINE_CUPPA_CONFIG_H

#define FINECUPPA_NAMESPACE_OPEN namespace fine_cuppa {
#define FINECUPPA_NAMESPACE_CLOSE }

#define FINECUPPA_MAJOR_VERSION 0
#define FINECUPPA_MINOR_VERSION 5
#define FINECUPPA_PATCH_VERSION 0

// #ifndef USE_MD_MPI
// #define USE_MD_MPI
// #endif


// #ifndef USE_DEALII
// #define USE_DEALII
// #endif

#endif
