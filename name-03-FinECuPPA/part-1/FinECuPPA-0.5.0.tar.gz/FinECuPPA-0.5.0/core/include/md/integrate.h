#ifndef INTEGRATE_H
#define INTEGRATE_H

#include "finecuppa_config.h"

#include "pointers.h"

#include <random>

FINECUPPA_NAMESPACE_OPEN

class Integrate : protected Pointers {
public:
  Integrate (class MD *);
 	 
  bool run (unsigned int, double);
private:
	class Output *output;

  void step ();
  void setup ();
  void cleanup ();
  void velocity_verlet ();
  void velocity_verlet_Langevin ();
	bool boundary_condition ();
	Real_t dt;
	
	std::mt19937 rnd_generator;
	std::normal_distribution<double> rnd_ndist; // stddev() == 1	
};

FINECUPPA_NAMESPACE_CLOSE

#endif
