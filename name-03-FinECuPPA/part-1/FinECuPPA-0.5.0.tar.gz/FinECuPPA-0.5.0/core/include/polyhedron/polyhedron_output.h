#ifndef POLYHEDRON_OUTPUT_H
#define POLYHEDRON_OUTPUT_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_geometry {
class Polyhedron_Output : protected Pointers{
public:
  Polyhedron_Output (class MD *);
  ~Polyhedron_Output ();
  
	void mesh_povray (const NS_geometry::Polyhedron &, std::string file = "o_mesh.pov"); // povray output mesh ".pov"
	void mesh_tcl (const NS_geometry::Polyhedron &, std::string file = "o_mesh.tcl"); // vmd output mesh ".tcl"
	void normals_tcl (const NS_geometry::Polyhedron &, std::string file = "o_normals.tcl" ); // vmd output normals ".tcl"
	void edges_tcl (const NS_geometry::Polyhedron &, std::string file = "o_edges.tcl"); // vmd output edges  ".tcl"
   
	//void mesh_povray (const std::vector<NS_geometry::Polyhedron> &); // povray output mesh ".pov"
//	void mesh_vmd (const std::vector<NS_geometry::Polyhedron> &); // vmd output mesh ".tcl"
//	void normals_vmd (const std::vector<NS_geometry::Polyhedron> &); // vmd output normals ".tcl"
	//void edges_vmd (const std::vector<NS_geometry::Polyhedron> &); // vmd output edges  ".tcl"
   

};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
