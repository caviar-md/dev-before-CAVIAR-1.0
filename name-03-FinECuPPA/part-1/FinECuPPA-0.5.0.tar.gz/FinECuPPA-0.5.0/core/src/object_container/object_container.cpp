#include "object_container.h"

#include "finecuppa_config.h"

FINECUPPA_NAMESPACE_OPEN

Object_container::Object_container (MD *md) : Pointers{md} {
}

Object_container::~Object_container () {
  for (auto i : shape)
    delete i;
  for (auto i : force_field)
    delete i;
//  for (auto i : finite_element)
//    delete i;    
}

FINECUPPA_NAMESPACE_CLOSE

