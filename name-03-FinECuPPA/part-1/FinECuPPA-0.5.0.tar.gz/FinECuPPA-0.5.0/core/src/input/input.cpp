#include "input.h"

#include "finecuppa_config.h"

#include <map>
#include <cmath>
#include <algorithm>

#include "error.h"
#include "parser.h"
#include "update.h"
#include "output.h"
#include "data_reader_all.h"
#include "atom_data_all.h"
#include "input_commands_map.h"
#include "object_handler.h"
#include "object_container.h"
#include "object_creator.h"

FINECUPPA_NAMESPACE_OPEN

Input::Input (MD *md) : Pointers {md}, parser {new Parser{md}} {}

Input::Input (MD *md, const std::string &file) : Pointers {md}, parser {new Parser{md, file}} {}

Input::~Input () {
  delete parser;
}

void Input::read (Parser * parser) {
  while (read_command (parser));
}

void Input::read () {
  while (read_command (parser));
}

bool Input::read_command (Parser * parser) {
  auto command = parser->get_command_identifier();
  auto command_lowercase = command;
  std::transform(command_lowercase.begin(), command_lowercase.end(), command_lowercase.begin(), ::tolower);  //transform command to lower case
  
  if (commands_map.count (command_lowercase) != 0) 
    return (this->*commands_map.at(command_lowercase)) (parser);
  else if (object_creator->commands_map.count (command_lowercase) != 0) {
    return (object_creator->*object_creator->commands_map.at(command_lowercase)) (parser);
  } else if (object_handler->commands_map.count (command_lowercase) != 0) {
    return (object_handler->*object_handler->commands_map.at(command_lowercase)) (parser);
  } else if (object_container->all_names.count(command) != 0){ // object name is case sensitive
    return object_handler->read_object (parser, command);
  } else {
		error->all (FILE_LINE_FUNC, "Invalid command or object NAME");
  }
  return true;  
}

bool Input::read_script_from_file (Parser *) {
  return true;
}
/*
bool Input::atom_style (Parser *) {
  auto atom_style_identifier = parser->get_identifier();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  if (atom_style_identifier != "simple") {
    delete atom_data;
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)     \
    if (reader_identifier == #key) atom_data = new Class {md};
#include "all_atom_data.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  }
  return true;
}
*/

bool Input::read_data_with_format (Parser *) {
	bool correct_read_data_type = false;
  // the following two initialization must be on separate lines to insure correct order
  auto reader_identifier = parser->get_identifier();
  auto file_name = parser->get_string();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  
#define DATA_READER_CLASS
#define DataReaderStyle(key,Class)                \
  if (reader_identifier == #key) {                \
    correct_read_data_type = true;                \
    auto data_reader = new Class (md, file_name); \
    auto result = data_reader->read ();           \
    delete data_reader;                           \
    return result;                                \
  }
#include "data_reader_all.h"
#undef DataReaderStyle
#undef DATA_READER_CLASS
  if (! parser->end_of_line () || !correct_read_data_type ) error->all (FILE_LINE_FUNC, "Invalid syntax. this type of data_reader doesn't exist.");    
  return false;
}



bool Input::periodic_boundary (Parser *) {
  auto xbc = parser->get_int(); atom_data->x_bc = xbc;
  auto ybc = parser->get_int(); atom_data->y_bc = ybc;
  auto zbc = parser->get_int(); atom_data->z_bc = zbc;
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
	return true;
}

bool Input::time_step (Parser *) {
  auto d_t = parser->get_real();	md->update->dt = d_t;
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
	return true;
}
bool Input::output_step (Parser *) {
	output->set_parameters (parser);
	return true;
}

bool Input::run_simulation (Parser *) {
  auto num_steps = parser->get_int();
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  return update->run (num_steps);
}

bool Input::print (Parser *) {
  parser->write_to_stream (std::cout);
  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax. Expected end of line.");
  return true;
}

bool Input::exit_program (Parser *) {
  return false;
}

bool Input::delete_object (Parser *) {
  return true;
}

FINECUPPA_NAMESPACE_CLOSE

