
## About Scripts

This folder contains the script in which you can call for your program. They are written in FinECuPPA language.
They can easily be used in your code.
