
This directory contains the test suit which all of them have to be done before
each version release. It also contains some tests for the implementation of the
algorithms.


After any new version or after any change in FinECuPPA syntax, maybe all of the
scripts for the runtime tests has to be checked and updated.


Categories of the tests:
- build with all permutations of cmake options.
- run with all permutations of cmake options.


