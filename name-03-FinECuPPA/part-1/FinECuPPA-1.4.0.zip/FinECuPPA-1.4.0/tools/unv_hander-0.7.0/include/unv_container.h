#ifndef UNV_CONTAINER_H
#define UNV_CONTAINER_H

#include <vector>
#include "universal_dataset_number_all.h"
#include "vector.h"

namespace NS_mesh_handler {


class Unv_container {
public:
  Unv_container ();
  ~Unv_container ();  

  
  std::vector<Universal_dataset_number_2411> udn_2411;
  std::vector<Universal_dataset_number_2412> udn_2412;
  std::vector<Universal_dataset_number_2467> udn_2467;
  std::vector<Universal_dataset_number_unsupported> udn_unsupported;
  
};

}

#endif



