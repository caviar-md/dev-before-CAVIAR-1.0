#include "unv_handler.h"

#include <iostream>
#include <algorithm>    // std::sort, std::count

#define POW2(X) X*X
namespace NS_mesh_handler {

  
  void Unv_handler::remove_similar_points (const double tol_sqr) {
    unsigned uci = unv_container.size() - 1;    

    auto &udn_2411 = unv_container[uci].udn_2411;
    auto num_of_points = udn_2411.size();
    std::vector<std::vector<unsigned>> similar_points;
    std::vector<unsigned> similar_list;
    std::vector<unsigned> to_remove;
    similar_points.resize (num_of_points);

    for (unsigned i = 0; i < num_of_points ; ++i) {
    
      if (std::count(similar_list.begin(), similar_list.end(), i+1)>0) 
        continue;
        

      
      for (unsigned j = i+1; j < num_of_points ; ++j) {
        double distance = POW2((udn_2411[i].record2[0] - udn_2411[j].record2[0]))
                        + POW2((udn_2411[i].record2[1] - udn_2411[j].record2[1]))
                        + POW2((udn_2411[i].record2[2] - udn_2411[j].record2[2]));
                              
        if (distance < tol_sqr) {

          similar_points[i].push_back (j+1);
          similar_list.push_back (j+1);
          to_remove.push_back(j);
        }
      }
    }

    if (similar_list.size()==0) return;
    
    auto &udn_2412 = unv_container[uci].udn_2412;
    for (unsigned i = 0; i < udn_2412.size() ; ++i) {
                 
      int FE_Id = udn_2412[i].record1[1];
      bool beam_type = (FE_Id==11 || FE_Id==21 || FE_Id==22 || FE_Id==23 || FE_Id==24);
      unsigned num_of_elements = unv_container[uci].udn_2412[i].record1[5];
      
      for (unsigned j = 0; j < num_of_elements ; ++j) {
        for (unsigned m = 0; m < similar_points.size() ; ++m) {
          for (unsigned n = 0; n < similar_points[m].size() ; ++n) {            
            
            if (beam_type) {              
              if (udn_2412[i].record3[j] == similar_points[m][n]) {              
                udn_2412[i].record3[j] = m+1;        
              }
            } else {        
              if (udn_2412[i].record2[j] == similar_points[m][n]) {              
                udn_2412[i].record2[j] = m+1;      
              }                
            }
                      
          }        
        }      
      }         
    }
    
    std::cout << "no_similar_points: " << to_remove.size() << "\n";
    std::sort(to_remove.begin(), to_remove.end(), std::greater<unsigned>());
    for (unsigned i = 0 ; i < to_remove.size(); ++i) 
      udn_2411.erase(udn_2411.begin() + to_remove[i]);     
    
  }  
}
