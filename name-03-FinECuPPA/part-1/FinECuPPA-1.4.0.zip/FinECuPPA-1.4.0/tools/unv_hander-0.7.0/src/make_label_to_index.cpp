#include "unv_handler.h"

//#include <iostream>
//#include <algorithm>    // std::sort, std::count

namespace NS_mesh_handler {

  void Unv_handler::make_label_to_index (const std::vector<Universal_dataset_number_2411> & u
                           ,std::vector<unsigned> & v) {

    unsigned max = 0;
    for (unsigned i = 0; i < u.size(); ++i) 
      if (max < u[i].record1[0]) 
        max = u[i].record1[0];
    
    v.resize(max, 0);
    for (unsigned i = 0; i < u.size(); ++i) 
      v[u[i].record1[0]] = i;      
   
  }
  
  void Unv_handler::make_label_to_index (const std::vector<Universal_dataset_number_2412> & u
                           ,std::vector<unsigned> & v) {
    unsigned max = 0;
    for (unsigned i = 0; i < u.size(); ++i) 
      if (max < u[i].record1[0]) 
        max = u[i].record1[0];
    
    v.resize(max, 0);
    for (unsigned i = 0; i < u.size(); ++i) 
      v[u[i].record1[0]] = i;            
      
  }

  
}  
