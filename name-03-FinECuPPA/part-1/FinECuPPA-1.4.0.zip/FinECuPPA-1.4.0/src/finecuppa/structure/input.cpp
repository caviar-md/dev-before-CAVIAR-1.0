#include "finecuppa/structure/input.h"
#include "finecuppa/structure/object_creator.h"
#include "finecuppa/structure/input/commands_map.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/tools.h"

#include <map>
#include <cmath>
#include <algorithm>

FINECUPPA_NAMESPACE_OPEN

Input::Input (FinECuPPA *fptr) : Pointers {fptr}, parser {new Parser{fptr}} {}

Input::Input (FinECuPPA *fptr, const std::string &file) : Pointers {fptr}, parser {new Parser{fptr, file}} {}

Input::~Input () {
  delete parser;
}

void Input::read (Parser * parser) {
  while (read_command (parser));
}

void Input::read () {
  while (read_command (parser));
}

bool Input::read_command (Parser * parser) {
  auto command = parser->get_command_identifier();
  auto command_lowercase = command;
#ifdef FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE
  std::transform(command_lowercase.begin(), command_lowercase.end(), command_lowercase.begin(), ::tolower);  //transform command to lower case
#endif  
  if (commands_map.count (command_lowercase) != 0) 
    return (this->*commands_map.at(command_lowercase)) (parser);
  else if (object_creator->commands_map.count (command_lowercase) != 0) {
    return (object_creator->*object_creator->commands_map.at(command_lowercase)) (parser);
  } else if (object_handler->commands_map.count (command_lowercase) != 0) {
    return (object_handler->*object_handler->commands_map.at(command_lowercase)) (parser);
  } else if (object_container->all_names.count(command) != 0){ // object name is case sensitive
    return object_handler->read_object (parser, command);
  } else {
    error->all (FC_FILE_LINE_FUNC_PARSE, "Invalid command or object NAME");
  }
  return true;  
}

bool Input::read_script_from_file (Parser *) {
  return true;
}

bool Input::exit_program (Parser *) {
  return false;
}

bool Input::call_output (Parser *) {
  return output->read (parser);
}

bool Input::call_object_container (Parser *) {
  return object_container->read (parser);
}


FINECUPPA_NAMESPACE_CLOSE

