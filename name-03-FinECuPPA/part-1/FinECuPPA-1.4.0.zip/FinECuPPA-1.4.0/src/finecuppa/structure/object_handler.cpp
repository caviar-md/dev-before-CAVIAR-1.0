#include "finecuppa/structure/object_handler.h"
#include "finecuppa/structure/object_handler/all.h"
#include "finecuppa/structure/object_handler/commands_map.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/all_base.h"
#include "finecuppa/objects/utility/all.h"
#include "finecuppa/objects/shape/boundary.h"

FINECUPPA_NAMESPACE_OPEN

Object_handler::Object_handler (FinECuPPA *fptr) : Pointers{fptr} {}

Object_handler::~Object_handler () {

}


bool Object_handler::read_object (Parser * parser, const std::string object_name) {

  bool in_file = true;
  object_container = fptr->object_container;
  
  std::map<std::string,object_handler::Dictionary>::iterator it;
  it = object_container -> dictionary.find(object_name);  
  
  if (it == object_container -> dictionary.end())
    error->all (FC_FILE_LINE_FUNC_PARSE, "Object_handler : read : Invalid object NAME");

#define FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(OBJECT_TYPE) \
  if (it->second.type == object_handler::gdst(#OBJECT_TYPE)) \
    {in_file = object_container -> OBJECT_TYPE [it->second.index]->read(parser);\
     return in_file;} 

  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(element)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(atom)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(molecule)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(shape)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(random_1d)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(grid_1d)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(boundary)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(distribution)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(force_field)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(finite_element)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(simulator)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(domain)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(atom_data)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(integration)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(neighborlist)
  FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION(long_range_solver)

#undef FINECUPPA_LOCAL_CHECK_AND_RUN_READ_FUNCTION
  return in_file; //WARNING
}

FINECUPPA_NAMESPACE_CLOSE

