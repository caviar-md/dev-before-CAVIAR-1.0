#include "finecuppa/structure/object_creator.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/all_objects.h"

FINECUPPA_NAMESPACE_OPEN

#define FINECUPPA_LOCAL_GET_OBJECT_NAME(OBJECT_TYPE)\
  std::string st = #OBJECT_TYPE;\
  st.append(" creation"); \
  output->info(st, 0, false); \
  std::string NAME = ""; \
  bool name_called = false; \
  bool in_file = true; \
  std::string object_type = ""; \
  while(true) { \
    GET_A_TOKEN_FOR_CREATION \
    ASSIGN_NAME \
    else GET_A_STRING_NNT(object_type, #OBJECT_TYPE, "") \
  }


#define FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(OBJECT_TYPE) \
  int index = object_container -> OBJECT_TYPE.size ();\
  object_container -> OBJECT_TYPE.push_back (p_sh);\
  object_handler::Dictionary dict (object_handler::gdst(#OBJECT_TYPE), index);\
  object_container -> dictionary.insert (std::make_pair(NAME,dict)); \
  return in_file;


bool Object_creator::force_field (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(force_field)

  objects::Force_field * p_sh;  
  if (string_cmp(object_type, "lj")) {
    p_sh = new objects::force_field::Lj (fptr); 
  } else if (string_cmp(object_type, "lj_acc")) {
    p_sh = new objects::force_field::Lj_acc (fptr); 
  } else if (string_cmp(object_type, "lj_cell_list")) {
    p_sh = new objects::force_field::Lj_cell_list (fptr); 
  } else if (string_cmp(object_type, "granular")) {
    p_sh = new objects::force_field::Granular (fptr); 
  } else if (string_cmp(object_type, "geometry")) {
    p_sh = new objects::force_field::Geometry (fptr); 
  } else if (string_cmp(object_type, "geometry_lj_10_4")) {
    p_sh = new objects::force_field::Geometry_lj_10_4 (fptr); 
  } else if (string_cmp(object_type, "finite_element")) {
    p_sh = new objects::force_field::Finite_element (fptr); 
  } else if (string_cmp(object_type, "dealii_poisson")) {
    p_sh = new objects::force_field::Dealii_poisson (fptr); 
  } else if (string_cmp(object_type, "dealii_poisson_ewald")) {
    p_sh = new objects::force_field::Dealii_poisson_ewald (fptr); 
  } else if (string_cmp(object_type, "gravity")) {
    p_sh = new objects::force_field::Gravity (fptr); 
  } else if (string_cmp(object_type, "electrostatic")) {
    p_sh = new objects::force_field::Electrostatic (fptr); 
  } else if (string_cmp(object_type, "electrostatic_ewald_r")) {
    p_sh = new objects::force_field::Electrostatic_ewald_r (fptr); 
  } else if (string_cmp(object_type, "electrostatic_ewald_k")) {
    p_sh = new objects::force_field::Electrostatic_ewald_k (fptr); 
  } else if (string_cmp(object_type, "electrostatic_ewald_slab_correction")) {
    p_sh = new objects::force_field::Electrostatic_ewald_slab_correction (fptr); 
  } else if (string_cmp(object_type, "dpd")) {
    p_sh = new objects::force_field::Dpd (fptr); 
  } else if (string_cmp(object_type, "dpd_acc")) {
    p_sh = new objects::force_field::Dpd_acc (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined force_field");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(force_field)
}

bool Object_creator::shape (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(shape)

  objects::Shape * p_sh;  
  if (string_cmp(object_type, "circle")) {
    p_sh = new objects::shape::Circle (fptr); 
  } else if (string_cmp(object_type, "sphere")) {
    p_sh = new objects::shape::Sphere (fptr); 
  } else  if (string_cmp(object_type, "closed_lines")) {
    p_sh = new objects::shape::Closed_lines (fptr); 
  } else  if (string_cmp(object_type, "polyhedron")) {
    p_sh = new objects::shape::Polyhedron (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined shape");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(shape)
}


bool Object_creator::finite_element (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(finite_element)

  objects::Finite_element * p_sh;
  if (string_cmp(object_type, "fe_dealii_poisson")) {
#ifdef USE_DEALII  
    p_sh = new objects::finite_element::FE_dealii_poisson (fptr);  
    object_container -> finite_element.push_back (p_sh); 
#else 
    error->all(FC_FILE_LINE_FUNC_PARSE,"FinECuPPA have to be compiled with '-DUSE_DEALII=ON' flag");
#endif    
  }  else if (string_cmp(object_type, "fe_dealii_poisson_mpi")) {
#ifdef USE_DEALII_WITH_MPI
    p_sh = new objects::finite_element::FE_dealii_poisson_mpi (fptr);  
    object_container -> finite_element.push_back (p_sh); 
#else 
    error->all(FC_FILE_LINE_FUNC_PARSE,"FinECuPPA have to be compiled  with '-DUSE_DEALII_WITH_MPI=ON' and '-DUSE_MD_MPI=ON' flag");
#endif    
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined finite_element");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(finite_element)

}

bool Object_creator::boundary (Parser *parser) {

  output->info("boundary creation. ");
  std::string NAME = "";
  bool name_called = false;
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    ASSIGN_NAME
  }

  objects::shape::Boundary *p_sh;
  p_sh = new objects::shape::Boundary (fptr);

  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(boundary)
}

bool Object_creator::long_range_solver (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(long_range_solver)

  objects::Long_range_solver * p_sh;  
  if (string_cmp(object_type, "pppm") ||
      string_cmp(object_type, "p3m") ) {
  //  p_sh = new long_range_solver::PPPM (fptr); 
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT implemented yet");
  } else if (string_cmp(object_type, "ewald")) {
    p_sh = new objects::long_range_solver::Ewald (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined shape");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(long_range_solver)
}

bool Object_creator::integration (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(integration)

  objects::Integration * p_sh;  
  if (string_cmp(object_type, "velocity_verlet")) {
    p_sh = new objects::integration::Velocity_verlet (fptr); 
  } else if (string_cmp(object_type, "velocity_verlet_langevin")) {
    p_sh = new objects::integration::Velocity_verlet_langevin (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined integration");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(integration)
}

bool Object_creator::simulator (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(simulator)

  objects::Simulator * p_sh;  
  if (string_cmp(object_type, "MD")) {
    p_sh = new objects::simulator::Md (fptr); 
  } else if (string_cmp(object_type, "monte_carlo")) {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT implemented yet");
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined simulator");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(simulator)
}

bool Object_creator::atom_data (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(atom_data)

  objects::Atom_data * p_sh;  
  if (string_cmp(object_type, "simple")) {
    p_sh = new objects::atom_data::Simple (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined atom_data");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(atom_data)
}

bool Object_creator::domain (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(domain)

  objects::Domain * p_sh;  
  if (string_cmp(object_type, "box")) {
    p_sh = new objects::domain::Box (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined domain");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(domain)
}

bool Object_creator::neighborlist (Parser *parser) {

  FINECUPPA_LOCAL_GET_OBJECT_NAME(neighborlist)

  objects::Neighborlist * p_sh;  
  if (string_cmp(object_type, "verlet_list")) {
    p_sh = new objects::neighborlist::Verlet_list (fptr); 
  } else if (string_cmp(object_type, "cell_list")) {
    p_sh = new objects::neighborlist::Cell_list (fptr); 
  } else {
    error->all(FC_FILE_LINE_FUNC_PARSE,"NOT defined neighborlist");
  }
  
  FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER(neighborlist)
}

#undef FINECUPPA_LOCAL_GET_OBJECT_NAME
#undef FINECUPPA_LOCAL_ADD_OBJECT_TO_CONTAINER

FINECUPPA_NAMESPACE_CLOSE

