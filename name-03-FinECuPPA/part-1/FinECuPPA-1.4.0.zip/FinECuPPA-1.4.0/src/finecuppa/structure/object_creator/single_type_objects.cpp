#include "finecuppa/structure/object_creator.h"
#include "finecuppa/objects/utility/all.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN

#define FINECUPPA_OBJECT_CREATOR_FUNCTION(FUNCTION_NAME,CLASS_NAME) \
bool Object_creator::FUNCTION_NAME (Parser * parser) { \
  std::string f_name1 = "Object creator: " ;\
  std::string f_name2 = #FUNCTION_NAME  ;\
  f_name1.append(f_name2);\
  output->info(f_name1);\
  GET_A_TOKEN_FOR_CREATION_NAME_RETURN(token);\
  NAME_ASSIGN_CHECK(token);\
  object_container->all_names.insert(token.string_value);\
  CLASS_NAME *p_sh;\
  p_sh = new CLASS_NAME (fptr);\
  int index = object_container->FUNCTION_NAME.size ();\
  object_container -> FUNCTION_NAME.push_back (p_sh);\
  object_handler::Dictionary dict (object_handler::gdst(#FUNCTION_NAME), index);\
  object_container -> dictionary.insert (std::make_pair(token.string_value,dict));\
  return true;\
} 
 
FINECUPPA_OBJECT_CREATOR_FUNCTION(element,objects::utility::Element)

FINECUPPA_OBJECT_CREATOR_FUNCTION(atom,objects::utility::Atom)

FINECUPPA_OBJECT_CREATOR_FUNCTION(molecule,objects::utility::Molecule)

FINECUPPA_OBJECT_CREATOR_FUNCTION(grid_1d,objects::utility::Grid_1D)

FINECUPPA_OBJECT_CREATOR_FUNCTION(random_1d,objects::utility::Random_1D)

FINECUPPA_OBJECT_CREATOR_FUNCTION(distribution,objects::utility::Distribution)

#undef FINECUPPA_OBJECT_CREATOR_FUNCTION
FINECUPPA_NAMESPACE_CLOSE


