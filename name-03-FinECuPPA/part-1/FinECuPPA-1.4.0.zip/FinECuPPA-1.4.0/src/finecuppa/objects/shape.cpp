#include "finecuppa/objects/shape.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Shape::Shape (FinECuPPA *fptr) : Pointers{fptr} {}
Shape::~Shape () {}

bool Shape::is_outside (const Vector<double> &v) {
  return !is_inside(v);
}
  
bool Shape::is_outside (const Vector<double> &v, const double r) {
  return !is_inside(v, r);
}
} //objects

FINECUPPA_NAMESPACE_CLOSE

