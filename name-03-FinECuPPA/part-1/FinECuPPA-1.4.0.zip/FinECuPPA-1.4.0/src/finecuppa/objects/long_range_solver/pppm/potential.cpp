#include "finecuppa/objects/long_range_solver/pppm.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {


double PPPM::k_space_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::r_space_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::self_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::dipole_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::total_potential (const Vector<double> &r) {
  return k_space_potential(r)+r_space_potential(r);//+self_energy()+dipole_energy();
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

