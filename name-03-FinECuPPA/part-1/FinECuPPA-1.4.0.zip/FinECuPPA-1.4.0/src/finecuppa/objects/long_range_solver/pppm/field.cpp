#include "finecuppa/objects/long_range_solver/pppm.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {

Vector<double> PPPM::k_space_field (const Vector<double> &r) {
  Vector<double> external_field_k {0, 0, 0};
  external_field_k = r;
  return external_field_k;
}
Vector<double> PPPM::k_space_field (int i) {
  Vector<double> external_field_k {0, 0, 0};
  return i*external_field_k;
}
Vector<double> PPPM::r_space_field (const Vector<double> &r) {
  Vector<double> external_field_r {0, 0, 0};
  external_field_r = r;
  return external_field_r;
}
Vector<double> PPPM::r_space_field (int i) {
  Vector<double> external_field_r {0, 0, 0};
  return i*external_field_r;
}
Vector<double> PPPM::dipole_field ( ) {
  Vector<double> external_field_dipole {0, 0, 0};
  return external_field_dipole;
}

Vector<double> PPPM::total_field (const Vector<double> &r) {
  return k_space_field(r)+r_space_field(r);//+self_field(i)+dipole_field(i);
}
Vector<double> PPPM::total_field (int i) {
  return k_space_field(i)+r_space_field(i);//+self_field(i)+dipole_field(i);
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

