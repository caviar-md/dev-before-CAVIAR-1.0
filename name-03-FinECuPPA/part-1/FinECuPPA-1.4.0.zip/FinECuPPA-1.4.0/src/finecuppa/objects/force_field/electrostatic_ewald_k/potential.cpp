#include "finecuppa/objects/force_field/electrostatic_ewald_k.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/macro_constants.h"

#include <complex>
#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {


double Electrostatic_ewald_k::potential (const Vector<double> &r) {
  double p = k_space_potential(r);
  if (slab_geometry)
    p += slab_geometry_correction_potential(r);
  if (dipole)
    p += dipole_potential_value;
  return p;
}

double Electrostatic_ewald_k::potential (const int i) {
  double p = k_space_potential(i);
  if (slab_geometry)
    p += slab_geometry_correction_potential(i);
  if (dipole)
    p += dipole_potential_value;
  return p;
}

double Electrostatic_ewald_k::k_space_potential (const Vector<double> &r) {
// XXX Working scheme
/*
  double sum_k = 0;

  static std::complex<double> ii(0.0, 1.0);    
  const auto &pos = atom_data -> owned.position;

  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    const auto r_ij = r - pos[j];
    std::complex<double> rho (0,0);
    for (int k = 0; k < n_k_vectors; ++k) {
      rho +=  field_k_coef[k] * std::exp(-ii*(k_vector[k]*r_ij));
    }

    const double rho_norm = std::real(rho);
    sum_k += charge_j * rho_norm;

  }

  return FC_4PI * l_xyz_inv * sum_k * k_electrostatic;
*/

//Re(S_j S_k e(-ik(ri-rj))) = Re(S_k S_j e(-ik(ri-rj))) = Re(S_k e(-ik ri) S_j e(+ik(rj)))

// XXX Working scheme with seperation of 'r' and 'pos_j' vectors
/*
  double sum_k = 0;

  static std::complex<double> ii(0.0, 1.0);    
  const auto &pos = atom_data -> owned.position;

  for (int k = 0; k < n_k_vectors; ++k) {
    const auto k_vector_k = k_vector[k];
    const auto field_k_coef_k = field_k_coef[k];

    std::complex<double> rho (0,0);

    for (unsigned int j=0;j<pos.size();++j) { 
      const auto type_j = atom_data -> owned.type [j] ;
      const auto charge_j = atom_data -> owned.charge [ type_j ];

      rho +=  charge_j * std::exp(ii*(k_vector_k*pos[j]));

    }

    rho *= std::exp(-ii*(k_vector_k*r));

    const double rho_norm = field_k_coef_k*std::real(rho);

    sum_k += rho_norm;
  }
  return FC_4PI * l_xyz_inv * sum_k * k_electrostatic;
*/

// XXX Fastest Working scheme
// /*
  double sum_k = 0;

  static std::complex<double> ii(0.0, 1.0);    

  for (int k = 0; k < n_k_vectors; ++k) {
    const auto k_vector_k = k_vector[k];
    const auto field_k_coef_k = field_k_coef[k];

    auto rho = potential_k_coef_cmplx[k];

    rho *= std::exp(-ii*(k_vector_k*r));

    const double rho_norm = field_k_coef_k*std::real(rho);

    sum_k += rho_norm;
  }
  return FC_4PI * l_xyz_inv * sum_k * k_electrostatic;
// */

}

double Electrostatic_ewald_k::k_space_potential (const int i) {
  return k_space_potential(atom_data-> owned.position[i]);
}

double Electrostatic_ewald_k::slab_geometry_correction_potential (const Vector<double> &r) {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return r.x;
}

double Electrostatic_ewald_k::slab_geometry_correction_potential (const int i) {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return 0.0 * i;
}

double Electrostatic_ewald_k::dipole_potential () {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return 0;
}

double Electrostatic_ewald_k::self_potential ()  {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return 0;
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

