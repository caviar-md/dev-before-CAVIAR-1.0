#include "finecuppa/objects/force_field/electrostatic_ewald_k.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {


Vector<double> Electrostatic_ewald_k::k_space_field (const int i) {
  Vector<double> field {0,0,0};
  const auto &pos = atom_data -> owned.position;    
  static std::complex<double> ii(0.0, 1.0);    

  std::complex<double> sum_kx (0.0, 0.0);
  std::complex<double> sum_ky (0.0, 0.0);
  std::complex<double> sum_kz (0.0, 0.0);

  for (int k = 0; k<n_k_vectors; ++k) {

    const auto sum_j_c = std::conj(potential_k_coef_cmplx[k]);
    const auto c = field_k_coef[k] * sum_j_c * std::exp(ii*(k_vector[k]*pos[i]));   

    sum_kx += k_vector[k].x * c;
    sum_ky += k_vector[k].y * c;
    sum_kz += k_vector[k].z * c;

  }  

  const double sum_jx = std::imag(sum_kx);
  const double sum_jy = std::imag(sum_ky);
  const double sum_jz = std::imag(sum_kz);

  Vector<double> sv {sum_jx, sum_jy, sum_jz};

  const auto sum = FC_4PI *  sv ;

  field =  k_electrostatic * l_xyz_inv * sum;

  return field;
}

Vector<double> Electrostatic_ewald_k::k_space_field (const Vector<double> &r) {
  Vector<double> field {0,0,0};

  static std::complex<double> ii(0.0, 1.0);    

  std::complex<double> sum_kx (0.0, 0.0);
  std::complex<double> sum_ky (0.0, 0.0);
  std::complex<double> sum_kz (0.0, 0.0);

  for (int k = 0; k<n_k_vectors; ++k) {

    const auto sum_j_c = std::conj(potential_k_coef_cmplx[k]);
    const auto c = field_k_coef[k] * sum_j_c * std::exp(ii*(k_vector[k]*r));   

    sum_kx += k_vector[k].x * c;
    sum_ky += k_vector[k].y * c;
    sum_kz += k_vector[k].z * c;

  }  

  const double sum_jx = std::imag(sum_kx);
  const double sum_jy = std::imag(sum_ky);
  const double sum_jz = std::imag(sum_kz);

  Vector<double> sv {sum_jx, sum_jy, sum_jz};

  const auto sum = FC_4PI *  sv ;

  field =  k_electrostatic * l_xyz_inv * sum;

  return field;
}

Vector<double> Electrostatic_ewald_k::dipole_field () {
  const auto &pos = atom_data -> owned.position;
  Vector<double> sum_j {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];   
    sum_j += charge_j* pos[j];
  }
  return FC_4PI * l_xyz_inv * sum_j / (1+2*epsilon_dipole);
}


Vector<double> Electrostatic_ewald_k::slab_geometry_correction_field (int i) {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return Vector<double> {i*0.0,0.0,0.0};
}

Vector<double> Electrostatic_ewald_k::slab_geometry_correction_field (const Vector<double> &r) {
  error->all(FC_FILE_LINE_FUNC, "not implemented");
  return Vector<double> {r.x,0.0,0.0};
}


Vector<double> Electrostatic_ewald_k::field (int i) {
  auto field = k_space_field(i);  
  if (slab_geometry)
    field += slab_geometry_correction_field(i);
  if (dipole)
    field += dipole_field();
  return field;
}

Vector<double> Electrostatic_ewald_k::field (const Vector<double> &r) {
  auto field = k_space_field(r);
  if (slab_geometry)
    field += slab_geometry_correction_field(r);
  if (dipole)
    field += dipole_field_vector;
  return field;
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

