#include "finecuppa/objects/utility/element.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace utility {

Element::Element (FinECuPPA *fptr) : Pointers{fptr},
    mass{1}, radius{1}, charge{0} {
    element_index = object_container -> element.size();
    }

Element::~Element () {}
  

bool Element::read ( Parser * parser) {
  output->info("Element read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    ASSIGN_REAL(radius,"ELEMENT READ: ","")
    else ASSIGN_REAL(mass,"ELEMENT READ: ","")
    else ASSIGN_REAL(charge,"ELEMENT READ","")
    else error->all (FC_FILE_LINE_FUNC_PARSE, " ELEMENT: Unknown variable or command");    
  }
  
  return in_file;;
}

double Element::get_radius () const {
  return radius;
}

double Element::get_mass () const {
  return mass;
}

double Element::get_charge () const {
  return charge;
}            

int Element::get_element_index() const {
  return element_index;
}

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE
