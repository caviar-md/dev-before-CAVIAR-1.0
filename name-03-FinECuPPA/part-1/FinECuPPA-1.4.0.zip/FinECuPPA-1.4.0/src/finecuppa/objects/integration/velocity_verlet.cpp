#include "finecuppa/objects/integration/velocity_verlet.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

Velocity_verlet::Velocity_verlet (FinECuPPA *fptr) : Integration{fptr} {}

Velocity_verlet::~Velocity_verlet (){}

bool Velocity_verlet::read (finecuppa::Parser *parser) {
  output->info("Integration Velocity_verlet read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"add_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist.push_back(object_container->neighborlist[it->second.index]);
    } else if (string_cmp(t,"add_force_field") || string_cmp(t,"force_field")) {
      FIND_OBJECT_BY_NAME(force_field,it)
      force_field.push_back(object_container->force_field[it->second.index]);
    } else if (read_base_class_commands(parser)) {
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

void Velocity_verlet::step_part_I () {

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();

  for (unsigned int i=0; i<psize; i++) { 
    vel [i] += 0.5 * acc [i] * dt;
    pos [i] += vel [i] * dt;

    acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

}

void Velocity_verlet::step_part_II () {

  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  for (auto f : force_field)
    f -> calculate_acceleration ();
    
  for (unsigned int i=0; i<vel.size(); i++) {
    vel [i] += 0.5 * acc [i] * dt;
  }

}

} //integration
} //objects

FINECUPPA_NAMESPACE_CLOSE


