#include "finecuppa/FinECuPPA.h"

#include <string>

#include "finecuppa/structure/all.h"

FINECUPPA_NAMESPACE_OPEN

#ifdef USE_MD_MPI
FinECuPPA::FinECuPPA (int argc, char **argv, MPI_Comm mpi_comm) :
  mpi_comm {mpi_comm},
#else
FinECuPPA::FinECuPPA (int argc, char **argv) :
#endif
  comm {new Communicator {this}},
  error {new Error {this}},
  output {new Output {this}},
  input {new Input {this}},
  object_handler {new Object_handler {this}},
  object_container {new Object_container {this}},
  object_creator {new Object_creator {this}},  
  in {std::cin.rdbuf()},
  out {std::cout.rdbuf()},
  err {std::cerr.rdbuf()},
  log_flag {true},
  out_flag {true},
  err_flag {true},
  argc{argc},
  argv{argv} {
    if (comm->me == 0) log.open ("log");
}

FinECuPPA::~FinECuPPA () {
  delete input;
  delete output;
  delete error;
  delete comm;
  delete object_handler;  
  delete object_container;    
  delete object_creator;    
}

void FinECuPPA::execute () {
  std::string greeting = "FinECuPPA-";
  greeting += std::to_string (FINECUPPA_MAJOR_VERSION);
  greeting += ".";
  greeting += std::to_string (FINECUPPA_MINOR_VERSION);
  greeting += ".";
  greeting += std::to_string (FINECUPPA_PATCH_VERSION);
    
  output->info(greeting);
    
  input->read ();
}

FINECUPPA_NAMESPACE_CLOSE

