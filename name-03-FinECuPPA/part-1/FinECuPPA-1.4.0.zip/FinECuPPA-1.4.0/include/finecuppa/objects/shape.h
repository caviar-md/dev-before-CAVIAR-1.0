#ifndef FINECUPPA_FINECUPPA_SHAPE_H
#define FINECUPPA_FINECUPPA_SHAPE_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

inline void normalize (Vector<Real_t> & v) {
  v /= std::sqrt(v*v);
}

class Shape : protected Pointers {
 public:
  Shape (class FinECuPPA *);
  virtual ~Shape();
  virtual bool read(class finecuppa::Parser *)=0;
  virtual bool is_inside (const Vector<double> &)=0;
  virtual bool is_outside (const Vector<double> &);
  virtual bool is_inside (const Vector<double> &, const double rad)=0;
  virtual bool is_outside (const Vector<double> &, const double rad);
  virtual bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector)=0;

};
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
