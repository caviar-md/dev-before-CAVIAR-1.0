#ifndef FINECUPPA_FINITE_ELEMENT_H
#define FINECUPPA_FINITE_ELEMENT_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

class Finite_element : protected Pointers {
  public:
    Finite_element (class FinECuPPA *);
    virtual ~Finite_element();
    virtual void calculate_acceleration ();
    virtual bool read(class finecuppa::Parser *);//=0;  
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
