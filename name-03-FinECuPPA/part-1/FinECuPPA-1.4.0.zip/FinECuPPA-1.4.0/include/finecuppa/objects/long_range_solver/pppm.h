#ifndef FINECUPPA_LONG_RANGE_SOLVER_PPPM_H
#define FINECUPPA_LONG_RANGE_SOLVER_PPPM_H

#include "finecuppa/objects/long_range_solver.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {

class PPPM : public Long_range_solver {
 public:
  PPPM(class FinECuPPA *);
  ~PPPM();
  bool read(class finecuppa::Parser *);  
  void calculate();
  
  Vector<double> k_space_field(int);  
  Vector<double> r_space_field(int); 
  Vector<double> dipole_field(  );
  Vector<double> total_field(int);

  Vector<double> k_space_field(const Vector<double> &); 
  Vector<double> r_space_field(const Vector<double> &); 
  Vector<double> total_field(const Vector<double> &);  
        
  double k_space_potential(const Vector<double> &);  
  double r_space_potential(const Vector<double> &); 
  double dipole_potential(const Vector<double> &);
  double self_potential(const Vector<double> &);
  double total_potential(const Vector<double> &);  
      
  double k_space_energy( );  
  double r_space_energy( ); 
  double dipole_energy( );
  double self_energy( );  
  double total_energy( );    
  
 protected: 
  class FinECuPPA *fptr;     
};

} // long_range_solver
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
