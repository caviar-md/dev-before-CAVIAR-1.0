#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_OUTPUT_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_OUTPUT_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Output : protected Pointers{
public:
  Output (class FinECuPPA *);
  ~Output ();
  
  void mesh_povray (const shape::polyhedron::Polyhedron &, std::string file = "o_mesh.pov"); // povray output mesh ".pov"
  void mesh_tcl (const shape::polyhedron::Polyhedron &, std::string file = "o_mesh.tcl"); // vfptr output mesh ".tcl"
  void normals_tcl (const shape::polyhedron::Polyhedron &, std::string file = "o_normals.tcl" ); // vfptr output normals ".tcl"
  void edges_tcl (const shape::polyhedron::Polyhedron &, std::string file = "o_edges.tcl"); // vfptr output edges  ".tcl"
   
  //void mesh_povray (const std::vector<polyhedron::Polyhedron> &); // povray output mesh ".pov"
//  void mesh_vfptr (const std::vector<polyhedron::Polyhedron> &); // vfptr output mesh ".tcl"
//  void normals_vfptr (const std::vector<polyhedron::Polyhedron> &); // vfptr output normals ".tcl"
  //void edges_vfptr (const std::vector<polyhedron::Polyhedron> &); // vfptr output edges  ".tcl"
   

};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
