#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_FORMAT_VTK_READER_h
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_FORMAT_VTK_READER_h

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Format_Vtk_Reader : protected Pointers {
public:

  Format_Vtk_Reader (class FinECuPPA *);
  ~Format_Vtk_Reader();
  
  void read_polyhedron (shape::polyhedron::Polyhedron &, const std::string &);

// It checks if the two vertices are similar 
// Then makes a map of all vertices to the similar
// ones with the lower index, then clear
// void merge_vertices (int); 

};
} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
