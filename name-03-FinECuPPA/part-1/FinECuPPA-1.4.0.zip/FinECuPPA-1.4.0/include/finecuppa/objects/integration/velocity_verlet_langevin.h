#ifndef FINECUPPA_INTEGRATION_VELOCITY_VERLET_LANGEVIN_H
#define FINECUPPA_INTEGRATION_VELOCITY_VERLET_LANGEVIN_H

#include "finecuppa/objects/integration.h"
#include <random>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

class Velocity_verlet_langevin : public Integration {
public:
  Velocity_verlet_langevin (class FinECuPPA *);
   ~Velocity_verlet_langevin();    
  bool read (class finecuppa::Parser *);
protected:

  void step_part_I ();
  void step_part_II ();
  void setup_custom ();
  std::mt19937 rnd_generator_x, rnd_generator_y, rnd_generator_z;
  std::vector<double> eta_x, eta_y, eta_z;
// the default stddev is 1  
  std::normal_distribution<double> rnd_ndist_x, rnd_ndist_y, rnd_ndist_z;    
  double temperature, zeta, kb;
  double a, b, c; 
};

} //integration
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
