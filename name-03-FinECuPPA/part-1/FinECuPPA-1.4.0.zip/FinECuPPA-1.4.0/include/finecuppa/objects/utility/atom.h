#ifndef FINECUPPA_OBJECT_UTILITY_ATOM_H
#define FINECUPPA_OBJECT_UTILITY_ATOM_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace utility {
class Molecule;
class Atom  : protected Pointers {
 public:
  Atom (class FinECuPPA *);    
  Atom (const Atom &);
  Atom (class FinECuPPA *, class Molecule *,  Vector<double>, Vector<double>, unsigned int);
  Atom ();
  ~Atom () ;
  bool read (Parser *);
  Vector<double> pos_tot () const;
  Vector<double> vel_tot () const; 
  Vector<double> pos () const;
  Vector<double> & pos ();
  Vector<double> vel () const;
  Vector<double> & vel ();
  double get_radius () const;
  unsigned int get_element_index () const;
  void output_xyz (std::ofstream &);  
  void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);      
  bool part_of_a_molecule;    
  Molecule * upper_level_molecule;
  
  protected:
  Vector<double> position, velocity;
  unsigned int element_index;

};

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
