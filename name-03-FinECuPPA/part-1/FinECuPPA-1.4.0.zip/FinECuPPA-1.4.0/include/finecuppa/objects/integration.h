#ifndef FINECUPPA_INTEGRATION_H
#define FINECUPPA_INTEGRATION_H

#include "finecuppa/utility/pointers.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Atom_data;
class Neighborlist;
class Force_field;
class Integration : protected Pointers {
public:
  Integration (class FinECuPPA *);
  virtual ~Integration  ();
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual bool read_base_class_commands(class finecuppa::Parser *);
  virtual bool run (const double, const int, const int);
protected:
  std::vector<class objects::Neighborlist *> neighborlist;
  std::vector<objects::Force_field *> force_field; 
  class objects::Atom_data *atom_data;
  virtual void step_part_I () = 0;
  virtual void step_part_II () = 0;
  virtual void setup ();
  virtual void setup_custom (); // called after the default 'setup()'
  virtual void cleanup ();
  virtual void cleanup_custom (); // called after the default 'cleanup()'
  virtual bool boundary_condition ();
  virtual void output_total_force();
  virtual void output_total_energy();

  Real_t dt;
  
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
