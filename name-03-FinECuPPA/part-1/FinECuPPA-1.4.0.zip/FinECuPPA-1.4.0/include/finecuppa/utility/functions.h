#ifndef FINECUPPA_UTILITY_H
#define FINECUPPA_UTILITY_H

#include "finecuppa_config.h"
#include <algorithm>


FINECUPPA_NAMESPACE_OPEN

template <typename T1, typename T2>
bool string_cmp(const T1 a, const T2 b) {
#ifdef FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE
  T1 a_lowercase = a;
  T1 b_lowercase = b;
  std::transform(a_lowercase.begin(), a_lowercase.end(), a_lowercase.begin(), ::tolower);  
  std::transform(b_lowercase.begin(), b_lowercase.end(), b_lowercase.begin(), ::tolower);  
  return (a_lowercase == b_lowercase);
#else
  return (a==b);
#endif
}
/*
template <typename T>
constexpr T min (T a, T b) {
  return a < b ? a : b;
}

template <typename T>
constexpr T max (T a, T b) {
  return a > b ? a : b;
}

template <typename T>
constexpr T ipow (T num, unsigned pow) {
  return pow ? num*ipow(num, pow-1) : 1;
}
*/
FINECUPPA_NAMESPACE_CLOSE

#endif
