#ifndef FINECUPPA_INPUT_COMMANDS_MAP_H
#define FINECUPPA_INPUT_COMMANDS_MAP_H

#include "finecuppa/structure/input.h"

FINECUPPA_NAMESPACE_OPEN

//using CommandFunc = bool (Input::*) (class Parser *); 

const std::map<std::string,CommandFunc> Input::commands_map = {
  
  {"read",&Input::read_script_from_file},  
  {"read_script",&Input::read_script_from_file},
  {"read_script_from_file",&Input::read_script_from_file},     
  {"output", &Input::call_output},
  {"object_container", &Input::call_object_container},
  {"exit", &Input::exit_program},
  {"quit", &Input::exit_program}
};

FINECUPPA_NAMESPACE_CLOSE

#endif
