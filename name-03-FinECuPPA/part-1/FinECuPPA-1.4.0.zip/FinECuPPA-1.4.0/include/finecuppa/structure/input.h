#ifndef FINECUPPA_INPUT_H
#define FINECUPPA_INPUT_H

#include "finecuppa/utility/pointers.h"
#include <istream>
#include <map>

FINECUPPA_NAMESPACE_OPEN

using CommandFunc = bool (Input::*) (class Parser *); // a pointer to boolean function of Input class.

class Input : protected Pointers {
public:
  Input (class FinECuPPA *);
  Input (class FinECuPPA *, const std::string &);
  ~Input ();
  
  void read ();
protected:
  class Parser *parser;
  const static std::map<std::string,CommandFunc> commands_map;
  void read (Parser *);
  bool read_command (Parser *);  
  bool call_output (Parser *);
  bool call_object_container (Parser *);
  bool read_script_from_file (Parser *);
  bool exit_program (Parser *);
};

FINECUPPA_NAMESPACE_CLOSE

#endif
