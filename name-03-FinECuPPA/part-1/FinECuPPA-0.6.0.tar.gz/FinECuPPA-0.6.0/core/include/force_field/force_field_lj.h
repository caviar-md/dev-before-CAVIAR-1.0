#ifndef FORCE_FIELD_LJ_H
#define FORCE_FIELD_LJ_H

#include "finecuppa_config.h"

#include "force_field.h"

#include <vector>

FINECUPPA_NAMESPACE_OPEN

class Force_field_lj : public Force_field {
public:
  Force_field_lj (class MD *);
  ~Force_field_lj () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> epsilon,sigma;
  
  class Parser *parser;
	class Output *output;
	class Error *error;  
};

FINECUPPA_NAMESPACE_CLOSE

#endif
