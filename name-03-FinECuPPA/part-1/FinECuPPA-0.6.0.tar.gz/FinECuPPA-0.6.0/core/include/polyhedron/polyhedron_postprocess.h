#ifndef POLYHEDRON_POSTPROCESS_H
#define POLYHEDRON_POSTPROCESS_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_geometry {
class Polyhedron_Postprocess : protected Pointers{
public:
  Polyhedron_Postprocess (class MD *);
  ~Polyhedron_Postprocess ();
  

	void make_grid (NS_geometry::Polyhedron&); // contains the faces neccesary to check
									      // make_grid has to be called after lowest_highest_coord()
	void lowest_highest_coord (NS_geometry::Polyhedron&); // calculates gxlo, gxhi, gylo...


};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
