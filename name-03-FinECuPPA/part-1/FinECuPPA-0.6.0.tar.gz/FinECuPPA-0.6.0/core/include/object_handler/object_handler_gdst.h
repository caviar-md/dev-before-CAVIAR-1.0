#ifndef OBJECT_HANDLER_GDST_H
#define OBJECT_HANDLER_GDST_H

#include "finecuppa_config.h"

#include <string>
#include <map>

FINECUPPA_NAMESPACE_OPEN

namespace NS_object_handler {

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::map<std::string,int> dictionary_second_type = {
	{"element",1},
	{"atom",2},
	{"molecule",3},	
	{"random_1d",4},
	{"boundary",5},	
	{"shape",6},	
	{"grid_1d",7},
	{"distribution",8},
	{"force_field",9},
	{"finite_element",10},	
	{"int_variable",-1},	
	{"real_variable",-2},	
	{"int_2d_vector",-3},	
	{"real_2d_vector",-4},	
	{"int_3d_vector",-5},	
	{"real_3d_vector",-6},
};


}

FINECUPPA_NAMESPACE_CLOSE

#endif
 
