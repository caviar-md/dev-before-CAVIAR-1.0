#include "object_handler_dictionary.h"

#include "finecuppa_config.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_object_handler {


}

FINECUPPA_NAMESPACE_CLOSE
