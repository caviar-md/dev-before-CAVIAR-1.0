#include "shape.h"

#include "finecuppa_config.h"

#include "object_handler.h"
#include "object_handler_preprocessors.h"
#include "object_handler_dictionary.h"

#include "parser.h"
#include "lexer.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_shape {


  Shape::Shape (MD *md) : Pointers{md},
		output{md->output}, error{md->error} {}
	Shape::~Shape () {}
		

}

FINECUPPA_NAMESPACE_CLOSE

