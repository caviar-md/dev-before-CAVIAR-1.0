#include "atom_data.h"

#include "finecuppa_config.h"

#include <algorithm>

#include "communicator.h"
#include "domain.h"
#include "force_field.h"

FINECUPPA_NAMESPACE_OPEN

constexpr auto expected_imbalance_factor = 1.1;

bool Atom_data::exchange_owned () {
	bool make_neighlist = false;

	//const auto co_ext = 0.01*md->force_field->cutoff; //****//
  const auto co_ext = 0.0;
  
	const auto x_llow = domain->x_lower_local - co_ext;
	const auto x_lupp = domain->x_upper_local + co_ext;
	const auto y_llow = domain->y_lower_local - co_ext;
	const auto y_lupp = domain->y_upper_local + co_ext;
	const auto z_llow = domain->z_lower_local - co_ext;
	const auto z_lupp = domain->z_upper_local + co_ext;

	const auto x_width = domain->x_upper_local - domain->x_lower_local;
	const auto y_width = domain->y_upper_local - domain->y_lower_local;
	const auto z_width = domain->z_upper_local - domain->z_lower_local;


	auto &pos = owned.position;

#ifdef USE_MD_MPI
	auto &vel = owned.velocity;
	auto &acc = owned.acceleration;
	auto &id  = owned.id;
	auto &type = owned.type;

	const auto grid_index_x = comm->grid_index_x;
	const auto grid_index_y = comm->grid_index_y;
	const auto grid_index_z = comm->grid_index_z;

	const auto nprocs_x = comm->nprocs_x;
	const auto nprocs_y = comm->nprocs_y;
	const auto nprocs_z = comm->nprocs_z;

//	const auto nprocs = comm->nprocs;
	const auto me = comm->me;

	const auto &all = comm->all;

	std::vector<std::vector<std::vector<std::vector<int>>>> o_send_id, o_recv_id, o_send_index;

	o_send_id.resize(3); o_recv_id.resize(3); o_send_index.resize(3);
	for (auto i=0; i<3;++i) {
		o_send_id[i].resize(3);	o_recv_id[i].resize(3); o_send_index[i].resize(3);
		for (auto j=0; j<3;++j) {
			o_send_id[i][j].resize(3); o_recv_id[i][j].resize(3); o_send_index[i][j].resize(3);

		}
	}

	int o_recv_n[3][3][3]; // num of owned to be recieved from domain [i][j][k]

	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				o_recv_n[i][j][k] = 0;
			}
		}
	}

	for (unsigned i=0; i<num_local_atoms; ++i) {
		const auto xlc = pos[i].x < x_llow;
		const auto xuc = pos[i].x > x_lupp;
		const auto ylc = pos[i].y < y_llow;
		const auto yuc = pos[i].y > y_lupp;
		const auto zlc = pos[i].z < z_llow;
		const auto zuc = pos[i].z > z_lupp;

		int x_val, y_val, z_val;

		if (xlc) x_val = -1;
		else if (xuc) x_val = +1;
		else x_val = 0;

		if (ylc) y_val = -1;
		else if (yuc) y_val = +1;
		else y_val = 0;

		if (zlc) z_val = -1;
		else if (zuc) z_val = +1;
		else z_val = 0;

		if (grid_index_x == 0) x_val *= x_bc; 						// periodic or non-periodic boundary condition
		if (grid_index_x == nprocs_x - 1) x_val *= x_bc;  // //
		if (grid_index_y == 0) y_val *= y_bc;							// //
		if (grid_index_y == nprocs_y - 1) y_val *= y_bc;	// //
		if (grid_index_z == 0) z_val *= z_bc;							// //
		if (grid_index_z == nprocs_z - 1) z_val *= z_bc;	// //

		if (x_val != 0 && y_val != 0 && z_val != 0) { 
			o_send_id    [x_val + 1][y_val + 1][z_val + 1].push_back (id[i]);
			o_send_index [x_val + 1][y_val + 1][z_val + 1].push_back (i);
			continue;
		}
		if (x_val != 0 && y_val != 0) { 
			o_send_id    [x_val + 1][y_val + 1][1].push_back (id[i]);
			o_send_index [x_val + 1][y_val + 1][1].push_back (i);
			continue;
		}
		if (x_val != 0 && z_val != 0) { 
			o_send_id    [x_val + 1][1][z_val + 1].push_back (id[i]);
			o_send_index [x_val + 1][1][z_val + 1].push_back (i);
			continue;
		}
		if (y_val != 0 && z_val != 0) { 
			o_send_id    [1] [y_val + 1][z_val + 1].push_back (id[i]);
			o_send_index [1] [y_val + 1][z_val + 1].push_back (i);
			continue;
		}
		if (x_val != 0) { 
			o_send_id    [x_val + 1][1][1].push_back (id[i]);
			o_send_index [x_val + 1][1][1].push_back (i);
			continue;
		}
		if (y_val != 0) { 
			o_send_id    [1][y_val + 1][1].push_back (id[i]);
			o_send_index [1][y_val + 1][1].push_back (i);
			continue;
		}
		if (z_val != 0) { 
			o_send_id    [1][1][z_val + 1].push_back (id[i]);
			o_send_index [1][1][z_val + 1].push_back (i);
			continue;
		}
	}
	MPI_Barrier (mpi_comm);
// ===============================send num of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					int num_s = o_send_id[i][j][k].size();
					MPI_Send (&num_s, 1, MPI_INT, all[i][j][k], 0, mpi_comm);
					MPI_Recv (&o_recv_n[i][j][k], 1, MPI_INT, all[i][j][k], 0, mpi_comm, MPI_STATUS_IGNORE);
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ===============================send id of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					int num_s = o_send_id[i][j][k].size();	
					if (num_s>0){
						MPI_Send (o_send_id[i][j][k].data(), num_s, MPI_INT, all[i][j][k] , 1, mpi_comm);
					}					
					unsigned num_r = o_recv_n [i][j][k];
					if (num_r>0){
						int *tmp_r = new int[num_r];
						MPI_Recv (&tmp_r, num_r, MPI_INT, all[i][j][k], 1, mpi_comm, MPI_STATUS_IGNORE);
            for (unsigned m = 0; m < num_r; ++m)
							o_recv_id[i][j][k].push_back (tmp_r[m]);
					  delete[] tmp_r;
					}
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ==============================send type of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					for (auto m : o_send_index[i][j][k]) {
						MPI_Send (&type[m], 1, MPI_INT, all[i][j][k], id[m], mpi_comm);
					}
					for (auto m : o_recv_id[i][j][k]) {
						int tmp;
						MPI_Recv (&tmp, 1, MPI_INT, all[i][j][k], m, mpi_comm, MPI_STATUS_IGNORE);
						type.push_back (tmp);
						id.push_back (m);
					} 
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ==============================send position of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					for (auto m : o_send_index[i][j][k]) { 
						Vector<double> p_tmp {pos[m].x, pos[m].y, pos[m].z};
						MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, all[i][j][k], id[m], mpi_comm);
					}
					for (auto m : o_recv_id[i][j][k]) {
						Vector<double> p_tmp;
						MPI_Recv (&p_tmp, 3, MPI_DOUBLE, all[i][j][k], m, mpi_comm, MPI_STATUS_IGNORE);
						if (i==0) while (p_tmp.x < x_llow) p_tmp.x+= x_width;
						if (j==0) while (p_tmp.y < y_llow) p_tmp.y+= y_width;
						if (k==0) while (p_tmp.z < z_llow) p_tmp.z+= z_width;
						if (i==2) while (p_tmp.x > x_lupp) p_tmp.x-= x_width;
						if (j==2) while (p_tmp.y > y_lupp) p_tmp.y-= y_width;
						if (k==2) while (p_tmp.z > z_lupp) p_tmp.z-= z_width;
						pos.push_back (p_tmp);
						++num_local_atoms;
					} 
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ==============================send velocity of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					for (auto m : o_send_index[i][j][k]) { 
						Vector<double> p_tmp {vel[m].x, vel[m].y, vel[m].z}; 
						MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, all[i][j][k], id[m], mpi_comm); 
					} 
					for (auto m : o_recv_id[i][j][k]) { 
						Vector<double> p_tmp; 
						MPI_Recv (&p_tmp, 3, MPI_DOUBLE, all[i][j][k], m, mpi_comm, MPI_STATUS_IGNORE); 
						vel.push_back (p_tmp);
					}  
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ==============================send acceleration of owned
	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
				if (me != all[i][j][k]) {
					for (auto m : o_send_index[i][j][k]) { 
						Vector<double> p_tmp {acc[m].x, acc[m].y, acc[m].z}; 
						MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, all[i][j][k], id[m], mpi_comm); 
					} 
					for (auto m : o_recv_id[i][j][k]) { 
						Vector<double> p_tmp; 
						MPI_Recv (&p_tmp, 3, MPI_DOUBLE, all[i][j][k], m, mpi_comm, MPI_STATUS_IGNORE); 
						acc.push_back (p_tmp);
					}  
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);

// ================================================ self move

	std::vector<int>o_send_index_lin; // gather all the indexes in a one dimensional array. used in erase.

	for (auto i=0; i<3;++i) {
		for (auto j=0; j<3;++j) {
			for (auto k=0; k<3;++k) {
//				if (i==1&&j==1&&k==1) continue;
				if (me == all[i][j][k]) {
					auto ii=i-1,jj=j-1,kk=k-1;
					for (auto m : o_send_index[i][j][k]) {
						pos[m].x -= ii * x_width;
						pos[m].y -= jj * y_width;
						pos[m].z -= kk * z_width;						
					}	
				} else {
					for (auto m : o_send_index[i][j][k]) {
						o_send_index_lin.push_back (m);
					}
				}
			}
		}
	}
	MPI_Barrier (mpi_comm);
// ================================================ delete moved atoms
	std::sort(o_send_index_lin.begin(), o_send_index_lin.end(), std::greater<int>()); // sort them from greatest to lowest to maintain lower index
	for (auto i : o_send_index_lin) {
		pos.erase (pos.begin()+i);	
		vel.erase (vel.begin()+i);	
		acc.erase (acc.begin()+i);	
		type.erase (type.begin()+i);	
		id.erase (id.begin()+i);
		--num_local_atoms;
		make_neighlist = true; 	
	}

#else
	for (unsigned int i = 0 ; i < num_local_atoms; ++i) {
		if (x_bc == 1) { 
			while (pos[i].x < x_llow) pos[i].x += x_width;
			while (pos[i].x > x_lupp) pos[i].x -= x_width;
		}
		if (y_bc == 1) {
			while (pos[i].y < y_llow) pos[i].y += y_width;
			while (pos[i].y > y_lupp) pos[i].y -= y_width;			
		}
		if (z_bc == 1) {
			while (pos[i].z < z_llow) pos[i].z += z_width;
			while (pos[i].z > z_lupp) pos[i].z -= z_width;
			
		}
	}	
#endif
	return make_neighlist;
}

FINECUPPA_NAMESPACE_CLOSE


