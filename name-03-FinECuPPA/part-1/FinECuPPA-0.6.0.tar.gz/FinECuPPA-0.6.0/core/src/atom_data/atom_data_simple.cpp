#include "atom_data_simple.h"

#include "finecuppa_config.h"

FINECUPPA_NAMESPACE_OPEN

Atom_data_simple::Atom_data_simple (MD *md) : Atom_data{md} {}

void Atom_data_simple::allocate () {
  
}

FINECUPPA_NAMESPACE_CLOSE

