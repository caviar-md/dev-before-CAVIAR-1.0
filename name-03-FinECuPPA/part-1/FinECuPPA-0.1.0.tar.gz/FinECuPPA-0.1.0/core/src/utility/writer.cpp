#include "writer.h"

#include "finecuppa_config.h"

FINECUPPA_NAMESPACE_OPEN

Writer::Writer (MD *md) : Pointers{md} {}

FINECUPPA_NAMESPACE_CLOSE
