#include "shape_polyhedron.h"

#include "finecuppa_config.h"

#include "object_handler_all.h"
#include "object_container.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "output.h"
#include "atom_data.h"
#include "utility.h"


FINECUPPA_NAMESPACE_OPEN

namespace NS_shape {

Polyhedron::Polyhedron (MD *md) : Shape {md},
				object_container{md->object_container}, output{md->output}, error{md->error}, 
  polyhedron_handler {new NS_geometry::Polyhedron_Handler{md}}
  {}

Polyhedron::~Polyhedron () { 
	delete polyhedron_handler;	
}

bool Polyhedron::read(Parser * parser) {
	return polyhedron_handler -> read (parser);
}

bool Polyhedron::is_inside(const Vector<double> &v0) {
  return polyhedron_handler -> is_inside (v0);   
}

bool Polyhedron::is_outside(const Vector<double> &v) {
  return !is_inside (v);
}

bool Polyhedron::is_inside(const Vector<double> &v, const double r) {
  return polyhedron_handler -> is_inside (v, r); 
}

bool Polyhedron::is_outside(const Vector<double> &v, const double r) {
  return !is_inside (v,r);
}

bool Polyhedron::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
  return polyhedron_handler -> in_contact(v, r, contact_vector);
}


} //namespace

FINECUPPA_NAMESPACE_CLOSE


