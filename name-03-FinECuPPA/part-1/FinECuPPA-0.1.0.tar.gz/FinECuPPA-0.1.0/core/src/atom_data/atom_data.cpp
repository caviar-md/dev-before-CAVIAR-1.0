#include "atom_data.h"

#include "finecuppa_config.h"

#include <algorithm>

#include "communicator.h"
#include "domain.h"
#include "force_field.h"

FINECUPPA_NAMESPACE_OPEN

constexpr auto expected_imbalance_factor = 1.1;

Atom_data::Atom_data (MD *md) : Pointers{md}, num_local_atoms{0}, num_total_atoms{0}, num_atom_types{0}, x_bc{0}, y_bc{0}, z_bc{0} {}

Atom_data::~Atom_data () {
  
}

unsigned int Atom_data::get_global_id () {
#ifdef USE_MPI
	MPI_Barrier (mpi_comm); // does it have to be here??
  MPI_Allreduce (num_local_atoms, num_total_atoms, 1, MPI_INT, MPI_SUM, mpi_comm);
#else
  num_total_atoms = owned.position.size();
#endif
  return num_total_atoms;
}

void Atom_data::set_num_total_atoms (GlobalID_t n) {
  num_total_atoms = n;
  num_local_atoms_est = n * expected_imbalance_factor / comm->nprocs;
}

void Atom_data::allocate () {
  owned.id.reserve (num_local_atoms_est);
//  owned.charge.reserve (num_local_atoms_est);
  owned.position.reserve (num_local_atoms_est);
  owned.velocity.reserve (num_local_atoms_est);
  owned.acceleration.reserve (num_local_atoms_est);
}

bool Atom_data::add_atom (GlobalID_t id, AtomType_t type, const Vector<Real_t> &pos, const std::vector<Real_t> &, const std::vector<int> &) {
  if (pos.x >= domain->x_lower_local && pos.x < domain->x_upper_local &&
      pos.y >= domain->y_lower_local && pos.y < domain->y_upper_local &&
      pos.z >= domain->z_lower_local && pos.z < domain->z_upper_local) {
    owned.type.push_back (type);
    owned.position.push_back (pos);
		owned.id.push_back ( id );
		owned.velocity.push_back (Vector<Real_t> {0,0,0});
		owned.acceleration.push_back (Vector<Real_t> {0,0,0});
    ++num_local_atoms;
    //std::cout << "atom added_1 " << num_local_atoms << std::endl;
    return true;
  }
  else return false;
}

bool Atom_data::add_atom (GlobalID_t id, AtomType_t type, const Vector<Real_t> &pos, const Vector<Real_t> &vel, const std::vector<Real_t> &, const std::vector<int> &) {
  if (pos.x >= domain->x_lower_local && pos.x < domain->x_upper_local &&
      pos.y >= domain->y_lower_local && pos.y < domain->y_upper_local &&
      pos.z >= domain->z_lower_local && pos.z < domain->z_upper_local) {
		owned.type.push_back (type);
    owned.position.push_back (pos);
		owned.id.push_back ( id );
		owned.velocity.push_back (vel);
		owned.acceleration.push_back (Vector<Real_t> {0,0,0});
    ++num_local_atoms;
    //std::cout << "atom added_2 " << num_local_atoms << std::endl;    
    return true;
  }
  else return false;
  //else {std::cout << "atom not added_2 " << num_local_atoms << std::endl;  return false;  }
}

bool Atom_data::add_masses (unsigned int type, Real_t m) {
	if (type + 1 > owned.mass.size())
	  owned.mass.resize (type + 1);
	owned.mass[type] = m;
	std::cout<<"info: atom_data: added mass: type: "<< type << " , value: " << owned.mass[type] << std::endl;
	return true; //WARNING	
}

bool Atom_data::add_charges (unsigned int type, Real_t c) {
	if (type + 1 > owned.charge.size())
	  owned.charge.resize (type + 1);
	owned.charge[type] = c;
	std::cout<<"info: atom_data: added charge: type: "<< type << " , value: " << owned.charge[type] << std::endl;
	return true; //WARNING
}

FINECUPPA_NAMESPACE_CLOSE


