#include "object_handler_all.h"

#include "finecuppa_config.h"

#include "object_container.h"
#include "object_handler_commands_map.h"

FINECUPPA_NAMESPACE_OPEN

Object_handler::Object_handler (MD *md) : Pointers{md}, error{md->error} {}

Object_handler::~Object_handler () {

}


bool Object_handler::read_object (Parser * parser, const std::string object_name) {

	bool in_file = true;
  object_container = md->object_container;
  
	std::map<std::string,NS_object_handler::Dictionary>::iterator it;
	it = object_container -> dictionary.find(object_name);	
	
	if (it == object_container -> dictionary.end())
		error->all (FILE_LINE_FUNC, "Object_handler : read : Invalid object NAME");
	if (it->second.type == NS_object_handler::gdst("element")) 
		{in_file = object_container -> element[it->second.index].read(parser); return in_file;}
	if (it->second.type == NS_object_handler::gdst("atom")) 
		{in_file = object_container -> atom[it->second.index].read(parser); return in_file;}
	if (it->second.type == NS_object_handler::gdst("molecule")) 
		{in_file = object_container -> molecule[it->second.index].read(parser); return in_file;}
	if (it->second.type == NS_object_handler::gdst("shape"))
		{in_file = object_container -> shape[it->second.index]->read(parser); return in_file;}
  if (it->second.type == NS_object_handler::gdst("random_1d")) 
		{in_file = object_container -> random_1d[it->second.index].read(parser); return in_file;}
  if (it->second.type == NS_object_handler::gdst("grid_1d")) 
		{in_file = object_container -> grid_1d[it->second.index].read(parser); return in_file;}
  if (it->second.type == NS_object_handler::gdst("boundary")) 
		{in_file = object_container -> boundary[it->second.index].read(parser); return in_file;}													
  if (it->second.type == NS_object_handler::gdst("distribution")) 
		{in_file = object_container -> distribution[it->second.index].read(parser); return in_file;}
  if (it->second.type == NS_object_handler::gdst("force_field")) 
		{in_file = object_container -> force_field[it->second.index]->read(parser); return in_file;}		
  if (it->second.type == NS_object_handler::gdst("finite_element")) 
		{in_file = object_container -> finite_element[it->second.index]->read(parser); return in_file;}	
					
	return in_file; //WARNING
}

FINECUPPA_NAMESPACE_CLOSE

