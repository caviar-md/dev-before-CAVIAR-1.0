#ifdef USE_MPI
#include <mpi.h>
#endif

#include "finecuppa_config.h"

#include "md.h"


int main (int argc, char* argv[]) {

#ifdef USE_MPI
  MPI_Init (&argc, &argv);
//  fine_cuppa::MD md (argc, argv);  
  fine_cuppa::MD md (argc, argv, MPI::COMM_WORLD);
#else
  fine_cuppa::MD md (argc, argv);
#endif
  try {  
    md.execute ();
  }
  catch (std::exception &exc) {
    std::cerr << "Exception on processing: " << std::endl
              << exc.what() << std::endl;
  }
  catch (...) {
    std::cerr << "Unknown exception!" << std::endl;  
  } 
#ifdef USE_MPI
  MPI_Barrier (MPI_COMM_WORLD);
  MPI_Finalize ();
#endif
  return 0;
}


