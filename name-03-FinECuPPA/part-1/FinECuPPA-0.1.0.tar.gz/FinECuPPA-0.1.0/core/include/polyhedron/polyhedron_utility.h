#ifndef POLYHEDRON_UTILITY_H
#define POLYHEDRON_UTILITY_H

#include "finecuppa_config.h"

#include "pointers.h"
#include "polyhedron.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_geometry {
class Polyhedron_Utility : protected Pointers {
public:
  Polyhedron_Utility (class MD*);
  ~Polyhedron_Utility ();
  

	void make_normal (NS_geometry::Polyhedron &); // after reading unv file, it calculates normal vectors		
	void make_edge_norms (NS_geometry::Polyhedron &); // makes normals of faces made of edges and other normals used in check_inside() algorithm.
	void invert_normals (NS_geometry::Polyhedron &); // multiply all the normal Vectors with -1

  class Output * output;
  class Error * error;
};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
