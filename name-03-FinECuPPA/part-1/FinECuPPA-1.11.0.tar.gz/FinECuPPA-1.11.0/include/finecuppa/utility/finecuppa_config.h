
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_FINECUPPA_CONFIG_H
#define FINECUPPA_FINECUPPA_CONFIG_H

#define FINECUPPA_NAMESPACE_OPEN namespace finecuppa {
#define FINECUPPA_NAMESPACE_CLOSE }

#define FINECUPPA_MAJOR_VERSION 1
#define FINECUPPA_MINOR_VERSION 11
#define FINECUPPA_PATCH_VERSION 0

#define FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE

// #ifndef FINECUPPA_WITH_MPI
/* #undef FINECUPPA_WITH_MPI */
// #endif


// #ifndef FINECUPPA_WITH_DEALII
// #define FINECUPPA_WITH_DEALII
// #endif

#endif
