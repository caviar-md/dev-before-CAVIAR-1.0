
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_WRITER_FORCEFIELD_H
#define FINECUPPA_OBJECTS_WRITER_FORCEFIELD_H

#include "finecuppa/objects/writer.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace writer {

class Force_field : public Writer {
 public:
  Force_field (class FinECuPPA *);
  ~Force_field ( );
  bool read (class finecuppa::interpreter::Parser *);
  void initialize();
  void write();
  void write(int); // current time_step
  void write(double); // current time
  void write(int, double); //time_step and time
  void start_new_files(); //add_time_to_previous
  void start_new_files(std::string &); //add_time_to_previous

 public:

};

} //writer
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
