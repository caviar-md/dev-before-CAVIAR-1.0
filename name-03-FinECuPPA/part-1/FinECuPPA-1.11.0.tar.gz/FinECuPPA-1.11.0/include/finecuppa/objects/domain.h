
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_DOMAIN_H
#define FINECUPPA_OBJECTS_DOMAIN_H

#include "finecuppa/utility/objects_common_headers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Domain : public Pointers {
public:
  Domain (class FinECuPPA *);
  virtual ~Domain ();
  virtual bool read (class finecuppa::interpreter::Parser *) = 0;
  virtual void calculate_local_domain ();
  virtual void generate() = 0;
  virtual void calculate_procs_grid ();
  virtual int grid2rank (int x, int y, int z); // calculates process rank from it grid index
  virtual void find_best_grid (); // with respect to the number of processes, makes a grid with lowest shared area possible.

  virtual Vector<Real_t> periodic_distance (const Vector<Real_t> );

  Vector<int> boundary_condition; 

  int grid_index_x, grid_index_y, grid_index_z; // starts from (0) to (nprocs_i-1) ; i=x,y,z
  int nprocs_x, nprocs_y, nprocs_z; // it can be at least (1) and at most (nprocs)

  Vector <Real_t> lower_global, upper_global;
  Vector <Real_t> lower_local, upper_local;


// used in MD_MPI case:
  int me, nprocs;// MPI process rank and number of processes



  int all[3][3][3]; // all neighborlist domains around the me=all [1][1][1]. left=all[0][1][1]. up=all[1][2][1]. 
                    // if one domain exists, in one process case, all[i][j][k]=me for 0<=i,j,k<=2 
                    // left&right: x direction, down&up: y direction, bottom&top: z direction. right&up&top are the positive directions
  std::vector<int> neighborlist_domains;  // defined to have a faster MPI when we have less than 27 processes or when domains can have similar neigbors



public:

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
