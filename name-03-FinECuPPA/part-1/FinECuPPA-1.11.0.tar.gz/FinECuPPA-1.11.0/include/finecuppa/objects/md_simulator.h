
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_MDSIMULATOR_H
#define FINECUPPA_OBJECTS_MDSIMULATOR_H

#include "finecuppa/utility/objects_common_headers.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
class Atom_data;
class Integrator;
class Neighborlist;
class Force_field;
class Constraint;
class Writer;
class Md_simulator : public Pointers {
 public:
  Md_simulator (class FinECuPPA *);
  virtual ~Md_simulator ( );
  virtual bool read (class finecuppa::interpreter::Parser *) = 0;
  virtual bool read_base_class_commands(class finecuppa::interpreter::Parser *);
  virtual bool run () = 0;
  virtual void step(int i);
  virtual void initialize();
  virtual void setup ();
  virtual void cleanup ();
  virtual bool boundary_condition();

  class objects::Atom_data *atom_data;
  class objects::Integrator *integrator;
  std::vector<class objects::Neighborlist *> neighborlist;
  std::vector<objects::Force_field *> force_field; 
  std::vector<objects::Constraint *> constraint; 
  std::vector<objects::Writer *> writer; 

  double time, dt;
  clock_t t_start, t_end;
  double initial_time, final_time;
  bool use_time, use_step;
  int initial_step, final_step;
  bool initialized;

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
