
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_ATOMDATA_H
#define FINECUPPA_OBJECTS_ATOMDATA_H

#include "finecuppa/utility/objects_common_headers.h"
#include "finecuppa/objects/atom_data/utility/bond.h"
#include "finecuppa/objects/atom_data/utility/angle.h"


FINECUPPA_NAMESPACE_OPEN

namespace objects {

class Domain;
namespace unique { 
class Atom; class Atom_group; class Atom_list;
class Molecule; class Molecule_group; class Molecule_list; 
}
namespace neighborlist {
class Cell_list;
}
class Atom_data : public Pointers {
public:
  Atom_data (class FinECuPPA *);
  virtual ~Atom_data ();
  virtual bool read (class finecuppa::interpreter::Parser *) = 0;

  // check if a position is empty of any atom. Usage in fixing number of atoms
  // or molarity when one wants to create atoms.
  virtual bool empty_of_atoms(const Vector<Real_t>, double radius);
  // checks by atom_type
  virtual bool empty_of_atoms(const Vector<Real_t>, int type);
  virtual bool empty_of_atoms(objects::unique::Atom &a);
  virtual bool empty_of_atoms(objects::unique::Molecule &m);

  // is it useful?
  virtual void set_num_total_atoms (GlobalID_t);

  // is it useful?
  virtual void set_num_atom_types (AtomType_t n) {num_atom_types = n;}

  // reserve the owned std::vector for a faster push_back assignment
  virtual void reserve_owned_vectors ();  

  // gets the data and add it to the owned if it should be owned.
  virtual bool add_atom (GlobalID_t, 
                         AtomType_t,
                         const Vector<Real_t> &,
                         const Vector<Real_t> &vel = Vector<Real_t>{0.0,0.0,0.0},
                         const std::vector<Real_t> &other_real = std::vector<Real_t>{},
                         const std::vector<int> &other_int = std::vector<int>{});

  // add unique::Atom to the owned data
  virtual bool add_atom(finecuppa::objects::unique::Atom &a);
  virtual bool add_atom(finecuppa::objects::unique::Atom_group &a);
  virtual bool add_atom(finecuppa::objects::unique::Atom_list &a);

  // add unique::Molecule to the owned data
  virtual bool add_molecule(finecuppa::objects::unique::Molecule &m);
  virtual bool add_molecule(finecuppa::objects::unique::Molecule_group &m);
  virtual bool add_molecule(finecuppa::objects::unique::Molecule_list &m);

  // sets the mass of an atom type
  virtual bool add_masses (unsigned int, Real_t);  

  // sets the charge of an atom type
  virtual bool add_charges (unsigned int, Real_t);  
  
  // does as it says.
  virtual void remove_atom(const int index);
  virtual void remove_atom(std::vector<int> index_list);  // it copy the vector

  // calculates total kinetic energy of the atoms
  virtual double kinetic_energy();


  // calculates total kinetic energy of a type of atoms
  virtual double kinetic_energy(const int);

  virtual void add_random_velocity();

  // find and exchange owned atoms between domain or do periodic exchange
  virtual bool exchange_owned ();
  
  // find and exchange ghost atoms between domains or do periodic ghost
  virtual void exchange_ghost ();

  // does as it says
  virtual bool position_inside_local_domain(const Vector<double> &pos);

  // finds the global_id of an Atom that's going to be added.  
  virtual GlobalID_t get_global_id ();  


  // used when there are different MPI domains and all of them should know all
  // the atom_data
  virtual void synch_owned_data(int type);

  // recording owned.position, velocity... in the owned.position_old ... if
  // necessary.
  virtual void record_owned_old_data();
  
  // Here we define an unnamed interpreter and make two of it. It can have a name
  // but since it is used only once here, its name won't be of any use. Also 
  // a good name would be 'atom_data' which is used before!.
  struct {
    // 'id' is a global and unique number assigned to an atom.
    std::vector<GlobalID_t> id;

    // A tag to be done on the atoms.
    std::vector<AtomType_t> tag;

    // Atom type decides the charge, mass and any other property shared between
    // a defined type (for example, Elements).
    std::vector<AtomType_t> type;

    // 'mass' of an atom defined by the type.
    std::vector<Real_t> mass;
    std::vector<Real_t> mass_inv; //since  usually use mass inverse;

    // 'charge' of an atom defined by the type.
    std::vector<Real_t> charge;

    // 'radius' of an atom defined by the type. The user and the developers are
    // free to use this variable (for now!).
    std::vector<Real_t> radius;

    // Different by atom_id. Can be changed in simulation (it is needed to be sent-recv. by MPI)
    std::vector<Real_t> charge_atom; 

    // Different by atom_id. Can be changed in simulation (it is needed to be sent-recv. by MPI)
    std::vector<Real_t> mass_atom; 

    // Atom kinematic properties in the current time-step.
    std::vector<Vector<Real_t>> position, velocity, acceleration;

    // This vectors are used in some integrator schemes and constraint methods.
    // They can be defined in their related objects, but they may be needed in
    // more than one objects at once (for example, constraint::M_shake and 
    // integrator::Leap_frog). This makes it the reason to define it here.
    // This function may be needed to have MPI_send-recv. process in these case.
    // look up to it.
    std::vector<Vector<Real_t>> position_old, velocity_old, acceleration_old; 


    // this vector is meaningful when there's one domain. We can calculate MSD
    // using this. It collects number of periodic domain cross for each particle.
    std::vector<Vector<int>> msd_domain_cross;

    
    // this part matters when molecules are in the play. The first index, meaning
    // the first std::vector, is the molecule index. the inner data contain bonds.
    std::vector <std::vector<objects::atom_data::Bond>> atomic_bond_vector; 
    // and a list of atoms which are in the molecule
    // note that this is different from Molecule->atomic_bond_index_list
    std::vector <std::vector<int>> atomic_bond_index_vector; 
    // this vector contain a molecule index for all the atoms. if it's '-1' the
    // atom is not of any molecule. This matters in the MPI process. All of the
    // atoms of a molecule should be existed in one process.
    std::vector <int> molecule_index; //

    // The first index, meaning
    // the first std::vector, is the molecule index. the inner data contain angles.
    std::vector <std::vector<objects::atom_data::Angle>> atomic_angle_vector; 
    // and a list of atoms which are in the molecule
    std::vector <std::vector<int>> atomic_angle_index_vector;  
  }  
  // There are two types of this unnamed interpreter: owned and ghost. 'owned' atoms
  // are the one that matter in integrators in the domain. Ghost particles are
  // the particle near the domain boundaries which are not from the domain. Their
  // usage is for short-range force-field calculations.
  owned, ghost; 

  // it turns the process of recording owned data in the releated std::vector
  bool record_owned_position_old, record_owned_velocity_old, record_owned_acceleration_old;

  // since not all of the situations need ghost particles velocity, we only send
  // if it is required.
  bool make_ghost_velocity;

  // what these variables do are obvious. 'est' is for estimation.
  LocalID_t num_local_atoms, num_local_atoms_est;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;

  std::vector<int> ghost_rank; // the rank of the domain in which the owned counterpart exists

  // i wonder if this should be here or it should be in the neighborlist class
  std::vector<Vector<Real_t>> last_reneighborlist_pos;

  // if true, more than just atom position have to be synched in single domain mpi case
  bool synch_owned_data_bcast_details;

  // is it useful?
  double neighborlist_cutoff;

  // obvious
  double ghost_cutoff;

  // is it useful?
  double cutoff_extra;

  // usage
  class objects::Domain *domain;

  // usage in 'empty_of_atoms()' functions.
  class objects::neighborlist::Cell_list *cell_list;

  FC_BASE_OBJECT_COMMON_TOOLS

};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
