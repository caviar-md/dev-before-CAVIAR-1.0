
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_DISTRIBUTION_H
#define FINECUPPA_OBJECTS_UNIQUE_DISTRIBUTION_H

#include "finecuppa/objects/unique.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
class Shape;
namespace unique {
class Molecule;
class Molecule_group;
class Atom;
class Atom_group;
class Grid_1D;
class Random_1D;
class Distribution : public Unique {
 public:
  Distribution (class FinECuPPA *);
  ~Distribution () ;
  bool read (finecuppa::interpreter::Parser *);    
  void verify_settings ();
  bool distribute_grid_3D();
  bool distribute_random_3D();

  bool check_radius;
  
  class Shape *boundary_shape;
  class Atom *atom;
  class Atom_group *atom_group;
  class Molecule *molecule;
  class Molecule_group *molecule_group;

  class Grid_1D *grid_1d_x, *grid_1d_y, *grid_1d_z;
  class Random_1D *random_1d_x, *random_1d_y, *random_1d_z;
  
  std::vector<double> radius_vector;

};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
