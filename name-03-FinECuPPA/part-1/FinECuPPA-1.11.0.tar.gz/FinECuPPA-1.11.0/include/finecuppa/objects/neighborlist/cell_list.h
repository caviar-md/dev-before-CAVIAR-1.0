
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_NEIGHBORLIST_CELLLIST_H
#define FINECUPPA_OBJECTS_NEIGHBORLIST_CELLLIST_H

#include "finecuppa/objects/neighborlist.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Domain;
namespace neighborlist {
// to this point, the
// cell list usage is in the potential calculation of electrostatic_ewald_r force_field
// on the finite_element mesh boundaries, 
class Cell_list : public Neighborlist {
 public:
  Cell_list (class FinECuPPA *);
  bool read (class finecuppa::interpreter::Parser *);
  void init ();
  bool rebuild_neighlist ();
  void build_neighlist ();
  void build_binlist ();
  Vector<int> binlist_index (const Vector<double> &);
  int neigh_bin_index (const Vector<double> &);
 public:
  void make_neigh_bin ();
  class objects::Domain *domain;
  bool domain_set;
  bool make_neighlist; // if 'true' one can use this class as a 'verlet_list'.
  double cutoff_neighlist;
};

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
