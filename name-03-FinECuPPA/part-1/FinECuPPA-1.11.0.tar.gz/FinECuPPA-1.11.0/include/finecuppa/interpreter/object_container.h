
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_INTERPRETER_OBJECTCONTAINER_H
#define FINECUPPA_INTERPRETER_OBJECTCONTAINER_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/utility/vector2D.h"
#include "finecuppa/interpreter/object_handler/dictionary.h"

#include <vector>
#include <string>
#include <map>
#include <unordered_set>
#include <memory>

#define FC_COMPLETE_FORWARD_DECLERATION
#include "finecuppa/objects/macro/declaration/all.h"
#undef FC_COMPLETE_FORWARD_DECLERATION

FINECUPPA_NAMESPACE_OPEN
namespace interpreter {
class Parser;
class Object_container : public Pointers  {
public:
  Object_container (class FinECuPPA *);
  ~Object_container ();
  bool read (finecuppa::interpreter::Parser *);
  void report();

  std::map<std::string,finecuppa::interpreter::object_handler::Dictionary> dictionary;

  std::unordered_set<std::string> all_names;

#define FC_GENERAL_CLASSNAME_MACRO(VAR1,VAR2,VAR3) \
  std::vector< VAR3 *> VAR2; // 1

#define FC_GENERAL_CLASSNAME_MACRO_ACTIVATED

#include "finecuppa/objects/macro/declaration/all.h"

#undef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#undef FC_GENERAL_CLASSNAME_MACRO

  // basic types
  std::vector<int> int_variable; // -1
  std::vector<double> real_variable; // -2
  std::vector<Vector2D<int>> int_2d_vector; // -3
  std::vector<Vector2D<double>> real_2d_vector; // -4
  std::vector<Vector<int>> int_3d_vector; // -5
  std::vector<Vector<double>> real_3d_vector; // -6
  std::vector<std::string> string_variable; // -7
  std::vector<bool> boolean_variable; // -8
  std::vector<std::shared_ptr<std::ofstream>>  ofs_objects;

public:

} ;
} //interpreter
FINECUPPA_NAMESPACE_CLOSE

#endif
 
