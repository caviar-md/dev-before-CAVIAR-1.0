
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/shape/polyhedron/input.h"
#include "finecuppa/objects/shape/polyhedron/format_vtk_reader.h"
#include "finecuppa/objects/shape/polyhedron/format_stl_reader.h"

#include <string>
#include <fstream>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {

Input::Input (FinECuPPA *fptr) : Pointers{fptr} {}

Input::~Input () { }

void Input::read_vtk (shape::polyhedron::Polyhedron & p_object, const std::string &file_name) {
  class Format_vtk_reader fvr (fptr);
  fvr.read_polyhedron (p_object, file_name);
}

void Input::read_stl (shape::polyhedron::Polyhedron & p_object, const std::string &file_name) {
  class Format_stl_reader fvr (fptr);
  fvr.read_polyhedron (p_object, file_name);
}

} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

