
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/force_field/electrostatic.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include "finecuppa/objects/atom_data.h"

#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

double Electrostatic::energy () {
// /* // XXX scheme using potential formula.
  const auto &pos = atom_data -> owned.position;    
  double energy_r = 0 ;
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
    const auto charge_j = atom_data -> owned.charge [ type_j ];
//    energy_r += charge_j * potential(j); // 
    energy_r += charge_j * potential(pos [j]); //
  }
  return 0.5 * energy_r ;
// */

}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

