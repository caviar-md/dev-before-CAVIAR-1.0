
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/constraint/atoms_molarity.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/unique/atom.h"
#include "finecuppa/objects/unique/molecule.h"
#include "finecuppa/utility/interpreter_io_headers.h"

#include <random>
#include <algorithm>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

static inline int int_floor(double x) 
{ 
    return (int)(x+100000) - 100000; 
}

Atoms_molarity::Atoms_molarity (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  minimum_limit = 0;
  calculation_box_low = Vector<double> {0.0,0.0,0.0};
  calculation_box_high = Vector<double> {0.0,0.0,0.0};
  creation_box_low = Vector<double> {0.0,0.0,0.0};
  creation_box_high = Vector<double> {0.0,0.0,0.0};
  creation_try = 1;
  creation_molecule = nullptr;
  creation_atom = nullptr;
  settings_verified = false;
  steps = 0; check_steps=1;
  minimum_set = false;
  maximum_set = false;
}

Atoms_molarity::~Atoms_molarity () {}

bool Atoms_molarity::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"add_atom_type")) {
      int i = 0;
      GET_OR_CHOOSE_A_INT(i,"","")
      if (i < 0) error->all (FC_FILE_LINE_FUNC_PARSE, "atom_type have to be non-negative."); 
      atom_type_list.push_back(i);
    } else if (string_cmp(t,"check_steps")) {
      GET_OR_CHOOSE_A_INT(check_steps,"","")
      if (check_steps < 0) error->all (FC_FILE_LINE_FUNC_PARSE, "check_steps have to be non-negative."); 
    } else if (string_cmp(t,"creation_try")) {
      GET_OR_CHOOSE_A_INT(creation_try,"","")
      if (creation_try < 0) error->all (FC_FILE_LINE_FUNC_PARSE, "creation_try have to be non-negative."); 
    } else if (string_cmp(t,"minimum_limit")) {
      GET_OR_CHOOSE_A_INT(minimum_limit,"","")
      if (minimum_limit < 0) error->all (FC_FILE_LINE_FUNC_PARSE, "minimum_limit have to be non-negative."); 
      minimum_set = true;
    } else if (string_cmp(t,"maximum_limit")) {
      GET_OR_CHOOSE_A_INT(maximum_limit,"","")
      if (maximum_limit < 0) error->all (FC_FILE_LINE_FUNC_PARSE, "maximum_limit have to be non-negative."); 
      maximum_set = true;
    } else if (string_cmp(t,"calculation_box")) {
      GET_OR_CHOOSE_A_REAL(calculation_box_low.x,"","")
      GET_OR_CHOOSE_A_REAL(calculation_box_high.x,"","")
      GET_OR_CHOOSE_A_REAL(calculation_box_low.y,"","")
      GET_OR_CHOOSE_A_REAL(calculation_box_high.y,"","")
      GET_OR_CHOOSE_A_REAL(calculation_box_low.z,"","")
      GET_OR_CHOOSE_A_REAL(calculation_box_high.z,"","")
    } else if (string_cmp(t,"creation_box")) {
      GET_OR_CHOOSE_A_REAL(creation_box_low.x,"","")
      GET_OR_CHOOSE_A_REAL(creation_box_high.x,"","")
      GET_OR_CHOOSE_A_REAL(creation_box_low.y,"","")
      GET_OR_CHOOSE_A_REAL(creation_box_high.y,"","")
      GET_OR_CHOOSE_A_REAL(creation_box_low.z,"","")
      GET_OR_CHOOSE_A_REAL(creation_box_high.z,"","")
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"set_creation_molecule") || string_cmp(t,"creation_molecule")) {
      FIND_OBJECT_BY_NAME(unique,it)
      FC_CHECK_OBJECT_CLASS_NAME(unique,it,molecule)
      objects::unique::Molecule *a = dynamic_cast<objects::unique::Molecule *>(object_container->unique[it->second.index]);
      creation_molecule = a;
    } else if (string_cmp(t,"set_creation_atom") || string_cmp(t,"creation_atom")) {
      FIND_OBJECT_BY_NAME(unique,it)
      FC_CHECK_OBJECT_CLASS_NAME(unique,it,atom)
      objects::unique::Atom *a = dynamic_cast<objects::unique::Atom *>(object_container->unique[it->second.index]);
      creation_atom = a;
    } else {
      error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
    }
  }
  return in_file;
}


void Atoms_molarity::step_part_I () {

}

void Atoms_molarity::verify_settings () {
  FC_NULLPTR_CHECK(atom_data)

  if (creation_box_high.x < creation_box_low.x) 
    error->all (FC_FILE_LINE_FUNC, "creation_box_high.x < creation_box_low.x");
  if (creation_box_high.y < creation_box_low.y) 
    error->all (FC_FILE_LINE_FUNC, "creation_box_high.x < creation_box_low.x");
  if (creation_box_high.z < creation_box_low.z) 
    error->all (FC_FILE_LINE_FUNC, "creation_box_high.x < creation_box_low.x");

  if (calculation_box_high.x < calculation_box_low.x) 
    error->all (FC_FILE_LINE_FUNC, "calculation_box_high.x < calculation_box_low.x");
  if (calculation_box_high.y < calculation_box_low.y) 
    error->all (FC_FILE_LINE_FUNC, "calculation_box_high.x < calculation_box_low.x");
  if (calculation_box_high.z < calculation_box_low.z) 
    error->all (FC_FILE_LINE_FUNC, "calculation_box_high.x < calculation_box_low.x");

  if (creation_molecule==nullptr && creation_atom == nullptr)

    error->all (FC_FILE_LINE_FUNC, "creation_molecule==nullptr && creation_atom == nullptr"); 

  if (!(minimum_set || maximum_set))
    output->warning("Atoms_molarity:: !(minimum_set || maximum_set)");

  settings_verified = true;
}

void Atoms_molarity::step_part_II () {
  ++steps;
  if ((steps%check_steps)!=0) { return;}

  if (steps == 100000) steps = 0;

  // if nothing is set. Don't do any calculation.
  if (!(minimum_set || maximum_set)) return;

  if (!settings_verified) verify_settings();

  auto &pos = atom_data->owned.position;
  auto &type = atom_data->owned.type;


  // we record a list of atom indices that are in the area. It is used when we
  // have a maximum_limit constraint.
  std::vector <int>  index_inside_domain;

  
  // for efficiency reasons
  if (maximum_set)
    index_inside_domain.reserve(maximum_limit+20);  


  // getting the number of atoms in the calculation_box
  auto dcal = calculation_box_high - calculation_box_low;
  int sum_of_type = 0;
  for (unsigned int i = 0; i < pos.size(); ++i) {
    auto pm = pos[i] - calculation_box_low;
    for (auto l : atom_type_list) {
    if (type[i] == static_cast<unsigned> (l)) {
      if ((int_floor(pm.x / dcal.x) == 0) && 
          (int_floor(pm.y / dcal.y) == 0) &&
          (int_floor(pm.z / dcal.z) == 0) ) {
        ++sum_of_type;
        if (maximum_set) 
          index_inside_domain.push_back(i);
      }
    }
    }
  }

  static std::mt19937 mt(1);

  // adding atoms if neccesary.
  if (minimum_set && sum_of_type < minimum_limit) {

  static std::uniform_real_distribution<double> dist_x(creation_box_low.x, creation_box_high.x);
  static std::uniform_real_distribution<double> dist_y(creation_box_low.y, creation_box_high.y);
  static std::uniform_real_distribution<double> dist_z(creation_box_low.z, creation_box_high.z);


  int tries = 0;

  if (creation_molecule!=nullptr) {
    auto a = *creation_molecule;
    while (tries < creation_try && sum_of_type < minimum_limit) {
      Vector<double> p {dist_x(mt),dist_y(mt), dist_z(mt)};
      a.position = p;
      if (atom_data->empty_of_atoms(a)) { 
        if (atom_data->add_molecule(a)) {
          sum_of_type++;
        }
      }
      ++tries;
    }
  } else if (creation_atom != nullptr) {
    auto a = *creation_atom;
    while (tries < creation_try && sum_of_type < minimum_limit) {
      Vector<double> p {dist_x(mt),dist_y(mt), dist_z(mt)};
      a.position = p;
      if (atom_data->empty_of_atoms(a)) { 
        if (atom_data->add_atom(a)) {
          sum_of_type++;
        }
      }
      ++tries;
    }
  } 
  }

  // removing atom if necessary
  if (maximum_set && sum_of_type > maximum_limit) {

    int diff = sum_of_type - maximum_limit;

    std::vector<int> selected_types_counter(atom_type_list.size(), 0);
    std::vector<int> v_delete_list;
    v_delete_list.reserve(diff);

    // Method I:
    // delete randomly. It may works, but it may be unnecessarily time consuming
    // in situations of low molarities. 
    /*
    std::uniform_int_distribution<> dist_i(0, index_inside_domain.size()-1);
    for (int n=0; n<diff; ++n) {
      int i = dist_i(mt);
      // element is in the vector
      if (std::find(v_delete_list.begin(), v_delete_list.end(), i) == v_delete_list.end())
        v_delete_list.push_back(index_inside_domain[i]);
    }*/
    

    // Method II:
    // Delete according to the index.
    // since the particles are identical we can easily remove them in a list.
    // Currently it makes no artifact in the simulations that I know.
    // we delete from the last to the first,
    // because in this case we will have less sorting steps. Since the 
    // 'index_inside_domain' vector is constructed from 0 to last;
    auto i_last = index_inside_domain.size() - 1;
    for (int n=0; n<diff; ++n) {
      int i = index_inside_domain[i_last - n];
      int t = type[i];
      for (auto l : atom_type_list) {
        if (l == t) {
          
        }
      }

/*
      while (all_type_found) {
        int i = index_inside_domain[i_last - n];
        int t = type[i];
        for (int l = 0; l < atom_type_list.size(); ++l) {
          if (t==atom_type_list[l]) {
            if (selected_types_counter[l] < diff) {
              selected_types_counter[l] = selected_types_counter[l] + 1;
              v_delete_list.push_back(i);
            } else {
            }
          }
        }
      }
*/

      v_delete_list.push_back(index_inside_domain[i_last - n]);
    }

    atom_data->remove_atom(v_delete_list);
    
  }

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

