
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// Implementation of M-Shake algorithm is done by Ashkan Shahmoradi
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/constraint/m_shake.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include <string>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {



void M_shake::inverse2(std::vector<std::vector<double>>&A, std::vector<std::vector<double>>&minv) {
/*
      for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j){ 
          std::cout << A[i][j] << " ";
        }
        std::cout << std::endl;
      }
      std::cout << std::endl;
*/
  const int A_size = A.size();
  switch (A_size) {

  case(2) : {
    long double det=(A[0][0]*A[1][1]) - (A[0][1]*A[1][0]);
    double invdet = 1.0 / det;
    minv[0][0] =  A[1][1] * invdet;
    minv[0][1] = -A[0][1] * invdet;
    minv[1][0] = -A[1][0] * invdet;
    minv[1][1] =  A[0][0] * invdet;
    return;
  }

  case(3) : {
    long double det=(A[0][0] * (A[1][1] * A[2][2] - A[2][1] * A[1][2])) - 
  	    (A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0])) + 
	      (A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]));//+0.00001;

    if (det==static_cast<long double>(0)) {
      for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j){ 
          std::cout << A[i][j] << " ";
        }
        std::cout << std::endl;
      }
      std::cout << std::endl;

      error->all(FC_FILE_LINE_FUNC,"det==0");
    }

//    if (det<static_cast<long double>(1e-5))
//      error->all(FC_FILE_LINE_FUNC,"det<1e-5");

    double invdet = 1.0 / det;

    minv[0][0] = (A[1][1] * A[2][2] - A[2][1] * A[1][2]) * invdet;
    minv[0][1] = (A[0][2] * A[2][1] - A[0][1] * A[2][2]) * invdet;
    minv[0][2] = (A[0][1] * A[1][2] - A[0][2] * A[1][1]) * invdet;
    minv[1][0] = (A[1][2] * A[2][0] - A[1][0] * A[2][2]) * invdet;
    minv[1][1] = (A[0][0] * A[2][2] - A[0][2] * A[2][0]) * invdet;
    minv[1][2] = (A[1][0] * A[0][2] - A[0][0] * A[1][2]) * invdet;
    minv[2][0] = (A[1][0] * A[2][1] - A[2][0] * A[1][1]) * invdet;
    minv[2][1] = (A[2][0] * A[0][1] - A[0][0] * A[2][1]) * invdet;
    minv[2][2] = (A[0][0] * A[1][1] - A[1][0] * A[0][1]) * invdet;
    return;
  }

//  case(4) : {  }


  default: {
    error->all(FC_FILE_LINE_FUNC,static_cast<std::string> ("Matrix inverse of the level") + std::to_string(A_size) + " is not implemented yet.");
  }

  }
}



M_shake::M_shake (FinECuPPA *fptr) : Constraint{fptr}, 
    atom_data{nullptr}, domain{nullptr},
    dt{-1.0}, error_tolerance{1e-6},
    domain_dh{Vector<double>{0,0,0}},
    domain_bc{Vector<int>{0,0,0}},
    initialized{false}, velocity_fix{true}
{
  FC_OBJECT_INITIALIZE_INFO
}

M_shake::~M_shake () {}

bool M_shake::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"dt") ) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
    } else if (string_cmp(t,"error_tolerance") ) {
      GET_OR_CHOOSE_A_REAL(error_tolerance,"","")
    } else if (string_cmp(t,"set_domain") || string_cmp(t,"domain")) {
      FIND_OBJECT_BY_NAME(domain,it)
      domain = object_container->domain[it->second.index];
      domain_dh = 0.5*(domain->upper_global - domain->lower_global);
      domain_bc = domain->boundary_condition;
    } else if (string_cmp(t,"velocity_fix")) {
      int v=0;
      GET_OR_CHOOSE_A_INT(v,"","")
      if (v==0) velocity_fix = false;
      if (v==1) velocity_fix = true;
    } 
    else FC_ERR_UNDEFINED_VAR(t)

  }
  return in_file;
}

void M_shake::initialize () {
  FC_NULLPTR_CHECK(atom_data)
  atom_data->record_owned_position_old = true;

  FC_NULLPTR_CHECK(domain)
  if (dt <= 0.0) error->all (FC_FILE_LINE_FUNC, "dt have to be a positive number");      
  initialized = true;
}

void M_shake::step_part_I () {

}

void M_shake::step_part_II () {

  if (!initialized) initialize();

  bond_fix(); // XXX P.I


  if (velocity_fix) {
    // this fix has to be done only on the M-Shake molecules. If not, the normal
    // leap-frog step has to be enough.
    auto &vel = atom_data -> owned.velocity;
    auto &pos = atom_data -> owned.position;
    auto &pos_old = atom_data -> owned.position_old;
    //auto &acc = atom_data -> owned.acceleration;
    auto &atomic_bond_index_vector = atom_data -> owned.atomic_bond_index_vector;
    for (unsigned int i=0; i<atomic_bond_index_vector.size(); i++) { 
    for (unsigned int j=0; j<atomic_bond_index_vector[i].size(); j++) { // XXX P.II
      const auto k = atomic_bond_index_vector[i][j];
      vel[k] = (pos[k] - pos_old[k]) / dt ;			
    }
    }
  }
}


void M_shake::bond_fix () {


  auto &pos = atom_data -> owned.position;
  auto &pos_old = atom_data -> owned.position_old;
  auto &atomic_bond_index_vector = atom_data -> owned.atomic_bond_index_vector;
  auto &atomic_bond_vector = atom_data -> owned.atomic_bond_vector;

  /*
  for (unsigned int i=0; i<atomic_bond_vector.size(); i++) { 
  for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
     std::cout << atomic_bond_vector[i][j].index_1 << " , " 
               << atomic_bond_vector[i][j].index_2 << " , "  
               << atomic_bond_vector[i][j].length << std::endl;
  }
  }
     std::cout << std::endl;
  for (unsigned int i=0; i<atomic_bond_index_vector.size(); i++) { 
  for (unsigned int j=0; j<atomic_bond_index_vector[i].size(); j++) { 
     std::cout << atomic_bond_index_vector[i][j] << " , " ;
  }
  }
  std::cout << std::endl;//
  */


  for (unsigned int i=0; i<atomic_bond_index_vector.size(); i++) { 

    auto Nc = atomic_bond_index_vector[i].size();
    if (Nc==0) continue;
	  std::vector<std::vector<double>> A (Nc, std::vector<double> (Nc,0));
    std::vector<std::vector<double>> M (Nc, std::vector<double> (Nc,0));  //inverse of matrix A


	  std::vector<double> C(Nc,0);

		double sum_err = 1.0;


    while(sum_err>error_tolerance) {

      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 

        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;
        double d = atomic_bond_vector[i][j].length;
        double mass_inv_k1 = 1.0/atom_data->owned.mass[atom_data->owned.type[k1]];
        double mass_inv_k2 = 1.0/atom_data->owned.mass[atom_data->owned.type[k2]];
				double dx =  fix_distance_x(pos[k1].x-pos[k2].x);
				double dy =  fix_distance_y(pos[k1].y-pos[k2].y);
				double dz =  fix_distance_z(pos[k1].z-pos[k2].z);
				double r2 = (dx*dx)+(dy*dy)+(dz*dz);
				C[j] = (r2 - d*d)/(4*dt*dt); 

        double dx_old =  fix_distance_x(pos_old[k1].x-pos_old[k2].x);
        double dy_old =  fix_distance_y(pos_old[k1].y-pos_old[k2].y);
        double dz_old =  fix_distance_z(pos_old[k1].z-pos_old[k2].z);

        for (unsigned int jp=0; jp<atomic_bond_vector[i].size(); jp++) { 
          int kp1 = atomic_bond_vector[i][jp].index_1, kp2 = atomic_bond_vector[i][jp].index_2;

          double dx =  fix_distance_x(pos[kp1].x-pos[kp2].x);
          double dy =  fix_distance_y(pos[kp1].y-pos[kp2].y);
          double dz =  fix_distance_z(pos[kp1].z-pos[kp2].z);

          double r_r_old_dot = (dx_old * dx) + (dy_old * dy) + (dz_old * dz) ;

				
          A[j][jp] = (mass_inv_k1*(delta(k1,kp1) - delta(k1,kp2)) 
                     +mass_inv_k2*(delta(k2,kp2) - delta(k2,kp1)) ) * r_r_old_dot;
					
				}
			}	

      inverse2(A,M);
      //print_matrix("A",A);


      std::vector<double> l(Nc, 0);		//lagrange multipliers
      //double l[Nc];									
      //for(int t=0;t<Nc;t++) l[t]=0;
			
      for(unsigned int t1=0;t1<Nc;t1++){		
      for(unsigned int t2=0;t2<Nc;t2++){
        l[t1] += M[t1][t2]*C[t2];
      }}
	
      //double fcx, fcy, fcz;
	
      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;

        double mass_inv_k1 = 1.0/atom_data->owned.mass[atom_data->owned.type[k1]];
        double mass_inv_k2 = 1.0/atom_data->owned.mass[atom_data->owned.type[k2]];

	  	  double dx_old = fix_distance_x ( pos_old[k1].x - pos_old[k2].x );
		    double dy_old = fix_distance_y ( pos_old[k1].y - pos_old[k2].y );
	      double dz_old = fix_distance_z ( pos_old[k1].z - pos_old[k2].z );

        double r_k1k2_x = dx_old;
        double r_k1k2_y = dy_old;
        double r_k1k2_z = dz_old;

        double f_coef = -2*dt*dt*l[j];
			
				
        double fcx = -f_coef*r_k1k2_x;
        double fcy = -f_coef*r_k1k2_y;		
        double fcz = -f_coef*r_k1k2_z;		
			
        pos[k1].x -= fcx * mass_inv_k1;
        pos[k1].y -= fcy * mass_inv_k1;
        pos[k1].z -= fcz * mass_inv_k1;
        pos[k2].x += fcx * mass_inv_k2;
        pos[k2].y += fcy * mass_inv_k2;
        pos[k2].z += fcz * mass_inv_k2;
      }
	
	
      sum_err = 0.0;
      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;
        double d = atomic_bond_vector[i][j].length;
				double dx =  fix_distance_x ( pos[k1].x - pos[k2].x );
				double dy =  fix_distance_y ( pos[k1].y - pos[k2].y );
				double dz =  fix_distance_z ( pos[k1].z - pos[k2].z );
				double r2 = (dx*dx) + (dy*dy) + (dz*dz);
				C[j] = (r2 - d*d)/(2*d*d);
				sum_err += C[j];
			}
      sum_err = abs( sum_err );

    }
  }
}








} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE


