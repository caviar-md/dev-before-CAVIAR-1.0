
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/integrator/velocity_verlet.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integrator {

Velocity_verlet::Velocity_verlet (FinECuPPA *fptr) : Integrator{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  integrator_type = 1;
}

Velocity_verlet::~Velocity_verlet (){}

bool Velocity_verlet::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"time_step")
          || string_cmp(t,"timestep") || string_cmp(t,"dt")) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
    } else FC_ERR_UNDEFINED_VAR(t)
  }
  return in_file;
}

void Velocity_verlet::verify_settings (){
  FC_NULLPTR_CHECK(atom_data)
}

void Velocity_verlet::step_part_I () {

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();


  for (unsigned int i=0; i<psize; i++) { 

    vel [i] += 0.5 * acc [i] * dt;
    pos [i] += vel [i] * dt;
    acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

}

void Velocity_verlet::step_part_II () {

  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;
    
  for (unsigned int i=0; i<vel.size(); i++) {
    vel [i] += 0.5 * acc [i] * dt;
  }

}

} //integrator
} //objects

FINECUPPA_NAMESPACE_CLOSE


