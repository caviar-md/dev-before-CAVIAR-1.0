
//========================================================================
//
// Copyright (C) 2016 - 2019 by FinECuPPA authors: Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/integrator.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/interpreter_io_headers.h"

#include <iomanip>
#include <string>

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Integrator::Integrator (FinECuPPA *fptr) : Pointers{fptr}, 
    atom_data{nullptr} {
  FC_OBJECT_INITIALIZE
}

Integrator::~Integrator (){}

void Integrator::verify_settings () {
  
}


} //objects

FINECUPPA_NAMESPACE_CLOSE


