#include <iostream>
#include "unv_handler.h"

int main () {

  NS_mesh_handler::Unv_handler unv_handler;
/*
  unv_handler.import("../mesh/Mesh_box_gr.unv", true);
  unv_handler.convert_tetra_to_hexa ();  
  unv_handler.remove_hexa_internals (1e-9);    
  unv_handler.export_("../mesh/test.unv", false);  
*/  
/*
  unv_handler.import ("../mesh/Mesh_5_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_6_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_7_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_8_merge_g.unv", true); 
  unv_handler.remove_hexa_internals (1e-9);  
  unv_handler.export_vtk("../mesh/test.vtk");  
*/
/*
  unv_handler.import ("../mesh/Mesh_5_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_6_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_7_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_8_merge_g.unv", true);    
  unv_handler.merge_all (true);
  unv_handler.remove_hexa_internals (1e-9);    
  unv_handler.export_ ("../mesh/test.unv",false);
*/
/*
  unv_handler.import("../mesh/Mesh_4_compound_tetra.unv", true);  
  unv_handler.import("../mesh/Mesh_1.unv", true);    
  unv_handler.import("../mesh/Mesh_2.unv", true);      
  unv_handler.merge_all (true);  
  unv_handler.convert_tetra_to_hexa ();
  unv_handler.remove_hexa_internals (1e-9); 
  unv_handler.export_("../mesh/test.unv", false);  
*/  
/*  
  unv_handler.import("../mesh/Mesh_1_compound_1part_hexa.unv", true);
  unv_handler.remove_similar_points (1e-9);  
  unv_handler.export_("../mesh/test.unv", false);  
*/ 
/*    
  unv_handler.import("../mesh/Mesh_2_compound_3part_hexa.unv", true);  
  unv_handler.remove_hexa_internals (1e-9);
  unv_handler.export_("../mesh/test.unv", false);  
*/
/*
  unv_handler.import ("../mesh/Mesh_1_gr_delete.unv", true);
  unv_handler.import ("../mesh/Mesh_2_gr_delete.unv", true);
  unv_handler.merge_all (true);  
  unv_handler.remove_hexa_internals (1e-9);
  unv_handler.export_ ("../mesh/test.unv",true);  
*/  
  
  unv_handler.import ("../mesh/compound.unv", true);  
  unv_handler.remove_hexa_internals (1e-9);
  unv_handler.export_("../mesh/test.unv", false);    

}
