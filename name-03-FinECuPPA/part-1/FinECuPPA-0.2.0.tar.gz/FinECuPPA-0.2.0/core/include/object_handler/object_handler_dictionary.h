#ifndef OBJECT_HANDLER_DICTIONARY_H
#define OBJECT_HANDLER_DICTIONARY_H

#include "finecuppa_config.h"

#include <string>
#include <map>

FINECUPPA_NAMESPACE_OPEN

namespace NS_object_handler {

class Dictionary {
	public:
	Dictionary () { };
	Dictionary (int t, int i) : type(t), index(i){ };
	~Dictionary () {};
	int type; 
	int index; 

};


}

FINECUPPA_NAMESPACE_CLOSE

#endif
 
