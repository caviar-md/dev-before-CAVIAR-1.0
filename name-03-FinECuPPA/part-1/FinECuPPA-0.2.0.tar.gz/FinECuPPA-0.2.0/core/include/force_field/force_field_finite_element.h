#ifndef FORCE_FIELD_FINITE_ELEMENT_H
#define FORCE_FIELD_FINITE_ELEMENT_H

#include "finecuppa_config.h"

#include "force_field.h"
#include "finite_element.h"

#include <vector>
#include "vector.h"

FINECUPPA_NAMESPACE_OPEN

class Force_field_finite_element : public Force_field {
public:
  Force_field_finite_element (class MD *);
  ~Force_field_finite_element () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  NS_finite_element::Finite_element<3> *finite_element;
  class Parser *parser;
	class Output *output;
	class Error *error;
};

FINECUPPA_NAMESPACE_CLOSE

#endif
