#include "object_utility_random_1d.h"

#include "finecuppa_config.h"

#include "object_handler_all.h"
#include "object_container.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_object_utility {

//====================================
//====================================
//====================================

	Random_1D::Random_1D () {}
	
  Random_1D::Random_1D (Object_container * all_obj) : 
   min{0}, max{2}, stddev{1}, mean{1}, type{"type"}, seed{1}, generated{false},
   parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
  {
    type_int = 0;
  }	
	
  Random_1D::Random_1D (Object_container * all_obj, std::string type, double min, double max, double stddev, double mean, int seed) : 
   min{min}, max{max}, stddev{stddev}, mean{mean}, type{type}, seed{seed}, generated{false},
   parser{all_obj->parser}, output{all_obj->output}, error{all_obj->error}, object_container{all_obj}
  {
    type_int = 0;
  }
  
	Random_1D::~Random_1D () {
//			delete ran_x,ran_y,ran_z;
//			delete n_dis_x,n_dis_y,n_dis_z;
//			delete u_dis_x,u_dis_y,u_dis_z;
		}
	bool Random_1D::read(Parser* parser) {
		output->info("Random Read: ");
		
		bool in_file = true;
		while(true) {
		  GET_A_TOKEN_FOR_CREATION
		  if (token.string_value=="GENERATE") {generate(); break;}
      else ASSIGN_STRING(type,"Random_1D creation: ","")
		  else ASSIGN_REAL(min,"Random_1D creation: ","")
		  else ASSIGN_REAL(max,"Random_1D creation: ","")
		  else ASSIGN_REAL(stddev,"Random_1D creation: ","")
		  else ASSIGN_REAL(mean,"Random_1D creation: ","")
		  else ASSIGN_INT(seed,"Random_1D creation: ","")	
		  else error->all(FILE_LINE_FUNC,"Random_1D creation: Unknown variable or command ");
	  }
		return in_file;;

	}
	
	void Random_1D::generate () {
		output->info("Random Generate: ");	
	  if (generated == true) 
	    error->all(FILE_LINE_FUNC,"Random_1D: cannot be generated twice. ");
	  generated = true;
	  ran_gen = new std::mt19937 (seed);
	  if (type=="UNIFORM") {
	    type_int = 1;
    	u_dist = new std::uniform_real_distribution<> (min, max) ;
    } else if (type=="NORMAL") {
      type_int = 2;
    	n_dist = new std::normal_distribution<> (mean, stddev);
    } else error->all (FILE_LINE_FUNC, "RANDOM_1D generate: Expected NORMAL or UNIFORM for the type. ");
	}
	
}

FINECUPPA_NAMESPACE_CLOSE

