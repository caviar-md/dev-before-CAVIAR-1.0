#include "output.h"

#include "finecuppa_config.h"

#include <sys/stat.h> // used for mkdir()

#include "atom_data.h"
#include "communicator.h"
#include "force_field.h"
#include "parser.h"
#include "error.h"

FINECUPPA_NAMESPACE_OPEN

Output::Output (MD *md) : Pointers{md}, atom_data{md->atom_data}, comm{md->comm}, energy_step{100}, xyz_step{1000}, povray_step{10000}, output_energy{false}, output_xyz{false}, output_povray{false} {
  tStart1 = clock();
}

void Output::set_parameters (Parser * parser) {
	auto command = parser->get_identifier();
	if (command=="energy") {
  	auto steps = parser->get_literal_int(); 
		energy_step = steps;
		output_energy = true;
	} else if (command=="xyz") {
  	auto steps = parser->get_literal_int(); 
		xyz_step = steps;
		output_xyz = true;
	} else if (command=="povray") {
		auto steps = parser->get_literal_int();
		povray_step = steps;
		output_povray = true;
	} else {
			error->all (FILE_LINE_FUNC, "Invalid syntax: This output command doesn't exist.");
	}

  if (! parser->end_of_line ()) error->all (FILE_LINE_FUNC, "Invalid syntax");
}

void Output::dump_data (int i) {
	if (output_energy && i%energy_step == 0)
		dump_energy (i);
	if (output_xyz && i%xyz_step == 0) {
		dump_xyz (i); 
		clock_t tStart2 = clock();
		std::cout << "info: dump xyz at step " << i << " . Elapsed time: "  
		          << (double)(tStart2 - tStart1)/CLOCKS_PER_SEC << std::endl;
		tStart1 = tStart2;
  }
	if (output_povray && i%povray_step == 0)
		dump_povray (i);
}

void Output::dump_energy (int i) {
  std::cout << "incomplete function:" << __FILE__<<__LINE__<<__func__  << std::endl;
	double p_e = 0;//force_field->potential_energy; 
	double k_e = 0;//force_field->kinetic_energy;
	//force_field->calculate_kinetic_energy();
#ifdef USE_MPI
	const int me = comm->me;
	double p_e_all=0.0,k_e_all=0.0;
	MPI_Barrier (mpi_comm);	
//	MPI_reduce (&p_e, &p_e_all, 1, MPI_DOUBLE, MPI_SUM, 0, mpi_comm);
//	MPI_reduce (&k_e, &k_e_all, 1, MPI_DOUBLE, MPI_SUM, 0, mpi_comm); 
	MPI_Allreduce (&p_e, &p_e_all, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
	MPI_Allreduce (&k_e, &k_e_all, 1, MPI_DOUBLE, MPI_SUM, mpi_comm); 

	if (me ==0){
		ofs_energy << i << " " << k_e << " " << p_e << " " << k_e + p_e << "\n";
	}
#else
	ofs_energy << i << " " << k_e << " " << p_e << " " << k_e + p_e << "\n";
#endif	
}

void Output::dump_povray (int i) {
	atom_data = md->atom_data;
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);	

	const int nprocs = comm->nprocs;
	const int me = comm->me;

  const auto &pos = atom_data -> owned.position;
  const auto &id  = atom_data -> owned.id; 
	const auto &type = atom_data ->owned.type;	

	std::vector<std::vector<int>> all_id;
	std::vector<Vector<double>> all_pos;
	std::vector<int> all_type;
	
	const auto nla = pos.size();//atom_data -> num_local_atoms;
	const auto nta = atom_data -> num_total_atoms;
//	std::cout <<"nla" << nla <<std::endl;
//	std::cout <<"nta" << nta <<std::endl;
	int nla_list [ nprocs ];

	if (nprocs > 1) {
	/*
		for (auto j=0;j<atom_data->ghost.id.size(); ++j)
			if (atom_data->ghost.id[j] == 26)
				std::cout<<"me:" << me << "\tt:" << i <<std::endl;			

		for (auto j=0;j<pos.size(); ++j)
			if (id[j] == 26)
				std::cout<<"me:" << me << " p:" << atom_data->owned.acceleration[j] << "\tt:" << i << "\ttyp:" << type[j] <<std::endl;			
		std::cout<<"me:" << me << " g:" << atom_data->ghost.position.size() << std::endl;
		std::cout<<"me:" << me << " " << pos.size() << id.size() << type.size() << atom_data->owned.acceleration.size() << atom_data -> owned.velocity.size() <<std::endl;
  */
		if (me != 0) { //==================================// nla send
			MPI_Send (&nla, 1, MPI_INT, 0, 0, mpi_comm);
		} else {
			nla_list[0]=nla;
			for (unsigned int i=1; i < nprocs; ++i) {
				MPI_Recv (nla_list+i, 1, MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// id send
			MPI_Send (id.data(), nla, MPI_INT, 0, 0, mpi_comm); // ********CHANGE id to INT before send it *****//
		} else {

			all_id.resize (nprocs);

			for (unsigned int i=0; i < nla; ++i) { // local copy
				all_id[0].push_back (id[i]);
			}
			for (unsigned int i=1; i < nprocs; ++i) {
				int tmp [nla_list[i]];
				MPI_Recv (&tmp, nla_list[i], MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
				for (unsigned int j=0; j<nla_list[i];++j)
					all_id[i].push_back(tmp[j]);
			}
		} //-----------------------------------------------//

			MPI_Barrier (mpi_comm);


		if (me != 0) { //==================================// pos send
			for (unsigned int i=0; i<pos.size (); ++i){
				Vector<double> p_tmp {pos[i].x, pos[i].y, pos[i].z};
				MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, 0, id[i], mpi_comm);
			}
		} else {
			all_pos.reserve(nta);
			for (unsigned int i=0; i<nla; ++i){
				Vector<double> p_tmp;
				p_tmp = pos[i];
				all_pos.push_back (p_tmp);
			}

			for (unsigned int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) {
					Vector<double> p_tmp;
					MPI_Recv (&p_tmp, 3, MPI_DOUBLE, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_pos.push_back (p_tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// type send
			for (unsigned int i=0; i<pos.size (); ++i){
				MPI_Send (&type[i], 1, MPI_INT, 0, id[i], mpi_comm); 
			}
		} else {
			all_type.reserve(nta);
			for (unsigned int i=0; i<nla; ++i){
				int tmp = type[i];
				all_type.push_back (tmp);
			}

			for (int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) { 
					int tmp;
					MPI_Recv (&tmp, 1, MPI_INT, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_type.push_back (tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);


	} else {//==================================// one_processor MPI counterpart.
					// this part can be written in a more concise way.
			all_id.resize (nprocs);
			for (unsigned int i=0; i < nla; ++i) { 
				all_id[0].push_back (id[i]);
				all_pos.push_back (pos[i]);
				all_type.push_back (type[i]);

			}
	
	} //-----------------------------------------------//

	MPI_Barrier (mpi_comm);
#endif

#ifdef USE_MPI
	if (me == 0) {
#endif


	std::string str_povray = "o_pov/o_";

	int b = i;int c = 0;
	while (b>0) {
		b /= 10;
		++c;
	}

	int d = 10 - c;
	while (d>0) {
		str_povray += std::to_string (0);
		--d;
	}

	str_povray += std::to_string (i);
	str_povray.append (".pov");

	const char * char_povray	= str_povray.c_str ();
	ofs_povray.open (char_povray);
	
	
	const auto &all_pos = atom_data -> owned.position;
	//const auto &all_type = atom_data ->owned.type;	
	unsigned int nta = atom_data -> num_total_atoms;
	ofs_povray << "\nunion {\n";
	for (unsigned int i = 0; i<nta; ++i) {
		ofs_povray << "\tsphere {"
		 				<< "<" << all_pos[i].x << "," << all_pos[i].y 
						<< "," << all_pos[i].z << ">,"
//						<< geometry->radius[all_type[i]-1] << "}\n";
						<< "1.0" << "}\n";
	}
	ofs_povray << "\ttexture {\n"
		      	 << "\t\tpigment { color Yellow }\n }\n";

	ofs_povray <<"}\n";					

	ofs_povray.close ();

#ifdef USE_MPI		
	}
#endif
}


void Output::dump_xyz (int i) {
	atom_data = md->atom_data;
#ifdef USE_MPI
	MPI_Barrier (mpi_comm);	

	const int nprocs = comm->nprocs;
	const int me = comm->me;

  const auto &pos = atom_data -> owned.position;
  const auto &id  = atom_data -> owned.id; 
	const auto &type = atom_data ->owned.type;	

	std::vector<std::vector<int>> all_id;
	std::vector<Vector<double>> all_pos;
	std::vector<int> all_type;
	
	const auto nla = pos.size();//atom_data -> num_local_atoms;
	const auto nta = atom_data -> num_total_atoms;
//	std::cout <<"nla" << nla <<std::endl;
//	std::cout <<"nta" << nta <<std::endl;
	int nla_list [ nprocs ];

	if (nprocs > 1) {
	/*
//		for (auto j=0;j<atom_data->ghost.id.size(); ++j)
			if (atom_data->ghost.id[j] == 26)
				std::cout<<"me:" << me << "\tt:" << i <<std::endl;			

//		for (auto j=0;j<pos.size(); ++j)
			if (id[j] == 26)
				std::cout<<"me:" << me << " p:" << atom_data->owned.acceleration[j] << "\tt:" << i << "\ttyp:" << type[j] <<std::endl;			
//		std::cout<<"me:" << me << " g:" << atom_data->ghost.position.size() << std::endl;
//		std::cout<<"me:" << me << " " << pos.size() << id.size() << type.size() << atom_data->owned.acceleration.size() << atom_data -> owned.velocity.size() <<std::endl;
*/
		if (me != 0) { //==================================// nla send
			MPI_Send (&nla, 1, MPI_INT, 0, 0, mpi_comm);
		} else {
			nla_list[0]=nla;
			for (int i=1; i < nprocs; ++i) {
				MPI_Recv (nla_list+i, 1, MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// id send
			MPI_Send (id.data(), nla, MPI_INT, 0, 0, mpi_comm); // ********CHANGE id to INT before send it *****//
		} else {

			all_id.resize (nprocs);

			for (unsigned int i=0; i < nla; ++i) { // local copy
				all_id[0].push_back (id[i]);
			}
			for (unsigned int i=1; i < nprocs; ++i) {
				int tmp [nla_list[i]];
				MPI_Recv (&tmp, nla_list[i], MPI_INT, i, 0, mpi_comm, MPI_STATUS_IGNORE);
				for (unsigned int j=0; j<nla_list[i];++j)
					all_id[i].push_back(tmp[j]);
			}
		} //-----------------------------------------------//

			MPI_Barrier (mpi_comm);


		if (me != 0) { //==================================// pos send
			for (auto i=0; i<pos.size (); ++i){
				Vector<double> p_tmp {pos[i].x, pos[i].y, pos[i].z};
				MPI_Send (&p_tmp.x, 3, MPI_DOUBLE, 0, id[i], mpi_comm);
			}
		} else {
			all_pos.reserve(nta);
			for (auto i=0; i<nla; ++i){
				Vector<double> p_tmp;
				p_tmp = pos[i];
				all_pos.push_back (p_tmp);
			}

			for (int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) {
					Vector<double> p_tmp;
					MPI_Recv (&p_tmp, 3, MPI_DOUBLE, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_pos.push_back (p_tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);

		if (me != 0) { //==================================// type send
			for (unsigned int i=0; i<pos.size (); ++i){
				MPI_Send (&type[i], 1, MPI_INT, 0, id[i], mpi_comm); 
			}
		} else {
			all_type.reserve(nta);
			for (unsigned int i=0; i<nla; ++i){
				int tmp = type[i];
				all_type.push_back (tmp);
			}

			for (unsigned int i=1; i < nprocs; ++i) {
				for (auto j : all_id[i]) { 
					int tmp;
					MPI_Recv (&tmp, 1, MPI_INT, i, j, mpi_comm, MPI_STATUS_IGNORE);
					all_type.push_back (tmp);
				}
			}
		} //-----------------------------------------------//

		MPI_Barrier (mpi_comm);


	} else {//==================================// one_processor MPI counterpart.
					// this part can be written in a more concise way.
			all_id.resize (nprocs);
			for (unsigned int i=0; i < nla; ++i) { 
				all_id[0].push_back (id[i]);
				all_pos.push_back (pos[i]);
				all_type.push_back (type[i]);

			}
	
	} //-----------------------------------------------//

	MPI_Barrier (mpi_comm);

	if (me == 0) {
/*		std::cout<<nla_list[0] <<" " << nla_list[1] << std::endl;
		int k = 0;
		for (auto i = 0; i < nprocs; ++i) {
			for (auto j = 0; j < all_id[i].size(); ++j) {
				std::cout << i << ": " << all_id[i][j] << " p: " << all_pos[k] << std::endl;
				++k;
			}
		}*/
		ofs_xyz << all_type.size() << "\nAtom\n";
		for (unsigned int i=0; i<all_type.size(); ++i) {
			ofs_xyz << all_type[i] << " " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n";
		}
	  ofs_xyz << std::flush;
	}
//	if (me==0) std::cout <<" i:" << i << std::flush;
#else
//	std::cout <<" i:" << i << std::flush;
  ++i; //WARNING
  auto &all_pos = atom_data -> owned.position;
	auto &all_type = atom_data ->owned.type;	
//	unsigned int nta = atom_data -> num_total_atoms;
	auto nta = atom_data -> owned.position.size();
	ofs_xyz << nta << "\nAtom\n";
	for (unsigned int i = 0; i<nta; ++i) {
		ofs_xyz << all_type[i] << " " << all_pos[i].x << " " << all_pos[i].y << " " << all_pos[i].z << "\n";
	}
	ofs_xyz << std::flush;
#endif

}

void Output::close_files () {
#ifdef USE_MPI
	if (comm->me == 0) {
		close_them ();
	}
#else
	close_them ();
#endif
}


void Output::open_files () {
#ifdef USE_MPI
	if (comm->me ==0){
		open_them ();
	}
#else
	open_them ();
#endif
}


void Output::close_them () {
	ofs_energy.close ();
	ofs_xyz.close	();
	ofs_velocities.close ();
}


void Output::open_them () {

	std::string str_energy = "o_e",
							str_xyz	= "o_xyz",
							str_velocities = "o_v";


	std::string str_filename = "";
	//char buffer[50] = "";

// --- just to make povray outpuy folder ---
	if (output_povray) {
		std::string str_folder_pov;
  	str_folder_pov.append("o_pov"); 
  	const char* char_folder_pov = str_folder_pov.c_str();
		mkdir (char_folder_pov,0777);  // make povray  output folder //
	}
// =========================================


/*
#ifdef USE_MPI
	sprintf ( buffer, "_me%u", comm->me );
	str_filename.append ( buffer);
#endif
*/

/*
 	sprintf ( buffer, "_n%u", G_no_grains );
	str_filename.append ( buffer);
*/
	str_xyz.append ( str_filename);
	str_xyz.append ( ".xyz");

	str_filename.append ( ".txt" );

	str_energy.append (str_filename);
//	str_velocities.append (str_filename);



	const char * char_energy = str_energy.c_str ();
	const char * char_xyz = str_xyz.c_str ();
//	const char * char_velocities	= str_velocities.c_str ();


	if (output_energy)
		ofs_energy.open	(char_energy);
	if (output_xyz)
		ofs_xyz.open (char_xyz);

}

void Output::print_hello () {
	for (unsigned int i = 1; i<5; i++) {
		ofs_energy << i <<" hello\n";
		ofs_xyz << i <<" hello\n"<<std::flush;
		ofs_velocities << i <<" hello\n"<<std::flush;
	}
}

FINECUPPA_NAMESPACE_CLOSE

