
There are examples provided at FinECuPPA directory. 
to use them, after building FinECuPPA, one just have to direct the script to the FinECuPPA binary.

