#include "finecuppa/structure/object_creator.h"
#include "finecuppa/objects/single_type_objects/all.h"
#include "finecuppa/objects/all_structure_tools.h"

FINECUPPA_NAMESPACE_OPEN


#define FC_GENERAL_CLASSNAME_MACRO(VAR1,FUNCTION_NAME,CLASS_NAME) \
bool Object_creator::FUNCTION_NAME (Parser * parser) { \
  GET_A_TOKEN_FOR_CREATION_NAME_RETURN(token);\
  NAME_ASSIGN_CHECK(token);\
  object_container->all_names.insert(token.string_value);\
  CLASS_NAME *p_sh;\
  p_sh = new CLASS_NAME (fptr);\
  p_sh->this_object_name = token.string_value;\
  int index = object_container->FUNCTION_NAME.size ();\
  object_container -> FUNCTION_NAME.push_back (p_sh);\
  object_handler::Dictionary dict (object_handler::gdst(#FUNCTION_NAME), index);\
  object_container -> dictionary.insert (std::make_pair(token.string_value,dict));\
  return true;\
} 

#define FC_GENERAL_CLASSNAME_MACRO_ACTIVATED

#include "finecuppa/objects/single_type_objects/macro/all.h"

#undef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#undef FC_GENERAL_CLASSNAME_MACRO



FINECUPPA_NAMESPACE_CLOSE


