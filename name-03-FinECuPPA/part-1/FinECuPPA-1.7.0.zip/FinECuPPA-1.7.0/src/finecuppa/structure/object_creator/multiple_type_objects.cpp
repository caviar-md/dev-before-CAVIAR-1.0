#include "finecuppa/structure/object_creator.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/all_derived_classes.h"

FINECUPPA_NAMESPACE_OPEN

#define FC_GET_OBJECT_NAME(OBJECT_TYPE)\
  std::string NAME = ""; \
  bool name_called = false; \
  bool in_file = true; \
  std::string object_type = ""; \
  while(true) { \
    GET_A_TOKEN_FOR_CREATION \
    ASSIGN_NAME \
    else GET_A_STRING_NNT(object_type, #OBJECT_TYPE, "") \
  }\
  bool object_type_found = false;

//-----------------------------


#define FC_ADD_OBJECT_TO_CONTAINER(OBJECT_TYPE) \
  if (!object_type_found) \
    error->all(FC_FILE_LINE_FUNC_PARSE,static_cast<std::string>("Undefined '") + #OBJECT_TYPE +"::"+object_type+"'."); \
  p_sh->this_object_name = NAME; \
  int index = object_container -> OBJECT_TYPE.size ();\
  object_container -> OBJECT_TYPE.push_back (p_sh);\
  object_handler::Dictionary dict (object_handler::gdst(#OBJECT_TYPE), index);\
  object_container -> dictionary.insert (std::make_pair(NAME,dict)); \
  return in_file;




#define FC_CHECK_AND_CREATE(VAR1,VAR2,VAR3) \
  if ((!object_type_found) && string_cmp_i(object_type, #VAR2)) { \
    object_type_found = true; \
    p_sh = new VAR3 (fptr); \
  }


#define FC_OBJECT_CREATOR_DEFAULT_FUNCTION(VAR1) \
  bool Object_creator:: VAR1 (Parser *parser) 

#define FC_OBJECT_CREATOR_FUNCTION_DEFINITON
#define FC_CHECK_AND_CREATE_ACTIVATED

#include "finecuppa/objects/macro/all.h"


#undef FC_CHECK_AND_CREATE_ACTIVATED
#undef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
#undef FC_OBJECT_CREATOR_DEFAULT_FUNCTION
#undef FC_CHECK_AND_CREATE

/*
bool Object_creator::force_field (Parser *parser) {

  FC_GET_OBJECT_NAME(force_field)

  bool object_type_found = false;
  objects::Force_field * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::force_field::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/force_field/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'force_field::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(force_field)
}
*/



/*
bool Object_creator::shape (Parser *parser) {

  FC_GET_OBJECT_NAME(shape)

  bool object_type_found = false;
  objects::Shape * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::shape::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/shape/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'shape::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(shape)
}



bool Object_creator::long_range_solver (Parser *parser) {

  FC_GET_OBJECT_NAME(long_range_solver)

  bool object_type_found = false;
  objects::Long_range_solver * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::long_range_solver::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/long_range_solver/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'long_range_solver::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(long_range_solver)
}

bool Object_creator::writer (Parser *parser) {

  FC_GET_OBJECT_NAME(writer)

  bool object_type_found = false;
  objects::Writer * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::writer::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/writer/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'writer::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(writer)
}

bool Object_creator::integration (Parser *parser) {

  FC_GET_OBJECT_NAME(integration)

  bool object_type_found = false;
  objects::Integration * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::integration::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/integration/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'integration::"+object_type+"'.");

 
  FC_ADD_OBJECT_TO_CONTAINER(integration)
}

bool Object_creator::simulator (Parser *parser) {

  FC_GET_OBJECT_NAME(simulator)

  bool object_type_found = false;
  objects::Simulator * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::simulator::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/simulator/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'simulator::"+object_type+"'.");


  FC_ADD_OBJECT_TO_CONTAINER(simulator)
}

bool Object_creator::atom_data (Parser *parser) {

  FC_GET_OBJECT_NAME(atom_data)

  bool object_type_found = false;
  objects::Atom_data * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::atom_data::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/atom_data/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'atom_data::"+object_type+"'.");
  
  FC_ADD_OBJECT_TO_CONTAINER(atom_data)
}

bool Object_creator::domain (Parser *parser) {

  FC_GET_OBJECT_NAME(domain)

  bool object_type_found = false;
  objects::Domain * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::domain::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/domain/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'domain::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(domain)
}

bool Object_creator::neighborlist (Parser *parser) {

  FC_GET_OBJECT_NAME(neighborlist)

  bool object_type_found = false;
  objects::Neighborlist * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::neighborlist::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/neighborlist/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'neighborlist::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(neighborlist)
}

bool Object_creator::constraint (Parser *parser) {

  FC_GET_OBJECT_NAME(neighborlist)

  bool object_type_found = false;
  objects::Constraint * p_sh;  
#define FC_CHECK_AND_CREATE(TYPE) \
  if ((!object_type_found) && string_cmp_i(object_type, #TYPE)) { \
    object_type_found = true; \
    p_sh = new objects::constraint::TYPE (fptr); \
  }

#define FC_CHECK_AND_CREATE_ACTIVATED
#include "finecuppa/objects/constraint/all.h"
#undef FC_CHECK_AND_CREATE_ACTIVATED

#undef FC_CHECK_AND_CREATE
  if (!object_type_found)
    error->all(FC_FILE_LINE_FUNC_PARSE,"Undefined 'constraint::"+object_type+"'.");

  FC_ADD_OBJECT_TO_CONTAINER(constraint)
}
*/
#undef FC_GET_OBJECT_NAME
#undef FC_ADD_OBJECT_TO_CONTAINER

FINECUPPA_NAMESPACE_CLOSE

