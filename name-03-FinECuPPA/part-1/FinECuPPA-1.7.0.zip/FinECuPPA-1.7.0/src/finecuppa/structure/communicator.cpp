#include "finecuppa/structure/communicator.h"
#include "finecuppa/objects/domain.h"

#include <vector>
#include <map>

FINECUPPA_NAMESPACE_OPEN

Communicator::Communicator (FinECuPPA *fptr) : Pointers{fptr} {
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  MPI_Comm_rank (mpi_comm, &me);
  MPI_Comm_size (mpi_comm, &nprocs);
#endif
}



void Communicator::broadcast (bool &flag) {
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  MPI_Bcast (&flag, 1, MPI::BOOL, 0, mpi_comm);
#else
  std::cout <<"Communicator::broadcast " << flag << std::endl;
#endif
}

void Communicator::broadcast (size_t &n) {
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
#else
  std::cout <<"Communicator::broadcast " << n << std::endl;  
#endif
}

void Communicator::broadcast (size_t &n, char *str) {
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
  MPI_Bcast (str, n, MPI::CHAR, 0, mpi_comm);
#else
  std::cout <<"Communicator::broadcast " << n << " " << str << std::endl;  
#endif
}

void Communicator::broadcast (std::string &str) {
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)

  int n = me == 0 ? str.length() : 0;
  MPI_Bcast (&n, 1, MPI::INT, 0, mpi_comm);
  MPI_Barrier (mpi_comm);

  // The reason behind '[n+1]' for 'char *tmp' is because of 'strcpy':
  // (from http://www.cplusplus.com/reference/cstring/strcpy/)
  // To avoid overflows, the size of the array pointed by destination shall be
  // long enough to contain the same C string as source (including the 
  // terminating null character), and should not overlap in memory with source.
  char *tmp = new char[n+1];

  strcpy (tmp, str.c_str());

  MPI_Bcast (tmp, n, MPI::CHAR, 0, mpi_comm);

  if (tmp) {
    if ( tmp[0] ) {
      str.assign (const_cast<const char *> (tmp), n);
    } else { }
  } else { }

  MPI_Barrier (mpi_comm);

  delete[] tmp;

#else
  std::cout <<"Communicator::broadcast is called in non-mpi mode" << str << std::endl;  
#endif
}



FINECUPPA_NAMESPACE_CLOSE

