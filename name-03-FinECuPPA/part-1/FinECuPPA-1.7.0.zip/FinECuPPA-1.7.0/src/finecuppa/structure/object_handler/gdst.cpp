#include "finecuppa/structure/object_handler/gdst.h"

FINECUPPA_NAMESPACE_OPEN

namespace object_handler {

int gdst (const std::string & t) { //get_dictionary_second_type 
  for (int i = 0; i <  static_cast<int>(object_handler::dictionary_second_type.size()); ++i) {
    if (dictionary_second_type[i]==t) return i;
  }
  return 0;
}

}

FINECUPPA_NAMESPACE_CLOSE

