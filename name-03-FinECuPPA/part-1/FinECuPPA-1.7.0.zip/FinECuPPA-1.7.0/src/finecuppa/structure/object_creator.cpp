#include "finecuppa/structure/object_creator.h"
#include "finecuppa/structure/object_creator/commands_map.h"

FINECUPPA_NAMESPACE_OPEN

Object_creator::Object_creator (FinECuPPA *fptr) : Pointers{fptr} { }
  
Object_creator::~Object_creator () { }

FINECUPPA_NAMESPACE_CLOSE


