#include "finecuppa/structure/input.h"
#include "finecuppa/structure/object_creator.h"
#include "finecuppa/structure/input/commands_map.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/all_structure_tools.h"

#include <map>
#include <cmath>
#include <algorithm>

//#define DEBUG_ME

FINECUPPA_NAMESPACE_OPEN

// used in order to remove 'if' or 'elseif' from the line and get the condition
/*
static std::string remove_the_first_word (const std::string &str) {
  int i = 0;
  while (isblank(str[i])) i++;
  while (!isblank(str[i])) i++;
  while (isblank(str[i])) i++;
  if (i > static_cast<int>(str.size())) return "";
  return str.substr(i);
}
*/

Input::Input (FinECuPPA *fptr) : Pointers {fptr}, parser {new Parser{fptr}},
    fptr{fptr}
{
  fptr->interpreter_num_Input_class++;
#ifdef DEBUG_ME
  std::cout<<"DEBUG_ME: INPUT constructor t1" << std::endl;
#endif
}

Input::Input (FinECuPPA *fptr, const std::string &file) : Pointers {fptr},
    parser {new Parser{fptr, file}}, fptr{fptr} {
  fptr->interpreter_num_Input_class++;
#ifdef DEBUG_ME
  std::cout<<"DEBUG_ME: INPUT constructor t2" << std::endl;
#endif
}

Input::Input (FinECuPPA *fptr, std::istringstream &iss) : Pointers {fptr},
    parser {new Parser{fptr, iss}}, fptr{fptr} {
  fptr->interpreter_num_Input_class++;
#ifdef DEBUG_ME
  std::cout<<"DEBUG_ME: INPUT constructor t3" << std::endl;
#endif
}

Input::~Input () {
  fptr->interpreter_num_Input_class--;
#ifdef DEBUG_ME
  std::cout<<"DEBUG_ME: INPUT destructor " << std::endl;
#endif
  delete parser;
}

// called by FinECuPPA object at execute()
void Input::read () {
  while (read_command (parser));
  if (fptr->interpreter_num_Input_class==1) {
    if (fptr->interpreter_break_called) {
      error->all (FC_FILE_LINE_FUNC_PARSE, "stray 'break' command.");
    } else if (fptr->interpreter_continue_called) {
      error->all (FC_FILE_LINE_FUNC_PARSE, "stray 'continue' command.");
    }
  }
}

bool Input::read (Parser * parser) {
  while (read_command (parser));
  return true;
}

bool Input::read_command (Parser * parser) {
  // there can be more than one Input levels when there's a 'break' or 'continue'
  // call. For example in cases there's an 'if' condition inside a 'do' loop.
  // In that case, the interpreter isn't allowed to do anything unless the command
  // is handled.
  if (fptr->interpreter_break_called || fptr->interpreter_continue_called) {
    return false;
  }
  Token t;
  do { // go to the first non-eol token
    t = parser->get_raw_token();
  } while (t.kind == Kind::eol);

  std::string command;
  if (t.kind == Kind::eof) return false;
  if (t.kind == Kind::identifier)
    command = t.string_value;
  auto command_lowercase = command;
#ifdef FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE
  //transform 'command' to lower case
  std::transform(command_lowercase.begin(), command_lowercase.end(),
                 command_lowercase.begin(), ::tolower);  
#endif  
  if (commands_map.count (command_lowercase) != 0) 
    return (this->*commands_map.at(command_lowercase)) (parser);
  else if (object_creator->commands_map.count (command_lowercase) != 0) {
    return (object_creator->*object_creator->commands_map.at(command_lowercase)) (parser);
  } else if (object_handler->commands_map.count (command_lowercase) != 0) {
    return (object_handler->*object_handler->commands_map.at(command_lowercase)) (parser);
  } else if (object_container->all_names.count(command) != 0){ // object name is case sensitive
    return object_handler->read_object (parser, command);
  } else {
    error->all (FC_FILE_LINE_FUNC_PARSE, static_cast<std::string>("Invalid command or object name: ")+command_lowercase);
  }
  return true;  
}


FINECUPPA_NAMESPACE_CLOSE

