#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Constraint::Constraint (FinECuPPA *fptr) : Pointers{fptr}, integration_type{-1},
    integration{nullptr} {
  FC_OBJECT_INITIALIZE
}

Constraint::~Constraint () {}

} //objects



FINECUPPA_NAMESPACE_CLOSE

