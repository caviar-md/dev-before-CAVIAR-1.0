#include "finecuppa/objects/single_type_objects/distribution.h"
#include "finecuppa/objects/shape.h"
#include "finecuppa/objects/single_type_objects/grid_1d.h"
#include "finecuppa/objects/single_type_objects/atom.h"
#include "finecuppa/objects/single_type_objects/molecule.h"
#include "finecuppa/objects/all_structure_tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {


Distribution::Distribution (FinECuPPA *fptr) : Pointers{fptr},
    check_radius{false},
    boundary_shape{nullptr}, 
    object_atom{nullptr},
    object_molecule{nullptr}, container_molecule{nullptr},
    grid_1d_x{nullptr}, grid_1d_y{nullptr}, grid_1d_z{nullptr},
    random_1d_x{nullptr}, random_1d_y{nullptr}, random_1d_z{nullptr}
{
  FC_OBJECT_INITIALIZE_INFO
}
  
Distribution::~Distribution () {}  
  
bool Distribution::read (Parser* parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
      
  while(true){
    GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (string_cmp(t,"boundary_shape")) {
      FIND_OBJECT_BY_NAME(shape,it)
      boundary_shape = object_container->shape[it->second.index];
    } else if (string_cmp(t,"object_atom")) {
      FIND_OBJECT_BY_NAME(atom,it)        
      object_atom = object_container->atom[it->second.index];
    } else if (string_cmp(t,"object_molecule")) {
      FIND_OBJECT_BY_NAME(molecule,it)        
      object_molecule = object_container->molecule[it->second.index];
    } else if (string_cmp(t,"container_molecule")) {
      FIND_OBJECT_BY_NAME(molecule,it)        
      container_molecule = object_container->molecule[it->second.index];
    } else if (string_cmp(t,"distribute_grid_3d")) {
      distribute_grid_3D();
      return in_file;
    } else if (string_cmp(t,"distribute_random_3d")) {
      distribute_random_3D(); 
      return in_file;
    } else if (string_cmp(t,"grid_1d_x")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      grid_1d_x = object_container->grid_1d[it->second.index];
    } else if (string_cmp(t,"grid_1d_y")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      grid_1d_y = object_container->grid_1d[it->second.index];
    } else  if (string_cmp(t,"grid_1d_z")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      grid_1d_z = object_container->grid_1d[it->second.index];
    } else  if (string_cmp(t,"random_1d_x")) {
      FIND_OBJECT_BY_NAME(random_1d,it)        
      random_1d_x = object_container->random_1d[it->second.index];
    } else  if (string_cmp(t,"random_1d_y")) {
      FIND_OBJECT_BY_NAME(random_1d,it)        
      random_1d_y = object_container->random_1d[it->second.index];
    } else  if (string_cmp(t,"random_1d_z")) {
      FIND_OBJECT_BY_NAME(random_1d,it)        
      random_1d_z = object_container->random_1d[it->second.index];
    } else {
      FC_ERR_UNDEFINED_VAR(t)
    }
  }
  return in_file;
}
  
bool Distribution::distribute_grid_3D( ) {
  output->info("distribute_grid_3D:");
  bool in_file = true;

  FC_NULLPTR_CHECK(grid_1d_x)
  FC_NULLPTR_CHECK(grid_1d_y)
  FC_NULLPTR_CHECK(grid_1d_z)

  FC_NULLPTR_CHECK(container_molecule)

  if (object_atom==nullptr && object_molecule==nullptr ) {
    error->all(FC_FILE_LINE_FUNC, "(object_atom==nullptr && object_molecule==nullptr )");
  }
    
  std::vector<double> r_vector; // radius of atoms
  std::vector<Vector<double>> p_vector; // total positions of atoms
  if (object_atom != nullptr) {
    r_vector.push_back (object_atom->get_radius());
    p_vector.push_back (object_atom->pos_tot());
  }
  if (object_molecule != nullptr) {
    object_molecule->give_position_and_radius (p_vector, r_vector);
  }


  for (unsigned int i = 0; i < grid_1d_x->no_points(); ++i) {
  double x = grid_1d_x->give_point(i);
  for (unsigned int j = 0; j < grid_1d_y->no_points(); ++j) {
  double y = grid_1d_y->give_point(j);      
  for (unsigned int k = 0; k < grid_1d_z->no_points(); ++k) {  
    double z = grid_1d_z->give_point(k);          
    const Vector<double> p {x,y,z}, v{0,0,0};
         /* 
          // simple method - just center is inside condition
          if (boundary_shape->is_inside(p)) {
            if (object_atom_check)
              container_molecule->add_atom (*object_atom, p, v);
            if (object_molecule_check)
              container_molecule->add_molecule (*object_molecule, p, v);
          }
        */
          
    bool inside_flag = true;
    if (boundary_shape != nullptr)
      for (unsigned int m = 0; m<r_vector.size(); ++m)
        if (!boundary_shape->is_inside(p + p_vector[m], r_vector[m])) {
          inside_flag = false;
          continue;
       }
            
    if (inside_flag) {
      if (object_atom != nullptr)
        container_molecule->add_atom (*object_atom, p, v);
      if (object_molecule != nullptr)
        container_molecule->add_molecule (*object_molecule, p, v);              
    }
          
  }
  }
  }
    
  container_molecule -> correct_heritage ();
    
  return in_file;
}
  
  
bool Distribution::distribute_random_3D( ) {
  output->info("DISTRIBUTE_RANDOM_3D: ");   
  bool in_file = true;
   
  FC_ERR_NOT_IMPLEMENTED
      
  return in_file;
}
  
} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

