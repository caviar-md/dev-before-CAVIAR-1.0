#ifdef USE_DEALII

#include "finecuppa/objects/force_field/dealii_poisson_ewald.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

namespace dealii_poisson_ewald {

double BoundaryValues::potential_of_free_charges (const dealii::Point<3> &p) const
{
  const Vector<double> r = {p[0], p[1], p[2]};

  const auto &field_k_coef = deal_force -> field_k_coef;
  const auto &k_vector = deal_force -> k_vector;
  const auto &potential_k_coef_cmplx = deal_force -> potential_k_coef_cmplx;
  const auto n_k_vectors = deal_force -> n_k_vectors;
  const auto l_xyz_inv = deal_force -> l_xyz_inv;

// potential r-space
  double potential_r = 0 ;  
// XXX Working scheme using binlist. 
// TODO: Using verlet_list here needs a neigborlist for every quadrature
// points of the finite_element cells on the boundaries. In addition to that,
// one needs to write a customized version of dealii::interpolate_boundary_value
// template function.

  {
  const auto &pos = atom_data -> owned.position;
  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;
  const auto nb_i = neighborlist -> neigh_bin_index (r);
  const int pos_size = pos.size();

  const auto pos_i = r;

  for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];

    for (unsigned i = 0; i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++i) {

      int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][i];

      bool is_ghost = j >= pos_size;

      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {

        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ]; 
      const auto r_ij = pos_i - pos_j;

      if (r_ij.x == 0 && r_ij.y == 0 && r_ij.z == 0) continue;

      const auto r_ij_norm = std::sqrt(r_ij*r_ij);
      const auto erfc_arg = alpha*r_ij_norm;

      potential_r += charge_j * std::erfc(erfc_arg) / r_ij_norm;    
    }
  }
  }

// potential k-space 
  double potential_k = 0 ;  
// XXX Fastest Working scheme
  {
  double sum_k = 0;

  static std::complex<double> ii(0.0, 1.0);    


  for (int k = 0; k < n_k_vectors; ++k) {
    const auto k_vector_k = k_vector[k];
    const auto field_k_coef_k = field_k_coef[k];

    auto rho = potential_k_coef_cmplx[k];

    rho *= std::exp(-ii*(k_vector_k*r));

    const double rho_norm = field_k_coef_k*std::real(rho);

    sum_k += rho_norm;
  }
  potential_k = FC_4PI * l_xyz_inv * sum_k;
  }

// final

  return potential_r + potential_k;
}
//--------------------------------------------------

//template <int dim>
//double BoundaryValues<dim>::value (const Point<dim> &p, const unsigned int ) const
double BoundaryValues::value (const Point<3> &p, const unsigned int ) const
{
#ifdef USE_MD_MPI
  double total_potential_of_free_charges = 0;
  double local_potential_of_free_charges = potential_of_free_charges (p);
//  MPI_Barrier (mpi_communicator); // XXX is it nessecary?

  MPI_Allreduce(&local_potential_of_free_charges,
    &total_potential_of_free_charges,
    1, MPI::DOUBLE, MPI_SUM,  MPI::COMM_WORLD);
    
  return total_potential - total_potential_of_free_charges;
#else
  return total_potential - potential_of_free_charges (p);
#endif     
}

} // dealii_poisson_ewald

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE
#endif
