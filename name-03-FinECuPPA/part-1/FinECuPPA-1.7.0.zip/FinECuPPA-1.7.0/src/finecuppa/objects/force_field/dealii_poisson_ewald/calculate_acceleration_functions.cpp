#ifdef USE_DEALII

#include "finecuppa/objects/force_field/dealii_poisson_ewald.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {


//==================================================
//==================================================
//==================================================


void Dealii_poisson_ewald::calculate_all_particles_ewald_r_acc_neighlist() {
// XXX ewald r-space part - using 'neighlist'
// XXX Working scheme (neighlist) with both 'cell_list' and 'verlet_list'
  const auto &pos = atom_data -> owned.position;
  const unsigned pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  const auto &nlist = neighborlist -> neighlist;
  for (unsigned i = 0; i < pos_size; ++i) {
    const auto pos_i = atom_data->owned.position [i];
    const auto type_i = atom_data -> owned.type [ i ];      
    const auto charge_i = atom_data -> owned.charge [ type_i ];      
    const auto mass_i = atom_data -> owned.mass [ type_i ];      
    for (auto j : nlist[i]) {
      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      
      const auto mass_j = atom_data -> owned.mass [ type_j ];      
      const auto r_ij = pos_i - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*FC_PIS_INV*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);

      const auto force =  k_electrostatic * charge_i * charge_j *sum_r;    

      atom_data -> owned.acceleration[i] += force / mass_i;
      if (!is_ghost)
        atom_data -> owned.acceleration[j] -= force / mass_j;        
    
    }
  }
 
}

//==================================================
//==================================================
//==================================================


void Dealii_poisson_ewald::calculate_all_particles_ewald_r_acc_binlist() {

// XXX Working scheme (binlist) of  'cell_list'

  const auto &pos = atom_data -> owned.position;
  const unsigned pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;


  for (unsigned i = 0; i < pos_size; ++i) {
    const auto pos_i = atom_data->owned.position [i];
    const auto type_i = atom_data -> owned.type [ i ];      
    const auto charge_i = atom_data -> owned.charge [ type_i ];      
    const auto mass_i = atom_data -> owned.mass [ type_i ];      

    const auto nb_i = neighborlist -> neigh_bin_index (pos_i);
    for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];

    for (unsigned bl_i = 0; bl_i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++bl_i) {

      unsigned int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][bl_i];

      if (i>j) continue; // Works as multiplying a '0.5' to the sum. ...
      // ... We have to do this because  we use Newton's third law down there.
      //

      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];

      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      
      const auto mass_j = atom_data -> owned.mass [ type_j ];      
      const auto r_ij = pos_i - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*FC_PIS_INV*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);

      const auto force =  k_electrostatic * charge_i * charge_j *sum_r;    

      atom_data -> owned.acceleration[i] += force / mass_i;
      if (!is_ghost)
        atom_data -> owned.acceleration[j] -= force / mass_j;        
    
    }
    }
  }

}

//==================================================
//==================================================
//==================================================


void Dealii_poisson_ewald::calculate_all_particles_ewald_k_acc() {
// XXX Working scheme of the order N. Best one.
///*
  const auto &pos = atom_data -> owned.position;    
  static std::complex<double> ii(0.0, 1.0);    


  for (int k = 0; k<n_k_vectors; ++k) {

    const auto sum_j_c = std::conj(potential_k_coef_cmplx[k]);

    for (unsigned int i=0;i<pos.size();++i) {
      const auto type_i = atom_data -> owned.type [i] ;
      const auto charge_i = atom_data -> owned.charge [ type_i ];    
      const auto mass_i = atom_data -> owned.mass [ type_i ];    
  
      const double sum_j = std::imag(sum_j_c * std::exp(ii*(k_vector[k]*pos[i])));
      const auto sum_k = FC_4PI * field_k_coef[k] * k_vector[k] * sum_j ;

      const auto force =  k_electrostatic * charge_i * l_xyz_inv * sum_k;
      atom_data -> owned.acceleration[i] += force / mass_i;

    }
  }
//*/
}


} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE
#endif
