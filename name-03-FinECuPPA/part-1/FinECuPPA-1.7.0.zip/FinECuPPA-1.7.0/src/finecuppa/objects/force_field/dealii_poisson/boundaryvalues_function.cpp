#ifdef USE_DEALII

#include "finecuppa/objects/force_field/dealii_poisson.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/atom_data.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {
namespace dealii_poisson {

// for ewald in dealii_poisson:
// if We want to change from Cell List to Verlet List, we have to implement a new
// function for DealII, similar to what it does in 'interpolate_boundary_condition'
template <int dim>
double BoundaryValues<dim>::potential_of_free_charges (const dealii::Point<3> &p) const
{
  if ((!(ewald_r==nullptr))&&(!(ewald_k==nullptr))) {
    return k_electrostatic *
          (ewald_r ->potential(Vector<double>{p[0], p[1], p[2]}) +
           ewald_k ->potential(Vector<double>{p[0], p[1], p[2]}) );
  } else {
    const auto &pos = atom_data -> owned.position;
    double total_potential = 0;
    for (unsigned int i=0;i<pos.size();++i) {
       const auto type_i = atom_data -> owned.type [i] ;
      const auto charge_i = atom_data -> owned.charge [ type_i ];
      const dealii::Point<3> c_pos = {pos[i].x, pos[i].y, pos[i].z};
      double c_dist = p.distance(c_pos);
      total_potential += charge_i / c_dist;
    }   
    total_potential *= k_electrostatic;
    return total_potential;
  }
}
//--------------------------------------------------

template <int dim>
double BoundaryValues<dim>::value (const Point<dim> &p,
                                   const unsigned int ) const
{
#ifdef USE_MD_MPI
  double total_potential_of_free_charges = 0;
  double local_potential_of_free_charges = potential_of_free_charges (p);
//  MPI_Barrier (mpi_communicator); // XXX is it nessecary?

  MPI_Allreduce(&local_potential_of_free_charges,
    &total_potential_of_free_charges,
    1, MPI::DOUBLE, MPI_SUM,  MPI::COMM_WORLD);
    
  return total_potential - total_potential_of_free_charges;
#else
  return total_potential - potential_of_free_charges (p);
#endif     
}


} //dealii_poisson
} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

template class finecuppa::objects::force_field::dealii_poisson::BoundaryValues<3>;
#endif
