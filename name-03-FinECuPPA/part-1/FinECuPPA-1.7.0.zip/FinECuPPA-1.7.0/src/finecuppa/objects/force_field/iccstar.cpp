#include "finecuppa/objects/force_field/iccstar.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Iccstar::Iccstar (FinECuPPA *fptr) : Force_field{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  FC_ERR_NOT_IMPLEMENTED
}

bool Iccstar::read (Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
  }
  
  return in_file;
}

void Iccstar::calculate_acceleration () {

}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

