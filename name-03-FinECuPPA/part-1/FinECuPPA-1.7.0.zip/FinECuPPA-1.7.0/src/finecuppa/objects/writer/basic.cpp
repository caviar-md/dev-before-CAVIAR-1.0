#include "finecuppa/objects/writer/basic.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace writer {

Basic::Basic (FinECuPPA *fptr) : Writer{fptr}
{
  FC_OBJECT_INITIALIZE_INFO
}

Basic::~Basic () {}

bool Basic::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


} //basic
} //objects
FINECUPPA_NAMESPACE_CLOSE

