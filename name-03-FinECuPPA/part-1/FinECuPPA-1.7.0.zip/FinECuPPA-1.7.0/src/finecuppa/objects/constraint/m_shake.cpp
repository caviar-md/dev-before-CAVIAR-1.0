#include "finecuppa/objects/constraint/m_shake.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

M_shake::M_shake (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

M_shake::~M_shake () {}

bool M_shake::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


void M_shake::step_part_I () {

}

void M_shake::step_part_II () {

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

