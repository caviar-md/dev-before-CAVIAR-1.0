#include "finecuppa/objects/constraint/nose_hoover.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Nose_hoover::Nose_hoover (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

Nose_hoover::~Nose_hoover () {}

bool Nose_hoover::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


void Nose_hoover::step_part_I () {

}

void Nose_hoover::step_part_II () {

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

