#include "finecuppa/objects/constraint/rattle.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Rattle::Rattle (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

Rattle::~Rattle () {}

bool Rattle::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


void Rattle::step_part_I () {

}

void Rattle::step_part_II () {

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

