#include "finecuppa/objects/constraint/brendsen.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Brendsen::Brendsen (FinECuPPA *fptr) : Constraint{fptr}
{
  FC_OBJECT_INITIALIZE_INFO
}

Brendsen::~Brendsen () {}

bool Brendsen::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


void Brendsen::step_part_I () {
  switch(integration_type) {

  // velocity_verlet
  case 1:


  // leap_frog
  case 2:


  default:
    error->all("The constraint is not supported with the integration scheme.");
  }
}

void Brendsen::step_part_II () {

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

