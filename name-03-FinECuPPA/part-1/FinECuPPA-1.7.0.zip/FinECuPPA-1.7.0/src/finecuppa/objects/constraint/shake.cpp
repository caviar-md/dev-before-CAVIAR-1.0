#include "finecuppa/objects/constraint/shake.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/all_structure_tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Shake::Shake (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

Shake::~Shake () {}

bool Shake::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


void Shake::step_part_I () {

}

void Shake::step_part_II () {

}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

