#include "finecuppa/objects/simulator.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Simulator::Simulator (FinECuPPA *fptr) : Pointers{fptr} {
  FC_OBJECT_INITIALIZE
}

Simulator::~Simulator () {}

} //objects



FINECUPPA_NAMESPACE_CLOSE

