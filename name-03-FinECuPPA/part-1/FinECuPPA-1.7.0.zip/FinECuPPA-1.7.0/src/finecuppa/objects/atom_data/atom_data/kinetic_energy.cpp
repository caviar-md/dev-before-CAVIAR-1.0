#include "finecuppa/objects/atom_data.h"
#include "finecuppa/structure/communicator.h"
#include "finecuppa/structure/error.h"
#include "finecuppa/objects/domain.h"

#include <algorithm>


FINECUPPA_NAMESPACE_OPEN
namespace objects {


double Atom_data::kinetic_energy () {
  double e_total = 0.0;

  double e_owned = 0.0;

  for (int i = 0; i < static_cast<int>(owned.position.size()); ++i) {
    e_owned += owned.mass[owned.type[i]] * (owned.velocity[i] * owned.velocity[i]);
  }
  e_owned *= 0.5;

#ifdef USE_MD_MPI
  MPI_Allreduce (&e_owned, &e_total, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
  return e_total;
#else
  return e_owned;
#endif

}

double Atom_data::kinetic_energy (const int t) {
  double e_total = 0.0;

  double e_owned = 0.0;

  for (int i = 0; i < static_cast<int>(owned.position.size()); ++i) {
    if (t==static_cast<int>(owned.type[i])) {
      e_owned += owned.mass[owned.type[i]] * (owned.velocity[i] * owned.velocity[i]);
    }
  }
  e_owned *= 0.5;

#ifdef USE_MD_MPI
  MPI_Allreduce (&e_owned, &e_total, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
  return e_total;
#else
  return e_owned;
#endif

}

} //objects

FINECUPPA_NAMESPACE_CLOSE


