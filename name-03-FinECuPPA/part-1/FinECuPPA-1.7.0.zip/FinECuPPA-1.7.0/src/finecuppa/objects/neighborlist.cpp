#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/structure/error.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
Neighborlist::Neighborlist (FinECuPPA *fptr) : Pointers{fptr}, 
    atom_data{nullptr} {
  FC_OBJECT_INITIALIZE
}

Neighborlist::~Neighborlist () {}

Vector<int> Neighborlist::binlist_index (const Vector<double> &a) {
  error->all("NOT implemented yet");
  return Vector<int> {static_cast<int>(a.x),0,0};
}
int Neighborlist::neigh_bin_index (const Vector<double> &a) {
  error->all("NOT implemented yet");
  return a.x;
}

} //objects
FINECUPPA_NAMESPACE_CLOSE

