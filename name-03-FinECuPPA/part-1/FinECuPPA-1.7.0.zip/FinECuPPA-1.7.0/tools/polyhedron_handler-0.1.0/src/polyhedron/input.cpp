#include "finecuppa/objects/shape/polyhedron/input.h"
#include "finecuppa/objects/shape/polyhedron/format_vtk_reader.h"
#include "finecuppa/objects/shape/polyhedron/format_stl_reader.h"

#include <string>
#include <fstream>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {

Input::Input (FinECuPPA *fptr) : Pointers{fptr} {}

Input::~Input () { }

void Input::read_vtk (shape::polyhedron::Polyhedron & p_object, const std::string &file_name) {
  class Format_vtk_reader fvr (fptr);
  fvr.read_polyhedron (p_object, file_name);
}

void Input::read_stl (shape::polyhedron::Polyhedron & p_object, const std::string &file_name) {
  class Format_stl_reader fvr (fptr);
  fvr.read_polyhedron (p_object, file_name);
}

} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

