Polyhedron Handler project
Developed by Morad Biagooi
m.biagooi@gmail.com

What this code do?
It will fix some features of Polyhedrons imported from VTK or STL files.
Sometimes one has to make a polyhedron boundary out of a mesh. The mesh can be
quite refine but the polyhedron usually doesn't need to be so.
