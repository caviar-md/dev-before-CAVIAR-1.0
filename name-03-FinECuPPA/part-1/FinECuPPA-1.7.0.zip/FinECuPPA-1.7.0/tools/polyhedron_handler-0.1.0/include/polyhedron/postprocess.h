#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POSTPROCESS_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POSTPROCESS_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Postprocess : protected Pointers{
public:
  Postprocess (class FinECuPPA *);
  ~Postprocess ();
  

  void make_grid (shape::polyhedron::Polyhedron &); // contains the faces neccesary to check
                        // make_grid has to be called after lowest_highest_coord()
  void lowest_highest_coord (shape::polyhedron::Polyhedron &); // calculates gxlo, gxhi, gylo...


};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
