FOLDER_POV_MERGED='pov_merged/'
CAM_FILE='camera.pov'
MESH_FILE='o_mesh.pov'
SEARCH_DIR='../o_pov'

rm -r $FOLDER_POV_MERGED
mkdir $FOLDER_POV_MERGED

#============== merging files
echo "===== MERGING PART ====="

for ENTERY in "$SEARCH_DIR"/*
do
	FILE_NAME1=$(basename "$ENTERY")
	FILE_NAME2="m$FILE_NAME1"
#	echo "$FILE_NAME1"
#	echo "$FILE_NAME2"
#	echo "$FOLDER_POV_MERGED$FILE_NAME2" 
	cat $CAM_FILE $MESH_FILE $ENTERY > $FOLDER_POV_MERGED$FILE_NAME2
done

#============== png making
echo "===== PNG MAKING PART ====="

for ENTERY in "$FOLDER_POV_MERGED"/*
do
		povray $ENTERY +Q3 +W320 +H200
	#echo "$ENTERY"
done

#============== gif making
echo "===== GIF MAKING PART ====="

convert -delay 20 -loop 0 $FOLDER_POV_MERGED*.png myimage.gif

#==============
#eog myimage.gif

