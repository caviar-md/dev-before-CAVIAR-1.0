#ifndef FINECUPPA_UTILITY_MACRO_FUNCTIONS_H
#define FINECUPPA_UTILITY_MACRO_FUNCTIONS_H


#define FC_SET_OBJECT_TYPE \
  if (this_object_full_type=="") { \
    this_object_full_type = __func__; \
  } else { \
    this_object_full_type = this_object_full_type + "::" + __func__; \
  } \
  this_object_type = __func__;


#define FC_OBJECT_INITIALIZE \
  FC_SET_OBJECT_TYPE 

#define FC_OBJECT_INITIALIZE_INFO \
  FC_OBJECT_INITIALIZE \
  output->info_create (this_object_full_type);

#define FC_OBJECT_READ_INFO \
  output->info_read(this_object_full_type);

#define FC_BASE_OBJECT_COMMON_TOOLS \
  public:\
  std::string this_object_name, this_object_type, this_object_full_type;

#define FC_ERR_NOT_IMPLEMENTED \
  error->all(FC_FILE_LINE_FUNC, static_cast<std::string> ("This feature is not completely implemented yet."));

#define FC_ERR_NOT_IMPLEMENTED_VAR(VAR) \
  error->all(FC_FILE_LINE_FUNC, static_cast<std::string> ("This feature '") + #VAR  + "' is not completely implemented yet.");

#define FC_ERR_UNDEFINED \
  error->all(FC_FILE_LINE_FUNC, static_cast<std::string> ("Undefined variable or command."));

#define FC_ERR_UNDEFINED_VAR(VAR) \
  error->all(FC_FILE_LINE_FUNC, static_cast<std::string> ("Undefined variable or command: '") + #VAR + "'.");

#define FC_NULLPTR_CHECK(OBJECT) \
  if (OBJECT == nullptr) \
    error->all(FC_FILE_LINE_FUNC, static_cast<std::string> ("Encountered 'nullptr' for '") + #OBJECT + "'.");


#endif
