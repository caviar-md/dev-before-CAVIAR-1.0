#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Lj,lj,objects::force_field::Lj)
#endif
