#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Lj_cell_list,lj_cell_list,objects::force_field::Lj_cell_list)
#endif
