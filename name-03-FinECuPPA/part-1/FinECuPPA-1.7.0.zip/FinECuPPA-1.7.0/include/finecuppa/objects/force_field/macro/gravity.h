#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Gravity,gravity,objects::force_field::Gravity)
#endif
