#ifndef FINECUPPA_FORCE_FIELD_MAGNETIC_H
#define FINECUPPA_FORCE_FIELD_MAGNETIC_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {

namespace force_field {

class Magnetic : public Force_field {
public:
  Magnetic (class FinECuPPA *);
  ~Magnetic () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
protected:

  double amplitude;
  Vector<double> direction;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
