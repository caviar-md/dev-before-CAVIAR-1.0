#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Gravity_external,gravity_external,objects::force_field::Gravity_external)
#endif
