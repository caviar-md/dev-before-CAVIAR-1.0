#ifndef FINECUPPA_FORCE_FIELD_GRAVITY_H
#define FINECUPPA_FORCE_FIELD_GRAVITY_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Gravity : public Force_field {
public:
  Gravity (class FinECuPPA *);
  ~Gravity () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
protected:
  //std::vector<std::vector<Real_t>> epsilon,sigma;
  double k_gravity;
  Vector<double> external_field;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
