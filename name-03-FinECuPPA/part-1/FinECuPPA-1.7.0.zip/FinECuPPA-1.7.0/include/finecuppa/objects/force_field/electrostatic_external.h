#ifndef FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EXTERNAL_H
#define FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EXTERNAL_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Electrostatic_external : public Force_field {
public:
  Electrostatic_external (class FinECuPPA *);
  ~Electrostatic_external () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
protected:

  double amplitude;
  Vector<double> direction;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
