#ifndef FINECUPPA_FORCE_FIELD_ELECTROMAGNETIC_H
#define FINECUPPA_FORCE_FIELD_ELECTROMAGNETIC_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Electromagnetic : public Force_field {
public:
  Electromagnetic (class FinECuPPA *);
  ~Electromagnetic () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
protected:

  double amplitude_E, amplitude_B;
  Vector<double> direction_E, direction_B;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
