#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Iccstar,iccstar,objects::force_field::Iccstar)
#endif
