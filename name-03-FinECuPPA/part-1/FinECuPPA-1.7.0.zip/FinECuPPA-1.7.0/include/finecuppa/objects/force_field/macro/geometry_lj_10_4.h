#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Geometry_lj_10_4,geometry_lj_10_4,objects::force_field::Geometry_lj_10_4)
#endif
