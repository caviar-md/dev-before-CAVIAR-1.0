#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Electrostatic,electrostatic,objects::force_field::Electrostatic)
#endif
