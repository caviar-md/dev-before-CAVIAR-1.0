#ifndef FINECUPPA_FORCE_FIELD_ELECTROMAGNETIC_EXTERNAL_H
#define FINECUPPA_FORCE_FIELD_ELECTROMAGNETIC_EXTERNAL_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Electromagnetic_external : public Force_field {
public:
  Electromagnetic_external (class FinECuPPA *);
  ~Electromagnetic_external () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
protected:

  double amplitude_E, amplitude_B;
  Vector<double> direction_E, direction_B;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
