#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Granular,granular,objects::force_field::Granular)
#endif
