#ifndef FINECUPPA_INTEGRATION_LEAP_FROG_H
#define FINECUPPA_INTEGRATION_LEAP_FROG_H

#include "finecuppa/objects/integration.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

class Leap_frog : public Integration {
public:
  Leap_frog (class FinECuPPA *);
   ~Leap_frog();
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

protected:

  std::vector<Vector<Real_t>> position_old, velocity_old, acceleration_old;
};

} //integration
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
