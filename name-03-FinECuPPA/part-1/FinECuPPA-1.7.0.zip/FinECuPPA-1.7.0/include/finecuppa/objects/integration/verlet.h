#ifndef FINECUPPA_INTEGRATION_VERLET_H
#define FINECUPPA_INTEGRATION_VERLET_H

#include "finecuppa/objects/integration.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

class Verlet : public Integration {
public:
  Verlet (class FinECuPPA *);
   ~Verlet();
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

protected:

  std::vector<Vector<Real_t>> position_old, velocity_old, acceleration_old;
};

} //integration
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
