#ifndef FINECUPPA_CONSTRAINT_H
#define FINECUPPA_CONSTRAINT_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Integration;
class Atom_data;
class Constraint : protected Pointers {
 public:
  Constraint (class FinECuPPA *);
  virtual ~Constraint ( );
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void step_part_I () = 0;
  virtual void step_part_II () = 0;

  int integration_type;
  class Integration *integration;
  class objects::Atom_data *atom_data;
 protected:

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
