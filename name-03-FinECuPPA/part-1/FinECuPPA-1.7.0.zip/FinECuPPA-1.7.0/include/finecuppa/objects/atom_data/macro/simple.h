#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Simple,simple,objects::atom_data::Simple)
#endif

