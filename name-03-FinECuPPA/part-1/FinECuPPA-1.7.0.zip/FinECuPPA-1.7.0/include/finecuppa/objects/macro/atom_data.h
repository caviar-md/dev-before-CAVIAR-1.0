
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Atom_data,atom_data,objects::Atom_data)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Atom_data;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(atom_data) {

  FC_GET_OBJECT_NAME(atom_data)

  objects::Atom_data * p_sh; 

#include "finecuppa/objects/atom_data/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(atom_data)
}
#endif
