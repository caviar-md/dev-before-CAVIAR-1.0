
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Force_field,force_field,objects::Force_field)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Force_field;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(force_field) {

  FC_GET_OBJECT_NAME(force_field)

  objects::Force_field * p_sh; 

#include "finecuppa/objects/force_field/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(force_field)
}
#endif
