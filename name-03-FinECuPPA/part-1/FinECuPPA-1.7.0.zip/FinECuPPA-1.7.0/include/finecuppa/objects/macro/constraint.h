
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Constraint,constraint,objects::Constraint)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Constraint;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(constraint) {

  FC_GET_OBJECT_NAME(constraint)

  objects::Constraint * p_sh; 

#include "finecuppa/objects/constraint/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(constraint)
}
#endif
