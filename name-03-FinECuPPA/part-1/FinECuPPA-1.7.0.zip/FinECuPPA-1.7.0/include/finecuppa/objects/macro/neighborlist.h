
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Neighborlist,neighborlist,objects::Neighborlist)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Neighborlist;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(neighborlist) {

  FC_GET_OBJECT_NAME(neighborlist)

  objects::Neighborlist * p_sh; 

#include "finecuppa/objects/neighborlist/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(neighborlist)
}
#endif
