
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Domain,domain,objects::Domain)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Domain;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(domain) {

  FC_GET_OBJECT_NAME(domain)

  objects::Domain * p_sh; 

#include "finecuppa/objects/domain/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(domain)
}
#endif
