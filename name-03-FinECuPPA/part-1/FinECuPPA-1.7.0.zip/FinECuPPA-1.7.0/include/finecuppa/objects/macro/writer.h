
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Writer,writer,objects::Writer)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Writer;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(writer) {

  FC_GET_OBJECT_NAME(writer)

  objects::Writer * p_sh; 

#include "finecuppa/objects/writer/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(writer)
}
#endif
