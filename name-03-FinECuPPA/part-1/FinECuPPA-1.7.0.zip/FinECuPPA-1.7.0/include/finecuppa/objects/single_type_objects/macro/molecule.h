
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Molecule,molecule,objects::single_type_objects::Molecule)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {
class Molecule;
}
}
FINECUPPA_NAMESPACE_CLOSE
#endif
