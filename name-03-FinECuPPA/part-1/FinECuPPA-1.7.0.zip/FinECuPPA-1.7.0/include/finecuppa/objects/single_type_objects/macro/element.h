
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Element,element,objects::single_type_objects::Element)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {
class Element;
}
}
FINECUPPA_NAMESPACE_CLOSE
#endif
