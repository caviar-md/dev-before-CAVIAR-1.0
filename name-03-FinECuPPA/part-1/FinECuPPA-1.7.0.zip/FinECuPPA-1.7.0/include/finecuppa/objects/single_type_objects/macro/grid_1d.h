
#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Grid_1D,grid_1d,objects::single_type_objects::Grid_1D)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {
class Grid_1D;
}
}
FINECUPPA_NAMESPACE_CLOSE
#endif
