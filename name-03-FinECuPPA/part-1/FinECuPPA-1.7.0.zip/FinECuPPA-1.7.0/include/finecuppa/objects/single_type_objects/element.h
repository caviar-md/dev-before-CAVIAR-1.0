#ifndef FINECUPPA_OBJECT_STOBJECTS_ELEMENT_H
#define FINECUPPA_OBJECT_STOBJECTS_ELEMENT_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace single_type_objects {

class Element : protected Pointers {
 public:
  Element () ;
  Element (class FinECuPPA *) ;    
  ~Element ();
  bool read (Parser *);
  double get_radius () const ;
  double get_mass () const ;
  double get_charge () const ;
  int get_element_index() const ;

 protected:
  int element_index;
  double mass, radius, charge;

  FC_BASE_OBJECT_COMMON_TOOLS
      
};

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif 
