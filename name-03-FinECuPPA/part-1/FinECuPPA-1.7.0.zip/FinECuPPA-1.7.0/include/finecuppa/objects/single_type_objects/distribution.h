#ifndef FINECUPPA_OBJECT_STOBJECTS_DISTRIBUTION_H
#define FINECUPPA_OBJECT_STOBJECTS_DISTRIBUTION_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Shape;
namespace single_type_objects {
class Molecule;
class Atom;
class Grid_1D;
class Random_1D;
class Distribution : protected Pointers {
 public:
  Distribution (class FinECuPPA *);
  ~Distribution () ;
  bool read (Parser *);    
  bool distribute_grid_3D();
  bool distribute_random_3D();

  bool check_radius;
  
  class Shape *boundary_shape;
  class Atom *object_atom;
  class Molecule *object_molecule, *container_molecule;

  class Grid_1D *grid_1d_x, *grid_1d_y, *grid_1d_z;
  class Random_1D *random_1d_x, *random_1d_y, *random_1d_z;
  

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
