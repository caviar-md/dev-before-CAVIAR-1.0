#include "finecuppa/objects/domain/macro/box.h"
