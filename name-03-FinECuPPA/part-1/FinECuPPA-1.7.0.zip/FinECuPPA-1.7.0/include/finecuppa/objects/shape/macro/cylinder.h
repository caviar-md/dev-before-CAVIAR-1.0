#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Cylinder,cylinder,objects::shape::Cylinder)
#endif
