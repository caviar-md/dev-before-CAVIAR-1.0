#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Circle,circle,objects::shape::Circle)
#endif
