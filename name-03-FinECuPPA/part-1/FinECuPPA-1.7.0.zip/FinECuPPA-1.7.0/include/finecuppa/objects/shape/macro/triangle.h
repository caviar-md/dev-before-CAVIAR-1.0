#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Triangle,triangle,objects::shape::Triangle)
#endif
