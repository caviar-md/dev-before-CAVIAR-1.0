#ifndef FINECUPPA_SHAPE_SPHERE_H
#define FINECUPPA_SHAPE_SPHERE_H

#include "finecuppa/objects/shape.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
class Sphere : public Shape {
public:
  Sphere (class FinECuPPA *) ;
  ~Sphere ();
  
  bool read(class finecuppa::Parser *);

  double radius;

  Vector<double> center;

  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);   
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);
   
  bool make_basis_vectors();

};

} //shape 
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif

