#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Closed_lines,closed_lines,objects::shape::Closed_lines)
#endif
