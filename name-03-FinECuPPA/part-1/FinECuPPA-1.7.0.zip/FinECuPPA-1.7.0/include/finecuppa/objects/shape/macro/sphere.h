#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Sphere,sphere,objects::shape::Sphere)
#endif
