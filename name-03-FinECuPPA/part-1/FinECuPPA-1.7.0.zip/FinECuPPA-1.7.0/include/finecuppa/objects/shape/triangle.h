#ifndef FINECUPPA_SHAPE_TRIANGLE_H
#define FINECUPPA_SHAPE_TRIANGLE_H

#include "finecuppa/objects/shape.h"
#include "finecuppa/utility/vector.h"
FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {

class Triangle : public Shape {
public:
  Triangle (class FinECuPPA *) ;
  ~Triangle ();

// there are different ways to define a circle: 3 points on it, centre and one point on it, centre and radius and normal,...
  bool read(class finecuppa::Parser *);
  double radius;
  double flatness_tol;
  Vector<double> center;
  Vector<double> normal;
  bool on_the_plane (const Vector<double> &v);
  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);  
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);  
  
  bool make_basis_vectors();


};

} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
