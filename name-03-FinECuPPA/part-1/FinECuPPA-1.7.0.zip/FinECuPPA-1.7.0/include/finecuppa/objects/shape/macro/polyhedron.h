#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Polyhedron,polyhedron,objects::shape::Polyhedron)
#endif
