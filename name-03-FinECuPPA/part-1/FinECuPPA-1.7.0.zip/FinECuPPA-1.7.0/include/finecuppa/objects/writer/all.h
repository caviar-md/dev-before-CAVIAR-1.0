#include "finecuppa/objects/writer/basic.h"
