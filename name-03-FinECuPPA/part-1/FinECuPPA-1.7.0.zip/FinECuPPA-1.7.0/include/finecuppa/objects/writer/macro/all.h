#include "finecuppa/objects/writer/macro/basic.h"
