#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Nve,nve,objects::constraint::Nve)
#endif
