#ifndef FINECUPPA_CONSTRAINT_RATTLE_H
#define FINECUPPA_CONSTRAINT_RATTLE_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

class Rattle : public Constraint {
 public:
  Rattle (class FinECuPPA *);
   ~Rattle ( );
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

 protected:

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
