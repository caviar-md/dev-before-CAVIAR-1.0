#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Nose_hoover,nose_hoover,objects::constraint::Nose_hoover)
#endif
