#ifndef FINECUPPA_CONSTRAINT_NOSE_HOOVER_H
#define FINECUPPA_CONSTRAINT_NOSE_HOOVER_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

class Nose_hoover : public Constraint {
 public:
  Nose_hoover (class FinECuPPA *);
  ~Nose_hoover ( );
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

 protected:

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
