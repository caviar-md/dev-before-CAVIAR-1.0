#ifndef FINECUPPA_CONSTRAINT_M_SHAKE_H
#define FINECUPPA_CONSTRAINT_M_SHAKE_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

class M_shake : public Constraint {
 public:
  M_shake (class FinECuPPA *);
   ~M_shake ( );
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

 protected:

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
