#ifndef FINECUPPA_CONSTRAINT_NVE_H
#define FINECUPPA_CONSTRAINT_NVE_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

class Nve : public Constraint {
 public:
  Nve (class FinECuPPA *);
   ~Nve ( );
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

  double energy;
 protected:

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
