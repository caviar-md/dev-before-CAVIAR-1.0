#ifdef FC_CHECK_AND_CREATE_ACTIVATED
FC_CHECK_AND_CREATE(Monte_carlo,monte_carlo,objects::simulator::Monte_carlo)
#endif
