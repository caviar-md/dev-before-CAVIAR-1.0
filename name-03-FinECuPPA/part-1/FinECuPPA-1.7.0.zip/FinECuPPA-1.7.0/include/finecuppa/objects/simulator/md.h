#ifndef FINECUPPA_SIMULATOR_MD_H
#define FINECUPPA_SIMULATOR_MD_H

#include "finecuppa/objects/simulator.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace simulator {

class Md : public Simulator {
 public:
  Md (class FinECuPPA *);
   ~Md ( );
  bool read (class finecuppa::Parser *);
  bool run ();
  void verify_settings ();
  void setup ();
  void cleanup ();

 protected:
  class objects::Integration *integration;
  double total_time;
  double time_step;
  double initial_time, final_time;
  int initial_step, final_step;
  bool use_time, use_step;
};

} //simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
