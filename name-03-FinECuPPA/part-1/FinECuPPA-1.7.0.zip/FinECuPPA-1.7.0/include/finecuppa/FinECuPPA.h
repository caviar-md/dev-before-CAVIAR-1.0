#ifndef FINECUPPA_FINECUPPA_H
#define FINECUPPA_FINECUPPA_H

#include "finecuppa/utility/finecuppa_config.h"
#include "finecuppa/utility/types.h"
#include "finecuppa/utility/macro_functions.h"

#include <iostream>
#include <fstream>
#include <map>

#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
#include <mpi.h>
#endif

#include "finecuppa/utility/functions.h"

FINECUPPA_NAMESPACE_OPEN

class FinECuPPA {
public:
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  FinECuPPA (int, char**, MPI_Comm);
#else
  FinECuPPA (int, char**);
#endif
  ~FinECuPPA ();
  void execute ();
  
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  MPI_Comm mpi_comm;
#endif
  class Communicator *comm;
  class Error *error;
  class Output *output;
  class Input *input;
  class Object_handler *object_handler;
  class Object_container *object_container;
  class Object_creator *object_creator;
  
  std::ofstream log;
  std::istream in;
  std::ostream out, err;
  bool log_flag, out_flag, err_flag;
  int argc;
  char **argv;

  // these are some helper variables for the interpreter. Not for users.
  // They can be protected.
  int interpreter_num_Input_class;
  bool interpreter_break_called;
  bool interpreter_continue_called;
};

FINECUPPA_NAMESPACE_CLOSE

#endif
