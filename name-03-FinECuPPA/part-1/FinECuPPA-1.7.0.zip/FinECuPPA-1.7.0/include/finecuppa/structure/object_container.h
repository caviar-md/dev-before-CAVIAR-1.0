#ifndef FINECUPPA_OBJECT_CONTAINER_H
#define FINECUPPA_OBJECT_CONTAINER_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/utility/vector2D.h"
#include "finecuppa/structure/object_handler/dictionary.h"

#include <vector>
#include <string>
#include <map>
#include <unordered_set>
#include <memory>

#define FC_COMPLETE_FORWARD_DECLERATION
#include "finecuppa/objects/macro/all.h"
#include "finecuppa/objects/single_type_objects/macro/all.h"
#undef FC_COMPLETE_FORWARD_DECLERATION

FINECUPPA_NAMESPACE_OPEN

class Parser;
class Object_container : protected Pointers  {
public:
  Object_container (class FinECuPPA *);
  ~Object_container ();
  bool read (Parser *);
  void report();

  std::map<std::string,object_handler::Dictionary> dictionary;

  std::unordered_set<std::string> all_names;

#define FC_GENERAL_CLASSNAME_MACRO(VAR1,VAR2,VAR3) \
  std::vector< VAR3 *> VAR2; // 1

#define FC_GENERAL_CLASSNAME_MACRO_ACTIVATED

#include "finecuppa/objects/macro/all.h"
#include "finecuppa/objects/single_type_objects/macro/all.h"

#undef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#undef FC_GENERAL_CLASSNAME_MACRO

  // basic types
  std::vector<int> int_variable; // -1
  std::vector<double> real_variable; // -2
  std::vector<Vector2D<int>> int_2d_vector; // -3
  std::vector<Vector2D<double>> real_2d_vector; // -4
  std::vector<Vector<int>> int_3d_vector; // -5
  std::vector<Vector<double>> real_3d_vector; // -6
  std::vector<std::string> string_variable; // -7
  std::vector<bool> boolean_variable; // -8
  std::vector<std::shared_ptr<std::ofstream>>  ofs_objects;

protected:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
