#ifndef FINECUPPA_ERROR_H
#define FINECUPPA_ERROR_H

#include "finecuppa/utility/pointers.h"

#define FC_FILE_LINE_FUNC_LINE_COL __FILE__,__LINE__,__func__,line,col
#define FC_FILE_LINE_FUNC_PARSE __FILE__,__LINE__,__func__,parser->line,parser->col
#define FC_FILE_LINE_FUNC __FILE__,__LINE__,__func__

FINECUPPA_NAMESPACE_OPEN

class Error : protected Pointers {
public:
  Error (FinECuPPA *);

  void all (const std::string &);

  void all (const char *, int, const char *, const std::string &, unsigned int, const char *);
  void one (const char *, int, const char *, const std::string &, unsigned int, const char *);
  
  void all (const char *, int, const char *, const std::string &, unsigned int, const std::string &);
  void one (const char *, int, const char *, const std::string &, unsigned int, const std::string &);

  void all (const char *, int, const char *, const std::string &);
  void one (const char *, int, const char *, const std::string &);
};

FINECUPPA_NAMESPACE_CLOSE

#endif
