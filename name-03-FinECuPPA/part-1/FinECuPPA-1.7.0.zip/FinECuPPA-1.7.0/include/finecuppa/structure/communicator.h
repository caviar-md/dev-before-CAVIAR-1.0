#ifndef FINECUPPA_COMMUNICATOR_H
#define FINECUPPA_COMMUNICATOR_H

#include "finecuppa/utility/pointers.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects { class Domain; }
class Communicator : protected Pointers {
public:
  Communicator (FinECuPPA *);

  // broadcast a variable from the root process to others
  void broadcast (bool &);
  void broadcast (size_t &);
  void broadcast (size_t &, char *);
  void broadcast (std::string &);
  
  int me, nprocs;// MPI process rank and number of processes

};

FINECUPPA_NAMESPACE_CLOSE

#endif
