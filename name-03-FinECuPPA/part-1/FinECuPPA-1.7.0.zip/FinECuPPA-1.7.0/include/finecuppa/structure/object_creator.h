#ifndef FINECUPPA_OBJECT_CREATOR_H
#define FINECUPPA_OBJECT_CREATOR_H

#include "finecuppa/utility/pointers.h"

#include <string>
#include <map>

FINECUPPA_NAMESPACE_OPEN
class Parser;
using CommandFunc_object_creator = bool (Object_creator::*) (Parser *); // a pointer to boolean function of ...

class Object_creator : protected Pointers  {
public:
  Object_creator (class FinECuPPA *);
  ~Object_creator ();
  
  const static std::map<std::string, CommandFunc_object_creator> commands_map;
  
  // objects creator function declerations.

#define FC_GENERAL_CLASSNAME_MACRO(VAR1,VAR2,VAR3) \
  bool VAR2 (Parser *);

#define FC_GENERAL_CLASSNAME_MACRO_ACTIVATED

#include "finecuppa/objects/macro/all.h"
#include "finecuppa/objects/single_type_objects/macro/all.h"

#undef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#undef FC_GENERAL_CLASSNAME_MACRO


  // basic types creator function declerations.

#define FC_BASIC_TYPES_MACRO(VAR1) \
  bool VAR1 (Parser *);

#define FC_BASIC_TYPES_MACRO_ACTIVATED

#include "finecuppa/structure/object_handler/all_basic_types_macro.h"

#undef FC_BASIC_TYPES_MACRO_ACTIVATED
#undef FC_BASIC_TYPES_MACRO
  
protected:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
