#ifndef FINECUPPA_OUTPUT_H
#define FINECUPPA_OUTPUT_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/structure/communicator.h"

#include <time.h>


FINECUPPA_NAMESPACE_OPEN
class Communicator;
namespace objects { class Atom_data; }
class Output : protected Pointers {
public:
  Output (class FinECuPPA *);
  void open_files (); 
  void close_files (); 
  void dump_data (int); 

  template <typename T>
  void comment (T &, const bool endline=true); 

  template <typename T>
  void info (T &, const int level=0, const bool endline=true);

  template <typename T>
  void info_create (T &, const int level=1, const bool endline=true);

  template <typename T>
  void info_read (T &, const int level=1, const bool endline=true);

  template <typename T>
  void warning (T &, const int level=0, const bool endline=true);

  bool read (class Parser *);

protected:
  class Communicator *comm;
  objects::Atom_data *atom_data;

  void open_them (); // open files after making their names
  void close_them (); // closes files
  void dump_energy (int); // dump energy to file 
  void dump_xyz (int); // dump positions to file in xyz format
  void dump_povray (int); // dump positions to snapshot files in povray format

  int energy_step, xyz_step, povray_step; // number of steps to output data

  std::ofstream ofs_energy,  ofs_xyz, ofs_velocities, ofs_povray; // output files

  bool output_energy, output_xyz, output_povray; // if true, outputs would be created  
  bool output_info[5], output_warning[5];
  clock_t tStart1;
};

template <typename T>
void Output::info (T & str, int level, bool endline) {
  if (output_info[level]) {
#ifdef USE_MD_MPI
    MPI_Barrier (mpi_comm);
    int me = comm -> me;
    if (me==0) {
#endif
      std::cout << "info: ";
      std::cout << str;
      if (endline)
        std::cout << std::endl;
      else
        std::cout << std::flush;
#ifdef USE_MD_MPI
    }
#endif
  }
}

template <typename T>
void Output::info_create (T & str, int level, bool endline) {
  std::string s = "A " + str + " is created.";
  info(s, level, endline);
}

template <typename T>
void Output::info_read (T & str, int level, bool endline) {
  std::string s =  str + ".read(parser) is called.";
  info(s, level, endline);
}

template <typename T>
void Output::warning (T & str, int level, bool endline) {
  if (output_warning[level]) {
#ifdef USE_MD_MPI
    MPI_Barrier (mpi_comm);
    int me = comm -> me;
    if (me==0) {
#endif
      std::cout << "WARNING: ";
      std::cout << str;
      if (endline)
        std::cout << std::endl;
      else
        std::cout << std::flush;
#ifdef USE_MD_MPI
    }
#endif
  }
}

template <typename T>
void Output::comment (T & str, bool endline) {
#ifdef USE_MD_MPI
    MPI_Barrier (mpi_comm);
    int me = comm -> me;
    if (me==0) {
#endif
      std::cout << str;
      if (endline)
        std::cout << std::endl;
      else
        std::cout << std::flush;
#ifdef USE_MD_MPI
    }
#endif
}

FINECUPPA_NAMESPACE_CLOSE

#endif
