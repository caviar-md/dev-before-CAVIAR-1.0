#ifndef FINECUPPA_INPUT_H
#define FINECUPPA_INPUT_H

#include "finecuppa/utility/pointers.h"
#include <istream>
#include <map>

FINECUPPA_NAMESPACE_OPEN

// a pointer to boolean function of Input class.
//using InputCommandFunc = bool (Input::*) (class Parser *); 
using InputCommandFunc = char (Input::*) (class Parser *); 

class Input : protected Pointers {
public:
  Input (class FinECuPPA *);
  Input (class FinECuPPA *, const std::string &);
  Input (class FinECuPPA *, std::istringstream &);
  ~Input ();
  
  void read ();
protected:
  class Parser *parser;
  class FinECuPPA *fptr;

  const static std::map<std::string,InputCommandFunc> commands_map;

  bool read (Parser *);

  bool read_command (Parser *);  

  // commands


  char command_output (Parser *);
  char command_object_container (Parser *);
  char command_read_script_from_file (Parser *);
  char command_exit_program (Parser *);
  char command_echo(Parser *);
  char command_print(Parser *);
  char command_fprint(Parser *);

  char command_for(Parser *);
  char command_next(Parser *);

  char command_while(Parser *);
  char command_do(Parser *);
  char command_end_do(Parser *);

  char command_break(Parser *);
  char command_continue(Parser *);

  char command_if(Parser *);
  char command_else_if(Parser *);
  char command_else(Parser *);
  char command_end_if(Parser *);

  char command_evaluate(Parser *);
  char command_evaluate(const std::string &);

  char command_calculate(Parser *);
  char command_calculate(const std::string &);

  char command_compare_string (Parser *);
  char command_compare_string (const std::string &);
  char command_compare_real (Parser *);
  char command_compare_real (const std::string &);
  char command_compare_int (Parser *);
  char command_compare_int (const std::string &);
  char command_compare (Parser *);
  char command_compare (const std::string &);

  char command_delete_object(Parser *);
  char command_delete_object(const std::string &);

  char command_help(Parser *);
  char command_exit(Parser *);
  char command_delete(Parser *);

  char command_include(Parser *);
  char command_import(Parser *);
  char command_read(Parser *);


  char command_function(Parser *);
  char command_end_function(Parser *);

  char command_class(Parser *);
  char command_end_class(Parser *);

};

FINECUPPA_NAMESPACE_CLOSE

#endif

