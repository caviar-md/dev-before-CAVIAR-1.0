#ifndef VECTOR_H
#define VECTOR_H

#include "finecuppa_config.h"

#include <iostream>

FINECUPPA_NAMESPACE_OPEN

template <typename T>
struct Vector {
  T x, y, z;
};

template <typename T>
Vector<T> operator+ (const Vector<T> &lhs) {
  return lhs;
}

template <typename T>
Vector<T> operator- (const Vector<T> &lhs) {
  return Vector<T> {-lhs.x, -lhs.y, -lhs.z};
}

template <typename T>
Vector<T> operator+ (const Vector<T> &lhs, const Vector<T> &rhs) {
  return Vector<T> {lhs.x+rhs.x, lhs.y+rhs.y, lhs.z+rhs.z};
}

template <typename T>
Vector<T> operator- (const Vector<T> &lhs, const Vector<T> &rhs) {
  return Vector<T> {lhs.x-rhs.x, lhs.y-rhs.y, lhs.z-rhs.z};
}

template <typename T>
T operator* (const Vector<T> &lhs, const Vector<T> &rhs) {
  return lhs.x*rhs.x + lhs.y*rhs.y + lhs.z*rhs.z;
}

template <typename T>
Vector<T> operator* (const Vector<T> &lhs, const double &rhs) {
  return Vector<T> {lhs.x*rhs, lhs.y*rhs, lhs.z*rhs};
}

template <typename T>
Vector<T> operator/ (const Vector<T> &lhs, const double &rhs) {
  return Vector<T> {lhs.x/rhs, lhs.y/rhs, lhs.z/rhs};
}

template <typename T>
Vector<T> operator* (const double &lhs, const Vector<T> &rhs) {
  return Vector<T> {rhs.x*lhs, rhs.y*lhs, rhs.z*lhs};
}

template <typename T>
bool operator== (const Vector<T> &lhs, const Vector<T> &rhs) {
  return rhs.x==lhs.x && rhs.y==lhs.y && rhs.z==lhs.z;
}

template <typename T>
Vector<T> & operator+= (Vector<T> &lhs, const Vector<T> &rhs) {
  lhs.x += rhs.x;
  lhs.y += rhs.y;
  lhs.z += rhs.z;
  return lhs;
}

template <typename T>
Vector<T> & operator-= (Vector<T> &lhs, const Vector<T> &rhs) {
  lhs.x -= rhs.x;
  lhs.y -= rhs.y;
  lhs.z -= rhs.z;
  return lhs;
}

template <typename T>
Vector<T> & operator*= (Vector<T> &lhs, const double &rhs) {
  lhs.x *= rhs;
  lhs.y *= rhs;
  lhs.z *= rhs;
  return lhs;
}

template <typename T>
Vector<T> & operator/= (Vector<T> &lhs, const double &rhs) {
  lhs.x /= rhs;
  lhs.y /= rhs;
  lhs.z /= rhs;
  return lhs;
}

template <typename T>
std::ostream & operator<< (std::ostream& out, const Vector<T> &rhs) {
  return out << rhs.x << '\t' << rhs.y << '\t' << rhs.z;
}

template <typename T>
std::istream& operator<< (std::istream& in, Vector<T> &rhs) {
  return in >> rhs.x >> rhs.y >> rhs.z;
}

template <typename T>
constexpr Vector<T> cross_product (const Vector<T> &v1, const Vector<T> &v2) {
	return	Vector<T> {v1.y*v2.z - v1.z*v2.y, v1.z*v2.x - v1.x*v2.z, v1.x*v2.y - v1.y*v2.x};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
