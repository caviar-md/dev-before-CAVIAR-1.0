#ifndef FORCE_FIELD_GEOMETRY_H
#define FORCE_FIELD_GEOMETRY_H

#include "finecuppa_config.h"

#include "force_field.h"

#include <vector>
#include <map>

#include "polyhedron_handler.h"
#include "shape.h"

FINECUPPA_NAMESPACE_OPEN

class Force_field_geometry : public Force_field {
public:
  Force_field_geometry (class MD *);
  ~Force_field_geometry ();
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:	
  std::vector<NS_shape::Shape *> shape;
  std::vector<double> radius;
  double young_modulus, dissip_coef;

  class Parser *parser;
	class Output *output;
	class Error *error;

};

FINECUPPA_NAMESPACE_CLOSE

#endif
