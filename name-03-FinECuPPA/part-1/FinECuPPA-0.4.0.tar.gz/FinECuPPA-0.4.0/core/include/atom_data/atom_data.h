#ifndef ATOM_DATA_H
#define ATOM_DATA_H

#include "finecuppa_config.h"

#include "pointers.h"

#include <vector>

#include "vector.h"

FINECUPPA_NAMESPACE_OPEN

class Atom_data : protected Pointers {
public:
  Atom_data (class MD *);
  virtual ~Atom_data ();
  
  void set_num_total_atoms (GlobalID_t);
  void set_num_atom_types (AtomType_t n) {num_atom_types = n;}
  
  LocalID_t num_local_atoms, num_local_atoms_est;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;
  
  virtual bool add_atom (GlobalID_t, AtomType_t, const Vector<Real_t> &, const std::vector<Real_t> &other_real = std::vector<Real_t>{}, const std::vector<int> &other_int = std::vector<int>{});
   virtual bool add_atom (GlobalID_t, AtomType_t, const Vector<Real_t> &, const Vector<Real_t> &, const std::vector<Real_t> &other_real = std::vector<Real_t>{}, const std::vector<int> &other_int = std::vector<int>{});

  virtual bool add_masses (unsigned int, Real_t);	
  virtual bool add_charges (unsigned int, Real_t);	

  struct {
    std::vector<GlobalID_t> id;
    std::vector<AtomType_t> type;
    std::vector<Real_t> mass;
    std::vector<Real_t> charge;    
//    std::vector<Real_t> charge_atom; // Different by atom_id. Can be changed in simulation (in this case, it is needed to be sent in MPI)
//    std::vector<Real_t> mass_atom; // Different by atom_id. Can be changed in simulation (in this case, it is needed to be sent in MPI)
    std::vector<Vector<Real_t>> position, velocity, acceleration;
//    std::vector<Vector<Real_t>> pos_3dot, pos_4dot; // will be used in predictor-corrector integration scheme. not implemented yet.
  } owned, ghost;
	std::vector<int> ghost_rank; // the rank of the domain in which the owned counterpart exists
	int x_bc,y_bc,z_bc; // boundary condition in different direction 
  std::vector<Vector<Real_t>> last_reneighbor_pos;
	bool exchange_owned ();
	void exchange_ghost ();
	Vector<Real_t> periodic_distance (Vector<Real_t>, const int, const int, const int);
	
	GlobalID_t get_global_id ();
protected:
  virtual void allocate ();
private:
  double cutoff;

};

FINECUPPA_NAMESPACE_CLOSE

#endif
