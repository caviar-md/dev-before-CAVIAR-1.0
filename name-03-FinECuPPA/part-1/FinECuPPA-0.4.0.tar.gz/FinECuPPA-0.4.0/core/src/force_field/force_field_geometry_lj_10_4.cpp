#include "force_field_geometry_lj_10_4.h"

#include "finecuppa_config.h"

#include <string>
#include <cmath>
#include <fstream>
#include <boost/algorithm/string.hpp>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
#include "object_handler_all.h"
#include "object_container.h"

FINECUPPA_NAMESPACE_OPEN

Force_field_geometry_lj_10_4::Force_field_geometry_lj_10_4 (MD *md) : Force_field {md}, output{md->output}, error{md->error}
{ 
	output->info ("A geometry force field is created.");

}

Force_field_geometry_lj_10_4::~Force_field_geometry_lj_10_4 () { 

}

bool Force_field_geometry_lj_10_4::read (class Parser *parser) {

	output->info("Force_field geometry read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
		if (boost::iequals(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
	    if (cutoff < 0.0) error->all (FILE_LINE_FUNC, "Force field cutoff have to non-negative.");		
		} else if (boost::iequals(t,"add_boundary")) {
      FIND_OBJECT_BY_NAME(boundary,it)
      shape.push_back (&object_container->boundary[it->second.index]);
      //boundary_check = true;
	  }	else if (boost::iequals(t,"add_shape")) {
	    FIND_OBJECT_BY_NAME(shape,it)
      shape.push_back (object_container->shape[it->second.index]);
      //shape_check = true;
	  } else if (boost::iequals(t,"wall_number_density")) {
      GET_OR_CHOOSE_A_REAL(wall_number_density,"","")
	    if (cutoff < 0.0) error->all (FILE_LINE_FUNC, "wall_number_density have to non-negative.");		
		} else if (boost::iequals(t,"epsilon")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(epsilon)
      if (vector_value < 0)  error->all (FILE_LINE_FUNC, "Epsilon have to be non-negative.");      
		}	else if (boost::iequals(t,"sigma")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(sigma)
      if (vector_value < 0)  error->all (FILE_LINE_FUNC, "Sigma have to be non-negative.");            
		} else error->all (FILE_LINE_FUNC, " Unknown variable or command");

	}
	
	return in_file;
}


void Force_field_geometry_lj_10_4::calculate_acceleration () {
  const auto &pos = atom_data -> owned.position;
//const auto &vel = atom_data -> owned.velocity;  
	auto &acc = atom_data -> owned.acceleration;
	for (unsigned int i=0;i<pos.size();++i) {
 		const auto type_i = atom_data -> owned.type [i] ;
	  const auto mass_i = atom_data -> owned.mass [ type_i ];	 
		for (unsigned int j=0; j<shape.size();++j) {
		  Vector <Real_t> contact_vector {0,0,0};				
      if (shape[j] -> in_contact(pos[i], cutoff, contact_vector)) { // NOTE the 'CUTOFF' instead of particle radius
/*
        auto eps_ij = epsilon [0][type_i];
        auto sig_ij = sigma   [0][type_i];
        auto sig_ij_inv = 1.0 / sig_ij;
        auto force_coef = 2.0 * 3.141592653589 * eps_ij * sig_ij * sig_ij * wall_number_density;
        
        auto r_sq     = contact_vector * contact_vector;
//      auto r_sq_inv = 1.0 / r_sq;
        auto r_norm   = std::sqrt (r_sq);
        auto r_inv    = 1.0 / r_norm;
        
        if (r_sq > cutoff*cutoff) continue;
        
        auto rho      = sig_ij * r_inv;
        auto rho_sq   = rho * rho;
        auto rho_5    = rho_sq * rho_sq * rho;
        
        auto r_cut        = cutoff;
//      auto r_cut_sq     = r_cut * r_cut;
//      auto r_cut_sq_inv = 1.0 / r_cut_sq;
        auto r_cut_norm   = r_cut;
        auto r_cut_inv    = 1.0 / r_cut_norm;
        
        auto rho_cut      = sig_ij * r_cut_inv;
        auto rho_cut_inv  = 1.0 / rho_cut;
        auto rho_cut_sq   = rho_cut * rho_cut;
        auto rho_cut_5    = rho_cut_sq * rho_cut_sq * rho_cut;
                
        auto force_norm     = force_coef * 4.0 *  ( - (rho_5*rho_5*r_inv)               + (rho_5*sig_ij_inv));
        auto force_norm_cut = force_coef * 4.0 *  ( - (rho_cut_5*rho_cut_5*rho_cut_inv) + (rho_cut_5*sig_ij_inv));
        
        auto force = (force_norm - force_norm_cut) * r_inv * contact_vector;
      
			  acc[i] += force/mass_i;
*/
        auto dr = contact_vector; 
        auto r_sq = dr*dr;
        if (r_sq > cutoff*cutoff) continue;
        auto eps_ij   = epsilon [0] [type_i];
        auto sigma_ij =  sigma [0] [type_i];

        auto r_c_sq_inv    = 1/(cutoff*cutoff);
        auto rho_c_sq_inv  = sigma_ij*sigma_ij*r_c_sq_inv;
        auto rho_c_6_inv   = rho_c_sq_inv*rho_c_sq_inv*rho_c_sq_inv;
        auto rho_c_12_inv  = rho_c_6_inv*rho_c_6_inv;
      
        auto r_sq_inv      = 1/r_sq;
        auto rho_sq_inv    = sigma_ij*sigma_ij*r_sq_inv;
        auto rho_6_inv     = rho_sq_inv*rho_sq_inv*rho_sq_inv;
        auto rho_12_inv    = rho_6_inv*rho_6_inv;

        auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + 
														 +12*rho_c_12_inv*r_c_sq_inv - 6*rho_c_6_inv*r_c_sq_inv 	) * dr;
														 
			  auto dr_norm = std::sqrt(r_sq);
			  auto r_m_rc = dr_norm-cutoff;
			  potential_energy += 4*eps_ij*(+rho_12_inv - rho_6_inv 
				  										 				-rho_c_12_inv + rho_c_6_inv 
				  														+4.0*eps_ij*(-12*rho_c_12_inv*r_c_sq_inv +6*rho_c_6_inv*r_c_sq_inv )*r_m_rc*dr_norm);
			  acc[i] += force / mass_i;

			 

			}
		}
	}
}

FINECUPPA_NAMESPACE_CLOSE

