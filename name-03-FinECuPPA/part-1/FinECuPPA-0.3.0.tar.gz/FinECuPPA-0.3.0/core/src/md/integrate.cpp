#include "integrate.h"

#include "finecuppa_config.h"

#include "object_container.h"
#include "neighbor.h"
#include "atom_data.h"
#include "force_field.h"
#include "output.h"
#include "update.h"

FINECUPPA_NAMESPACE_OPEN

Integrate::Integrate (MD *md) : Pointers{md}, output{md->output} {}

bool Integrate::run (unsigned int num_steps, double timestep) {
	dt = timestep;

  setup();
	
  for (unsigned int i = 1; i < num_steps+1; i++) {
    step ();
		bool make_list = boundary_condition (); // ***** the problem of difference between MPI and serial, maybe happens here

		output->dump_data (i);
	
    if (make_list || neighbor -> rebuild_neighlist ()) // this have to be checked from left,
		 																									 //	if not,we may get a segmentation fault
																											 //due to unequal pos.size() and old_pos.size() at neighbor
      neighbor -> build_neighlist();
  } 
	
  cleanup(); 
  return true; //WARNING
}

void Integrate::step () {

 // velocity_verlet (); 
  velocity_verlet_Langevin ();   

}

bool Integrate::boundary_condition () {
	bool result = false;
	result = atom_data -> exchange_owned ();
	atom_data -> exchange_ghost ();
#ifdef USE_MPI
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
	return result;
}

void Integrate::setup () {
	output->dump_data (0);
	neighbor -> init ();
	atom_data -> exchange_owned (); // isn't neccesary
	atom_data -> exchange_ghost ();
  neighbor -> build_neighlist ();
  for (auto f : object_container->force_field)
    f -> calculate_acceleration ();

}

void Integrate::cleanup () {

}

void Integrate::velocity_verlet () {
  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();

  for (unsigned int i=0; i<psize; i++) { 
    vel [i] += 0.5 * acc [i] * dt;
  	pos [i] += vel [i] * dt;

		acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

  for (auto f : object_container->force_field)
    f -> calculate_acceleration ();
    
  for (unsigned int i=0; i<psize; i++) {
    vel [i] += 0.5 * acc [i] * dt;
  }
}

void Integrate::velocity_verlet_Langevin () {
  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();
  
  const auto T = 3.325784081; // 400÷120.27239
  const auto zeta = 50.0; // Reduced Units for Finite Pore
//  const auto kb =  XYZ; 

  //const auto eta = rnd_ndist (rnd_generator);    
  
  const auto a = (2.0 - zeta * dt) / (2.0 + zeta * dt);
  const auto b = std::sqrt(1.0 * T * zeta * 0.5 * dt); // Reduced Units for Finite Pore problem
//  const auto b = std::sqrt(kb * T * zeta * 0.5 * dt);  
  const auto c = 2.0 * dt / (2.0 + zeta * dt);
      
  for (unsigned int i=0; i<psize; i++) { 
    const auto eta_x = rnd_ndist (rnd_generator);      
    const auto eta_y = rnd_ndist (rnd_generator); 
    const auto eta_z = rnd_ndist (rnd_generator);
    
    const auto eta = Vector<double>{eta_x, eta_y, eta_z};
    
    vel [i] += 0.5 * acc [i] * dt + b * eta;
  	pos [i] += vel [i] * c;

		acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

  for (auto f : object_container->force_field)
    f -> calculate_acceleration ();
    
  for (unsigned int i=0; i<psize; i++) {
    const auto eta_x = rnd_ndist (rnd_generator);      
    const auto eta_y = rnd_ndist (rnd_generator); 
    const auto eta_z = rnd_ndist (rnd_generator);    
    const auto eta = Vector<double>{eta_x, eta_y, eta_z};
    
    vel [i] = a * vel [i] + b * eta + 0.5 * acc [i] * dt;
  }
}

FINECUPPA_NAMESPACE_CLOSE


