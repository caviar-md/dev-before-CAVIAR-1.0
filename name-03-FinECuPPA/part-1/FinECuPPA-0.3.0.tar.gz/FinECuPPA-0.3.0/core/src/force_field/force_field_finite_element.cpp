#include "force_field_finite_element.h"

#include "finecuppa_config.h"

#include <cmath>
#include <boost/algorithm/string.hpp>

#include "neighbor.h"
#include "atom_data.h"
#include "parser.h"
#include "error.h"
#include "vector.h"
#include "output.h"
#include "object_handler_all.h"
#include "object_container.h"

FINECUPPA_NAMESPACE_OPEN

Force_field_finite_element::Force_field_finite_element (MD *md) : Force_field {md}, output{md->output}, error{md->error}
{

}

bool Force_field_finite_element::read (Parser *parser) {
	output->info("Force_field finite element read");
	bool in_file = true;

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		auto t = token.string_value;
		
		if (boost::iequals(t,"cutoff")) {
			error->all (FILE_LINE_FUNC, "cutoff is not implemented in force_field geometry");  
		} else if (boost::iequals(t,"finite_element")) {
      FIND_OBJECT_BY_NAME(finite_element,it)
      finite_element = object_container->finite_element[it->second.index];
	  } else error->all (FILE_LINE_FUNC, "Unknown variable or command");
	
	}
	
	return in_file;
  return true; // WARNING
}

void Force_field_finite_element::calculate_acceleration () {
  finite_element -> calculate_acceleration ();
}

FINECUPPA_NAMESPACE_CLOSE

