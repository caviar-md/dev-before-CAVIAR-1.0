A directory to do interesting things.
