#ifndef FINECUPPA_FE_DEALII_POISSON_MPI_H
#define FINECUPPA_FE_DEALII_POISSON_MPI_H

#ifdef USE_DEALII_WITH_MPI

#include "finecuppa_config.h"

#include "finite_element.h"


// deal parallel

#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/base/timer.h>

#include <deal.II/lac/generic_linear_algebra.h>


namespace LA
{
#if defined(DEAL_II_WITH_PETSC) && !(defined(DEAL_II_WITH_TRILINOS) && defined(FORCE_USE_OF_TRILINOS))
  using namespace dealii::LinearAlgebraPETSc;
#  define USE_PETSC_LA
#elif defined(DEAL_II_WITH_TRILINOS)
  using namespace dealii::LinearAlgebraTrilinos;
#else
#  error DEAL_II_WITH_PETSC or DEAL_II_WITH_TRILINOS required
#endif
}

#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>

#include <deal.II/lac/petsc_parallel_sparse_matrix.h>
#include <deal.II/lac/petsc_parallel_vector.h>
#include <deal.II/lac/petsc_solver.h>
#include <deal.II/lac/petsc_precondition.h>

#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/error_estimator.h>

#include <deal.II/base/utilities.h>
#include <deal.II/base/conditional_ostream.h>
#include <deal.II/base/index_set.h>
#include <deal.II/lac/sparsity_tools.h>

#include <deal.II/distributed/tria.h>
#include <deal.II/distributed/grid_refinement.h>


// deal serial
/*
#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>

#include <deal.II/fe/fe_q.h>

#include <deal.II/base/function.h>
#include <deal.II/base/tensor.h>

#include <deal.II/numerics/matrix_tools.h>

#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
*/

//
#include <fstream>
#include <iostream>
#include <cmath>



FINECUPPA_NAMESPACE_OPEN

namespace finite_element {



//==================================================
//==================================================
//==================================================

using namespace dealii;

template <int dim>
class FE_dealii_poisson_mpi : public Finite_element<dim>
{
public:
  FE_dealii_poisson_mpi (class MD *);
  ~FE_dealii_poisson_mpi ();

  void calculate_acceleration ();  
  bool read(Parser *);
  double total_potential_of_charges (const dealii::Point<3> &p);
  
private:

  void run ();
  void read_domain();
  void make_grid ();
  void make_boundary_face_normals ();
  void setup_system();
  void assemble_system();
  void solve ();
  void calculate_induced_charge (const int);

  void output_vtk_solution (const int) const;

  void refine_grid_adaptive ();
  void refine_boundary (const unsigned int);

  void set_boundary ();  
  
 
  void set_spherical_manifold();
  
  int tot_no_matched, tot_no_corrected;

  void rotate_and_add (const double angle, const int axis, const double merge_toll);
  void rotate_and_add_reserve (const double angle, const int axis, const double merge_toll);
  void match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll);
                                               
  void my_read_unv(std::istream &in, Triangulation<dim> & tria);


  MPI_Comm                                  mpi_communicator;

  parallel::distributed::Triangulation<dim> triangulation;

  DoFHandler<dim>                           dof_handler;
  FE_Q<dim>                                 fe;

  IndexSet                                  locally_owned_dofs;
  IndexSet                                  locally_relevant_dofs;

  ConstraintMatrix                          constraints;

  LA::MPI::SparseMatrix                     system_matrix;
  LA::MPI::Vector                           locally_relevant_solution;
  LA::MPI::Vector                           system_rhs;

//  ConditionalOStream                        pcout;
//  TimerOutput                               computing_timer;



  Triangulation<dim> tria_reserve;   // XXX needed locally?

  SparsityPattern sparsity_pattern; // XXX needed locally?
  
//  SparseMatrix<double> system_matrix; // serial  
//  dealii::Vector<double> solution; // serial
//  dealii::Vector<double> system_rhs; // serial
  
  class All_charges * all_charges;
  class Atom_data * atom_data;
  class Output * output;
	class Error * error;
	
	bool initialized;
	
  std::vector<std::pair<int,double>> boundary_id_value;
  std::vector<unsigned> boundary_id_list;
  std::vector<int> refine_sequence_type, refine_sequence_value;	
  double k_electrostatic;
  std::vector<std::string> unv_mesh_filename;  
  int time_step_count, time_step_solve, time_step_output_vtk;
  int time_step_induced_charge;
  bool output_vtk;
  double derivation_length;

  std::vector<Tensor<1,3,double>> face_normal;
  std::vector<Point<3>> face_center;  
  std::vector<double> face_area;
  std::vector<unsigned> face_id;  
  std::vector<unsigned> face_id_ignore;
  std::ofstream ofs_induced_charge;
  bool induced_charge_id_init;
  bool output_induced_charge;  
  unsigned int boundary_id_max;
  
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  int my_mpi_rank, mpi_world_size;
#endif   
};


//==================================================
//==================================================
//==================================================
/*

template <int dim>
class RightHandSide : public Function<dim>
{
public:
  RightHandSide () : Function<dim>() {}

  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;
};
*/

//==================================================
//==================================================
//==================================================

//==================================================
//==================================================
//==================================================

namespace dealii_poisson_mpi {
template <int dim>
class BoundaryValues : public Function<dim>
{
public:
  BoundaryValues () : Function<dim>() {}
  BoundaryValues (double tp) : Function<dim>(), total_potential{tp} {}  
  BoundaryValues (double tp, double k_electrostatic, class Atom_data * atom_data) : Function<dim>(), total_potential{tp}, k_electrostatic{k_electrostatic}, atom_data{atom_data} {}  
    
  virtual double value (const Point<dim> &p,
                        const unsigned int component = 0) const;                    
private:
  double total_potential;
  double potential_of_free_charges  (const dealii::Point<3> &p) const;
  double k_electrostatic;  
  class Atom_data * atom_data;
};
} //dealii_poisson_mpi

} //finite_element

FINECUPPA_NAMESPACE_CLOSE
#endif
#endif
