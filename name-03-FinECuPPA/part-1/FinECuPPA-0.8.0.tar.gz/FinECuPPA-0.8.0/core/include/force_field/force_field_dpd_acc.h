#ifndef FINECUPPA_FORCE_FIELD_DPD_ACC_H
#define FINECUPPA_FORCE_FIELD_DPD_ACC_H

#include "finecuppa_config.h"

#include "force_field.h"

#include <vector>
#include <random>

FINECUPPA_NAMESPACE_OPEN

class Force_field_dpd_acc : public Force_field { // this is maybe slower than dpd but more accurate, in the scense that it will send the force caclulated to the owned counterpart of ghost atoms.
public:
  Force_field_dpd_acc (class MD *);
  ~Force_field_dpd_acc () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<std::vector<Real_t>> conserv_coef, dissip_coef;
	Real_t temperature, kBoltzman;
	int rnd_seed;
	std::mt19937 rnd_generator;
	std::normal_distribution<double> rnd_ndist; // stddev() == 1

  class Parser *parser;
	class Output *output;
	class Error *error;	
};

FINECUPPA_NAMESPACE_CLOSE

#endif
