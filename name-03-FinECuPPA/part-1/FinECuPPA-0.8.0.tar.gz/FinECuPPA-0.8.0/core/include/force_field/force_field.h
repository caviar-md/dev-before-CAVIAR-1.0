#ifndef FINECUPPA_FORCE_FIELD_H
#define FINECUPPA_FORCE_FIELD_H

#include "finecuppa_config.h"

#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

class Force_field : protected Pointers {
public:
  Force_field (class MD *);
  virtual ~Force_field () {};
  virtual bool read (class Parser *) = 0;
  virtual void calculate_acceleration () = 0;
	virtual void calculate_kinetic_energy();  
	double kinetic_energy,potential_energy;
  double cutoff;	
private:
  class Parser *parser;
	class Output *output;
	class Error *error;
  
};

FINECUPPA_NAMESPACE_CLOSE

#endif
