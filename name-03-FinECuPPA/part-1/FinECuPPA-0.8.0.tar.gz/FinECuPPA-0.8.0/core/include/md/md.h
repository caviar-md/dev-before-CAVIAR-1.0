#ifndef FINECUPPA_MD_H
#define FINECUPPA_MD_H

#include "finecuppa_config.h"

#include <iostream>
#include <fstream>
#include <map>

#ifdef USE_MD_MPI
#include <mpi.h>
#endif

#include "types.h"

FINECUPPA_NAMESPACE_OPEN

class MD {
public:
#ifdef USE_MD_MPI
  MD (int, char**, MPI_Comm);
#else
  MD (int, char**);
#endif
  ~MD ();
  void execute ();
  
#ifdef USE_MD_MPI
  MPI_Comm mpi_comm;
#endif
  class Communicator *comm;
  class Error *error;
  class Output *output;
  class Input *input;
  class Domain *domain;
  class Atom_data *atom_data;
  class Update *update;
  class Neighbor *neighbor;  
	class Geometry *geometry;  
  class Writer *writer;	
  class Object_handler *object_handler;
  class Object_container *object_container;
  class Object_creator *object_creator;

  
  std::ofstream log;
  std::istream in;
  std::ostream out, err;
  bool log_flag, out_flag, err_flag;
  int argc; 
  char **argv;
  std::map<std::string,int> int_variables;
  std::map<std::string,Real_t> real_variables;
  std::map<std::string,std::string> string_variables;
};

FINECUPPA_NAMESPACE_CLOSE

#endif
