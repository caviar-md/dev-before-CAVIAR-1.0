#ifndef FINECUPPA_INTEGRATE_H
#define FINECUPPA_INTEGRATE_H

#include "finecuppa_config.h"

#include "pointers.h"

#include <random>

FINECUPPA_NAMESPACE_OPEN

class Integrate : protected Pointers {
public:
  Integrate (class MD *);
 	 
  bool run (unsigned int, double);
private:
	class Output *output;

  void step ();
  void setup ();
  void cleanup ();
  void velocity_verlet ();
  void velocity_verlet_Langevin ();
	bool boundary_condition ();
	Real_t dt;
	
	std::mt19937 rnd_generator_x, rnd_generator_y, rnd_generator_z;
	
// stddev() == 1	
	std::normal_distribution<double> rnd_ndist_x, rnd_ndist_y, rnd_ndist_z; 
};

FINECUPPA_NAMESPACE_CLOSE

#endif
