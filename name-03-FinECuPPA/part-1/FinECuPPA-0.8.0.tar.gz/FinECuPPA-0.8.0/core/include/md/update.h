#ifndef FINECUPPA_UPDATE_H
#define FINECUPPA_UPDATE_H

#include "finecuppa_config.h"

#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

class Update : protected Pointers {
public:
  Update (class MD *);
 	~Update ( );

  bool run (int);
  void verify_settings ();
  void setup ();
  void cleanup ();
	double dt;
private:
  class Integrate *integrate;
	class Output *output;
	clock_t t_start, t_end;
	double tot_time;
//	bool self_ghost ();
};

FINECUPPA_NAMESPACE_CLOSE

#endif
