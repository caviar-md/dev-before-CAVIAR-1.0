#ifdef FINECUPPA_ATOM_DATA_CLASS

AtomDataStyle(simple,Atom_data_simple)

#else

#ifndef ATOM_DATA_SIMPLE_H
#define ATOM_DATA_SIMPLE_H

#include "finecuppa_config.h"

#include "atom_data.h"

FINECUPPA_NAMESPACE_OPEN

class Atom_data_simple : public Atom_data {
public:
  Atom_data_simple (class MD *);
private:
  void allocate ();
};

FINECUPPA_NAMESPACE_CLOSE

#endif
#endif
