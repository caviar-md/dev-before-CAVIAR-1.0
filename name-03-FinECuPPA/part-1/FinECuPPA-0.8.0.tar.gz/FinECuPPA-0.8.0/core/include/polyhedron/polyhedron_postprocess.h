#ifndef FINECUPPA_POLYHEDRON_POSTPROCESS_H
#define FINECUPPA_POLYHEDRON_POSTPROCESS_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {
class Polyhedron_Postprocess : protected Pointers{
public:
  Polyhedron_Postprocess (class MD *);
  ~Polyhedron_Postprocess ();
  

	void make_grid (geometry::Polyhedron&); // contains the faces neccesary to check
									      // make_grid has to be called after lowest_highest_coord()
	void lowest_highest_coord (geometry::Polyhedron&); // calculates gxlo, gxhi, gylo...


};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
