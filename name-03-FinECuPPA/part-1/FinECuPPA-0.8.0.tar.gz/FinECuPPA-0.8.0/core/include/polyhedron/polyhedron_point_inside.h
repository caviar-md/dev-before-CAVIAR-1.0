#ifndef FINECUPPA_POLYHEDRON_POINT_INSIDE_H
#define FINECUPPA_POLYHEDRON_POINT_INSIDE_H

#include "finecuppa_config.h"

#include "pointers.h"
#include "polyhedron.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {
class Polyhedron_Point_Inside : protected Pointers {
public:
  Polyhedron_Point_Inside (class MD*);
  ~Polyhedron_Point_Inside ();
  

  bool is_inside(geometry::Polyhedron &, const Vector<double> &v0);
  bool is_outside(geometry::Polyhedron &, const Vector<double> &v);
  
  bool is_inside(geometry::Polyhedron &, const Vector<double> &v, const double r) ;
  bool is_outside(geometry::Polyhedron &, const Vector<double> &v, const double r);
  
  bool in_contact1 (geometry::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius, Vector<double> &contact_vector);
  bool in_contact2 (geometry::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius, Vector<double> &contact_vector);
  
    
  bool check_inside (geometry::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius);
  
  bool check_inside_ray (geometry::Polyhedron &, const Vector<Real_t> &v1, const int ray_axis);
  class Output *output;
  class Error *error;
};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
