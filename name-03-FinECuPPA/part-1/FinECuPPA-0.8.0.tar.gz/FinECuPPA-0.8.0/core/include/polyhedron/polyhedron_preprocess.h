#ifndef FINECUPPA_POLYHEDRON_PREPROCESS_H
#define FINECUPPA_POLYHEDRON_PREPROCESS_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "parser.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {
class Polyhedron_Preprocess : protected Pointers {
public:
  Polyhedron_Preprocess (class MD *);
  ~Polyhedron_Preprocess ();
  

	void pre_correct_normals (geometry::Polyhedron&); // checks neighbor faces and sorts the vertices so that their normal vectors would be alighned when created.


  void merge_vertices (geometry::Polyhedron&);
  


  class Output * output;
  class Error * error;


};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
