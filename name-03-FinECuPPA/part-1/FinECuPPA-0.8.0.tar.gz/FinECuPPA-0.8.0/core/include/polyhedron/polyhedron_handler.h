#ifndef FINECUPPA_POLYHEDRON_HANDLER_H
#define FINECUPPA_POLYHEDRON_HANDLER_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "pointers.h"
#include "output.h"
#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "polyhedron.h"
#include "polyhedron_input.h"
#include "polyhedron_utility.h"
#include "polyhedron_preprocess.h"
#include "polyhedron_postprocess.h"
#include "polyhedron_point_inside.h"
#include "polyhedron_output.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {
class Polyhedron_Handler : protected Pointers{
public:
  Polyhedron_Handler (class MD *);
  ~Polyhedron_Handler ();
  
  bool read (Parser *);
  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);	
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);  
   
private:
  void  command_parameters (Parser *);
  void  command_generate ();

	class geometry::Polyhedron_Input * polyhedron_input;
	class geometry::Polyhedron_Preprocess * polyhedron_preprocess;
	class geometry::Polyhedron_Postprocess * polyhedron_postprocess;
	class geometry::Polyhedron_Utility * polyhedron_utility;	
	class geometry::Polyhedron_Point_Inside * polyhedron_point_inside;	
	class geometry::Polyhedron_Output * polyhedron_output;
	
	
  geometry::Polyhedron polyhedron; 	

	Real_t young_modulus;
	std::vector<Real_t> radius;
	
	bool polyhedron_read, output_mesh_tcl, output_normals_tcl, output_edges_tcl, output_mesh_povray;
	bool invert_normals, correct_normals;	
	
  class Parser *parser;
	class Output *output;
	class Error *error;
};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
