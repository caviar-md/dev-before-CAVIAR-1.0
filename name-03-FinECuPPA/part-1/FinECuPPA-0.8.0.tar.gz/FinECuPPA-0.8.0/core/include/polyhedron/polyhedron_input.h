#ifndef FINECUPPA_POLYHEDRON_INPUT_H
#define FINECUPPA_POLYHEDRON_INPUT_H

#include "finecuppa_config.h"

#include "polyhedron.h"
#include "format_vtk_reader.h"
#include "parser.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {
class Polyhedron_Input : protected Pointers {
public:
  Polyhedron_Input (class MD *);
  ~Polyhedron_Input ();
  
	void read_vtk (geometry::Polyhedron&, const std::string &); // read vtk format // There's many unneeded points. 


  class Output * output;
  class Error * error;


};
}

FINECUPPA_NAMESPACE_CLOSE

#endif
