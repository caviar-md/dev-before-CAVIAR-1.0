#ifndef FINECUPPA_INPUT_H
#define FINECUPPA_INPUT_H

#include "finecuppa_config.h"

#include <istream>
#include <map>

#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

using CommandFunc = bool (Input::*) (class Parser *); // a pointer to boolean function of Input class.

class Input : protected Pointers {
public:
  Input (class MD *);
  Input (class MD *, const std::string &);
  ~Input ();
  
  void read ();
private:
  class Parser *parser;
  const static std::map<std::string,CommandFunc> commands_map;
  void read (Parser *); 
  
  bool read_command (Parser *);
  
  bool read_data_with_format (Parser *);
  bool read_script_from_file (Parser *);
  bool run_simulation (Parser *);
	bool time_step (Parser *);
	bool output_step (Parser *);	
  bool delete_object (Parser *);	
  bool exit_program (Parser *);
  bool print (Parser *);

};

FINECUPPA_NAMESPACE_CLOSE

#endif
