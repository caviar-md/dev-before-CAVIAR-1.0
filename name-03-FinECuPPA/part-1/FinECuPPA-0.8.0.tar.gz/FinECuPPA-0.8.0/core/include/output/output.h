#ifndef FINECUPPA_OUTPUT_H
#define FINECUPPA_OUTPUT_H

#include "finecuppa_config.h"

#include "pointers.h"
#include "communicator.h"

#include <time.h>

FINECUPPA_NAMESPACE_OPEN

class Output : protected Pointers {
public:
  Output (class MD *);
	void open_files (); // calls open_them() with MPI considerations
	void close_files (); // calls close_them() with MPI considerations
	void print_hello (); // a test funciton
	void dump_data (int); // calls dump_XXX() funcitons 

	template <typename T>
	void comment (T &); // ostream commens by process 0
	template <typename T>
	void info (T &);// ostream comments as info by process 0.
	template <typename T>
	void info_ne (T &);// ostream comments as info with no end line by process 0

	void set_parameters (class Parser *); // set parameters :)

private:
	class Atom_data *atom_data;
	class Communicator *comm;

	void open_them (); // open files after making their names
	void close_them (); // closes files
	void dump_energy (int); // dump energy to file 
	void dump_xyz (int); // dump positions to file in xyz format
	void dump_povray (int); // dump positions to snapshot files in povray format

	int energy_step, xyz_step, povray_step; // number of steps to output data

	std::ofstream ofs_energy,  ofs_xyz, ofs_velocities, ofs_povray; // output files

	bool output_energy, output_xyz, output_povray; // if true, outputs would be created	
	
	clock_t tStart1;
};

template <typename T>
void Output::info (T & str) {
#ifdef USE_MD_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout <<"info: "<< str << std::endl;
#else
	std::cout <<"info: "<< str << std::endl;
#endif
}

template <typename T>
void Output::info_ne (T & str) {
#ifdef USE_MD_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout <<"info: "<< str;
#else
	std::cout <<"info: "<< str;
#endif
}


template <typename T>
void Output::comment (T & str) {
#ifdef USE_MD_MPI
	MPI_Barrier (mpi_comm);
	int me = comm -> me;
	if (me==0)
		std::cout << str << std::flush;
#else
	std::cout << str << std::flush;
#endif
}

FINECUPPA_NAMESPACE_CLOSE

#endif
