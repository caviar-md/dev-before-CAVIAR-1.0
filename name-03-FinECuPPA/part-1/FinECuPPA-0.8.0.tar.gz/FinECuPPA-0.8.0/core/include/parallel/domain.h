#ifndef FINECUPPA_DOMAIN_H
#define FINECUPPA_DOMAIN_H

#include "finecuppa_config.h"

#include "pointers.h"
#include "vector.h"

#include <valarray>

FINECUPPA_NAMESPACE_OPEN

enum class Boundary {periodic, fixed};

class Domain : protected Pointers {
public:
  Domain (class MD *);
  
  void calculate_local_domain ();
  
  Real_t x_lower_global, y_lower_global, z_lower_global;
  Real_t x_upper_global, y_upper_global, z_upper_global;
  Real_t x_lower_local, y_lower_local, z_lower_local;
  Real_t x_upper_local, y_upper_local, z_upper_local;
  
  Vector<int> boundary_condition; 
private:
  
};

FINECUPPA_NAMESPACE_CLOSE

#endif
