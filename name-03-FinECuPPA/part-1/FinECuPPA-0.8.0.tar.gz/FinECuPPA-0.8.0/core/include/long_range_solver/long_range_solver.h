#ifndef FINECUPPA_LONG_RANGE_SOLVER_H
#define FINECUPPA_LONG_RANGE_SOLVER_H

#include "finecuppa_config.h"

//#include "pointers.h"
//#include "md.h"
//#include "output.h"
//#include "error.h"
#include "parser.h"
#include "vector.h"

FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

class Long_range_solver {
 public:
  Long_range_solver(class MD *) {}; 
  virtual ~Long_range_solver() {};
  virtual void calculate() = 0;
  
  virtual Vector<double> k_space_field(int) = 0;
  virtual Vector<double> r_space_field(int) = 0;
  virtual Vector<double> dipole_field(int) = 0;
  virtual Vector<double> total_field(int) = 0;  

  virtual Vector<double> k_space_field(const Vector<double> &) = 0; 
  virtual Vector<double> r_space_field(const Vector<double> &) = 0; 
  virtual Vector<double> total_field(const Vector<double> &) = 0;  
    
// The potential value is used for the calculation of charged particle in the
// presence of conductive geometries.
  virtual double k_space_potential(const Vector<double> &) = 0;  
  virtual double r_space_potential(const Vector<double> &) = 0;
  virtual double dipole_potential(const Vector<double> &) = 0;
  virtual double self_potential(const Vector<double> &) = 0;
  virtual double total_potential(const Vector<double> &) = 0;
    
  virtual double k_space_energy( ) = 0; 
  virtual double r_space_energy( ) = 0;
  virtual double dipole_energy( ) = 0;
  virtual double self_energy( ) = 0;
  virtual double total_energy( ) = 0;  

 private: 
  class MD *md;  
	class Output * output;
	class Error * error;    
};

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

#endif
