#ifndef FINECUPPA_LONG_RANGE_SOLVER_PPPM_H
#define FINECUPPA_LONG_RANGE_SOLVER_PPPM_H

#include "finecuppa_config.h"

//#include "pointers.h"
#include "long_range_solver.h"

FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

class PPPM : public Long_range_solver {
 public:
  PPPM(class MD *);
  ~PPPM();
  void calculate();
  
  Vector<double> k_space_field(int);  
  Vector<double> r_space_field(int); 
  Vector<double> dipole_field(int);
  Vector<double> total_field(int);

  Vector<double> k_space_field(const Vector<double> &); 
  Vector<double> r_space_field(const Vector<double> &); 
  Vector<double> total_field(const Vector<double> &);  
        
  double k_space_potential(const Vector<double> &);  
  double r_space_potential(const Vector<double> &); 
  double dipole_potential(const Vector<double> &);
  double self_potential(const Vector<double> &);
  double total_potential(const Vector<double> &);  
      
  double k_space_energy( );  
  double r_space_energy( ); 
  double dipole_energy( );
  double self_energy( );  
  double total_energy( );    
  
 private: 
  class MD *md;  
	class Output *output;
	class Error *error;    
};

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

#endif
