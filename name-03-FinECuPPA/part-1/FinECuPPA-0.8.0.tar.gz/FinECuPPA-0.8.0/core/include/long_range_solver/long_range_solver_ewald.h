#ifndef FINECUPPA_LONG_RANGE_SOLVER_EWALD_H
#define FINECUPPA_LONG_RANGE_SOLVER_EWALD_H

#include "finecuppa_config.h"

#include <vector>

//#include "pointers.h"
#include "long_range_solver.h"
#include "vector.h"

FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

class Ewald : public Long_range_solver {
 public:
  Ewald(class MD *);
  ~Ewald();
  void calculate();
  bool read(class Parser *);  
  
  Vector<double> k_space_field(int);  
  Vector<double> r_space_field(int); 
  Vector<double> dipole_field(int);
  Vector<double> total_field(int);    
  
  Vector<double> k_space_field(const Vector<double> &); 
  Vector<double> r_space_field(const Vector<double> &); 
  Vector<double> total_field(const Vector<double> &);    
       
  double k_space_potential(const Vector<double> &);  
  double r_space_potential(const Vector<double> &); 
  double dipole_potential(const Vector<double> &);
  double self_potential(const Vector<double> &);
  double total_potential(const Vector<double> &);    
    
  double k_space_energy( );  
  double r_space_energy( ); 
  double dipole_energy( );
  double self_energy( );
  double total_energy( );    
  
 private:
  double erfc_cutoff, alpha;
  double pi_root_inv, four_pi;
  std::vector<std::vector<std::vector<unsigned>>> particle_mesh_list;
  std::vector<std::vector<unsigned>> particle_neighbor_list;
//  std::vector<std::vector<std::vector<unsigned>>> charge_mesh;  PPPM
// simulation box lengths and its product
  double lx,lx_inv, ly,ly_inv, lz,lz_inv, l_xyz_inv;
  int mx_max, my_max, mz_max;
  int kx_max, ky_max, kz_max;
  double epsilon_prime;
  
  class MD *md;
	class Output *output;
	class Error *error;
	class Object_container *object_container;
	class Object_handler *object_handler;
	class Atom_data *atom_data;
};

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

#endif
