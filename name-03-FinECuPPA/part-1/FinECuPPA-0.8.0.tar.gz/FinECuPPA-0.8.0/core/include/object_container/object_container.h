#ifndef FINECUPPA_OBJECT_CONTAINER_H
#define FINECUPPA_OBJECT_CONTAINER_H

#include "finecuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "pointers.h"
#include "parser.h"
#include "output.h"
#include "error.h"

#include "vector.h"
#include "vector2D.h"
#include "shape.h"
#include "object_handler_dictionary.h"
#include "object_utility_all.h"
#include "force_field.h"
#include "finite_element.h"
#include "long_range_solver.h"

FINECUPPA_NAMESPACE_OPEN

class Object_container : protected Pointers  {
public:
  Object_container (class MD *);
  ~Object_container ();

	std::map<std::string,object_handler::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<object_utility::Element> element; // 1
	std::vector<object_utility::Atom> atom; // 2
	std::vector<object_utility::Molecule> molecule; // 3
	std::vector<shape::Boundary> boundary; // 4
	std::vector<object_utility::Random_1D> random_1d; // 5
	std::vector<shape::Shape *> shape; // 6	
	std::vector<object_utility::Grid_1D> grid_1d; // 7	
	std::vector<object_utility::Distribution> distribution; // 8
	std::vector<Force_field *> force_field; // 9
	std::vector<finite_element::Finite_element<3> *> finite_element; // 10
	std::vector<long_range_solver::Long_range_solver *> long_range_solver; // 11	
//	std::vector<integration::integration *> integration;
	
	std::vector<int> int_variable; // -1
	std::vector<double> real_variable; // -2
	std::vector<Vector2D<int>> int_2d_vector; // -3
	std::vector<Vector2D<double>> real_2d_vector; // -4
	std::vector<Vector<int>> int_3d_vector; // -5
	std::vector<Vector<double>> real_3d_vector; // -6

	class Parser * parser;
  class Output * output;
  class Error * error;
private:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
