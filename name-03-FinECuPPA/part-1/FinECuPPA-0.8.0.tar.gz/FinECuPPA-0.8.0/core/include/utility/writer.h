#ifndef FINECUPPA_WRITER_H
#define FINECUPPA_WRITER_H

#include "finecuppa_config.h"

#include "pointers.h"

FINECUPPA_NAMESPACE_OPEN

class Writer : protected Pointers {
public:
  Writer (class MD *);
private:
  
};

FINECUPPA_NAMESPACE_CLOSE

#endif
