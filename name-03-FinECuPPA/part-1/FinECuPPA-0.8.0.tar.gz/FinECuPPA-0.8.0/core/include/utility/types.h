#ifndef FINECUPPA_TYPES_H
#define FINECUPPA_TYPES_H

#include "finecuppa_config.h"

#include <limits>

FINECUPPA_NAMESPACE_OPEN

using LocalID_t = unsigned int; 	// changing these doesn't affect MPI_SEND and MPI_Recv MPI_DATA_TYPES yet
using GlobalID_t = unsigned int; 	// //
using AtomType_t = unsigned int; 	// //
using Real_t = double; 						// //

constexpr auto max_GlobalID = std::numeric_limits<GlobalID_t>::max();

FINECUPPA_NAMESPACE_CLOSE

#endif
