#include "data_reader_lammps.h"

#include "finecuppa_config.h"

#include <set>

#include "communicator.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "domain.h"
#include "atom_data.h"
#include "output.h"

FINECUPPA_NAMESPACE_OPEN

static const std::set<std::string> section_keywords {"Atoms"};

Data_reader_LAMMPS::Data_reader_LAMMPS (MD *md, const std::string &file) : Pointers{md}, parser{new Parser{md, file}},
 output{md->output}, num_total_atoms{0}, num_atom_types{0},
 xlo{-.5}, xhi{.5}, ylo{-.5}, yhi{.5}, zlo{-.5}, zhi{.5} {}

Data_reader_LAMMPS::~Data_reader_LAMMPS () {
  delete parser;
}

bool Data_reader_LAMMPS::read () {
//	output->info("The input file reading is started.");
	std::cout << "info: data reader LAMMPS: reading a LAMMPS format data file: " << std::endl;
  header ();
	output->info("data reader LAMMPS: The headers is read.");
  verify_and_set_header ();
  comm->calculate_procs_grid ();
  domain->calculate_local_domain ();
	output->info("data reader LAMMPS: Domains are set.");
  body ();
	output->info("data reader LAMMPS: The body is read.");
	output->info("data reader LAMMPS: The reading is finished.");
	return true; //WARNING	
}

bool Data_reader_LAMMPS::header () {
  bool in_header = true;
  while (in_header) {
    auto token = parser->get_val_token();
    switch (token.kind) {
      case Kind::eof:
        error->all (FILE_LINE_FUNC, "Unexpected end of file");
      
      case Kind::eol:
        continue;
      
      case Kind::identifier:
        if (section_keywords.count(token.string_value)) {
          parser->keep_current_token();
          in_header = false;
          break;
        } else error->all (FILE_LINE_FUNC, "Unexpected section keyword"); 
        
      case Kind::int_number: {
        int val = token.int_value;
        auto token = parser->get_val_token();
        if (token.kind == Kind::identifier) {
          auto str = token.string_value;
          if (str == "atoms") num_total_atoms = val;
          else if (str == "atom") {
            if (parser->get_identifier() == "types") num_atom_types = val;
            else error->all (FILE_LINE_FUNC, "Invalid header keyword");
          } else error->all (FILE_LINE_FUNC, "Invalid (or not yet supported) header keyword");
        }
        else if (token.kind == Kind::int_number || token.kind == Kind::real_number) {
					auto val2 = token.int_value;
          auto str1 = parser->get_identifier();
          auto str2 = parser->get_identifier();
          if (str1 == "xlo" && str2 == "xhi") {xlo = val; xhi = val2;}
          else if (str1 == "ylo" && str2 == "yhi") {ylo = val; yhi = val2;}
          else if (str1 == "zlo" && str2 == "zhi") {zlo = val; zhi = val2; in_header = false; break;}
          else error->all (FILE_LINE_FUNC, "Invalid (or not yet supported) header keyword");
        }
			}

      case Kind::real_number: {
        Real_t val = token.real_value;
        auto token = parser->get_val_token();
        if (token.kind == Kind::int_number || token.kind == Kind::real_number) {
					auto val2 = token.real_value;
          auto str1 = parser->get_identifier();
          auto str2 = parser->get_identifier();
          if (str1 == "xlo" && str2 == "xhi") {xlo = val; xhi = val2;}
          else if (str1 == "ylo" && str2 == "yhi") {ylo = val; yhi = val2;}
          else if (str1 == "zlo" && str2 == "zhi") {zlo = val; zhi = val2;in_header = false; break;}
          else error->all (FILE_LINE_FUNC, "Invalid (or not yet supported) header keyword");          
        }
      
			}
			/*
      case Kind::string:
      case Kind::plus:
      case Kind::minus:
      case Kind::mul:
      case Kind::div:
      case Kind::truediv:
      case Kind::modulus:
      case Kind::assign:                                          
      case Kind::lp:
      case Kind::rp:            
      case Kind::squote:
      case Kind::dquote:            
      case Kind::comment:
      case Kind::backslash: */
      default :         
      continue;
    }
  }
	return true; //WARNING  
}

bool Data_reader_LAMMPS::verify_and_set_header () {
  
  domain->x_lower_global = xlo;
  domain->x_upper_global = xhi;
  domain->y_lower_global = ylo;
  domain->y_upper_global = yhi;
  domain->z_lower_global = zlo;
  domain->z_upper_global = zhi;
  
  atom_data->set_num_atom_types (num_atom_types);
  atom_data->set_num_total_atoms (num_total_atoms);
	return true; //WARNING  
}

bool Data_reader_LAMMPS::body () {
  parser->end_of_line ();
  parser->end_of_line ();

//	auto section = parser->get_identifier ();
//	if (section == "Atoms") read_atoms ();

	bool in_body=true, atom_read=false, mass_read=false;
	while ( in_body ) {
		if ( atom_read && mass_read ) { in_body = false;break; }

		auto section = parser->get_identifier ();

 		if (section == "Atoms") {
			read_atoms (); atom_read=true;
	  	parser->end_of_line ();
			output->info ("data reader LAMMPS: Atoms is read.");
			continue;
		}

 		if (section == "Masses") { 
			read_masses (); mass_read=true;
	  	parser->end_of_line ();
			output->info ("data reader LAMMPS: Masses is read.");
			continue;
		}

	}
	return true; //WARNING	
}

bool Data_reader_LAMMPS::read_atoms () {
	parser->end_of_line ();	parser->end_of_line ();
  for (unsigned int i=0; i<num_total_atoms; ++i) {
    GlobalID_t id = parser->get_literal_int ();
    parser->get_literal_int (); ////GlobalID_t tag // unused variable
    AtomType_t type = parser->get_literal_int ();
		Real_t charge = parser->get_literal_real ();
    Real_t x = parser->get_literal_real (), y = parser->get_literal_real (), z = parser->get_literal_real ();
    parser->end_of_line ();
    atom_data->add_charges (type, charge);
    atom_data->add_atom (id, type, Vector<Real_t> {x, y, z});
  }
	return true; //WARNING  
}

bool Data_reader_LAMMPS::read_masses () {
	parser->end_of_line ();	parser->end_of_line ();
	for (unsigned int i=0; i<num_atom_types; ++i) {
    unsigned int type = parser->get_literal_int ();
		Real_t m = parser->get_literal_real ();
		if (type !=i+1) error->all (FILE_LINE_FUNC, "Input masses have to be in order from 1 to number of atom types.");
		atom_data->add_masses (type, m);
		parser->end_of_line ();
	}
	return true; //WARNING
}

FINECUPPA_NAMESPACE_CLOSE

