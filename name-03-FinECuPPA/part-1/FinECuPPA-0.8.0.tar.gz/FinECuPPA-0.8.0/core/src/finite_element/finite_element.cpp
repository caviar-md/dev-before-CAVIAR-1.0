#include "finite_element.h"

#include "finecuppa_config.h"

#include "object_handler.h"
#include "object_handler_preprocessors.h"
#include "object_handler_dictionary.h"

#include "parser.h"
#include "lexer.h"

FINECUPPA_NAMESPACE_OPEN

namespace finite_element {

  template <int dim>
  Finite_element<dim>::Finite_element (MD *md) : Pointers{md},
		output{md->output}, error{md->error} {}

  template <int dim>		
  Finite_element<dim>::~Finite_element () {}
  
  template <int dim>		
  void Finite_element<dim>::calculate_acceleration () {} 
  
  template <int dim>		
  bool Finite_element<dim>::read (Parser *parser) {return parser->end_of_line();}  
		
} //finite_element

FINECUPPA_NAMESPACE_CLOSE

template class fine_cuppa::finite_element::Finite_element<3>;
