#include "polyhedron_input.h"

#include "finecuppa_config.h"

#include <string>
#include <cmath>
#include <fstream>

#include "parser.h"
#include "lexer.h"
#include "error.h"
//#include "domain.h"
#include "output.h"
#include "atom_data.h"
//#include "kakaka_preprocessors.h"
#include "utility.h"

FINECUPPA_NAMESPACE_OPEN

namespace geometry {



Polyhedron_Input::Polyhedron_Input (MD *md) : Pointers{md}, 
				output{md->output}, error{md->error} {}

Polyhedron_Input::~Polyhedron_Input () { }


void Polyhedron_Input::read_vtk (geometry::Polyhedron & p_object, const std::string &file_name) {
  class Format_Vtk_Reader fvr (md);
  fvr.read_polyhedron (p_object, file_name);
}



} //namespace

FINECUPPA_NAMESPACE_CLOSE

