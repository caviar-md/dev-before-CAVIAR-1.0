#include "long_range_solver_ewald.h"
//#include "pointers.h"
#include "output.h"
#include "error.h"
#include "parser.h"
#include "lexer.h"
#include "md.h"
#include "domain.h"

#include "object_handler.h"
#include "object_handler_gdst.h"
#include "object_container.h"
#include "object_handler_preprocessors.h"
#include "atom_data.h"

#include <cmath>
#include <complex>

FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

Ewald::Ewald (MD *md) : 
 Long_range_solver{md}, output{md->output}, error{md->error},
 object_container{md->object_container}, object_handler{md->object_handler},
 atom_data{md->atom_data}
{ 
  mx_max = 1;  my_max = 1;  mz_max = 1;
  kx_max = 1;  ky_max = 1;  kz_max = 1;
  erfc_cutoff = 4.5;
  pi_root_inv = 1.0/std::sqrt(M_PI);
  four_pi = 4.0 * M_PI;
  epsilon_prime = 1;
  alpha = 1.0;
  
}

Ewald::~Ewald () {}

bool Ewald::read(Parser * parser) {
	output->info("Ewald: read");
	bool in_file = true;			

	while(true) {
		GET_A_TOKEN_FOR_CREATION
		ASSIGN_REAL(erfc_cutoff,"","")
		else ASSIGN_INT(alpha,"","")
		else ASSIGN_INT(mx_max,"","")
		else ASSIGN_INT(my_max,"","")
		else ASSIGN_INT(mz_max,"","")
		else ASSIGN_INT(kx_max,"","")
		else ASSIGN_INT(ky_max,"","")
		else ASSIGN_INT(kz_max,"","")		
		else error->all (FILE_LINE_FUNC, "Ewald: read: Unknown variable or command");
	}	
	return in_file;
}

void Ewald::calculate () {
  auto & domain = md->domain;
  lx = domain->x_upper_global - domain->x_lower_global;
  ly = domain->y_upper_global - domain->y_lower_global;
  lz = domain->z_upper_global - domain->z_lower_global;
  lx_inv = 1.0/lx;  ly_inv = 1.0/ly;  lz_inv = 1.0/lz;
  l_xyz_inv = 1.0 / (lx*ly*lz);

}

Vector<double> Ewald::k_space_field (const Vector<double> &r) {
  const auto &pos = atom_data -> owned.position;
  Vector<double> external_field_k {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	    
    const auto r_ij = r - pos[j]; // TODO make it one function with below
    
    Vector<double> sum_k {0, 0, 0};
    for (auto kx = -kx_max; kx <=kx_max; ++kx)
    for (auto ky = -ky_max; ky <=ky_max; ++ky)
    for (auto kz = -kz_max; kz <=kz_max; ++kz) {
      auto k_sq = kx*kx + ky*ky + kz*kz;
      if (k_sq == 0) continue;
      auto k_vec = Vector<double>{(double)kx*lx_inv,
                                (double)ky*ly_inv, (double)kz*lz_inv};
      k_vec *= 2.0 * M_PI;
      sum_k +=  k_vec * (1.0/k_sq) 
                * std::exp(-k_sq/(4*alpha)) * std::sin(k_vec*r_ij);
    }            
    external_field_k +=  charge_j *sum_k;    
  }
  return four_pi * external_field_k * l_xyz_inv;
}    

Vector<double> Ewald::k_space_field (int i) {
  const auto &pos = atom_data -> owned.position;
  Vector<double> external_field_k {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	    
    const auto r_ij = pos[i] - pos[j];  // TODO make it one function with above
    
    Vector<double> sum_k {0, 0, 0};
    for (auto kx = -kx_max; kx <=kx_max; ++kx)
    for (auto ky = -ky_max; ky <=ky_max; ++ky)
    for (auto kz = -kz_max; kz <=kz_max; ++kz) {
      auto k_sq = kx*kx + ky*ky + kz*kz;
      if (k_sq == 0) continue;
      auto k_vec = Vector<double>{(double)kx*lx_inv,
                                (double)ky*ly_inv, (double)kz*lz_inv};
      k_vec *= 2.0 * M_PI;
      sum_k +=  k_vec * (1.0/k_sq) 
                * std::exp(-k_sq/(4*alpha)) * std::sin(k_vec*r_ij);
    }            
    external_field_k +=  charge_j *sum_k;    
  }
  return four_pi * external_field_k * l_xyz_inv;
}      

Vector<double> Ewald::r_space_field (const Vector<double> &r) {
  const auto &pos = atom_data -> owned.position;
  const auto alpha_sq = alpha*alpha;  
  Vector<double> external_field_r {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	    
    const auto r_ij = r - pos[j]; // TODO make it one function with below
    
    Vector<double> sum_r {0, 0, 0};

    for (auto mx = -mx_max; mx <=mx_max; ++mx)
    for (auto my = -my_max; my <=my_max; ++my)
    for (auto mz = -mz_max; mz <=mz_max; ++mz) {
      if ((r_ij.x == 0 && r_ij.y == 0 && r_ij.z == 0) // XXX difference point
          && ((mx==0) && (my==0) && (mz==0)) ) continue;
      const auto m_vec = Vector<double>{mx*lx, my*ly, mz*lz};
      const auto rijml = r_ij + m_vec;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;
// the force has another 'exp' term. what about its truncation?      
      if (erfc_arg > erfc_cutoff) continue; //XXX
      sum_r += (2*alpha*pi_root_inv*std::exp(-alpha_sq*rijml_sq) 
               + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);
    }            
    external_field_r +=  charge_j *sum_r;    
  }
  return external_field_r ;
}     

Vector<double> Ewald::r_space_field (int i) {
  const auto &pos = atom_data -> owned.position;
  const auto alpha_sq = alpha*alpha;  
  Vector<double> external_field_r {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	    
    const auto r_ij = pos[i] - pos[j]; // TODO make it one function with above
    
    Vector<double> sum_r {0, 0, 0};

    for (auto mx = -mx_max; mx <=mx_max; ++mx)
    for (auto my = -my_max; my <=my_max; ++my)
    for (auto mz = -mz_max; mz <=mz_max; ++mz) {
      if ((i == (int)j) && ((mx==0) && (my==0) && (mz==0)) ) continue;
      const auto m_vec = Vector<double>{mx*lx, my*ly, mz*lz};
      const auto rijml = r_ij + m_vec;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;
// the force has another 'exp' term. what about its truncation?      
      if (erfc_arg > erfc_cutoff) continue; //XXX
      sum_r += (2*alpha*pi_root_inv*std::exp(-alpha_sq*rijml_sq) 
               + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);
    }            
    external_field_r +=  charge_j *sum_r;    
  }
  return external_field_r ;
}     

Vector<double> Ewald::dipole_field (int i) {
  const auto &pos = atom_data -> owned.position;
  Vector<double> sum_j {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	 
    sum_j += charge_j* pos[j];
  }
  return four_pi * l_xyz_inv * sum_j / (1+2*epsilon_prime);
}

Vector<double> Ewald::total_field (int i) {
  return k_space_field(i)+r_space_field(i);//+dipole_field(i);
}

Vector<double> Ewald::total_field (const Vector<double> &r) {
  return k_space_field(r)+r_space_field(r);//+dipole_field(i);
}
// This function is almost the same as 'k_space_energy', except for the 
// 'sum_rho +=' and 'sum_rho_norm ='.
double Ewald::k_space_potential (const Vector<double> &r) {
  double energy {0};
  const std::complex<double> ii(0.0,1.0);    
  const auto &pos = atom_data -> owned.position;
  const auto four_alpha2_inv = 1.0/(4.0*alpha*alpha);
  for (auto kx = -kx_max; kx <=kx_max; ++kx)
  for (auto ky = -ky_max; ky <=ky_max; ++ky)
  for (auto kz = -kz_max; kz <=kz_max; ++kz) {
  
    if (kx==0 && ky==0 && kz==0) continue;
    auto k_vec = Vector<double>{(double)kx*lx_inv,
                                (double)ky*ly_inv, (double)kz*lz_inv};
    k_vec *= 2.0 * M_PI;
    
    auto k_sq = kx*kx + ky*ky + kz*kz; 

    std::complex<double> sum_rho (0,0);
    for (unsigned int j=0;j<pos.size();++j) {
      const auto type_j = atom_data -> owned.type [j] ;
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	      
	    
      sum_rho +=  charge_j*std::exp(-ii*(k_vec*(r - pos[j])));
    }
//  do we need the real part or the abs of the value   
    double sum_rho_norm = std::abs(sum_rho); //XXX//
    energy += sum_rho_norm * std::exp(-k_sq*four_alpha2_inv) / k_sq;
  }
  return four_pi * 0.5 * l_xyz_inv * energy;
}

double Ewald::r_space_potential (const Vector<double> &r) {
  double energy {0};  
  const auto &pos = atom_data -> owned.position;

  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	    
    const auto r_ij = r - pos[j];
    
    double sum_m {0};
    for (auto mx = -mx_max; mx <=mx_max; ++mx)
    for (auto my = -my_max; my <=my_max; ++my)
    for (auto mz = -mz_max; mz <=mz_max; ++mz) {
      if ((r_ij.x == 0 && r_ij.y == 0 && r_ij.z == 0) 
          && ((mx==0) && (my==0) && (mz==0)) ) continue;
      const auto m_vec = Vector<double>{mx*lx, my*ly, mz*lz};
      const auto rijml = r_ij + m_vec;
      const auto rijml_norm = std::sqrt(rijml*rijml);
      const auto erfc_arg = alpha*rijml_norm;
      if (erfc_arg > erfc_cutoff) continue;         
      sum_m += std::erfc(erfc_arg) / rijml_norm;
    }
    energy += charge_j * sum_m;    
  }

  return -0.5*energy;
}

double Ewald::self_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double Ewald::dipole_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double Ewald::total_potential (const Vector<double> &r) {
  return k_space_potential(r)+r_space_potential(r);//+self_energy()+dipole_energy();
}

double Ewald::k_space_energy () {
  double energy {0};
  const std::complex<double> ii(0.0,1.0);    
  const auto &pos = atom_data -> owned.position;
  const auto four_alpha2_inv = 1.0/(4.0*alpha*alpha);
  for (auto kx = -kx_max; kx <=kx_max; ++kx)
  for (auto ky = -ky_max; ky <=ky_max; ++ky)
  for (auto kz = -kz_max; kz <=kz_max; ++kz) {
  
    if (kx==0 && ky==0 && kz==0) continue;
    auto k_vec = Vector<double>{(double)kx*lx_inv,
                                (double)ky*ly_inv, (double)kz*lz_inv};
    k_vec *= 2.0 * M_PI;
    
    auto k_sq = kx*kx + ky*ky + kz*kz; 

    std::complex<double> sum_rho (0,0);
    for (unsigned int j=0;j<pos.size();++j) {
      const auto type_j = atom_data -> owned.type [j] ;
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	      
	    
      sum_rho +=  charge_j*std::exp(-ii*(k_vec*pos[j]));
    }
    double sum_rho_norm = std::norm(sum_rho);
    energy += sum_rho_norm * std::exp(-k_sq*four_alpha2_inv) / k_sq;
  }
  return four_pi * 0.5 * l_xyz_inv * energy ;   
}

double Ewald::r_space_energy () {
  double energy {0};  
  const auto &pos = atom_data -> owned.position;

  for (unsigned int i=0;i<pos.size();++i) {  
    const auto type_i = atom_data -> owned.type [i] ;
    const auto charge_i = atom_data -> owned.charge [ type_i ];
    double energy_j = 0;
    for (unsigned int j=0;j<pos.size();++j) {
      const auto type_j = atom_data -> owned.type [j] ;
	    const auto charge_j = atom_data -> owned.charge [ type_j ];	    
      const auto r_ij = pos[i] - pos[j];
    
      double sum_m {0};
      for (auto mx = -mx_max; mx <=mx_max; ++mx)
      for (auto my = -my_max; my <=my_max; ++my)
      for (auto mz = -mz_max; mz <=mz_max; ++mz) {
        if ((i == j) && ((mx==0) && (my==0) && (mz==0)) ) continue;
        const auto m_vec = Vector<double>{mx*lx, my*ly, mz*lz};
        const auto rijml = r_ij + m_vec;
        const auto rijml_norm = std::sqrt(rijml*rijml);
        const auto erfc_arg = alpha*rijml_norm;
        if (erfc_arg > erfc_cutoff) continue; 
        sum_m += std::erfc(erfc_arg) / rijml_norm;
      }
      energy_j =  charge_j * sum_m;    
    }
    energy += charge_i*energy_j;
  }
  return -0.5*energy;
}

double Ewald::self_energy () {
  const auto &pos = atom_data -> owned.position;    
  double sum_j {0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	     
    sum_j += charge_j* charge_j;  
  }
  return -pi_root_inv*alpha*sum_j;
}

double Ewald::dipole_energy () {
  Vector<double> sum_j {0, 0, 0};
  const auto &pos = atom_data -> owned.position;  
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
	  const auto charge_j = atom_data -> owned.charge [ type_j ];	 
    sum_j += charge_j* pos[j];
  }
  double coef = 2.0 * M_PI * l_xyz_inv/(1+2*epsilon_prime);
  return coef*(sum_j*sum_j);
}

double Ewald::total_energy () {
  return k_space_energy()+r_space_energy()+self_energy()+dipole_energy();
}

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

