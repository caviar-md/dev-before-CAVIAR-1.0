#include "long_range_solver_pppm.h"
FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

PPPM::PPPM (MD *md) : 
 Long_range_solver{md}, output{md->output}, error{md->error} {

}

PPPM::~PPPM () {}

void PPPM::calculate () {}


Vector<double> PPPM::k_space_field (const Vector<double> &r) {
  Vector<double> external_field_k {0, 0, 0};
  return external_field_k;
}
Vector<double> PPPM::k_space_field (int i) {
  Vector<double> external_field_k {0, 0, 0};
  return external_field_k;
}
Vector<double> PPPM::r_space_field (const Vector<double> &r) {
  Vector<double> external_field_r {0, 0, 0};
  return external_field_r;
}
Vector<double> PPPM::r_space_field (int i) {
  Vector<double> external_field_r {0, 0, 0};
  return external_field_r;
}
Vector<double> PPPM::dipole_field (int i) {
  Vector<double> external_field_dipole {0, 0, 0};
  return external_field_dipole;
}

Vector<double> PPPM::total_field (const Vector<double> &r) {
  return k_space_field(r)+r_space_field(r);//+self_field(i)+dipole_field(i);
}
Vector<double> PPPM::total_field (int i) {
  return k_space_field(i)+r_space_field(i);//+self_field(i)+dipole_field(i);
}

double PPPM::k_space_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::r_space_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::self_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::dipole_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double PPPM::total_potential (const Vector<double> &r) {
  return k_space_potential(r)+r_space_potential(r);//+self_energy()+dipole_energy();
}

double PPPM::k_space_energy () {
  double energy {0};  
  return energy;
}

double PPPM::r_space_energy () {
  double energy {0};  
  return energy;
}

double PPPM::self_energy () {
  double energy {0};  
  return energy;
}

double PPPM::dipole_energy () {
  double energy {0};  
  return energy;
}

double PPPM::total_energy () {
  return k_space_energy()+r_space_energy()+self_energy()+dipole_energy();
}

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

