#include "long_range_solver.h"
FINECUPPA_NAMESPACE_OPEN

namespace long_range_solver {

} // long_range_solver

FINECUPPA_NAMESPACE_CLOSE

