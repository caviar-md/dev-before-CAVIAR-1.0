#include "object_handler_gdst.h"

#include "finecuppa_config.h"

FINECUPPA_NAMESPACE_OPEN

namespace object_handler {

int gdst (const std::string & t) { //get_dictionary_second_type 
	std::map<std::string,int>::const_iterator it;
	it = object_handler::dictionary_second_type.find(t);
	if (it == object_handler::dictionary_second_type.end()) return 0;
	else return it->second;
}

}

FINECUPPA_NAMESPACE_CLOSE

