#include "shape_boundary.h"

#include "finecuppa_config.h"

#include <boost/algorithm/string.hpp>

#include "object_handler_all.h"
#include "object_container.h"

FINECUPPA_NAMESPACE_OPEN

namespace shape {

//====================================
//====================================
//====================================

  Boundary::Boundary (MD *md) : Shape {md},
    object_container{md->object_container}, output{md->output}, error{md->error} {}

    
  Boundary::~Boundary () {}	
  
  bool Boundary::read (Parser* parser) {
		output->info("Data_reader_Kakaka: BOUNDARY Read: ");
		bool in_file = true;

#define AND_OR_INSIDE_OUTSIDE \
if (shapes.size() == 0) {\
  if (boost::iequals(t,"inside")) inside_check = true;\
  else if (boost::iequals(t,"outside")) inside_check = false;\
  else error->all(FILE_LINE_FUNC,"BOUNDARY Read: expected 'INSIDE' or 'OUTSIDE': ");\
} else if (boost::iequals(t,"inside") || boost::iequals(t,"outside"))\
    error->all(FILE_LINE_FUNC,"BOUNDARY Read: expected 'AND_INSIDE','AND_OUTSIDE', 'OR_INSIDE','OR_OUTSIDE': ");\
std::map<std::string,object_handler::Dictionary>::iterator it_1;\
std::string name_1;\
GET_A_STRING(name_1,"BOUNDARY Read: "," expected an BOUNDARY or SHAPE NAME: ")\
CHECK_NAME_EXISTANCE(name_1, it_1, "BOUNDARY Read: ","")\
if (it_1->second.type == object_handler::gdst("boundary"))\
	shapes.push_back(&object_container->boundary[it_1->second.index]);\
else if (it_1->second.type == object_handler::gdst("shape"))\
	shapes.push_back(object_container->shape[it_1->second.index]);\
else error->all(FILE_LINE_FUNC,"BOUNDARY Read: expected an BOUNDARY or SHAPE NAME: ");
		  	  
		while(true) {
		
		  GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
		  if (boost::iequals(t,"inside")) {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0);  //inside_check = true	 	
		  } else if (boost::iequals(t,"outside")) {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (0); //inside_check = flase	 	 	 	
		  } else if (boost::iequals(t,"and_inside")) {		    
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (1);  	 	
		  } else if (boost::iequals(t,"and_outside")) { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-1);
		  }	else if (boost::iequals(t,"or_inside")) { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (2);
		  }	else if (boost::iequals(t,"or_outside")) { 
        AND_OR_INSIDE_OUTSIDE
		  	operators.push_back (-2);
		  }		  	  	  
		  else error->all(FILE_LINE_FUNC,"BOUNDARY Read: Unknown variable or command ");
	  }
		return in_file;;
#undef AND_OR_INSIDE_OUTSIDE
	}
  
  bool Boundary::is_inside (const Vector<double> &v) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v);
    else tmp = !shapes[0]->is_inside(v);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  bool Boundary::is_inside (const Vector<double> &v, const double r) {
    bool tmp;
    
    if (inside_check) tmp = shapes[0]->is_inside(v, r);
    else tmp = !shapes[0]->is_inside(v, r);
    
    for (unsigned int i = 1; i < operators.size(); ++i) {
      switch (operators[i]) {
        case 1:
          tmp = (shapes[i]->is_inside(v, r) && tmp);
        break;

        case -1:
          tmp = (shapes[i]->is_outside(v, r) && tmp);                
        break;
        
        case 2:
          tmp = (shapes[i]->is_inside(v, r) || tmp);                
        break;
        
        case -2:
          tmp = (shapes[i]->is_outside(v, r) || tmp);                
        break;
        
        default:
          error->all(FILE_LINE_FUNC,"Boundary is_inside: undefined boolean operator. ");        
        break;                
      }
    }
    return tmp;
  }
  
  
  bool Boundary::is_outside (const Vector<double> &v) {
    return !is_inside(v);
  }
  
    bool Boundary::is_outside (const Vector<double> &v, const double r) {
    return !is_inside(v, r);
  }

		bool Boundary::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
      std::cout << "incomplete function:" << __FILE__<<__LINE__<<__func__  << std::endl;	
      std::cout << "  " << v << r << contact_vector   << std::endl; 		
			return false;
		}

}

FINECUPPA_NAMESPACE_CLOSE

