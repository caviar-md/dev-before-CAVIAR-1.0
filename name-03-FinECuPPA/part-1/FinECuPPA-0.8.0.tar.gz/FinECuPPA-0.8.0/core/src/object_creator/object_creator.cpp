#include "object_creator.h"

#include "finecuppa_config.h"

#include "object_creator_commands_map.h"
#include "object_handler_all.h"
#include "object_utility_all.h"
#include "object_container.h"
#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "output.h"

FINECUPPA_NAMESPACE_OPEN

Object_creator::Object_creator (MD *md) : 
Pointers{md}, object_container{md->object_container}, output{md->output}, error {md->error}
 { }
  
Object_creator::~Object_creator ()
 { }

  //if (!parser->end_of_line())                                                           
  //  object_container -> FUNCTION_NAME [index].read(parser);                             

//  if (name is similar to a command) error
//  if (name is repeated) delete the previous and make a warning  

#define OBJECT_CREATOR_FUNCTION(FUNCTION_NAME,CLASS_NAME)                               \
bool Object_creator::FUNCTION_NAME (Parser * parser) {                                  \
  std::string f_name1 = "Object creator: " ;                                            \
  std::string f_name2 = #FUNCTION_NAME  ;                                               \
  f_name1.append(f_name2);                                                              \
  output->info(f_name1);                                                                \
  GET_A_TOKEN_FOR_CREATION_NAME_RETURN(token);                                          \
	NAME_ASSIGN_CHECK(token);                                                             \
	object_container->all_names.insert(token.string_value);                               \
	                                                                                      \
  int index = object_container->FUNCTION_NAME.size ();                                  \
	object_container -> FUNCTION_NAME.push_back (CLASS_NAME (object_container));          \
	                                                                                      \
	object_handler::Dictionary dict (object_handler::gdst(#FUNCTION_NAME), index);	\
	object_container -> dictionary.insert (std::make_pair(token.string_value,dict));      \
                                                                                        \
  return true;                                                                          \
} 
 
OBJECT_CREATOR_FUNCTION(element,object_utility::Element)

OBJECT_CREATOR_FUNCTION(atom,object_utility::Atom)

OBJECT_CREATOR_FUNCTION(molecule,object_utility::Molecule)

OBJECT_CREATOR_FUNCTION(grid_1d,object_utility::Grid_1D)

OBJECT_CREATOR_FUNCTION(random_1d,object_utility::Random_1D)

OBJECT_CREATOR_FUNCTION(distribution,object_utility::Distribution)

FINECUPPA_NAMESPACE_CLOSE


