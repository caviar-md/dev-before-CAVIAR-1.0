#ifndef FINECUPPA_POINTERS_H
#define FINECUPPA_POINTERS_H

#ifdef USE_MD_MPI
#include <mpi.h>
#endif

#include "finecuppa/FinECuPPA.h"

FINECUPPA_NAMESPACE_OPEN

class Pointers {
public:
  inline constexpr Pointers (class FinECuPPA *fptr) :
    fptr {fptr},
#ifdef USE_MD_MPI
    mpi_comm {fptr->mpi_comm},
#endif
    comm {fptr->comm},
    error {fptr->error},
    output {fptr->output},
    input {fptr->input},
    object_handler {fptr->object_handler},
    object_container {fptr->object_container},
    object_creator {fptr->object_creator},    
    log {fptr->log},
    in {fptr->in},
    out {fptr->out},
    err {fptr->err},
    log_flag {fptr->log_flag},
    out_flag {fptr->out_flag},
    err_flag {fptr->err_flag} {}

protected:
  inline ~Pointers () = default;  // destructor need not be virtual b/c it is protected
  class FinECuPPA *fptr;
#ifdef USE_MD_MPI
  MPI_Comm &mpi_comm;
#endif
  class Communicator *&comm;
  class Error *&error;
  class Output *&output;
  class Input *&input;
  class Object_handler *&object_handler;
  class Object_container *&object_container;
  class Object_creator *&object_creator;
  
  std::ofstream &log;
  std::istream &in;
  std::ostream &out, &err;
  bool &log_flag, &out_flag, &err_flag;
  
};

FINECUPPA_NAMESPACE_CLOSE

#endif
