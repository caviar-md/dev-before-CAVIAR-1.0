#ifndef FINECUPPA_INPUT_H
#define FINECUPPA_INPUT_H

#include "finecuppa/utility/pointers.h"
#include <istream>
#include <map>

FINECUPPA_NAMESPACE_OPEN

// a pointer to boolean function of Input class.
using InputCommandFunc = bool (Input::*) (class Parser *); 

class Input : protected Pointers {
public:
  Input (class FinECuPPA *);
  Input (class FinECuPPA *, const std::string &);
  Input (class FinECuPPA *, std::istringstream &);
  ~Input ();
  
  void read ();
protected:
  class Parser *parser;
  class FinECuPPA *fptr;
  const static std::map<std::string,InputCommandFunc> commands_map;
  void read (Parser *);
  bool read_command (Parser *);  
  bool call_output (Parser *);
  bool call_object_container (Parser *);
  bool read_script_from_file (Parser *);
  bool exit_program (Parser *);
  bool echo(Parser *);
  bool print(Parser *);
  bool do_command(Parser *);
  bool end_do_command(Parser *);
  bool while_command(Parser *);
  bool if_command(Parser *);
  bool else_if_command(Parser *);
  bool else_command(Parser *);
  bool end_if_command(Parser *);
  bool ignore_to_endif(Parser *);
  bool break_command(Parser *);
  bool continue_command(Parser *);
  bool evaluate(Parser *);
  bool evaluate(const std::string &);
  bool compare_real (Parser *);
  bool compare_real (const std::string &);
  bool compare_int (Parser *);
  bool compare (Parser *);
  bool calculate(Parser *);
  bool calculate(const std::string &);
  bool help(Parser *);
};

FINECUPPA_NAMESPACE_CLOSE

#endif

