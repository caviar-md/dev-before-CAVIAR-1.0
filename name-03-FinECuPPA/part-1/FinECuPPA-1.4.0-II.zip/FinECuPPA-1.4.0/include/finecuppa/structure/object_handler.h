#ifndef FINECUPPA_OBJECT_HANDLER_H
#define FINECUPPA_OBJECT_HANDLER_H

#include "finecuppa/utility/pointers.h"
#include <string>
#include <map>

FINECUPPA_NAMESPACE_OPEN
class Parser;
using CommandFunc_object_handler = bool (Object_handler::*) (class Parser *); // a pointer to boolean function of ...

class Object_handler : protected Pointers  {
public:
  Object_handler (class FinECuPPA *);
  ~Object_handler ();
  
  const static std::map<std::string, CommandFunc_object_handler> commands_map;
  
  bool output_xyz (Parser *);    
  bool add_atom_to_molecule (Parser *);
  bool add_molecule_to_molecule (Parser *);
  bool read_object (Parser *, const std::string);

protected:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
