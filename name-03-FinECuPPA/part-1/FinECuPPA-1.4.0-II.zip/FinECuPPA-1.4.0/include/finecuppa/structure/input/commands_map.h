#ifndef FINECUPPA_INPUT_COMMANDS_MAP_H
#define FINECUPPA_INPUT_COMMANDS_MAP_H

#include "finecuppa/structure/input.h"

FINECUPPA_NAMESPACE_OPEN

//using CommandFunc = bool (Input::*) (class Parser *); 

const std::map<std::string,InputCommandFunc> Input::commands_map = {
  
  {"read",&Input::read_script_from_file},  
  {"read_script",&Input::read_script_from_file},
  {"read_script_from_file",&Input::read_script_from_file},     
  {"output", &Input::call_output},
  {"object_container", &Input::call_object_container},
  {"exit", &Input::exit_program},
  {"quit", &Input::exit_program},
  {"print", &Input::print},
  {"echo", &Input::echo},
  {"do", &Input::do_command},
  {"end_do", &Input::end_do_command},
  {"while", &Input::while_command},
  {"if", &Input::if_command},
  {"endif", &Input::end_if_command},
  {"end_if", &Input::end_if_command},
  {"else_if", &Input::else_if_command},
  {"elseif", &Input::else_if_command},
  {"else", &Input::else_command},
  {"break", &Input::break_command},
  {"continue", &Input::continue_command},
  {"evaluate", &Input::evaluate},
  {"calculate", &Input::calculate},
  {"compare_real", &Input::compare_real},
  {"compare_int", &Input::compare_int},
  {"compare", &Input::compare},
  {"help", &Input::help},
};

FINECUPPA_NAMESPACE_CLOSE

#endif
