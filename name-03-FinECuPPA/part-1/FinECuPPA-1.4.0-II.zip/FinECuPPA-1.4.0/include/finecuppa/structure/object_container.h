#ifndef FINECUPPA_OBJECT_CONTAINER_H
#define FINECUPPA_OBJECT_CONTAINER_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/utility/vector2D.h"
#include "finecuppa/structure/object_handler/dictionary.h"

#include <vector>
#include <string>
#include <map>
#include <unordered_set>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Force_field;
class Long_range_solver;
class Integration;
class Simulator;
class Domain;
class Atom_data;
class Neighborlist;
class Finite_element;
class Shape;
namespace shape {class Boundary;}
namespace utility {
class Element; class Atom; class Molecule; 
class Grid_1D; class Distribution; class Random_1D;
}
}
class Parser;
class Object_container : protected Pointers  {
public:
  Object_container (class FinECuPPA *);
  ~Object_container ();
  bool read (Parser *);
  void report();

  std::map<std::string,object_handler::Dictionary> dictionary;

  std::unordered_set<std::string> all_names;

  std::vector<objects::utility::Element *> element; // 1
  std::vector<objects::utility::Atom *> atom; // 2
  std::vector<objects::utility::Molecule *> molecule; // 3
  std::vector<objects::utility::Random_1D *> random_1d; // 5
  std::vector<objects::utility::Grid_1D *> grid_1d; // 7  
  std::vector<objects::utility::Distribution *> distribution; // 8
  std::vector<objects::shape::Boundary *> boundary; // 4
  std::vector<objects::Shape *> shape; // 6  
  std::vector<objects::Force_field *> force_field; // 9
  std::vector<objects::Finite_element *> finite_element; // 10
  std::vector<objects::Long_range_solver *> long_range_solver; // 11  
  std::vector<objects::Integration *> integration; //12
  std::vector<objects::Simulator *> simulator; //13
  std::vector<objects::Domain *> domain; //14
  std::vector<objects::Atom_data *> atom_data; //15
  std::vector<objects::Neighborlist *> neighborlist; //15
  
  std::vector<int> int_variable; // -1
  std::vector<double> real_variable; // -2
  std::vector<Vector2D<int>> int_2d_vector; // -3
  std::vector<Vector2D<double>> real_2d_vector; // -4
  std::vector<Vector<int>> int_3d_vector; // -5
  std::vector<Vector<double>> real_3d_vector; // -6
  std::vector<std::string> string_variable; // -7
  std::vector<bool> boolean_variable; // -8

protected:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
