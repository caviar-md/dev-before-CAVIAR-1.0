#ifndef FINECUPPA_OBJECTS_FORCE_FIELD_DEALII_POISSON_EWALD_H
#define FINECUPPA_OBJECTS_FORCE_FIELD_DEALII_POISSON_EWALD_H

#include "finecuppa/objects/force_field.h"

#ifdef USE_DEALII

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/base/function.h>
#include <deal.II/base/tensor.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>

#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Atom_data;
class Domain;
namespace force_field {
using namespace dealii;

class Dealii_poisson_ewald : public Force_field
{
public:
  Dealii_poisson_ewald (class FinECuPPA *);
  ~Dealii_poisson_ewald ();

  void calculate_acceleration ();  
  bool read(Parser *);
  double total_potential_of_charges (const dealii::Point<3> &p);
  
public:

  void run ();
  void read_domain();
  void make_grid ();
  void make_boundary_face_normals ();
  void setup_system();
  void assemble_system();
  void solve ();
  void calculate_induced_charge (const int);

  void output_vtk_solution (const int) const;

  void refine_grid_adaptive ();
  void refine_boundary (const unsigned int);

  void set_boundary ();  
  
  Triangulation<3>   tria_reserve;
  
  void set_spherical_manifold();
  
  int tot_no_matched, tot_no_corrected;

  void rotate_and_add (const double angle, const int axis, const double merge_toll);
  void rotate_and_add_reserve (const double angle, const int axis, const double merge_toll);
  void match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll);
                                               
    
  Triangulation<3> triangulation;
  FE_Q<3> fe;
  DoFHandler<3> dof_handler;

  SparsityPattern sparsity_pattern;
  SparseMatrix<double> system_matrix;
  
  ConstraintMatrix     constraints;
  
  dealii::Vector<double> solution;
  dealii::Vector<double> system_rhs;
  
  class All_charges * all_charges;
  class finecuppa::objects::Atom_data * atom_data;

  bool initialized;
  
  std::vector<std::pair<int,double>> boundary_id_value;
  std::vector<unsigned> boundary_id_list;
  std::vector<int> refine_sequence_type, refine_sequence_value;  
  double k_electrostatic;
  std::vector<std::string> unv_mesh_filename;  
  int time_step_count, time_step_solve, time_step_output_vtk;
  int time_step_induced_charge;
  bool output_vtk;
  double derivation_length;

  std::vector<Tensor<1,3,double>> face_normal;
  std::vector<Point<3>> face_center;  
  std::vector<double> face_area;
  std::vector<unsigned> face_id;  
  std::vector<unsigned> face_id_ignore;
  std::ofstream ofs_induced_charge;
  bool induced_charge_id_init;
  bool output_induced_charge;  
  unsigned int boundary_id_max;
  
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  int my_mpi_rank, mpi_world_size;
#endif  
  const int dim = 3;

  std::vector<Vector<double>> face_center_pos, face_center_field;
  std::vector<double> face_center_potential;
// ewald members
  bool ewald_initialized, calculated_once;
  void ewald_initialize();
  void calculate_alpha();
  void make_k_vectors ();
  void make_k_vectors_slab_geometry();
  void calculate_slab_geometry_coefficients();

  int cutoff_k, n_k_vectors;


///  void calculate_slab_geometry_coefficients();
  double  alpha;

// simulation box lengths and its product
  double lx,lx_inv, ly,ly_inv, lz,lz_inv, l_xyz_inv;

  int kx_max, ky_max, kz_max;
//  std::vector<std::vector<std::vector<double>>> k_coef;

  std::vector<Vector<double>> k_vector;
  std::vector<double> k_vector_sq;
  std::vector<double> field_k_coef;

  std::vector<std::complex<double>> potential_k_coef_cmplx; // depends on the positions...
  void calculate_potential_k_coef_cmplx(); // ...of the particles in each time step

  bool dipole;
  double epsilon_dipole;
  double dipole_potential_value, dipole_energy_value;
  Vector<double> dipole_field_vector;  
  Vector<double> dipole_field();  

  bool slab_geometry;

  class finecuppa::objects::Domain *domain;
  void calculate_all_particles_ewald_r_acc_neighlist();
  void calculate_all_particles_ewald_r_acc_binlist();
  void calculate_all_particles_ewald_k_acc();
  void calculate_all_particles_mesh_force_acc();
  Vector<double> ewald_total_field(const Vector<double> &);  
  Vector<double> k_space_field(const Vector<double> &);  
  Vector<double> r_space_field(const Vector<double> &);  
  Vector<double> slab_geometry_correction_field(const Vector<double> &);  
// ewald part finish

};



//==================================================
//==================================================
//==================================================

namespace dealii_poisson_ewald {
//template <int dim>
class BoundaryValues : public Function<3>
{
public:
  BoundaryValues () : Function<3>() {}
  
  BoundaryValues (double tp) : Function<3>(), total_potential{tp} {}  
  
  BoundaryValues (double tp,
    class finecuppa::objects::force_field::Dealii_poisson_ewald* df )
    : 
    Function<3>(),
    total_potential{tp},
    k_electrostatic{df->k_electrostatic},
    alpha{df->alpha},
    atom_data{df->atom_data},
    neighborlist{df->neighborlist},
    deal_force{df}
    {}

   
     
  virtual double value (const Point<3> &p,
                        const unsigned int component = 0) const;                    
protected:
  double total_potential;
  double potential_of_free_charges  (const dealii::Point<3> &p) const;
  double k_electrostatic;
  double alpha;
  class finecuppa::objects::Atom_data *atom_data;
  class finecuppa::objects::Neighborlist *neighborlist;
  class finecuppa::objects::force_field::Dealii_poisson_ewald *deal_force;

};
} //dealii_poisson_ewald
} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#else

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Dealii_poisson_ewald : public Force_field
{
public:
  Dealii_poisson_ewald (class FinECuPPA *fptr);
  ~Dealii_poisson_ewald ();
  void calculate_acceleration ();
  bool read(Parser *);

};
} //finite_element
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
#endif
