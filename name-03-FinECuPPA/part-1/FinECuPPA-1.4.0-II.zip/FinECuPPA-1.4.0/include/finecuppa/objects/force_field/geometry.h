#ifndef FINECUPPA_FORCE_FIELD_GEOMETRY_H
#define FINECUPPA_FORCE_FIELD_GEOMETRY_H

#include "finecuppa/objects/force_field.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Shape;
namespace force_field {

class Geometry : public Force_field {
public:
  Geometry (class FinECuPPA *);
  ~Geometry ();
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:  
  std::vector<finecuppa::objects::Shape *> shape;
  bool shape_size_warning;
  std::vector<double> radius;
  double young_modulus, dissip_coef;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
