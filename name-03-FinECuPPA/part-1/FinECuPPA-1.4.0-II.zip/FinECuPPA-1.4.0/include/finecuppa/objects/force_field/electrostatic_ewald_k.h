#ifndef FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EWALD_K_H
#define FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EWALD_K_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"

#include <vector>
#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Long_range_solver;
class Domain; 
namespace force_field {

class Electrostatic_ewald_k : public Force_field {
public:
  Electrostatic_ewald_k (class FinECuPPA *);
  ~Electrostatic_ewald_k () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
  double energy ();

protected:

  double self_energy ();
  double dipole_energy ();
  double k_space_energy ();

  double potential (const Vector<double> &);
  double potential (const int);
  double k_space_potential (const Vector<double> &);
  double k_space_potential (const int);
  double dipole_potential (const Vector<double> &);
  double dipole_potential (const int);

  Vector<double> field (const Vector<double> &);
  Vector<double> field (const int);
  Vector<double> k_space_field (const Vector<double> &);
  Vector<double> k_space_field (const int);
  Vector<double> dipole_field ();


  int n_k_vectors;
  bool initialized, calculated_once;
  void initialize();
  void make_k_vectors();
  void calculate_alpha();
  void calculate_dipole_sum();

  double k_electrostatic, alpha;
  Vector<double> external_field;

// simulation box lengths and its product
  double lx,lx_inv, ly,ly_inv, lz,lz_inv, l_xyz_inv;

  int kx_max, ky_max, kz_max;
//  std::vector<std::vector<std::vector<double>>> k_coef;

  std::vector<Vector<double>> k_vector;
  std::vector<double> k_vector_sq;
  std::vector<double> field_k_coef;//, potential_k_coef;

  std::vector<std::complex<double>> potential_k_coef_cmplx; // depends on the positions...
  void calculate_potential_k_coef_cmplx(); // ...of the particles in each time step

  bool dipole;
  double epsilon_dipole;
  double dipole_coef; // defined as k_electrostatic * 4PI/(1+2e')L^3
  Vector<double> dipole_field_vector, dipole_sum;  // dipole_sum: Sum_j(q_j vec(r_j))
  
  bool slab_geometry;
  int slab_normal_axis;
  double slab_lz;

  class finecuppa::objects::Domain *domain;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
