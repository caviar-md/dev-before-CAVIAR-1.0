#ifndef FINECUPPA_FORCE_FIELD_ELECTROSTATIC_H
#define FINECUPPA_FORCE_FIELD_ELECTROSTATIC_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Long_range_solver;
namespace force_field {

class Electrostatic : public Force_field {
public:
  Electrostatic (class FinECuPPA *);
  ~Electrostatic () {};
  double potential (const Vector<double> &);
  double potential (const int);

  Vector<double> field (const Vector<double> &);
  Vector<double> field (const int);

  double energy();

  bool read (class Parser *);
  void calculate_acceleration ();
protected:
  //std::vector<std::vector<Real_t>> epsilon,sigma;
  double k_electrostatic;
  Vector<double> external_field;
 
  class objects::Long_range_solver *long_range_solver;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
