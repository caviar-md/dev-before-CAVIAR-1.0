#ifndef FINECUPPA_FORCE_FIELD_DPD_H
#define FINECUPPA_FORCE_FIELD_DPD_H

#include "finecuppa/objects/force_field.h"
#include <vector>
#include <random>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Dpd : public Force_field { // there's a numeric error due to using ghost atoms and different random number generated for their owned counterpart atom. // this problem is solved at Dpd_acc
public:
  Dpd (class FinECuPPA *);
  ~Dpd () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  std::vector<std::vector<Real_t>> conserv_coef,dissip_coef;
  Real_t temperature, kBoltzman;
  int rnd_seed;
  std::mt19937 rnd_generator;
  std::normal_distribution<double> rnd_ndist; // stddev() == 1
  double dt;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif

