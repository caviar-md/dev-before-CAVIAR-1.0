#ifndef FINECUPPA_FORCE_FIELD_LJ_H
#define FINECUPPA_FORCE_FIELD_LJ_H

#include "finecuppa/objects/force_field.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Lj : public Force_field {
public:
  Lj (class FinECuPPA *);
  ~Lj () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  std::vector<std::vector<Real_t>> epsilon,sigma;  
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
