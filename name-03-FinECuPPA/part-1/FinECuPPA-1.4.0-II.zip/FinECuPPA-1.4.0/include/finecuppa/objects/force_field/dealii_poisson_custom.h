#ifndef FINECUPPA_OBJECTS_FORCE_FIELD_DEALII_POISSON_CUSTOM_H
#define FINECUPPA_OBJECTS_FORCE_FIELD_DEALII_POISSON_CUSTOM_H

#include "finecuppa/objects/force_field.h"

#ifdef USE_DEALII

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/base/function.h>
#include <deal.II/base/tensor.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Atom_data;
class Domain;
namespace force_field {
using namespace dealii;

class Dealii_poisson_custom : public Force_field
{
public:
  Dealii_poisson_custom (class FinECuPPA *);
  ~Dealii_poisson_custom ();

  void calculate_acceleration ();  
  bool read(Parser *);
  double total_potential_of_charges (const dealii::Point<3> &p);
  
public:

  void run ();
  void read_domain();
  void make_grid ();
  void make_boundary_face_normals ();
  void setup_system();
  void assemble_system();
  void solve ();
  void calculate_induced_charge (const int);

  void output_vtk_solution (const int) const;

  void refine_grid_adaptive ();
  void refine_boundary (const unsigned int);

  void set_boundary ();  
  
  Triangulation<3>   tria_reserve;
  
  void set_spherical_manifold();
  
  int tot_no_matched, tot_no_corrected;

  void rotate_and_add (const double angle, const int axis, const double merge_toll);
  void rotate_and_add_reserve (const double angle, const int axis, const double merge_toll);
  void match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll);
                                               
    
  Triangulation<3> triangulation;
  FE_Q<3> fe;
  DoFHandler<3> dof_handler;

  SparsityPattern sparsity_pattern;
  SparseMatrix<double> system_matrix;
  
  ConstraintMatrix     constraints;
  
  dealii::Vector<double> solution;
  dealii::Vector<double> system_rhs;
  
  class All_charges * all_charges;
  class finecuppa::objects::Atom_data * atom_data;

  bool initialized;
  
  std::vector<std::pair<int,double>> boundary_id_value;
  std::vector<unsigned> boundary_id_list;
  std::vector<int> refine_sequence_type, refine_sequence_value;  
  double k_electrostatic;
  std::vector<std::string> unv_mesh_filename;  
  int time_step_count, time_step_solve, time_step_output_vtk;
  int time_step_induced_charge;
  bool output_vtk;
  double derivation_length;

  std::vector<Tensor<1,3,double>> face_normal;
  std::vector<Point<3>> face_center;  
  std::vector<double> face_area;
  std::vector<unsigned> face_id;  
  std::vector<unsigned> face_id_ignore;
  std::ofstream ofs_induced_charge;
  bool induced_charge_id_init;
  bool output_induced_charge;  
  unsigned int boundary_id_max;
  
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  int my_mpi_rank, mpi_world_size;
#endif  
  const int dim = 3;

  std::vector<Vector<double>> face_center_pos, face_center_field;
  std::vector<double> face_center_potential;

  std::vector<finecuppa::objects::Force_field*> force_field_custom;

  class finecuppa::objects::Domain *domain;

  void calculate_all_particles_mesh_force_acc();

};



//==================================================
//==================================================
//==================================================

namespace dealii_poisson_custom {

class BoundaryValues : public Function<3>
{
public:
  BoundaryValues () : Function<3>() {}
  
  BoundaryValues (double tp) : Function<3>(), total_potential{tp} {}  
  
  BoundaryValues (double tp,
    class finecuppa::objects::force_field::Dealii_poisson_custom* df )
    : 
    Function<3>(),
    total_potential{tp},
    deal_force{df}
    {}
       
  virtual double value (const Point<3> &p,
                        const unsigned int component = 0) const;                    
protected:
  double total_potential;
  double potential_of_free_charges  (const dealii::Point<3> &p) const;

  class finecuppa::objects::force_field::Dealii_poisson_custom *deal_force;

};
} //dealii_poisson_custom
} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#else

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Dealii_poisson_custom : public Force_field
{
public:
  Dealii_poisson_custom (class FinECuPPA *fptr);
  ~Dealii_poisson_custom ();
  void calculate_acceleration ();
  bool read(Parser *);

};
} //finite_element
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
#endif
