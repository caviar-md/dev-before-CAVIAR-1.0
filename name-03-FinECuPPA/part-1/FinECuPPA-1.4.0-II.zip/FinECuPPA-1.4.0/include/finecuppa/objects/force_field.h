#ifndef FINECUPPA_FORCE_FIELD_H
#define FINECUPPA_FORCE_FIELD_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Atom_data; 
class Neighborlist; 
class Force_field  : protected Pointers {
 public:
  Force_field (class FinECuPPA *);
  virtual ~Force_field () {};
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void calculate_acceleration () = 0;
  virtual double energy();
  virtual double potential (const Vector<double> &);
  virtual double potential (const int);
  virtual Vector<double> field (const Vector<double> &);
  virtual Vector<double> field (const int);
  double cutoff;
  class objects::Atom_data *atom_data;
  class objects::Neighborlist *neighborlist;
  std::string object_base_class_name, object_class_name, object_name;
 protected:

};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
