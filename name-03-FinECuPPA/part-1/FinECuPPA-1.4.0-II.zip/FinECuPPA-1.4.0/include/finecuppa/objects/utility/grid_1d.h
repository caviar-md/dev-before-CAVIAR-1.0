#ifndef FINECUPPA_OBJECT_UTILITY_GRID_1D_H
#define FINECUPPA_OBJECT_UTILITY_GRID_1D_H

#include "finecuppa/utility/pointers.h"
#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace utility {
class Grid_1D : protected Pointers {
  public:
    Grid_1D (class FinECuPPA *) ;    
    Grid_1D (class FinECuPPA *, double MIN, double MAX, double increment, int segment) ;
    ~Grid_1D () ;
    
    bool read (Parser *);
    void generate (); // calculates the parameters
    unsigned int no_points ();
    double give_point ();
    double give_point (int);
    

    double min, max, increment;

    bool generated; // true if generate() has been called.    
    bool by_increment, by_segment;
    
    int segment;    
    int no_given_points;     
    int num; // number of random atoms or molecules to be created        
    int type_int;
   
    std::string TYPE;
    

  protected:
};

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
