#ifndef FINECUPPA_OBJECTS_ATOM_DATA_SIMPLE_H
#define FINECUPPA_OBJECTS_ATOM_DATA_SIMPLE_H

#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace atom_data {
class Simple : public Atom_data {
public:
  Simple (class FinECuPPA *);
  bool read (class finecuppa::Parser *);
  bool add_xyz_data_file(class finecuppa::Parser *);
protected:
  void allocate ();
};

} //atom_data
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif

