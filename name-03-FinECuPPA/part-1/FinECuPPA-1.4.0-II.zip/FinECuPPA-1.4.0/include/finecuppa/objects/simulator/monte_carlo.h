#ifndef FINECUPPA_SIMULATOR_MONTE_CARLO_H
#define FINECUPPA_SIMULATOR_MONTE_CARLO_H

#include "finecuppa/objects/simulator.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace simulator {

class Monte_carlo : public Simulator {
 public:
  Monte_carlo (class FinECuPPA *);
   ~Monte_carlo ( );
  bool read (class finecuppa::Parser *);
  bool run ();
  void verify_settings ();
  void setup ();
  void cleanup ();

 protected:
  int initial_step, final_step;
  double total_time;
};

} //simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
