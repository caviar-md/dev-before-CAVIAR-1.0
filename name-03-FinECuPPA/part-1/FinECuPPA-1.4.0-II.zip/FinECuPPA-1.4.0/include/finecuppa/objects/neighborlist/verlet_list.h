#ifndef FINECUPPA_NEIGHBORLIST_VERLET_LIST_H
#define FINECUPPA_NEIGHBORLIST_VERLET_LIST_H

#include "finecuppa/objects/neighborlist.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace neighborlist {
class Verlet_list : public Neighborlist {
 public:
  Verlet_list (class FinECuPPA *);
  bool read (class finecuppa::Parser *);
  void init ();
  bool rebuild_neighlist ();
  void build_neighlist ();
  double dt, cutoff_extra;
//  double cutoff; // Defined in the base class
 protected:
};

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
