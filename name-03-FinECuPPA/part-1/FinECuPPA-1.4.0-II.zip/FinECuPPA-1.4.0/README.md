
## What is this?

FinECuPPA is a molecular dynamics package written by Morad Biagooi. It's main
goal is to be user and also developer friendly. 
