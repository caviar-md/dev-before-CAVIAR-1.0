#include "unv_handler.h"

#include <iostream>

namespace NS_mesh_handler {

  void Unv_handler::merge_close_vertices (const double tolerance) {
    unsigned uci = unv_container.size() - 1;
    if (uci<0) {
      std::cout << "error: there's no unv_container\n";
      return;
    }
  }
}







