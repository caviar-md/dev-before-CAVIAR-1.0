for ubuntu copy 'finecuppa.lang' to 
'/usr/share/gtksourceview-X.Y/language-specs/' in which 'X' and 'Y' are the
 version major and minor numbers.
