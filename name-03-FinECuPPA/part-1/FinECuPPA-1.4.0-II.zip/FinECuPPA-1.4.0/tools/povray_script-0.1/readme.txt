Developed by Morad Biagooi
m.biagooi@gmail.com

Here are some simple scripts to visualize povray files made by FinECuPPA.
