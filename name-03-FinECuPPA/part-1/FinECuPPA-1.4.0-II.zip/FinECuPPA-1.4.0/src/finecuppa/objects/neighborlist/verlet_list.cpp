#include "finecuppa/objects/neighborlist/verlet_list.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace neighborlist {
Verlet_list::Verlet_list (FinECuPPA *fptr) : Neighborlist{fptr} 
{
  cutoff = 1.0;
  dt = 0.001;
}

bool Verlet_list::read (finecuppa::Parser *parser) {
  output->info("Neighborlist Verlet_list read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
      if (cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff have to non-negative."); 

    } else if (string_cmp(t,"dt")) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
      if (dt < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "dt have to non-negative."); 
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }

  return in_file;
}

void Verlet_list::init () {
  if (atom_data==nullptr) error->all("Verlet_list::init: atom_data = nullptr");
  auto &old_pos = atom_data->last_reneighborlist_pos;
  const auto &pos = atom_data->owned.position;
  old_pos.resize (pos.size());
}

bool Verlet_list::rebuild_neighlist () {
  bool result = false;
  const auto &pos = atom_data->owned.position, &old_pos = atom_data->last_reneighborlist_pos;
  for (unsigned int i=0; i<old_pos.size(); ++i) {
    auto disp = pos[i] - old_pos[i];
    result |= (disp*disp > cutoff_extra*cutoff_extra/4);
  }
#ifdef USE_MD_MPI
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Verlet_list::build_neighlist () {
  double max_vel_sq=0.0;
  for (const auto v:atom_data->owned.velocity) {// Any faster scheme using <algorithm>?
    double vel_sq_temp = v*v; 
     if (max_vel_sq<vel_sq_temp) max_vel_sq = vel_sq_temp;
  }

#ifdef USE_MD_MPI
  double max_vel_sq_all=0.0;
  MPI_Allreduce (&max_vel_sq,&max_vel_sq_all, 1, MPI_DOUBLE, MPI_MAX, mpi_comm); 
  double max_vel_all = std::sqrt(max_vel_sq_all);
#else
  double max_vel_all = std::sqrt(max_vel_sq);
#endif
  cutoff_extra = 30.0*dt*max_vel_all;  // XXX check the coef

  const auto &pos = atom_data->owned.position, & pos_ghost = atom_data -> ghost.position;
  const auto cutoff_sq = (cutoff + cutoff_extra)*(cutoff + cutoff_extra);
  const auto pos_size = pos.size();
  neighlist.clear ();
  neighlist.resize (pos_size);

  for (unsigned int i=0; i<pos_size; ++i) {
    for (unsigned int j=i+1; j<pos_size; ++j) {
      auto dr = pos[j] - pos[i];
      if (dr*dr < cutoff_sq) {
        neighlist[i].push_back (j);
      }
    }
    for (unsigned int j=0; j<pos_ghost.size(); ++j) {
      auto dr = pos_ghost[j] - pos[i];
      if (dr*dr < cutoff_sq) {
        neighlist[i].push_back (j + pos_size);
      }
    }
  }
  
  auto &old_pos = atom_data->last_reneighborlist_pos;
/*
  old_pos.clear ();
  for (unsigned int i=0; i<pos_size; ++i) {
    old_pos.push_back (pos[i]);
  }
*/
  old_pos = pos;

}

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

