#include "finecuppa/objects/simulator.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Simulator::Simulator (FinECuPPA *fptr) : Pointers{fptr} {}

Simulator::~Simulator () {}

} //objects



FINECUPPA_NAMESPACE_CLOSE

