#include "finecuppa/objects/utility/molecule.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/utility/atom.h"


FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace utility {

 
Molecule::Molecule (FinECuPPA *fptr) : Pointers{fptr},
    part_of_a_molecule{false}, upper_level_molecule{nullptr},
    position{Vector<double>{0,0,0}},
    velocity{Vector<double>{0,0,0}}
{}    
    
Molecule::Molecule (FinECuPPA *fptr, class Molecule * f,
    Vector<double> pos, Vector<double> vel) :  Pointers{fptr},
    part_of_a_molecule{true}, upper_level_molecule{f},
    position{pos}, velocity{vel}
{}
    
   
Molecule::Molecule (const Molecule & a) : Pointers{a}
{
  part_of_a_molecule = false;
  upper_level_molecule = nullptr;
  position = a.position;
  velocity = a.velocity;
  for (auto i : a.molecules) {
    Molecule a_new (i);
    a_new.part_of_a_molecule = true;
    a_new.upper_level_molecule = this;
    molecules.push_back (a_new);
  }
  for (auto i : a.atoms) {
    Atom a_new (i);
    a_new.part_of_a_molecule = true;
    a_new.upper_level_molecule = this;      
    atoms.push_back (a_new);
  }
}

Molecule::~Molecule () {}


bool Molecule::read ( Parser * parser) {
  output->info("Molecule read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    std::cout << t << std::endl;
    ASSIGN_REAL_3D_VECTOR(position,"MOLECULE READ: ","")
    else ASSIGN_REAL_3D_VECTOR(velocity,"MOLECULE READ: ","")
    else if (string_cmp(t,"add")) {
      in_file = add_directly(parser);
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: read: Unknown variable or command");
  }
  
  return in_file;
}

bool Molecule::add_directly ( Parser * parser) {

  auto t1 = parser->get_val_token();
  auto t1s = t1.string_value;
  if (t1.kind == Kind::eof || t1.kind == Kind::eol) 
    error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: add what?");

  std::map<std::string,object_handler::Dictionary>::iterator it;
  if (string_cmp(t1s,"atom")) {
    FIND_OBJECT_BY_NAME_NIC(atom,it)
  } else if (string_cmp(t1s,"molecule")) {
    FIND_OBJECT_BY_NAME_NIC(molecule,it)
  } else error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: add: expected atom or molecule");

  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  bool in_file = true;
  while (true) {
    GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;    
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"","")\
    } else if (string_cmp(t,"at_velocity")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"","")\
    }
  }

  if (string_cmp(t1s,"atom")) {
    objects::utility::Atom a_new = *object_container -> atom[it->second.index];
    if (position_called) 
      a_new.pos() = pos_;
    if (velocity_called) 
      a_new.vel() = vel_;
    add_atom (a_new);
  } else if (string_cmp(t1s,"molecule")) {
    objects::utility::Molecule a_new = *object_container -> molecule[it->second.index];  
    if (position_called)
      a_new.pos() = pos_;
    if (velocity_called) 
      a_new.vel() = vel_;
    add_molecule(a_new);
  }

  return in_file;
}

void Molecule::give_position_and_radius (std::vector<Vector<double>> &p_vector, std::vector<double> &r_vector) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].give_position_and_radius (p_vector, r_vector);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    r_vector.push_back (atoms[i].get_radius());
    p_vector.push_back (atoms[i].pos_tot());
  }  
}


void Molecule::correct_heritage () {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].upper_level_molecule = this;
    molecules[i].part_of_a_molecule = true;
    molecules[i].correct_heritage ();
  }  
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].upper_level_molecule = this;
    atoms[i].part_of_a_molecule = true; 
  }
}


void Molecule::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].extract_all_e_pos_vel(e, p, v);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].extract_all_e_pos_vel(e, p, v);
  }
 }
 

void Molecule::number_of_atoms (int &n) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].number_of_atoms (n);
  }
  n += atoms.size();
}


void Molecule::output_xyz (std::ofstream & out_file) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].output_xyz (out_file);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].output_xyz (out_file);
  }
}


Vector<double> Molecule::pos_tot () const {
  if (part_of_a_molecule) return position + upper_level_molecule->pos_tot();
   else return position;  
}
Vector<double> Molecule::vel_tot () const {
  if (part_of_a_molecule) return velocity + upper_level_molecule->vel_tot();
  else return velocity;  
}


bool Molecule::add_atom (const objects::utility::Atom &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].upper_level_molecule = this;
  atoms[i].part_of_a_molecule = true;
   atoms[i].pos() = p;
  atoms[i].vel() = v;
  return true; //WARNING
}

bool Molecule::add_molecule (const objects::utility::Molecule &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].upper_level_molecule = this;
  molecules[i].part_of_a_molecule = true;
  molecules[i].pos() = p;
  molecules[i].vel() = v;
  return true; //WARNING  
}

bool Molecule::add_atom (const objects::utility::Atom & a){
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].upper_level_molecule = this;
  atoms[i].part_of_a_molecule = true;
  return true; //WARNING  
}

bool Molecule::add_molecule (const objects::utility::Molecule & a){
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].upper_level_molecule = this;
  molecules[i].part_of_a_molecule = true;
  return true; //WARNING  
}

Vector<double> Molecule::pos () const {
  return position;  
}

Vector<double> & Molecule::pos ()  {
  return position;
}

Vector<double> Molecule::vel () const {
  return velocity;  
}

Vector<double> & Molecule::vel ()  {
  return velocity;
}

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

