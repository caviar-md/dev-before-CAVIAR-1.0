#include "finecuppa/objects/utility/distribution.h"
#include "finecuppa/objects/shape/boundary.h"
#include "finecuppa/objects/utility/grid_1d.h"
#include "finecuppa/objects/utility/atom.h"
#include "finecuppa/objects/utility/molecule.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace utility {


Distribution::Distribution (FinECuPPA *fptr) : Pointers{fptr},
    boundary_check{false}, a_object_check{false}, m_object_check{false},
    container_check{false} { }
  
Distribution::~Distribution () {}  
  
bool Distribution::read (Parser* parser) {
  output->info("distribution read:");
  bool in_file = true;
      
  while(true){
    GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (string_cmp(t,"boundary")) {
      FIND_OBJECT_BY_NAME(boundary,it)
      boundary = object_container->boundary[it->second.index];
      boundary_check = true;
    }  
    else if (string_cmp(t,"object")) {
      std::map<std::string,object_handler::Dictionary>::iterator it;std::string name_1;
      GET_A_STRING(name_1,""," expected an molecule or atom NAME. ")
      CHECK_NAME_EXISTANCE(name_1, it, " ","")
      if (it->second.type == object_handler::gdst("atom")) {
        a_object_check = true;        
        a_object = object_container->atom[it->second.index];          
      } else if (it->second.type == object_handler::gdst("molecule")) {
        m_object_check = true;
        m_object = object_container->molecule[it->second.index];                            
      } else error->all(FC_FILE_LINE_FUNC_PARSE," undefined molecule or atom NAME. ");
     }        
    else if (string_cmp(t,"container")) {
      FIND_OBJECT_BY_NAME(molecule,it)        
      container = object_container->molecule[it->second.index];        
      container_check = true;        
    }              
    else if (string_cmp(t,"distribute_grid_3d")) {distribute_grid_3D(parser); break;}      
    else if (string_cmp(t,"distribute_random_3d")) {distribute_random_3D(parser); break;}            
    else error->all(FC_FILE_LINE_FUNC_PARSE,"Unknown variable or command ");
  }
  return in_file;;
}
  
bool Distribution::distribute_grid_3D(Parser* parser) {
  output->info("distribute_grid_3D:");
  bool in_file = true;
  objects::utility::Grid_1D *pos_grid_X = nullptr, *pos_grid_Y = nullptr,
      *pos_grid_Z = nullptr;
      
  bool pos_grid_check_X=false, pos_grid_check_Y=false, pos_grid_check_Z=false;
    
  while(true){
    GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;
    if (string_cmp(t,"position_x")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      pos_grid_X = object_container->grid_1d[it->second.index];
      pos_grid_check_X = true;        
    } else if (string_cmp(t,"position_y")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      pos_grid_Y = object_container->grid_1d[it->second.index];
      pos_grid_check_Y = true;  
    }   else  if (string_cmp(t,"position_z")) {
      FIND_OBJECT_BY_NAME(grid_1d,it)        
      pos_grid_Z = object_container->grid_1d[it->second.index];
      pos_grid_check_Z = true;  
    } else error->all(FC_FILE_LINE_FUNC_PARSE,"Unknown variable or command ");
  }

  if (!(pos_grid_check_X && pos_grid_check_Y && pos_grid_check_Z))
    error->all(FC_FILE_LINE_FUNC_PARSE," three GRID_1D is needed for distribution ");
    
  std::vector<double> r_vector; // radius of atoms
  std::vector<Vector<double>> p_vector; // total positions of atoms
  if (a_object_check) {
    r_vector.push_back (a_object->get_radius());
    p_vector.push_back (a_object->pos_tot());
  }
  if (m_object_check) {
    m_object->give_position_and_radius (p_vector, r_vector);
  }


  for (unsigned int i = 0; i < pos_grid_X->no_points(); ++i) {
    double x = pos_grid_X->give_point(i);
    for (unsigned int j = 0; j < pos_grid_Y->no_points(); ++j) {
      double y = pos_grid_Y->give_point(j);      
      for (unsigned int k = 0; k < pos_grid_Z->no_points(); ++k) {  
        double z = pos_grid_Z->give_point(k);          
        const Vector<double> p {x,y,z}, v{0,0,0};
         /* // simple method - just center is inside condition
          if (boundary->is_inside(p)) {
            if (a_object_check)
              container->add_atom (*a_object, p, v);
            if (m_object_check)
              container->add_molecule (*m_object, p, v);
          }*/
          
        bool inside_flag = true;
        if (boundary_check)
          for (unsigned int m = 0; m<r_vector.size(); ++m)
            if (!boundary->is_inside(p + p_vector[m], r_vector[m])) {
              inside_flag = false;
              continue;
            }
            
        if (inside_flag) {
          if (a_object_check)
            container->add_atom (*a_object, p, v);
          if (m_object_check)
            container->add_molecule (*m_object, p, v);              
        }
          
      }
    }
  }
    
  container -> correct_heritage ();
    
  return in_file;
}
  



  
bool Distribution::distribute_random_3D(Parser* parser) {
  output->info("DISTRIBUTE_RANDOM_3D: ");   
  bool in_file = true;
  bool pos_rand_check_X=false, pos_rand_check_Y=false, pos_rand_check_Z=false;    
    /*
    object_utility::Random_1D *pos_rand_X, *pos_rand_Y, *pos_rand_Z;        
    while(true){
      GET_A_TOKEN_FOR_CREATION
      const auto t = token.string_value;
      if (t=="POSITION_X") {
        std::map<std::string,object_handler::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == object_handler::gdst("random_1d")) {
          pos_rand_X = &object_container->random_1d[it_1->second.index];
          pos_rand_check_X = true;
        } else error->all(FC_FILE_LINE_FUNC_PARSE,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
      } else if (t=="POSITION_Y") {
        std::map<std::string,object_handler::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D ","")
        if (it_1->second.type == object_handler::gdst("random_1d")) {
          pos_rand_Y = &object_container->random_1d[it_1->second.index];
          pos_rand_check_Y = true;
        } else error->all(FC_FILE_LINE_FUNC_PARSE,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D NAME. ");
      }   else  if (t=="POSITION_Z") {
        std::map<std::string,object_handler::Dictionary>::iterator it_1;std::string name_1;
        GET_A_STRING(name_1,"DISTRIBUTE_RANDOM_3D: "," expected an RANDOM_1D  NAME. ")
        CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTE_RANDOM_3D: ","")
        if (it_1->second.type == object_handler::gdst("random_1d")) {
          pos_rand_Z = &object_container->random_1d[it_1->second.index];
          pos_rand_check_Z = true;
        } else error->all(FC_FILE_LINE_FUNC_PARSE,"DISTRIBUTE_RANDOM_3D: undefined  RANDOM_1D  NAME. ");
      } else error->all(FC_FILE_LINE_FUNC_PARSE,"DISTRIBUTE_RANDOM_3D: Unknown variable or command ");
    }
    */
    
  if (!(pos_rand_check_X && pos_rand_check_Y && pos_rand_check_Z))
    error->all(FC_FILE_LINE_FUNC_PARSE," three GRID_1D is needed for distribution ");
    

      
  return in_file;
}
  
} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

