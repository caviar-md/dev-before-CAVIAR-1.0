#include "finecuppa/objects/simulator/monte_carlo.h"
#include "finecuppa/objects/tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace simulator {

Monte_carlo::Monte_carlo (FinECuPPA *fptr) : Simulator{fptr}  {}

Monte_carlo::~Monte_carlo () {}

bool Monte_carlo::read (finecuppa::Parser *parser) {
  output->info("simulator monte carlo: read:");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"run")) {
      run();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

bool Monte_carlo::run () {
  output->info ("Monte_carlo started.");
  verify_settings ();
  setup ();

  cleanup ();
  output->info ("Monte_carlo finished.");
  std::string s = "info: simulation time: " + std::to_string(total_time)
                + " (seconds)";
  output->info (s, 3);
  return true; //WARNING
}

void Monte_carlo::verify_settings () {

}

void Monte_carlo::setup () {
  output->open_files ();
  t_start = clock();
}

void Monte_carlo::cleanup () {
  output->close_files ();
  t_end = clock();
  total_time =  ( (float)t_end - (float)t_start ) / CLOCKS_PER_SEC;
}

} //simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

