#include "finecuppa/objects/force_field/finite_element.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/objects/finite_element.h"
#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Finite_element::Finite_element (FinECuPPA *fptr) : Force_field {fptr},
    finite_element{nullptr}
 { }

bool Finite_element::read (Parser *parser) {
  output->info("Force_field finite element read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    
    if (string_cmp(t,"cutoff")) {
      error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff is not implemented in force_field geometry");  
    } else if (string_cmp(t,"finite_element")) {
      FIND_OBJECT_BY_NAME(finite_element,it)
      finite_element = object_container->finite_element[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  
  }
  
  return in_file;
  return true; // WARNING
}

void Finite_element::calculate_acceleration () {
  if (finite_element == nullptr) error->all("finite_element::calculate_acceleration: finite_element = nullptr");
  finite_element -> calculate_acceleration ();
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

