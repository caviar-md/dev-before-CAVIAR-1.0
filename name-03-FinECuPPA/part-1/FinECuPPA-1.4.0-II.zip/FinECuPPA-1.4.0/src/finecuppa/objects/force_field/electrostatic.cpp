#include "finecuppa/objects/force_field/electrostatic.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/long_range_solver.h"
#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Electrostatic::Electrostatic (FinECuPPA *fptr) : Force_field{fptr}, k_electrostatic{1.0}, external_field{Vector<double>{0,0,0}},
 long_range_solver{nullptr}
 {
  output->info ("A electrostatic force field is created."); 
}

bool Electrostatic::read (Parser *parser) {
  output->info("Force_field electrostatic read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
      if (cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "Force field cutoff have to non-negative.");      
    } else if (string_cmp(t,"external_field")) {
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(external_field, "", "");
      //if (vector_value < 0)  error->all (FC_FILE_LINE_FUNC_PARSE, "Epsilon have to be non-negative.");      
    }  else if (string_cmp(t,"k_electrostatic")) {
      GET_OR_CHOOSE_A_REAL(k_electrostatic,"","")    
      if (k_electrostatic < 0)  error->all (FC_FILE_LINE_FUNC_PARSE, "k_electrostatic has to be non-negative.");            
    } else if (string_cmp(t,"long_range_solver") || string_cmp(t,"set_long_range_solver")) {
      FIND_OBJECT_BY_NAME(long_range_solver,it)
      long_range_solver = object_container->long_range_solver[it->second.index];
    } else if (string_cmp(t,"set_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist = object_container->neighborlist[it->second.index];
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: read: Unknown variable or command");
  }
  
  return in_file;
}

void Electrostatic::calculate_acceleration () {
  if (atom_data == nullptr) error->all("Electrostatic::calculate_acceleration: atom_data = nullptr");
//if (neighborlist == nullptr) error->all("Lj_acc::calculate_acceleration: neighborlist = nullptr");
  const auto &pos = atom_data -> owned.position;  
  if (!(long_range_solver==nullptr)) {
    long_range_solver -> calculate();    

    std::cout << std::endl << std::setprecision(20);
    std::cout << "force_field: et: " << long_range_solver -> total_energy () << std::endl;
    std::cout << std::endl;
    
    for (unsigned int i=0;i<pos.size();++i) {
      const auto type_i = atom_data -> owned.type [i] ;
      const auto mass_i = atom_data -> owned.mass [ type_i ];
      const auto charge_i = atom_data -> owned.charge [ type_i ];
      const auto coef = k_electrostatic * charge_i / mass_i;
      
      const auto total_field = long_range_solver -> total_field (i);
      atom_data -> owned.acceleration[i] += coef * total_field;
      std::cout << i << " : " << coef * total_field << "\n";
    }

  } else {
    for (unsigned int i=0;i<pos.size();++i) {
      const auto type_i = atom_data -> owned.type [i] ;
      const auto mass_i = atom_data -> owned.mass [ type_i ];
      const auto charge_i = atom_data -> owned.charge [ type_i ];
      for (unsigned int j=i+1;j<pos.size();++j) {

        const auto type_j = atom_data -> owned.type [j] ;
        const auto mass_j = atom_data -> owned.mass [ type_j ];
        const auto charge_j = atom_data -> owned.charge [ type_j ];      
        const auto dr = pos[j] - pos[i]; 
        const auto dr_sq = dr*dr;
        const auto dr_norm = std::sqrt(dr_sq);      
        const auto force = k_electrostatic * charge_i * charge_j * dr / (dr_sq*dr_norm);
        atom_data -> owned.acceleration [i] -= force / mass_i;
        atom_data -> owned.acceleration [j] += force / mass_j;

      }
    
      const auto force = external_field * charge_i;
      atom_data -> owned.acceleration [i] += force / mass_i;    
    }  

  }

}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

