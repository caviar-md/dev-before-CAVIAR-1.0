#ifdef USE_DEALII

#include "finecuppa/objects/force_field/dealii_poisson_custom.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/domain.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

namespace dealii_poisson_custom {

double BoundaryValues::potential_of_free_charges (const dealii::Point<3> &p) const
{
  const Vector<double> r = {p[0], p[1], p[2]};

  double potential = 0.0;
  for (auto &&f : deal_force -> force_field_custom)
    potential += f->potential (r);

  return potential;
}

double BoundaryValues::value (const Point<3> &p, const unsigned int ) const
{
#ifdef USE_MD_MPI
  double total_potential_of_free_charges = 0;
  double local_potential_of_free_charges = potential_of_free_charges (p);
//  MPI_Barrier (mpi_communicator); // XXX is it nessecary?

  MPI_Allreduce(&local_potential_of_free_charges,
    &total_potential_of_free_charges,
    1, MPI::DOUBLE, MPI_SUM,  MPI::COMM_WORLD);
    
  return total_potential - total_potential_of_free_charges;
#else
  return total_potential - potential_of_free_charges (p);
#endif     
}

} // dealii_poisson_custom
} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE
#endif
