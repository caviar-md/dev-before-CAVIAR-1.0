#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"
#include "finecuppa/objects/tools.h"

#include <iomanip>
#include <string>

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Integration::Integration (FinECuPPA *fptr) : Pointers{fptr}, 
    atom_data{nullptr} {}
Integration::~Integration (){}

bool Integration::read_base_class_commands (finecuppa::Parser *parser) {
  bool command_called = false;
  parser -> keep_current_token();
  auto token = parser -> get_val_token();
  auto t = token.string_value;
  if (string_cmp(t,"output_total_force") ) {
    command_called = true;
    output_total_force();
  } else if (string_cmp(t,"output_total_energy") ) {
    command_called = true;
    output_total_energy();
  }
  return command_called;
}

bool Integration::run (const double timestep, const int initial_step,
    const int final_step) {
  dt = timestep;

  setup();
  setup_custom();

  for (auto i = initial_step; i < final_step; ++i) {
    step_part_I ();
    
    bool make_list = boundary_condition (); 

    if (make_list) 
      for (auto n: neighborlist) n->build_neighlist ();
    else {
      for (auto n: neighborlist)
        make_list = make_list || n->rebuild_neighlist ();
      if (make_list) 
        for (auto n: neighborlist) n->build_neighlist ();
    }

    step_part_II ();

    output->dump_data (i);
  } 
  
  cleanup(); 
  cleanup_custom();
  return true; //WARNING
}


bool Integration::boundary_condition () {
  bool result = false;

// the result only in MPI case can
// become true, due to exchanging a particle between domains
  result = atom_data -> exchange_owned (); 

  atom_data -> exchange_ghost ();
#ifdef USE_MD_MPI
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Integration::setup () {
  if (atom_data == nullptr) error->all("Integration::setup: atom_data = nullptr");
  if (neighborlist.size()==0) output->warning("Integration::setup: neighborlist.size() = 0");
  if (force_field.size()==0) output->warning("Integration::setup: force_field.size() = 0");
  for (auto n: neighborlist) n->init ();
  atom_data -> exchange_owned (); // isn't neccesary
  atom_data -> exchange_ghost ();
  for (auto n: neighborlist) n->build_neighlist ();
  for (auto f : force_field) 
    f -> calculate_acceleration ();
  output->dump_data (0);

}
void Integration::setup_custom () { }
void Integration::cleanup () { }
void Integration::cleanup_custom () { }

void Integration::output_total_force() {
  if (atom_data == nullptr) {
    std::cout << "Integration::output_total_force : 'atom_data = nullptr' \n";
    return;
  }
  std::cout << std::setprecision(10);
  std::cout << "Integration::output_total_force :\n";
  const auto &pos_size = atom_data->owned.position.size();
  const auto &acc = atom_data->owned.acceleration;
  const auto &type = atom_data->owned.type;
  const auto &mass = atom_data->owned.mass;
  
  for (unsigned i = 0; i < pos_size ; ++i)
    std::cout << i << ": " << acc[i]*mass[ type[i] ] << "\n";
  std::cout << std::setprecision(6);
}

void Integration::output_total_energy() {
  if (force_field.size()==0) {
    std::cout << "Integration::output_total_energy: force_field.size()=0 \n";
    return;
  }
  std::cout << std::setprecision(10);
  double sum_e = 0;
  for (auto f : force_field) {
    const auto e = f -> energy ();
    sum_e += e;
    std::cout << "e: " << e << "\n";
  }
  std::cout << "sum_e: " << sum_e << std::endl;
  std::cout << std::setprecision(6);
}


} //objects

FINECUPPA_NAMESPACE_CLOSE


