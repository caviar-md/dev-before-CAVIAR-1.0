#include "finecuppa/objects/integration/velocity_verlet_langevin.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"


FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

Velocity_verlet_langevin::Velocity_verlet_langevin (FinECuPPA *fptr) : Integration{fptr} {
  rnd_generator_x.seed(1);
  rnd_generator_y.seed(2);
  rnd_generator_z.seed(3);
  kb = 1; temperature = 1; zeta = 1;
}

Velocity_verlet_langevin::~Velocity_verlet_langevin(){}

bool Velocity_verlet_langevin::read (finecuppa::Parser *parser) {
  output->info("Velocity_verlet_langevin read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"add_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist.push_back(object_container->neighborlist[it->second.index]);
    } else if (string_cmp(t,"add_force_field") || string_cmp(t,"force_field")) {
      FIND_OBJECT_BY_NAME(force_field,it)
      force_field.push_back(object_container->force_field[it->second.index]);
    } else if (string_cmp(t,"temperature")) {
      GET_OR_CHOOSE_A_REAL(temperature,"","")
      if (temperature < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "Temperature have to non-negative."); 
    } else if (string_cmp(t,"zeta")) {
      GET_OR_CHOOSE_A_REAL(zeta,"","")
      if (zeta < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "zeta have to non-negative."); 
    } else if (string_cmp(t,"kb")) {
      GET_OR_CHOOSE_A_REAL(kb,"","")
      if (kb < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "kb have to non-negative."); 
    } else if (string_cmp(t,"print_langevin_parameters")) {
      print_langevin_parameters();
    } else if (read_base_class_commands(parser)) {
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }

  return in_file;
}

void Velocity_verlet_langevin::print_langevin_parameters() {
  auto &vel = atom_data -> owned.velocity;
  Vector<double> sum_v {0.0,0.0,0.0};
  for (unsigned int i=0; i<vel.size(); i++) {
  
    std:: cout << i << " : " << vel [i] << " , " << vel[i]/dt << std::endl;
    sum_v += vel[i];
  }

  std::cout << "print_langevin_parameters:\n"
            << "a: " << a << " b: " << b << " c: " << c << "\n"
            << "b/(0.5*dt): " << b/(0.5*dt) << "(acceleration dimension)\n" 
            << "c*a: " << c*a << "(position dimension)\n" 
            << "c*b: " << c*b << "(position dimension)\n" << std::flush;
}

void Velocity_verlet_langevin::setup_custom () {
  a = (2.0 - zeta * dt) / (2.0 + zeta * dt);
  b = std::sqrt(kb * temperature * zeta * 0.5 * dt);  
  c = 2.0 * dt / (2.0 + zeta * dt);
}

void Velocity_verlet_langevin::step_part_I () {

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();
  
  eta_x.resize(psize);
  eta_y.resize(psize);
  eta_z.resize(psize);
  
  for (unsigned int i=0; i<psize; i++) { 
    eta_x[i] = rnd_ndist_x (rnd_generator_x);      
    eta_y[i] = rnd_ndist_y (rnd_generator_y); 
    eta_z[i] = rnd_ndist_z (rnd_generator_z);
    
    const auto eta = Vector<double>{eta_x[i], eta_y[i], eta_z[i]};

    vel [i] += 0.5 * acc [i] * dt + b * eta;
    pos [i] += vel [i] * c;

    acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }
}

void Velocity_verlet_langevin::step_part_II () {

  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  for (auto f : force_field)
    f -> calculate_acceleration ();
    
  for (unsigned int i=0; i<vel.size(); i++) {
    const auto eta = Vector<double>{eta_x[i], eta_y[i], eta_z[i]};
    
    vel [i] = a * vel [i] + b * eta + 0.5 * acc [i] * dt;
  }
}

} //integration
} //objects

FINECUPPA_NAMESPACE_CLOSE


