#include "finecuppa/objects/long_range_solver/ewald.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/neighborlist/cell_list.h"

#include <cmath>
#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {
inline int int_floor(double x) 
{ 
    return (int)(x+100000) - 100000; 
}
Ewald::Ewald (FinECuPPA *fptr) : Long_range_solver{fptr}
{ 
  manual_parameters = false;
  by_cutoff_r = false;
  by_accuracy = false;
  by_alpha = false;
  dipole = false;
  epsilon_dipole = 1.0;
  kx_max = 1;  ky_max = 1;  kz_max = 1;
  erfc_cutoff = 4.5;
  pi_root_inv = 1.0/std::sqrt(M_PI);
  four_pi = 4.0 * M_PI;
  alpha = 1.0;
  slab_geometry = false;
  calculated_once = false;
}

Ewald::~Ewald () {}

bool Ewald::read(finecuppa::Parser * parser) {
  output->info("Ewald: read");
  bool in_file = true;      

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

    if (string_cmp(t,"manual_parameters")) {
      manual_parameters = true;
    } else if (string_cmp(t,"set_epsilon_dipole") || string_cmp(t,"epsilon_dipole")) {
      GET_OR_CHOOSE_A_REAL(epsilon_dipole,"","")
      if (epsilon_dipole < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "epsilon_dipole have to non-negative.");  
      dipole = true;
    } else if (string_cmp(t,"set_alpha") || string_cmp(t,"alpha")) {
      GET_OR_CHOOSE_A_REAL(alpha,"","")
      if (alpha < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "alpha have to non-negative.");  
      by_alpha = true;
    } else if (string_cmp(t,"set_cutoff_k") || string_cmp(t,"cutoff_k")) {
      GET_OR_CHOOSE_A_REAL(cutoff_k,"","")
      if (cutoff_k < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff_k have to non-negative.");
      kx_max = ky_max = kz_max = floor(cutoff_k);
    } else if (string_cmp(t,"set_cutoff_r") || string_cmp(t,"cutoff_r")) {
      GET_OR_CHOOSE_A_REAL(cutoff_r,"","")
      if (cutoff_r < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff_r have to non-negative.");  
      by_cutoff_r = true;
    } else if (string_cmp(t,"set_accuracy") || string_cmp(t,"accuracy")) {
      GET_OR_CHOOSE_A_REAL(accuracy,"","")
      if (accuracy < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "accuracy have to non-negative.");  
      by_accuracy = true;
    } else if (string_cmp(t,"set_cell_list") || string_cmp(t,"cell_list")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist = object_container->neighborlist[it->second.index];
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"set_domain") || string_cmp(t,"domain")) {
      FIND_OBJECT_BY_NAME(domain,it)
      domain = object_container->domain[it->second.index];
    } else if (string_cmp(t,"set_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist = object_container->neighborlist[it->second.index];
    } else if (string_cmp(t,"set_slab_geometry") || string_cmp(t,"slab_geometry")) {
      slab_geometry = true;
      output->info("slab geometry is set and the 'domain' class information will be used for the direction.");
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Ewald: read: Unknown variable or command");
  }  
  return in_file;
}

void Ewald::calculate () {
  if (!calculated_once) {
    calculated_once = true;
    if (atom_data==nullptr) error->all("Ewald::calculate: atom_data = nullptr");
    if (neighborlist==nullptr) error->all("Ewald::calculate: neighborlist = nullptr");
    if (domain==nullptr) error->all("Ewald::calculate: domain_set = nullptr");
    const auto bc = domain->boundary_condition;
    const auto bc_sum = bc.x + bc.y + bc.z;
    if (bc_sum < 2) error->all("Ewald:: domain boundary condition has to be periodic in at least two dimensions.");
    if (bc_sum == 2) 
      if (!slab_geometry)
        error->all("Ewald::calculate: domain is perodic in two dimensions but the 'slab_geometry' variable is 'false'");
    lx = domain->upper_global.x - domain->lower_global.x;
    ly = domain->upper_global.y - domain->lower_global.y;
    lz = domain->upper_global.z - domain->lower_global.z;
    lx_inv = 1.0/lx;  ly_inv = 1.0/ly;  lz_inv = 1.0/lz;
    l_xyz_inv = 1.0 / (lx*ly*lz);

    if (!manual_parameters)
    calculate_alpha();

    make_k_vectors();

    if (slab_geometry)
      make_k_vectors_slab_geometry();
  }

  if (slab_geometry)
    calculate_slab_geometry_coefficients();

  if (dipole)
    dipole_field_vector = dipole_field ();
}

void Ewald::calculate_alpha () {
  output->info("Ewald: calculate_alpha");
  int sum_of_setup = static_cast<int>(by_alpha) + static_cast<int>(by_accuracy)
                    + static_cast<int>(by_cutoff_r) ;
  if (sum_of_setup > 1) error->all("Ewald::calculate: accuracy, cutoff and alpha cannot be set together.");
  if (sum_of_setup == 0) error->all("Ewald::calculate: accuracy or cutoff or alpha has to be set.");
  if (by_alpha) {
    error->all("Ewald::calculate_alpha: not developed yet. a  cutoff formula");
  }
  if (by_cutoff_r) {
    // W. Smith, Information Quarterly for Computer Simulation of Condensed Phases, 21 (1986) 37
    alpha = 3.5 / cutoff_r; 
    error->all("Ewald::calculate_alpha: not developed yet");
  }
  if (by_accuracy) {
    if (domain==nullptr) error->all("Ewald::calculate: domain_set = nullptr");
    if (neighborlist==nullptr) error->all("Ewald::calculate: neighborlist = nullptr");
    cutoff_r = neighborlist -> cutoff;
    const auto no_bins = neighborlist -> no_bins;

    double ln_accuracy = std::log(accuracy);
    double no_bins_mean = (1.0/3.0)*(no_bins.x + no_bins.y + no_bins.z);
    // J. Perram, H. Petersen and S. De Leeuw, Mol. Phys. 65 (1988) 875.
    // there's a modification by no basis, which is the mean of no_bins that used.
    // in the paper there's : alpha = no_bins * std::sqrt(...)
    alpha =  no_bins_mean * std::sqrt (-ln_accuracy); 
    double P_inv = 1.0 / M_PI;
    kx_max = - no_bins.x * P_inv * ln_accuracy;
    ky_max = - no_bins.y * P_inv * ln_accuracy;
    kz_max = - no_bins.z * P_inv * ln_accuracy;
    // 
  }
}

void Ewald::make_k_vectors () {
  const double two_pi = 2.0 * M_PI;

  output->info("Ewald: make_k_vectors");
  k_vector.clear();
  k_vector_sq.clear();
  field_k_coef.clear();
  potential_k_coef.clear();

  n_k_vectors = (2*kx_max)*(2*ky_max)*(2*kz_max);

  k_vector.reserve(n_k_vectors);
  k_vector_sq.reserve(n_k_vectors);
  field_k_coef.reserve(n_k_vectors);
//  potential_k_coef.reserve(n_k_vectors);

  const auto alpha_sq = alpha*alpha;
  const auto four_alpha2_inv = 1.0/(4.0*alpha_sq);

  for (auto kx = -kx_max; kx <=kx_max; ++kx) {
  for (auto ky = -ky_max; ky <=ky_max; ++ky) {
  for (auto kz = -kz_max; kz <=kz_max; ++kz) {

    Vector<double> k_vec {two_pi*kx*lx_inv, two_pi*ky*ly_inv, two_pi*kz*lz_inv};

    const auto k_vec_sq = k_vec * k_vec;
    if (k_vec_sq == 0) continue;

    auto k_vec_sq_inv = 1.0 / k_vec_sq;

    k_vector.push_back(k_vec);
    k_vector_sq.push_back(k_vec_sq);
    field_k_coef.push_back(k_vec_sq_inv * std::exp(-k_vec_sq*four_alpha2_inv));
//    potential_k_coef.push_back(k_vec_sq_inv * std::exp(-k_vec_sq*four_alpha2_inv));
//    std::cout << k_vec << ":\n" << field_k_coef[field_k_coef.size()-1] << "\n";
  }}}
  output->info("Ewald: make_k_vectors:finished");
}

void Ewald::make_k_vectors_slab_geometry () { 
  output->info("Ewald: make_k_vectors_slab_geometry");
  const auto x_coef = 2.0*M_PI*lx_inv;
  const auto y_coef = 2.0*M_PI*ly_inv;
  for (auto kx = 0; kx <=kx_max; ++kx) {
    slab_kx.push_back(x_coef*kx);
  }
  for (auto ky = 0; ky <=ky_max; ++ky) {
    slab_ky.push_back(y_coef*ky);
  }

  for (auto kx = 0; kx <=kx_max; ++kx) {
    for (auto ky = 0; ky <=ky_max; ++ky) {
      slab_kp_norm.push_back(y_coef*ky);
    }
  }
}

void Ewald::calculate_slab_geometry_coefficients () { 

}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

