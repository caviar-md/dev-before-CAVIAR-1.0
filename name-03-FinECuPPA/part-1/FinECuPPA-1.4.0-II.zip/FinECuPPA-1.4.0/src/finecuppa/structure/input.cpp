#include "finecuppa/structure/input.h"
#include "finecuppa/structure/object_creator.h"
#include "finecuppa/structure/input/commands_map.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/tools.h"

#include <map>
#include <cmath>
#include <algorithm>

FINECUPPA_NAMESPACE_OPEN

Input::Input (FinECuPPA *fptr) : Pointers {fptr}, parser {new Parser{fptr}},
    fptr{fptr}
 {}

Input::Input (FinECuPPA *fptr, const std::string &file) : Pointers {fptr},
    parser {new Parser{fptr, file}}, fptr{fptr} {}

Input::Input (FinECuPPA *fptr, std::istringstream &iss) : Pointers {fptr},
    parser {new Parser{fptr, iss}}, fptr{fptr} {}

Input::~Input () {
  delete parser;
}

void Input::read (Parser * parser) {
  while (read_command (parser));
}

void Input::read () {
  while (read_command (parser));
}

bool Input::read_command (Parser * parser) {
  auto command = parser->get_command_identifier();
  auto command_lowercase = command;
#ifdef FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE
  //transform 'command' to lower case
  std::transform(command_lowercase.begin(), command_lowercase.end(),
                 command_lowercase.begin(), ::tolower);  
#endif  
  if (commands_map.count (command_lowercase) != 0) 
    return (this->*commands_map.at(command_lowercase)) (parser);
  else if (object_creator->commands_map.count (command_lowercase) != 0) {
    return (object_creator->*object_creator->commands_map.at(command_lowercase)) (parser);
  } else if (object_handler->commands_map.count (command_lowercase) != 0) {
    return (object_handler->*object_handler->commands_map.at(command_lowercase)) (parser);
  } else if (object_container->all_names.count(command) != 0){ // object name is case sensitive
    return object_handler->read_object (parser, command);
  } else {
    error->all (FC_FILE_LINE_FUNC_PARSE, "Invalid command or object NAME");
  }
  return true;  
}

bool Input::read_script_from_file (Parser *parser) {
  auto file_name = parser->get_string();
  std::string st = "read_script_from_file : " +  file_name;
  output->info(st);
  finecuppa::Input inp (fptr, file_name);
  inp.read();
  return true;
}

bool Input::help (Parser *parser) {
  parser->end_of_line();
  std::cout << "Science Helps People!\n";
  return true;
}

bool Input::exit_program (Parser *) {
  return false;
}

bool Input::call_output (Parser *parser) {
  return output->read (parser);
}

bool Input::call_object_container (Parser *) {
  return object_container->read (parser);
}

bool Input::echo (Parser * parser) {
  std::string st = "";
  while (true) {
    auto t = parser -> get_val_token();
    //auto t = parser -> get_raw_token();
    if (t.kind == Kind::eof) break;
    else if (t.kind == Kind::eol) break;
    else if (t.kind == Kind::string) {
      // having 'get_string()' here may complicate 'kind::plus' conditions
      st += t.string_value;
    } else if (t.kind == Kind::identifier) {
      auto var_name = t.string_value;
      std::map<std::string,object_handler::Dictionary>::iterator it;
      it = object_container->dictionary.find(var_name);
      if (it == object_container->dictionary.end())   {
        error->all (FC_FILE_LINE_FUNC_PARSE, "unknown object name :" + var_name);      
      } else if (it->second.type == object_handler::gdst( "boolean_variable" )) {
        parser-> keep_current_token();
        bool r = parser-> get_bool();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "int_variable" )) {
        parser-> keep_current_token();
        double r = parser-> get_real();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "real_variable" )) {
        parser-> keep_current_token();
        double r = parser-> get_real();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "real_3d_vector" )) {
        auto v = object_container -> real_3d_vector [it->second.index];        
        st += "{" + std::to_string(v.x) + ", " + std::to_string(v.y) + ", "
            +  std::to_string(v.z) + "}";
      } else if (it->second.type == object_handler::gdst( "int_3d_vector" )) {
        auto v = object_container -> int_3d_vector [it->second.index];        
        st += "{" + std::to_string(v.x) + ", " + std::to_string(v.y) + ", "
            +  std::to_string(v.z) + "}";
      } else if (it->second.type == object_handler::gdst( "string_variable" )) {
        //st += object_container->string_variable[it->second.index];
        parser-> keep_current_token();
        std::string r = parser-> get_string();
        st += r;
      } else {
        error->all (FC_FILE_LINE_FUNC_PARSE, "this echo type is not implemented yet");      
      }
    } else if (t.kind == Kind::real_number || t.kind == Kind::int_number) {
      // the distinction between 'int_number' and 'real_number' is not nessecary
      // and it just complicates the code.
      parser-> keep_current_token();
      double r = parser-> get_real();
      st += std::to_string(r);
    } else if (t.kind == Kind::plus || t.kind == Kind::minus) {
      // the same as above
      parser-> keep_current_token();
      double r = parser-> get_real();
      st += std::to_string(r);
    } else {
      error->all (FC_FILE_LINE_FUNC_PARSE, "this echo type is not implemented yet");      
    }
  }

  std::cout << st << std::endl;
  return true;
}

bool Input::print (Parser *parser) {
  std::string st = parser -> get_string();
  std::cout << st << std::endl;

//  std::string dollars = "$";
//  std::size_t found = st.find(dollars);

  return true;
}

bool Input::evaluate(const std::string &str) {
  std::string st = str + "\n";
  std::istringstream iss (st);
  //std::cout << "iss: " << iss.str() << std::endl;
  finecuppa::Input inp (fptr, iss);
  inp.read();
  return true;
}

bool Input::evaluate (Parser *parser) {
  evaluate ( parser -> get_string() );
  return true;
}

// TODO: complete
bool Input::compare_int (Parser *parser) {
  return compare_real(parser);
}

bool Input::compare_real (const std::string &st) {
  std::istringstream iss (st);
  Parser p(fptr, iss);
  //std::cout << "X: " << st << " , result: " << p.compare_real() << std::endl;
  return p.compare_real();
}

bool Input::compare_real (Parser *parser) {
  std::string st = parser->rest_of_line();
  std::istringstream iss (st);
  Parser p(fptr, iss);
  bool result =  p.compare_real();
  //std::cout << "X: " << st << " , result: " << result << std::endl;
  parser->go_to_next_line();
  return result;
}

// TODO: complete
bool Input::compare (Parser *parser) {
  return compare_real(parser);
}

bool Input::calculate(const std::string &str) {
  std::string st = str + "\n";
  std::istringstream iss (st);
  //std::cout << "iss: " << iss.str() << std::endl;
  finecuppa::Input inp (fptr, iss);
  inp.read();
  return true;
}

bool Input::calculate (Parser *parser) {
  int num_of_condition_operators = 0;
  int condition_operator = 10;
  double left_side = 0;
  double right_side = 0;
  bool operator_called = false;
  while (true) {
    auto t = parser -> get_raw_token();
    if (t.kind == Kind::eof) break;
    else if (t.kind == Kind::eol) break;
    else if (t.kind == Kind::smaller) { //-2
      ++num_of_condition_operators; operator_called = true;
      condition_operator = -2;
    } else if (t.kind == Kind::larger) { //+2
      ++num_of_condition_operators; operator_called = true;
      condition_operator = +2;
    } else if (t.kind == Kind::eqsmaller) { //-1
      ++num_of_condition_operators; operator_called = true;
      condition_operator = -1;
    } else if (t.kind == Kind::eqlarger) { //+1
      ++num_of_condition_operators; operator_called = true;
      condition_operator = +1;
    } else if (t.kind == Kind::equal) { // 0
      ++num_of_condition_operators; operator_called = true;
      condition_operator = 0;
    } else {
      parser -> keep_current_token();
      if (operator_called) {right_side = parser->get_real(); break;}
      else left_side = parser->get_real();
    } 
  }

  if (num_of_condition_operators == 0)
    error->all (FC_FILE_LINE_FUNC_PARSE, "expected a conditional operator" ); 

  if (num_of_condition_operators > 1)
    error->all (FC_FILE_LINE_FUNC_PARSE, "only one conditional operator is allowed" ); 

  //std::cout <<"left: " << left_side << " , right: " << right_side << std::endl;

  if (condition_operator == -2) return (left_side <  right_side);
  if (condition_operator == -1) return (left_side <= right_side);
  if (condition_operator ==  0) return (left_side == right_side);
  if (condition_operator ==  1) return (left_side >= right_side);
  if (condition_operator ==  2) return (left_side >  right_side);

  return true;
}

bool Input::do_command (Parser *parser) {

  // The loops have no name at the default. It's no problem. The problem arises
  // When there's nesting loops with no name. It also can be solved by inspecting
  // the loop line.
  bool loop_condition_at_begining = false;
  bool loop_condition_at_ending   = false;
  std::string loop_name = "";
  std::string loop_condition = "";
  std::vector<std::string> loop_str;

  Token t;

  // here we save 'loop_name' and its 'while' condition if those are defined.
  while (true) {
    t = parser -> get_raw_token();
    if (t.kind == Kind::eof) 
      error->all(FC_FILE_LINE_FUNC_PARSE, "expected 'end_do' but reached 'eof'.");
    else if (t.kind == Kind::eol) break;
    else if (t.kind == Kind::identifier) {
      if (string_cmp (t.string_value, "while")) {
        loop_condition_at_begining = true;
        loop_condition = parser->rest_of_line();
        parser->go_to_next_line();
      } else {
        loop_name = t.string_value;
        t = parser -> get_raw_token();
        if (t.kind == Kind::identifier) { // in case it was 'do i while'
          parser-> keep_current_token(); continue;
        } else if (t.kind==Kind::assign) { // in case it was 'do i=something ...'
          std::map<std::string,object_handler::Dictionary>::iterator it;
          it = object_container->dictionary.find(loop_name);
          if (it == object_container->dictionary.end())   {
            error->all (FC_FILE_LINE_FUNC_PARSE, "unknown object name :" + loop_name);      
          } else if (it->second.type == object_handler::gdst( "int_variable" )) {
            double r = parser-> get_real();
            object_container -> int_variable [it->second.index] = r;
          } else if (it->second.type == object_handler::gdst( "real_variable" )) {
            double r = parser-> get_real();
            object_container -> real_variable [it->second.index] = r;
          } else {
            error->all(FC_FILE_LINE_FUNC_PARSE, "expected 'int' or 'real' variables.");
          }
        }
      }
    } else  error->all(FC_FILE_LINE_FUNC_PARSE, "unexpected token.");
  }


  // here we save all the lines into 'loop_str' until we reach 'end_do' with the same
  // name as 'loop_name'.
  while (true) {
    t = parser -> get_raw_token();
    if (t.kind == Kind::eof) {
      error->all(FC_FILE_LINE_FUNC_PARSE, "expected 'end_do' but reached 'eof'.");
    } else if (t.kind == Kind::eol) {
      // We save each line only after we reach 'eol'
      loop_str.push_back( parser->line );
      continue;
    } else if (t.kind == Kind::identifier) {
      auto ts = t.string_value;
      if (string_cmp (ts, "end_do")) {
        std::string end_do_name = "";
        bool eof_reached = false;
        bool loop_condition_at_ending_reserve = false;
        while (true) {
          t = parser -> get_val_token();
          if (t.kind == Kind::eof) {
            eof_reached = true;
            break;
          } else if (t.kind == Kind::eol) {
            break;
          } else if (t.kind == Kind::identifier) {
            if (string_cmp (t.string_value, "while")) {
              loop_condition_at_ending_reserve = true;
              //get condition
            } else {
              end_do_name = t.string_value;
            }
          }
        }

        if (end_do_name == loop_name) {
          loop_condition_at_ending = loop_condition_at_ending_reserve;
          break;
        } else {
          if (eof_reached)
            error->all(FC_FILE_LINE_FUNC_PARSE, "expected 'end_do' but reached 'eof'.");
          loop_str.push_back( parser->line );
        }
      }
    } 
  }
  if (loop_condition=="") {
    std::cout << "loop condition : nothing" << std::endl  ;
  } else {
    std::cout << "loop condition : " << loop_condition  ;
  }
  for (auto i : loop_str)
  std::cout << i ;

  if (loop_condition_at_begining && loop_condition_at_ending) 
    error->all(FC_FILE_LINE_FUNC_PARSE, "having 'while' condition twice in a "
                                        "loop is not permitted");
/*
  bool start_loop = true;
  if (loop_condition_at_begining)
    start_loop = evaluate_loop_condition;
  int i = 0;
  while(start_loop) {
    int b = evaluate (loop_str[i]);
    if (b==1) break;
    if (loop_condition_at_ending)
      start_loop = evaluate_loop_condition;
  }
*/
  return true;
}

bool Input::end_do_command (Parser *parser) {
  error->all(FC_FILE_LINE_FUNC_PARSE, "having 'end_do' without 'do' is not permitted ");
  return true;
}

bool Input::while_command (Parser *) {
  error->all(FC_FILE_LINE_FUNC_PARSE, "having 'while' without 'do' is not permitted ");
  return true;
}

bool Input::if_command (Parser *parser) {
  bool condition = compare_real(parser);
  if (condition) {
    while (true) {
      auto t = parser->get_val_token();
      auto ts = t.string_value;
      if (t.kind==Kind::eof) {
        error->all (FC_FILE_LINE_FUNC_PARSE,"expected 'endif'");
      } else if (t.kind==Kind::identifier) {
        if (string_cmp(ts,"end_if") || string_cmp(ts,"endif")) {
          return true;
        } else if (string_cmp(ts,"else")) {
          ignore_to_endif(parser); return true;
        } else if  (string_cmp(ts,"else_if") || string_cmp(ts,"elseif")) {
          ignore_to_endif(parser); return true;
        }
      } else {
        evaluate(parser->line);
        std::cout << "line evaluated: " << parser->line << std::endl;
        parser->go_to_next_line();
        std::cout << "hey " << std::endl;
      }
    }
  } else {
    // find next 'else', 'else_if' or 'endif'
    while (true) {
      auto t = parser->get_raw_token();
      auto ts = t.string_value;
      if (t.kind==Kind::eof) {
        error->all (FC_FILE_LINE_FUNC_PARSE,"expected 'endif'");
      } else if (t.kind==Kind::identifier) {
        if (string_cmp(ts,"else")) {
          else_command(parser); return true;
        } else if (string_cmp(ts,"else_if") || string_cmp(ts,"elseif")) {
          // one can use 'if_command' instead of 'else_if_command'. The logic
          // is the same
          //else_if_command(parser); return true; 
          if_command(parser); return true;
        } else if (string_cmp(ts,"end_if") || string_cmp(ts,"endif")) {
          return true;
        } else {
          parser->go_to_next_line(); continue;
        }
      } 
    }
  }
  return true;
}

bool Input::ignore_to_endif (Parser *parser) {
  while(true) {
    auto t = parser->get_raw_token();
    auto ts = t.string_value;
    if (t.kind==Kind::eof) {
      error->all (FC_FILE_LINE_FUNC_PARSE,"expected 'endif'");
    } else if (t.kind==Kind::identifier) {
      if (string_cmp(ts,"endif")||string_cmp(ts,"end_if")) {
        return true;
      }
    }
  }
  return true;
}

bool Input::else_if_command (Parser *) {
  return true;
}

bool Input::else_command (Parser *) {
  while (true) {
    auto t = parser->get_raw_token();
    auto ts = t.string_value;
    if (t.kind==Kind::identifier) {
      if (string_cmp(ts,"endif") || string_cmp(ts,"end_if") ) {
        return true;
      }
    } else {
      evaluate(parser->line);
      parser->go_to_next_line();
    }
  }   
}

bool Input::end_if_command (Parser *) {
  return true;
}

bool Input::break_command (Parser *) {
  return true;
}

bool Input::continue_command (Parser *) {
  return true;
}


FINECUPPA_NAMESPACE_CLOSE

