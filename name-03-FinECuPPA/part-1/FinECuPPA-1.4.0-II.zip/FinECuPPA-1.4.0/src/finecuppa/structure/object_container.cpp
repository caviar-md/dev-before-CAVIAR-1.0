#include "finecuppa/structure/object_container.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN

Object_container::Object_container (FinECuPPA *fptr) : Pointers{fptr} { }

Object_container::~Object_container () { }

bool Object_container::read (Parser * parser) {
  output->info("object_container read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"report")) {
      report();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }

  return in_file;
}

void Object_container::report () {
  output->info("object_container report:");
  std::unordered_set<std::string>::iterator it;
  for (it = all_names.begin(); it != all_names.end(); ++it)
    std::cout << *it << std::endl;
}
FINECUPPA_NAMESPACE_CLOSE

