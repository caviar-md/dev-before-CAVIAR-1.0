#include "finecuppa/structure/object_handler/all.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/utility/all.h"

#include <fstream>

FINECUPPA_NAMESPACE_OPEN


bool Object_handler::add_atom_to_molecule (Parser *parser) {
  output->info("add_atom");
  std::string name_1, name_2;
  GET_A_STRING(name_1,"ADD_atom: "," expected an atom or molecule NAME: ")

  std::map<std::string,object_handler::Dictionary>::iterator it_1, it_2;
  CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_atom: ","")

  std::string middle_command_1;
  GET_A_STRING(middle_command_1,"ADD_atom: "," Expected middle command: ")

  if (string_cmp(middle_command_1,"to_molecule")) {
    GET_A_STRING(name_2,"ADD_atom: "," expected an atom or molecule NAME: ")
     CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_atom: ","")
  }

  if (it_1->second.type != object_handler::gdst("atom"))
    error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: ADD atom: expected an atom NAME: ");

  if (it_2->second.type != object_handler::gdst("molecule"))
    error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: ADD atom: expected an molecule NAME: ");
      
  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  bool in_file = true;
  while (true) {
    GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;    
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"","")\
    } else if (string_cmp(t,"at_velocity")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"","")\
    }
  }

  objects::utility::Atom a_new = *object_container -> atom[it_1->second.index];
  if (position_called) {
    a_new.pos() = pos_;
  }
  if (velocity_called) {
    a_new.vel() = vel_;
  }
  object_container -> molecule[it_2->second.index] -> add_atom (a_new);
  return in_file;
}

// ========================
// ========================
// ========================

bool Object_handler::add_molecule_to_molecule (Parser *parser) {
  output->info("add_molecule");
  std::string name_1, name_2;
  GET_A_STRING(name_1,"ADD_molecule: "," expected an atom or molecule NAME: ")

  std::map<std::string,object_handler::Dictionary>::iterator it_1, it_2;
   CHECK_NAME_EXISTANCE(name_1,it_1,"ADD_atom: ","")

  std::string middle_command_1;
  GET_A_STRING(middle_command_1,"ADD_molecule: "," Expected middle command: ")

  if (string_cmp(middle_command_1,"to_molecule")) {
    GET_A_STRING(name_2,"ADD_atom: "," expected an atom or molecule NAME: ")
     CHECK_NAME_EXISTANCE(name_2,it_2,"ADD_atom: ","")
  }

  if (it_1->second.type != object_handler::gdst("molecule"))
    error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: ADD molecule: expected an molecule NAME: ");

  if (it_2->second.type != object_handler::gdst("molecule"))
    error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: ADD MOLECUE: expected an molecule NAME: ");


  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  bool in_file = true;
  while (true) {
    GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"ADD molecule: ","")\
    } else if (string_cmp(t,"at_velocity")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"ADD molecule: ","")\
    }
  }

  objects::utility::Molecule a_new = *object_container -> molecule[it_1->second.index];  
  if (position_called) {
    a_new.pos() = pos_;
  }
  if (velocity_called) {
    a_new.vel() = vel_;
  }
  object_container -> molecule[it_2->second.index] -> add_molecule(a_new);
  return in_file;
}


// ========================
// ========================
// ========================


bool Object_handler::output_xyz (Parser *parser) {
  output->info("output_xyz: ");
 
  std::ofstream out_file;
  std::string out_file_name = "o_";

  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;     
     if (string_cmp(t,"molecule")) {
      std::map<std::string,object_handler::Dictionary>::iterator it_1;
      std::string name_1;
      GET_A_STRING(name_1,"OUTPUT_XYZ: "," expected an molecule or atom NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
      if (it_1->second.type == object_handler::gdst("atom")) {
        out_file_name += "atom_" + name_1 + ".xyz";
        out_file.open (out_file_name.c_str());
        object_container -> atom[it_1->second.index] -> output_xyz (out_file);
      }  else if (it_1->second.type == object_handler::gdst("molecule")) {
        out_file_name += "molecule_" + name_1 + ".xyz";
        out_file.open (out_file_name.c_str());
        int n = 0;
        object_container -> molecule[it_1->second.index] -> number_of_atoms (n);
        out_file << n << "\n" << "Atom\n";
        object_container -> molecule[it_1->second.index] -> output_xyz (out_file);
      }  else error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: OUTPUT_XYZ: expected an molecule or atom NAME. ");
    } else  error->all(FC_FILE_LINE_FUNC_PARSE,"OUTPUT_XYZ: Unknown variable or command ");
  
  }
  
  out_file.close ();
  
  return in_file;

}


FINECUPPA_NAMESPACE_CLOSE

