#include "finecuppa/structure/output.h"
#include "finecuppa/structure/communicator.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"

#include <sys/stat.h> // used for mkdir() for povray

FINECUPPA_NAMESPACE_OPEN

Output::Output (FinECuPPA *fptr) : Pointers{fptr}, comm{fptr->comm},
atom_data{nullptr},
 energy_step{100}, xyz_step{1000}, povray_step{10000},
 output_energy{false}, output_xyz{false}, output_povray{false}
 {
  tStart1 = clock();
  for (int i=0; i<5; ++i) {
    output_info[i]=true;
    output_warning[i]=true;
  }
}

bool Output::read (Parser * parser) {
  info("output read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"xyz")) {
      GET_OR_CHOOSE_A_INT(xyz_step,"","")
      output_xyz = true;
    } else if (string_cmp(t,"energy")) {
      GET_OR_CHOOSE_A_INT(energy_step,"","")
      output_energy = true;
    } else if (string_cmp(t,"povray")) {
      GET_OR_CHOOSE_A_INT(povray_step,"","")
      output_povray = true;
    } else if (string_cmp(t,"info")) {
      int level = -1;
      GET_OR_CHOOSE_A_INT(level,"","")
      bool status = 0;
      GET_A_BOOL(status,"","")
      if (level > 5 || level < 0)
        error->all (FC_FILE_LINE_FUNC_PARSE, "'info' level is defined between 0 to 4. To choose all, use 5.");
      if (level == 5) for (int i=0; i<5; ++i) output_info[i] = status;
      else output_info[level] = status;
    } else if (string_cmp(t,"warning")) {
      int level = -1;
      GET_OR_CHOOSE_A_INT(level,"","")
      bool status = 0;
      GET_A_BOOL(status,"","")
      if (level > 5 || level < 0)
        error->all (FC_FILE_LINE_FUNC_PARSE, "'warning' level is defined between 0 to 4. To choose all, use 5.");
      if (level == 5) for (int i=0; i<5; ++i) output_warning[i] = status;
      else output_warning[level] = status;
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Invalid syntax: This output command doesn't exist.");
  }
  return in_file;

/*
  auto command = parser->get_identifier();
  if (command=="energy") {
    auto steps = parser->get_literal_int(); 
    energy_step = steps;
    output_energy = true;
  } else if (command=="xyz") {
    auto steps = parser->get_literal_int(); 
    xyz_step = steps;
    output_xyz = true;
  } else if (command=="povray") {
    auto steps = parser->get_literal_int();
    povray_step = steps;
    output_povray = true;
  } else {
      error->all (FC_FILE_LINE_FUNC_PARSE, "Invalid syntax: This output command doesn't exist.");
  }

  if (! parser->end_of_line ()) error->all (FC_FILE_LINE_FUNC_PARSE, "Invalid syntax"); */
}

void Output::dump_data (int i) {
  if (atom_data==nullptr)
    error->all("Output::dump_data: atom_data = nullptr");
  if (output_energy && i%energy_step == 0)
    dump_energy (i);
  if (output_xyz && i%xyz_step == 0) {
    dump_xyz (i); 
    clock_t tStart2 = clock();
    double dtstart= (double)(tStart2 - tStart1)/CLOCKS_PER_SEC;
    std::string s = "dump xyz at step " + std::to_string(i) +
                  + " . Elapsed time: " + std::to_string(dtstart);
    info (s, 2);
    tStart1 = tStart2;
  }
  if (output_povray && i%povray_step == 0)
    dump_povray (i);
}

void Output::dump_energy (int i) {
  std::string s = "incomplete function:";
  s += __FILE__ + std::to_string(__LINE__) + __func__;  
  warning(s);
  double p_e = 0;//force_field->potential_energy; 
  double k_e = 0;//force_field->kinetic_energy;
  //force_field->calculate_kinetic_energy();
#ifdef USE_MD_MPI
  const int me = comm->me;
  double p_e_all=0.0,k_e_all=0.0;
  MPI_Barrier (mpi_comm);  
//  MPI_reduce (&p_e, &p_e_all, 1, MPI_DOUBLE, MPI_SUM, 0, mpi_comm);
//  MPI_reduce (&k_e, &k_e_all, 1, MPI_DOUBLE, MPI_SUM, 0, mpi_comm); 
  MPI_Allreduce (&p_e, &p_e_all, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
  MPI_Allreduce (&k_e, &k_e_all, 1, MPI_DOUBLE, MPI_SUM, mpi_comm); 

  if (me ==0){
    ofs_energy << i << " " << k_e << " " << p_e << " " << k_e + p_e << "\n";
  }
#else
  ofs_energy << i << " " << k_e << " " << p_e << " " << k_e + p_e << "\n";
#endif  
}



void Output::close_files () {
#ifdef USE_MD_MPI
  if (comm->me == 0) {
    close_them ();
  }
#else
  close_them ();
#endif
}


void Output::open_files () {
#ifdef USE_MD_MPI
  if (comm->me ==0){
    open_them ();
  }
#else
  open_them ();
#endif
}


void Output::close_them () {
  ofs_energy.close ();
  ofs_xyz.close  ();
  ofs_velocities.close ();
}


void Output::open_them () {

  std::string str_energy = "o_e",
              str_xyz  = "o_xyz",
              str_velocities = "o_v";


  std::string str_filename = "";
  //char buffer[50] = "";

// --- just to make povray outpuy folder ---
  if (output_povray) {
    std::string str_folder_pov;
    str_folder_pov.append("o_pov"); 
    const char* char_folder_pov = str_folder_pov.c_str();
    mkdir (char_folder_pov,0777);  // make povray  output folder //
  }
// =========================================


/*
#ifdef USE_MD_MPI
  sprintf ( buffer, "_me%u", comm->me );
  str_filename.append ( buffer);
#endif
*/

/*
   sprintf ( buffer, "_n%u", G_no_grains );
  str_filename.append ( buffer);
*/
  str_xyz.append ( str_filename);
  str_xyz.append ( ".xyz");

  str_filename.append ( ".txt" );

  str_energy.append (str_filename);
//  str_velocities.append (str_filename);



  const char * char_energy = str_energy.c_str ();
  const char * char_xyz = str_xyz.c_str ();
//  const char * char_velocities  = str_velocities.c_str ();


  if (output_energy)
    ofs_energy.open  (char_energy);
  if (output_xyz)
    ofs_xyz.open (char_xyz);

}




FINECUPPA_NAMESPACE_CLOSE

