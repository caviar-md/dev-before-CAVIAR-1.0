#ifndef UDN_2411_H
#define UDN_2411_H

//#include <vector>

namespace NS_mesh_handler {

struct Universal_dataset_number_2411 {
/*
Record 1:        FORMAT(4I10)
                 Field 1       -- node label
                 Field 2       -- export coordinate system number
                 Field 3       -- displacement coordinate system number
                 Field 4       -- color
Record 2:        FORMAT(1P3D25.16)
                 Fields 1-3    -- node coordinates in the part coordinate
                                  system
 
Records 1 and 2 are repeated for each node in the model.
 

*/

  unsigned record1[4];
  //std::vector <unsigned int> record1;
  double record2[3];

};

}

#endif


