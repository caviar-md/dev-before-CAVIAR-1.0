#ifndef FINITE_ELEMENT_H
#define FINITE_ELEMENT_H

#include "finecuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "parser.h"
#include "output.h"
#include "error.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_finite_element {

template <int dim>
class Finite_element : protected Pointers {
	public:
		Finite_element (class MD *);
		virtual ~Finite_element();
    virtual void calculate_acceleration ();
		virtual bool read(Parser *);//=0;	

		Output * output;
		Error * error;
};

} //NS_finite_element

FINECUPPA_NAMESPACE_CLOSE

#endif
 
