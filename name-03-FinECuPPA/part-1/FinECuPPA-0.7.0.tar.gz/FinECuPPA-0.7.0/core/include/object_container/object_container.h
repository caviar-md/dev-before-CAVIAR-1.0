#ifndef OBJECT_CONTAINER_H
#define OBJECT_CONTAINER_H

#include "finecuppa_config.h"

#include <random>
#include <istream>
#include <vector>
#include <string>
#include <map>
#include <unordered_set>

#include "pointers.h"
#include "parser.h"
#include "output.h"
#include "error.h"

#include "vector.h"
#include "vector2D.h"
#include "shape.h"
#include "object_handler_dictionary.h"
#include "object_utility_all.h"
#include "force_field.h"
#include "finite_element.h"

FINECUPPA_NAMESPACE_OPEN

class Object_container : protected Pointers  {
public:
  Object_container (class MD *);
  ~Object_container ();

	std::map<std::string,NS_object_handler::Dictionary> dictionary;

	std::unordered_set<std::string> all_names;

	std::vector<NS_object_utility::Element> element; // 1
	std::vector<NS_object_utility::Atom> atom; // 2
	std::vector<NS_object_utility::Molecule> molecule; // 3
	std::vector<NS_shape::Boundary> boundary; // 4
	std::vector<NS_object_utility::Random_1D> random_1d; // 5
	std::vector<NS_shape::Shape *> shape; // 6	
	std::vector<NS_object_utility::Grid_1D> grid_1d; // 7	
	std::vector<NS_object_utility::Distribution> distribution; // 8
	std::vector<Force_field *> force_field; // 9
	std::vector<NS_finite_element::Finite_element<3> *> finite_element; // 10
//	std::vector<NS_integration::integration *> integration;
	
	std::vector<int> int_variable; // -1
	std::vector<double> real_variable; // -2
	std::vector<Vector2D<int>> int_2d_vector; // -3
	std::vector<Vector2D<double>> real_2d_vector; // -4
	std::vector<Vector<int>> int_3d_vector; // -5
	std::vector<Vector<double>> real_3d_vector; // -6

	class Parser * parser;
  class Output * output;
  class Error * error;
private:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
