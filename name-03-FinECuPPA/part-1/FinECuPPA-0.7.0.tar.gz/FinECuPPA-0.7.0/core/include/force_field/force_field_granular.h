#ifndef FORCE_FIELD_GRANULAR_H
#define FORCE_FIELD_GRANULAR_H

#include "finecuppa_config.h"

#include "force_field.h"

#include <vector>
#include "vector.h"

FINECUPPA_NAMESPACE_OPEN

class Force_field_granular : public Force_field {
public:
  Force_field_granular (class MD *);
  ~Force_field_granular () {};
  
  bool read (class Parser *);
  void calculate_acceleration ();
private:
  std::vector<Real_t> elastic_coef,dissip_coef, radius;
	Vector<Real_t> gravity;
	
  class Parser *parser;
	class Output *output;
	class Error *error;	
};

FINECUPPA_NAMESPACE_CLOSE

#endif
