#include "shape_sphere.h"

#include "finecuppa_config.h"

#include "object_handler_all.h"
#include "object_container.h"

#include "parser.h"
#include "lexer.h"

FINECUPPA_NAMESPACE_OPEN

namespace NS_shape {
	
		Sphere::Sphere (MD *md) : Shape {md},
				object_container{md->object_container}, output{md->output}, error{md->error} {}
		Sphere::~Sphere() {}
		
		bool Sphere::read(Parser * parser) {
			output->info("Data_reader_Kakaka: SPHERE read");
			bool in_file = true;
			

			while(true) {
				GET_A_TOKEN_FOR_CREATION
				ASSIGN_REAL_3D_VECTOR(center,"SPHERE read: ","")
				else ASSIGN_REAL(radius,"SPHERE read:","")
				else error->all (FILE_LINE_FUNC, "Data_reader_Kakaka: SPHERE read: Unknown variable or command");
			}

			return in_file;;

		}


		bool Sphere::is_inside(const Vector<double> &v) {
			Vector<double> v_1 = v - center;
			if (v_1*v_1 > radius*radius)
				return false;
			return true;
		}

		bool Sphere::is_inside(const Vector<double> &v, const double r) {
			Vector<double> v_1 = v - center;
			if (v_1*v_1 > (radius-r)*(radius-r))
				return false;
			return true;
		}
		
		bool Sphere::is_outside(const Vector<double> &v, const double r) {
		  return !is_inside(v,r);
		}
		bool Sphere::is_outside(const Vector<double> &v) {
		  return !is_inside(v);
		}		

		bool Sphere::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
			Vector<double> v_dif = v - center;
			const auto v_dif_sq = v_dif*v_dif;

			if (v_dif_sq < (radius-r)*(radius-r)) return false;
			if (v_dif_sq > (radius+r)*(radius+r))	return false;

			const auto v_dif_sq_norm = std::sqrt(v_dif_sq);
			const auto v_dif_norm = v_dif / v_dif_sq_norm;			
			Vector<double> tmp = - v_dif_norm * (v_dif_sq_norm-radius);
      contact_vector += tmp;
			return true;
		}
	
}

FINECUPPA_NAMESPACE_CLOSE


