
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_FINECUPPA_H
#define FINECUPPA_FINECUPPA_H

#include "finecuppa/utility/finecuppa_config.h"
#include "finecuppa/utility/types.h"

#include <iostream>
#include <fstream>
#include <map>

#if defined(FINECUPPA_WITH_MPI)
#include <mpi.h>
#endif

#include "finecuppa/utility/common_template_functions.h"

FINECUPPA_NAMESPACE_OPEN
namespace interpreter {
class Communicator;
class Error; 
class Output; 
class Input;
class Object_handler;
class Object_container;
class Object_creator;
}
class FinECuPPA {
public:
#if defined(FINECUPPA_WITH_MPI)
  FinECuPPA (int, char**, MPI_Comm);
#else
  FinECuPPA (int, char**);
#endif
  ~FinECuPPA ();
  void execute ();
  
#if defined(FINECUPPA_WITH_MPI)
  MPI_Comm mpi_comm;
#endif
  class interpreter::Communicator *comm;
  class interpreter::Error *error;
  class interpreter::Output *output;
  class interpreter::Input *input;
  class interpreter::Object_handler *object_handler;
  class interpreter::Object_container *object_container;
  class interpreter::Object_creator *object_creator;
  
  std::ofstream log;
  std::istream in;
  std::ostream out, err;
  bool log_flag, out_flag, err_flag;
  int argc;
  char **argv;

  // these are some helper variables for the interpreter. Not for users.
  // They can be public.
  int interpreter_num_Input_class;
  bool interpreter_break_called;
  bool interpreter_continue_called;
};

FINECUPPA_NAMESPACE_CLOSE

#endif
