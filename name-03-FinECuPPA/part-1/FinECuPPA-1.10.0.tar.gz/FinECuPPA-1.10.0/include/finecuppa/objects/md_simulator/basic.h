
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_MDSIMULATOR_BASIC_H
#define FINECUPPA_OBJECTS_MDSIMULATOR_BASIC_H

#include "finecuppa/objects/md_simulator.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace md_simulator {

class Basic : public Md_simulator {
 public:
  Basic (class FinECuPPA *);
   ~Basic ( );
  bool read (class finecuppa::interpreter::Parser *);
  bool run ();
  void verify_settings ();

/*

  void setup ();
  void cleanup ();

  void setup_custom (); // called after the default 'setup()'
  void cleanup_custom (); // called after the default 'cleanup()'
  bool boundary_condition ();
*/


};

} //md_simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
