
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_CONSTRAINT_NOSEHOOVER_H
#define FINECUPPA_OBJECTS_CONSTRAINT_NOSEHOOVER_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

class Nose_hoover : public Constraint {
 public:
  Nose_hoover (class FinECuPPA *);
  ~Nose_hoover ( );
  bool read (class finecuppa::interpreter::Parser *);

  void step_part_I ();
  void step_part_II ();

 public:

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
