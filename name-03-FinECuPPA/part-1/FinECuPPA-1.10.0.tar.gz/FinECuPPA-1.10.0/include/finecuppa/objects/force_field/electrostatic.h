
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_FORCEFIELD_ELECTROSTATIC_H
#define FINECUPPA_OBJECTS_FORCEFIELD_ELECTROSTATIC_H

#include "finecuppa/objects/force_field.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Electrostatic : public Force_field {
public:
  Electrostatic (class FinECuPPA *);
  ~Electrostatic () {};
  double potential (const Vector<double> &);
  double potential (const int);

  Vector<double> field (const Vector<double> &);
  Vector<double> field (const int);

  double energy();

  bool read (class finecuppa::interpreter::Parser *);
  void verify_settings ();
  void calculate_acceleration ();
public:
  //std::vector<std::vector<Real_t>> epsilon,sigma;
  double k_electrostatic;
  Vector<double> external_field;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
