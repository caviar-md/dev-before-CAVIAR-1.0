
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_NEIGHBORLIST_VERLETLIST_H
#define FINECUPPA_OBJECTS_NEIGHBORLIST_VERLETLIST_H

#include "finecuppa/objects/neighborlist.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace neighborlist {
class Verlet_list : public Neighborlist {
 public:
  Verlet_list (class FinECuPPA *);
  bool read (class finecuppa::interpreter::Parser *);
  void init ();
  bool rebuild_neighlist ();
  void build_neighlist ();
  double dt, cutoff_extra;
  double cutoff_extra_coef;
//  double cutoff; // Defined in the base class
 public:
};

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
