
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_GRID1D_H
#define FINECUPPA_OBJECTS_UNIQUE_GRID1D_H

#include "finecuppa/objects/unique.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace unique {
class Grid_1D : public Unique {
  public:
    Grid_1D (class FinECuPPA *) ;    
    Grid_1D (class FinECuPPA *, double MIN, double MAX, double increment, int segment) ;
    ~Grid_1D () ;
    void verify_settings ();    
    bool read (finecuppa::interpreter::Parser *);
    void generate (); // calculates the parameters
    unsigned int no_points ();
    double give_point ();
    double give_point (int);
    

    double min, max, increment;

    bool generated; // true if generate() has been called.    
    bool by_increment, by_segment;
    
    int segment;    
    int no_given_points;     
    int num; // number of random atoms or molecules to be created        
    int type_int;
   
    std::string TYPE;
    
};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
