
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_MOLECULE_H
#define FINECUPPA_OBJECTS_UNIQUE_MOLECULE_H

#include "finecuppa/objects/unique.h"
#include "finecuppa/objects/atom_data/utility/bond.h"
#include "finecuppa/objects/atom_data/utility/angle.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
namespace unique {
class Atom;
class Molecule_group;
class Molecule : public Unique {
 public:
  Molecule (class FinECuPPA *);
  Molecule (const Molecule & a);
  Molecule ();
  ~Molecule ();

  bool read (finecuppa::interpreter::Parser *);
  void verify_settings ();

  Vector<double> pos_tot () const;
  Vector<double> vel_tot () const;  

  bool add_atom (finecuppa::interpreter::Parser *); 
  bool add_atom (const class Atom &);
  bool add_atom (const class Atom &, const Vector<double> &p, const Vector<double> &v);  

  // called by the molecule itself. The output file name is automaticly generated
  void output_xyz ();

  // could be called by a Molecule_group or Molecule_list
  void output_xyz (std::ofstream &);
  
  // could be called in a library-type call. get's the output file name.
  void output_xyz (const std::string &);

  // puts the atoms type, total position and velocity inside the vectors.
  void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&,
      std::vector<Vector<double>>&);
  
  bool part_of_a_molecule_group;    
  Molecule_group * upper_level_molecule_group;

  Vector<double> position, velocity;
  std::vector<Atom> atoms;

  std::vector<objects::atom_data::Bond> atomic_bond; 
  std::vector<int> atomic_bond_index; 

  std::vector<objects::atom_data::Angle> atomic_angle; 
  std::vector<int> atomic_angle_index; 

  
};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
