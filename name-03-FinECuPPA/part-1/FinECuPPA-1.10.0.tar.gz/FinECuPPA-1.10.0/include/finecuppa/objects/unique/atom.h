
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_ATOM_H
#define FINECUPPA_OBJECTS_UNIQUE_ATOM_H

#include "finecuppa/objects/unique.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN

namespace objects {
namespace unique {
class Molecule;
class Atom_group;
class Atom  : public Unique {
 public:
  Atom (class FinECuPPA *);    
  Atom (const Atom &);
  Atom ();
  ~Atom () ;
  bool read (finecuppa::interpreter::Parser *);
  void verify_settings ();
  Vector<double> pos_tot () const;
  Vector<double> vel_tot () const; 

  void output_xyz (std::ofstream &);  
  void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&, std::vector<Vector<double>>&);      

  bool part_of_a_molecule;    
  Molecule * upper_level_molecule;

  bool part_of_a_atom_group;    
  Atom_group * upper_level_atom_group;
  
  Vector<double> position, velocity;
  unsigned int type;

};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
