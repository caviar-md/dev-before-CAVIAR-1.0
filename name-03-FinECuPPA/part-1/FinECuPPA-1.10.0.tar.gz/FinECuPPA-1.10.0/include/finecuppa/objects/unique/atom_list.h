
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_ATOMLIST_H
#define FINECUPPA_OBJECTS_UNIQUE_ATOMLIST_H

#include "finecuppa/objects/unique.h"
#include "finecuppa/objects/unique/atom.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
namespace unique {
class Atom_list  : public Unique {
 public:
  Atom_list (class FinECuPPA *);    
  Atom_list (const Atom_list &);
  Atom_list ();
  ~Atom_list () ;
  bool read (finecuppa::interpreter::Parser *);
  void verify_settings ();
  void add_atom(const objects::unique::Atom &);
  std::vector<objects::unique::Atom *> atoms;

};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
