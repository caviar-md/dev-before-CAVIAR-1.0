
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_INTEGRATOR_H
#define FINECUPPA_OBJECTS_INTEGRATOR_H

#include "finecuppa/utility/objects_common_headers.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
class Atom_data;

class Integrator : public Pointers {
public:
  Integrator (class FinECuPPA *);
  virtual ~Integrator  ();
  virtual bool read (class finecuppa::interpreter::Parser *) = 0;

public:
  virtual void step_part_I () = 0;
  virtual void step_part_II () = 0;
  class objects::Atom_data *atom_data;

  Real_t dt;

  // to be used in other objects;
  int integrator_type;

  FC_BASE_OBJECT_COMMON_TOOLS  
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
