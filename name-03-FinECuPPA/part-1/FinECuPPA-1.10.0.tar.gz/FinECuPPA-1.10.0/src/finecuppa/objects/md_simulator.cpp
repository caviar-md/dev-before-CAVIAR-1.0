
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/md_simulator.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/integrator.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/force_field.h"
#include "finecuppa/objects/constraint.h"
#include "finecuppa/objects/writer.h"
#include "finecuppa/utility/interpreter_io_headers.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Md_simulator::Md_simulator (FinECuPPA *fptr) : Pointers{fptr},
    initialized{false} {
  FC_OBJECT_INITIALIZE
}

Md_simulator::~Md_simulator () {}

void Md_simulator::verify_settings () {
  
}


bool Md_simulator::read_base_class_commands (finecuppa::interpreter::Parser *) {
  bool command_called = false;
/*
  parser -> keep_current_token();
  auto token = parser -> get_val_token();
  auto t = token.string_value;
  if (string_cmp(t,"output_total_force") ) {
    command_called = true;
    output_total_force();
  } else if (string_cmp(t,"output_total_energy") ) {
    command_called = true;
    output_total_energy();
  }
*/
  return command_called;
}

void Md_simulator::initialize () {
  initialized = true;
}

void Md_simulator::step (int i) {

  if (!initialized) {
    initialize();
    time = dt*initial_step;
    setup();
  }

  atom_data->record_owned_old_data();

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  static int my_mpi_rank = comm->me;

  if (my_mpi_rank==0) {

    // contains (initial) velocity and position incrementations and other things.
    step_part_I ();


    // fixing position and velocity according to the constraints
    for (auto&& c : constraint)
      c -> step_part_I ();


    bool make_list = boundary_condition (); 


    if (make_list) 
      for (auto&& n: neighborlist) n->build_neighlist ();
    else {
      for (auto&& n: neighborlist)
        make_list = make_list || n->rebuild_neighlist ();
      if (make_list) 
        for (auto&& n: neighborlist) n->build_neighlist ();
    }

  }


  atom_data->synch_owned_data(0);

  for (auto&& f : force_field)
    f -> calculate_acceleration ();

  MPI_Barrier(mpi_comm);

  if (my_mpi_rank==0) {


    // contains (final) velocity incrementations.
    step_part_II ();


    // last fixing of the velocity (if needed).
    for (auto&& c : constraint)
      c -> step_part_II ();
  }


  for (auto&& w : writer) 
    w -> write (i, time);

#else

  // contains (initial) velocity and position incrementations and other things.
  integrator->step_part_I ();

  // fixing position and velocity according to the constraints
  for (auto&& c : constraint)
    c -> step_part_I ();

  bool make_list = boundary_condition (); 


  if (make_list) 
    for (auto&& n: neighborlist) n->build_neighlist ();
  else {
    for (auto&& n: neighborlist)
      make_list = make_list || n->rebuild_neighlist ();
    if (make_list) 
      for (auto&& n: neighborlist) n->build_neighlist ();
  }

  for (auto&& f : force_field)
    f -> calculate_acceleration ();


  // contains (final) incrementaion
  integrator->step_part_II ();

  // last fixing of the velocity (if needed).
  for (auto&& c : constraint)
    c -> step_part_II ();

  for (auto&& w : writer) 
    w -> write (i, time);

#endif

  time += dt;

}


bool Md_simulator::boundary_condition () {
  bool result = false;

// the result only in MPI case can
// become true, due to exchanging a particle between domains
  result = atom_data -> exchange_owned (); 

  atom_data -> exchange_ghost ();
#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)

#elif defined(FINECUPPA_WITH_MPI)
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Md_simulator::setup () {
  t_start = clock();
  if (use_time) {
    initial_step = (int) initial_time/dt;
    final_step = (int) final_time/dt;
  }

  FC_NULLPTR_CHECK(atom_data)
  atom_data->record_owned_old_data();

  if (neighborlist.size()==0) output->warning("Md_simulator::setup: neighborlist.size() = 0");
  if (force_field.size()==0) output->warning("Md_simulator::setup: force_field.size() = 0");

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)

  atom_data->synch_owned_data(0);

  //if (my_mpi_rank==0) { // XXX STRANGE MPI BUG! if uncommented, the code will stuck somewhere else.

    for (auto&& n: neighborlist) n->init ();

    atom_data -> exchange_owned (); // isn't neccesary

    atom_data -> exchange_ghost ();

    for (auto&& n: neighborlist)
      n->build_neighlist ();

  //}




  for (auto&& f : force_field) 
    f -> calculate_acceleration ();


  for (auto&& w : writer) 
    w -> write (0, 0.0);

#else

  for (auto&& n: neighborlist) n->init ();

  atom_data -> exchange_owned (); // isn't neccesary

  atom_data -> exchange_ghost ();

  for (auto&& n: neighborlist) n->build_neighlist ();

  for (auto&& f : force_field) 
    f -> calculate_acceleration ();

  for (auto&& w : writer) 
    w -> write (0, 0.0);

#endif

}



void Md_simulator::cleanup () {

}


}

FINECUPPA_NAMESPACE_CLOSE

