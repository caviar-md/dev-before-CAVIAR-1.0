
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/force_field.h"
#include "finecuppa/interpreter/error.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Force_field::Force_field (FinECuPPA *fptr) : Pointers{fptr}, 
  atom_data{nullptr}, domain{nullptr}, neighborlist{nullptr} {
  FC_OBJECT_INITIALIZE
}

void Force_field::verify_settings () {
  
}

double Force_field::energy() {
  error->all(FC_FILE_LINE_FUNC, "The energy calculation of this force_field is not implemented");
  return 0.0;
}

double Force_field::potential (const Vector<double> &) {
  error->all(FC_FILE_LINE_FUNC, "The potential calculation of this force_field is not implemented");
  return 0.0;
}

double Force_field::potential (const int) {
  error->all(FC_FILE_LINE_FUNC, "The potential calculation of this force_field is not implemented");
  return 0.0;
}


Vector<double> Force_field::field (const Vector<double> &) {
  error->all(FC_FILE_LINE_FUNC, "The field calculation of this force_field is not implemented");
  return Vector<double> {0,0,0};
}

Vector<double> Force_field::field (const int) {
  error->all(FC_FILE_LINE_FUNC, "The field calculation of this force_field is not implemented");
  return Vector<double> {0,0,0};
}


} //objects

FINECUPPA_NAMESPACE_CLOSE

