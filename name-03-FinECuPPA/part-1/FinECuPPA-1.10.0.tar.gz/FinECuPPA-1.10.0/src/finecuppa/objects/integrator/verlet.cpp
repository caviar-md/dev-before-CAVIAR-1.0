
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/integrator/verlet.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integrator {

Verlet::Verlet (FinECuPPA *fptr) : Integrator{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  integrator_type = 4;
}

Verlet::~Verlet (){}

bool Verlet::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"time_step")
          || string_cmp(t,"timestep") || string_cmp(t,"dt")) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
    } else FC_ERR_UNDEFINED_VAR(t)
  }
  return in_file;
}

void Verlet::verify_settings (){
  FC_NULLPTR_CHECK(atom_data)
  atom_data->record_owned_acceleration_old = true;
}

void Verlet::step_part_I () {

  FC_OBJECT_VERIFY_SETTINGS

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();

  for (unsigned int i=0; i<psize; i++) { 
    pos [i] += vel [i] * dt + 0.5 * acc [i] * dt * dt;
    acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

}

void Verlet::step_part_II () {

  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;
  auto &acc_old = atom_data -> owned.acceleration_old; // Move it to M_shake    

  for (unsigned int i=0; i<vel.size(); i++) {
    vel [i] += 0.5 * (acc [i] + acc_old[i]) * dt;
  }

}

} //integrator
} //objects

FINECUPPA_NAMESPACE_CLOSE


