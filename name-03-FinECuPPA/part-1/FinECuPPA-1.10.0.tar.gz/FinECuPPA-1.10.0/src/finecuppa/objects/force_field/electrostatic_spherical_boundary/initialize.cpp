
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/force_field/electrostatic_spherical_boundary.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

void Electrostatic_spherical_boundary::initialize () {
  if (!calculated_once) {
    calculated_once = true;
    auto &pos = atom_data -> owned.position;  
    auto pos_size = pos.size();

    if (uncharged_particles_optimization) {
      int num_of_charged = 0;
      for (unsigned int i = 0; i < pos_size; ++i) {
        auto type_i = atom_data -> owned.type[i];
        auto charge_i = atom_data -> owned.charge[type_i];
        if (charge_i != 0.0) ++num_of_charged;
      }

      image.position.resize(num_of_charged, Vector<double> {0,0,0});
      image.charge.resize(num_of_charged, 0);

    } else {

      image.position.resize(pos_size, Vector<double> {0,0,0});
      image.charge.resize(pos_size, 0);

    }

  } 
 
  calculate_image_charges();
}


//==================================================
//==================================================
//==================================================

void Electrostatic_spherical_boundary::calculate_image_charges() {

  const auto &pos = atom_data -> owned.position;  
  const auto rad_sq = radius*radius;
  for (unsigned int i = 0; i < pos.size(); ++i) {
    auto type_i = atom_data -> owned.type[i];
    double charge_i = atom_data -> owned.charge[type_i];


    if (uncharged_particles_optimization)
      if (charge_i == 0.0) continue; 

    Vector<double> image_position_ = pos[i];
    const auto p_rel =  pos[i]-center;
    const auto p_sq = p_rel*p_rel;

    if (p_sq==0) continue;
    if (p_sq>rad_sq) {
      error->all (FC_FILE_LINE_FUNC, "particle outside sphere is not implemented yet.");
    } else if (p_sq == rad_sq) {
      error->all (FC_FILE_LINE_FUNC, "particle is on the shell.");
    } else {

      image_position_ *= radius*radius / p_sq;
      double image_charge_ = - charge_i * radius / std::sqrt(p_sq);
      //double image_charge_ = - charge_i*  std::sqrt(p_sq)/radius; //WHAT
      image.position[i] = image_position_;
      image.charge[i] = image_charge_;

    }
  }

}



} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

