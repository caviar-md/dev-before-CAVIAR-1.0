
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/md_simulator/basic.h"
#include "finecuppa/objects/integrator.h"
#include "finecuppa/utility/interpreter_io_headers.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace md_simulator {

Basic::Basic (FinECuPPA *fptr) : Md_simulator{fptr}
{
  FC_OBJECT_INITIALIZE_INFO
  use_time = false;
  use_step = false;
}

Basic::~Basic () {}

bool Basic::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"integrator") || string_cmp(t,"set_integrator")) {
      FIND_OBJECT_BY_NAME(integrator,it)
      integrator = object_container->integrator[it->second.index];
    } else if (string_cmp(t,"time_step")
          || string_cmp(t,"timestep") || string_cmp(t,"dt")) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
    } else if (string_cmp(t,"initial_time")) {
      GET_OR_CHOOSE_A_REAL(initial_time,"","")
      use_time = true;
    } else if (string_cmp(t,"final_time")) {
      GET_OR_CHOOSE_A_REAL(final_time,"","")
      use_time = true;
    } else if (string_cmp(t,"initial_step")) {
      GET_OR_CHOOSE_A_INT(initial_step,"","")
      use_step = true;
    } else if (string_cmp(t,"final_step")) {
      GET_OR_CHOOSE_A_INT(final_step,"","")
      use_step = true;
    } else if (string_cmp(t,"run")) {
      run();
    } else if (string_cmp(t,"add_constraint") || string_cmp(t,"constraint")) {
      FIND_OBJECT_BY_NAME(constraint,it)
      constraint.push_back(object_container->constraint[it->second.index]);
    } else if (string_cmp(t,"add_writer") || string_cmp(t,"writer")) {
      FIND_OBJECT_BY_NAME(writer,it)
      writer.push_back(object_container->writer[it->second.index]);
    } else if (string_cmp(t,"add_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist.push_back(object_container->neighborlist[it->second.index]);
    } else if (string_cmp(t,"add_force_field") || string_cmp(t,"force_field")) {
      FIND_OBJECT_BY_NAME(force_field,it)
      force_field.push_back(object_container->force_field[it->second.index]);
    } else  if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else  if (string_cmp(t,"step")) {
      int i=0;
      GET_OR_CHOOSE_A_INT(i,"","")
      step (i);
      continue;
    } else if (read_base_class_commands(parser)) {
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

bool Basic::run () {
  output->info ("MD started.");
  verify_settings ();

  t_start = clock();

  for (auto i = initial_step; i < final_step; ++i) 
    step(i);

  cleanup(); 

  output->info ("MD finished.");

  t_end = clock();
  double simulation_time =  ( (float)t_end - (float)t_start ) / CLOCKS_PER_SEC;


#if defined (FINECUPPA_WITH_MPI) 
  std::string s = "process " + std::to_strig(comm->me) + " : ";
#else
  std::string s = "";
#endif
  s += "simulation time: " + std::to_string(simulation_time) + " (seconds)";
  std::cout << s << std::endl;
  //output->info (s, 3);
  return true; //WARNING
}

void Basic::verify_settings () {
  if (integrator==nullptr) error->all ("Basic::verify_settings: integrator_set = false");
  if (use_time && use_step)
    error->all ("simulator md: verify_settings: cannot use both 'time' and 'step'.");
  if (!(use_time || use_step))
    error->all ("simulator md: verify_settings: please assign 'time' or 'step' variables.");
}

} //md_simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

