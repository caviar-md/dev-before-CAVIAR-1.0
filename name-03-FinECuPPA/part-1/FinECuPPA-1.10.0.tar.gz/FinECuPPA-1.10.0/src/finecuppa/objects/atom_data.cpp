
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/atom_data.h"
#include "finecuppa/interpreter/communicator.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/force_field.h"

#include "finecuppa/utility/interpreter_io_headers.h"
#include <algorithm>

FINECUPPA_NAMESPACE_OPEN

namespace objects {

constexpr auto expected_imbalance_factor = 1.1;

Atom_data::Atom_data (FinECuPPA *fptr) : Pointers{fptr}, 
    num_local_atoms{0},
    num_total_atoms{0}, num_atom_types{0},
    synch_owned_data_bcast_details{true},
    ghost_cutoff{0}, domain{nullptr}, cell_list{nullptr} {

  FC_OBJECT_INITIALIZE
  record_owned_position_old = false;
  record_owned_velocity_old = false;
  record_owned_acceleration_old = false;
}

Atom_data::~Atom_data () {
  
}

void Atom_data::verify_settings () {
  
}

void Atom_data::record_owned_old_data () {
  if (record_owned_position_old) owned.position_old = owned.position;
  if (record_owned_velocity_old) owned.velocity_old = owned.velocity;
  if (record_owned_acceleration_old) owned.acceleration_old = owned.acceleration;
}

unsigned int Atom_data::get_global_id () {
#ifdef FINECUPPA_WITH_MPI
  MPI_Barrier (mpi_comm); // does it have to be here??
  MPI_Allreduce (&num_local_atoms, &num_total_atoms, 1, MPI_UNSIGNED, MPI_SUM, mpi_comm);
#else
  num_total_atoms = owned.position.size();
#endif
  return num_total_atoms;
}

void Atom_data::set_num_total_atoms (GlobalID_t n) {
  num_total_atoms = n;
  num_local_atoms_est = n * expected_imbalance_factor / comm->nprocs;
}

void Atom_data::reserve_owned_vectors () {
  owned.id.reserve (num_local_atoms_est);
  owned.charge.reserve (num_local_atoms_est);
  owned.position.reserve (num_local_atoms_est);
  owned.velocity.reserve (num_local_atoms_est);
  owned.acceleration.reserve (num_local_atoms_est);
}

bool Atom_data::position_inside_local_domain(const Vector<double> &pos) {
  if (domain==nullptr) error->all(FC_FILE_LINE_FUNC,"domain = nullptr");

  if (pos.x >= domain->lower_local.x && pos.x < domain->upper_local.x &&
      pos.y >= domain->lower_local.y && pos.y < domain->upper_local.y &&
      pos.z >= domain->lower_local.z && pos.z < domain->upper_local.z) 
    return true;
  
  return false;
}


// XXX note that any new vector addition to this function should be deleted in 
// 'remove_atom()' functions.
bool Atom_data::add_atom (GlobalID_t id,
                          AtomType_t type,
                          const Vector<Real_t> &pos,
                          const Vector<Real_t> &vel,
                          const std::vector<Real_t> &,
                          const std::vector<int> &) {

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  const auto me = domain->me;
  if (me==0) {
#endif
  if (position_inside_local_domain (pos)) {
    owned.type.push_back (type);
    owned.position.push_back (pos);
    owned.id.push_back ( id );
    owned.velocity.push_back (vel);
    owned.acceleration.push_back (Vector<Real_t> {0,0,0});
    owned.msd_domain_cross.push_back(Vector<int> {0,0,0});
    ++num_local_atoms;
    return true;
  }
  else return false;
#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  }
#endif
  return false;
}

bool Atom_data::add_masses (unsigned int type, Real_t m) {
  if (type + 1 > owned.mass.size())
    owned.mass.resize (type + 1);
  owned.mass[type] = m;
  return true; //WARNING  
}

bool Atom_data::add_charges (unsigned int type, Real_t c) {
  if (type + 1 > owned.charge.size())
    owned.charge.resize (type + 1);
  owned.charge[type] = c;
  return true; //WARNING
}

void Atom_data::remove_atom(const int i) {
    owned.position.erase (owned.position.begin()+i);  
    owned.velocity.erase (owned.velocity.begin()+i);  
    owned.acceleration.erase (owned.acceleration.begin()+i);  
    owned.type.erase (owned.type.begin()+i);  
    owned.id.erase (owned.id.begin()+i);
    owned.msd_domain_cross.erase(owned.msd_domain_cross.begin()+i);
  --num_local_atoms;   
}

void Atom_data::remove_atom(std::vector<int> v_delete_list) {
  // sort them from greatest to lowest to maintain lower index
  std::sort(v_delete_list.begin(), v_delete_list.end(), std::greater<int>()); 
  for (auto i : v_delete_list) {
    owned.position.erase (owned.position.begin()+i);  
    owned.velocity.erase (owned.velocity.begin()+i);  
    owned.acceleration.erase (owned.acceleration.begin()+i);  
    owned.type.erase (owned.type.begin()+i);  
    owned.id.erase (owned.id.begin()+i);
    owned.msd_domain_cross.erase(owned.msd_domain_cross.begin()+i);
    --num_local_atoms;   
  }
}

} //objects

FINECUPPA_NAMESPACE_CLOSE


