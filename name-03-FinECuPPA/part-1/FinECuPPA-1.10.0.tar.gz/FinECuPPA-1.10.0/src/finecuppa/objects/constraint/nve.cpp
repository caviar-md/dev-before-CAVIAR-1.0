
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/constraint/nve.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/utility/interpreter_io_headers.h"


FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Nve::Nve (FinECuPPA *fptr) : Constraint{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  energy = 1.0;
}

Nve::~Nve () {}

bool Nve::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"energy")) {
      GET_OR_CHOOSE_A_REAL(energy,"","")
      if (energy <= 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "Temperature have to non-negative."); 
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else {
      error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
    }
  }
  return in_file;
}


void Nve::step_part_I () {

}

void Nve::step_part_II () {
  // XXX there may be two cases. 1: all of particles, 2: a particle of a type

  FC_NULLPTR_CHECK(atom_data)

  auto e = atom_data -> kinetic_energy(); // = sum of all particles {0.5 m * v^2}
  auto &vel = atom_data -> owned.velocity;

  e = e / atom_data -> owned.position.size(); // mean kinetic energy

  double c = std::sqrt ( energy / e ); //
  
  for (unsigned int i=0; i<vel.size(); i++) {
    vel [i] *= c;
  }
}

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

