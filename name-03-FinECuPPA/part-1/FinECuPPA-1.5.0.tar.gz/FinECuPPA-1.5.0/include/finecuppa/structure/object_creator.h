#ifndef FINECUPPA_OBJECT_CREATOR_H
#define FINECUPPA_OBJECT_CREATOR_H

#include "finecuppa/utility/pointers.h"

#include <string>
#include <map>

FINECUPPA_NAMESPACE_OPEN
class Parser;
using CommandFunc_object_creator = bool (Object_creator::*) (Parser *); // a pointer to boolean function of ...

class Object_creator : protected Pointers  {
public:
  Object_creator (class FinECuPPA *);
  ~Object_creator ();
  
  const static std::map<std::string, CommandFunc_object_creator> commands_map;
  
  
  bool element (Parser *);
  bool atom (Parser *);
  bool molecule (Parser *);
  bool random_1d (Parser *);
  bool grid_1d (Parser *);    
  bool boundary (Parser *);
  bool shape (Parser *);
  bool distribution (Parser *);
  bool force_field (Parser *);  
  bool finite_element (Parser *);    
  bool long_range_solver (Parser *);
  bool integration (Parser *);
  bool simulator (Parser *);
  bool domain (Parser *);
  bool neighborlist (Parser *);
  bool atom_data (Parser *);
  bool writer (Parser *);

  bool int_variable (Parser *);
  bool real_variable (Parser *);
  bool int_2d_vector (Parser *);
  bool real_2d_vector (Parser *);
  bool int_3d_vector (Parser *);
  bool real_3d_vector (Parser *);
  bool string_variable (Parser *);
  bool boolean_variable (Parser *);
  
protected:

} ;

FINECUPPA_NAMESPACE_CLOSE

#endif
 
