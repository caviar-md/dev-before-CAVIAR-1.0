#ifndef FINECUPPA_COMMUNICATOR_H
#define FINECUPPA_COMMUNICATOR_H

#include "finecuppa/utility/pointers.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects { class Domain; }
class Communicator : protected Pointers {
public:
  Communicator (FinECuPPA *);
  
  void calculate_procs_grid ();

// broadcast a variable from the root process to others
  void broadcast (bool &);
  void broadcast (size_t &);
  void broadcast (size_t &, char *);
  void broadcast (std::string &);
  
  int me, nprocs;// MPI process rank and number of processes
  int nprocs_x, nprocs_y, nprocs_z; // it can be at least (1) and at most (nprocs)
  int grid_index_x, grid_index_y, grid_index_z; // starts from (0) to (nprocs_i-1) ; i=x,y,z
  int all[3][3][3]; // all neighborlist domains around the me=all [1][1][1]. left=all[0][1][1]. up=all[1][2][1]. 
                    // if one domain exists, in one process case, all[i][j][k]=me for 0<=i,j,k<=2 
                    // left&right: x direction, down&up: y direction, bottom&top: z direction. right&up&top are the positive directions
  std::vector<int> neighborlist_domains;  // defined to have a faster MPI when we have less than 27 processes or when domains can have similar neigbors//**//
protected:
  inline int grid2rank (int x, int y, int z) const {return x + y*nprocs_x + z*nprocs_x*nprocs_y;} // calculates process rank from it grid index
  void find_best_grid (); // with respect to the number of processes, makes a grid with lowest shared area possible.
  class objects::Domain *domain;
};

FINECUPPA_NAMESPACE_CLOSE

#endif
