#ifndef FINECUPPA_OBJECT_HANDLER_COMMANDS_MAP
#define FINECUPPA_OBJECT_HANDLER_COMMANDS_MAP

#include "finecuppa/structure/object_handler.h"

FINECUPPA_NAMESPACE_OPEN

//using CommandFunc_object_handler = bool (Object_handler::*) (Parser *); // a pointer to boolean function of ...
const std::map<std::string, CommandFunc_object_handler> Object_handler::commands_map = {
    {  "output_xyz", &Object_handler::output_xyz},    
    {  "add_atom", &Object_handler::add_atom_to_molecule},
    {  "add_molecule", &Object_handler::add_molecule_to_molecule},
};

FINECUPPA_NAMESPACE_CLOSE

#endif
