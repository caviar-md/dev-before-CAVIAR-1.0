#ifndef FINECUPPA_SIMULATOR_H
#define FINECUPPA_SIMULATOR_H

#include "finecuppa/utility/pointers.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Integration;
class Simulator : protected Pointers {
 public:
  Simulator (class FinECuPPA *);
   virtual ~Simulator ( );
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual bool run ()=0;
  virtual void verify_settings()=0;
  virtual void setup ()=0;
  virtual void cleanup ()=0;
  double dt;
  std::string object_base_class_name, object_class_name, object_name;
 protected:
  clock_t t_start, t_end;
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
