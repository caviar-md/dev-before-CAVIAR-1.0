#ifndef FINECUPPA_LONG_RANGE_SOLVER_EWALD_H
#define FINECUPPA_LONG_RANGE_SOLVER_EWALD_H

#include <vector>
#include "finecuppa/objects/long_range_solver.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace long_range_solver {

class Ewald : public Long_range_solver {
 public:
  Ewald(class FinECuPPA *);
  ~Ewald();
  void calculate();
  bool read(class finecuppa::Parser *);  

  void make_k_vectors();
  void make_k_vectors_slab_geometry();

  Vector<double> k_space_field(int);
  Vector<double> r_space_field(int); 
  Vector<double> dipole_field(  );
  Vector<double> total_field(int);  
  Vector<double> slab_geometry_correction_field(int);
  
  Vector<double> k_space_field(const Vector<double> &); 
  Vector<double> r_space_field(const Vector<double> &); 
  Vector<double> total_field(const Vector<double> &);    
  Vector<double> slab_geometry_correction_field(const Vector<double> &);
       
  double k_space_potential(const Vector<double> &);  
  double r_space_potential(const Vector<double> &); 
  double dipole_potential(const Vector<double> &);
  double self_potential(const Vector<double> &);
  double total_potential(const Vector<double> &);    
  double slab_geometry_correction_potential(const Vector<double> &);    
    
  double k_space_energy( );  
  double r_space_energy( ); 
  double dipole_energy( );
  double self_energy( );
  double total_energy( );    
  double slab_geometry_correction_energy( );    

 protected:
  void calculate_alpha();
  void calculate_slab_geometry_coefficients();

  bool by_cutoff_r, by_accuracy, by_alpha;
  bool calculated_once, slab_geometry;
  bool manual_parameters;

  bool dipole;
  double epsilon_dipole;
  Vector<double> dipole_field_vector;  

  double accuracy;
  double erfc_cutoff, cutoff_r, cutoff_k, alpha;
  double pi_root_inv, four_pi;
//  std::vector<std::vector<std::vector<unsigned>>> particle_mesh_list;
//  std::vector<std::vector<unsigned>> particle_nlist;

// simulation box lengths and its product
  double lx,lx_inv, ly,ly_inv, lz,lz_inv, l_xyz_inv;

  int kx_max, ky_max, kz_max;
//  std::vector<std::vector<std::vector<double>>> k_coef;

  std::vector<Vector<double>> k_vector;
  std::vector<double> k_vector_sq;
  std::vector<double> field_k_coef, potential_k_coef;

  std::vector<double> slab_kx;
  std::vector<double> slab_ky;
  std::vector<double> slab_kp_norm;

  std::vector<double> slab_kx_coef;
  std::vector<double> slab_ky_coef;
  std::vector<double> slab_kp_coef;

  std::vector<double> slab_sin_kx_x; //f1 p
  std::vector<double> slab_sin_ky_y; //f2 f2 p

  std::vector<double> slab_sinh_kx_z; //f3 p
  std::vector<double> slab_sinh_ky_z; //f3 p
  std::vector<double> slab_sinh_kp_z; //f3 p

  std::vector<double> slab_cos_kx_x; //f2 f3 f3 p
  std::vector<double> slab_cos_ky_y; //f1 f3 f3 p

  std::vector<double> slab_cosh_kx_z; //f1 p
  std::vector<double> slab_cosh_ky_z; //f2 p
  std::vector<double> slab_cosh_kp_z; //f1 f2 p


  int n_k_vectors;
  class FinECuPPA *fptr;
};

} // long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
