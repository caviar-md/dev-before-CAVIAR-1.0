#ifndef FINECUPPA_FORCE_FIELD_GRANULAR_H
#define FINECUPPA_FORCE_FIELD_GRANULAR_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Granular : public Force_field {
public:
  Granular (class FinECuPPA *);
  ~Granular () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  std::vector<Real_t> elastic_coef,dissip_coef, radius;
  Vector<Real_t> gravity;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
