#ifndef FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EWALD_R_H
#define FINECUPPA_FORCE_FIELD_ELECTROSTATIC_EWALD_R_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Long_range_solver;
namespace force_field {

class Electrostatic_ewald_r : public Force_field {
public:
  Electrostatic_ewald_r (class FinECuPPA *);
  ~Electrostatic_ewald_r () {};

  double potential (const Vector<double> &);
  double potential (const int);

  Vector<double> field (const Vector<double> &);
  Vector<double> field (const int);

  bool read (class Parser *);
  void calculate_acceleration ();
  double energy();
protected:

  double k_electrostatic, alpha;
  Vector<double> external_field;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
