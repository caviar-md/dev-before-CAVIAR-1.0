#ifndef FINECUPPA_FORCE_FIELD_LJ_CELL_LIST_H
#define FINECUPPA_FORCE_FIELD_LJ_CELL_LIST_H

#include "finecuppa/objects/force_field.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Lj_cell_list : public Force_field {
public:
  Lj_cell_list (class FinECuPPA *);
  ~Lj_cell_list () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  std::vector<std::vector<Real_t>> epsilon,sigma;  
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
