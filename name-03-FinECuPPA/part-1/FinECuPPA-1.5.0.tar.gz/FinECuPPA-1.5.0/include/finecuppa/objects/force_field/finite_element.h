#ifndef FINECUPPA_FORCE_FIELD_FINITE_ELEMENT_H
#define FINECUPPA_FORCE_FIELD_FINITE_ELEMENT_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Finite_element;
namespace force_field {

class Finite_element : public Force_field {
public:
  Finite_element (class FinECuPPA *);
  ~Finite_element () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  objects::Finite_element *finite_element;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
