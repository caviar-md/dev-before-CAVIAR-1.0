#ifndef FINECUPPA_NEIGHBORLIST_CELL_LIST_H
#define FINECUPPA_NEIGHBORLIST_CELL_LIST_H

#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Domain;
namespace neighborlist {
class Cell_list : public Neighborlist {
 public:
  Cell_list (class FinECuPPA *);
  bool read (class finecuppa::Parser *);
  void init ();
  bool rebuild_neighlist ();
  void build_neighlist ();
  void build_binlist ();
  Vector<int> binlist_index (const Vector<double> &);
  int neigh_bin_index (const Vector<double> &);
 protected:
  void make_neigh_bin ();
  class objects::Domain *domain;
  bool domain_set;
  bool make_neighlist; // if 'true' one can use this class as a 'verlet_list'.
  double cutoff_neighlist;
};

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
