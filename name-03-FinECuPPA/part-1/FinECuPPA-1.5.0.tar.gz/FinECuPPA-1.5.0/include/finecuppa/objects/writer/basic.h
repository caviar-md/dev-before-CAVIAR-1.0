#ifndef FINECUPPA_WRITER_BASIC_H
#define FINECUPPA_WRITER_BASIC_H

#include "finecuppa/objects/writer.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace writer {

class Basic : public Writer {
 public:
  Basic (class FinECuPPA *);
   ~Basic ( );
  bool read (class finecuppa::Parser *);


 protected:

};

} //writer
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
