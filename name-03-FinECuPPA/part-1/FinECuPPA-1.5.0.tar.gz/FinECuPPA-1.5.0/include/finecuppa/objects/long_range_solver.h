#ifndef FINECUPPA_LONG_RANGE_SOLVER_H
#define FINECUPPA_LONG_RANGE_SOLVER_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Atom_data; 
class Domain; 
class Neighborlist;
class Long_range_solver  : protected Pointers {
 public:
  Long_range_solver(class FinECuPPA *); 
  virtual ~Long_range_solver();
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void calculate() = 0;
  
  virtual Vector<double> total_field(int) = 0;  
  virtual Vector<double> total_field(const Vector<double> &) = 0;  

// The potential value is used for the calculation of charged particle in the
// presence of conductive geometries.
  virtual double total_potential(const Vector<double> &) = 0;    

  virtual double total_energy( ) = 0;  
  std::string object_base_class_name, object_class_name, object_name;
 protected: 
  class FinECuPPA *fptr;
  class finecuppa::objects::Domain *domain;
  class finecuppa::objects::Atom_data *atom_data; 
  class finecuppa::objects::Neighborlist *neighborlist;  

};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
