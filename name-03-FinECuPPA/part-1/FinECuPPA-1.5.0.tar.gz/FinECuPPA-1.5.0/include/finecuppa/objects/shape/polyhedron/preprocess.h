#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_PREPROCESS_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_PREPROCESS_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {

struct Polyhedron;
class Preprocess : protected Pointers {
public:
  Preprocess (class FinECuPPA *);
  ~Preprocess ();
  
  void pre_correct_normals (shape::polyhedron::Polyhedron&); // checks neighborlist faces and sorts the vertices so that their normal vectors would be alighned when created.

  void merge_vertices (shape::polyhedron::Polyhedron&);
  
};
} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
