#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_H

#include "finecuppa/objects/shape.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron { class Handler; }

class Polyhedron : public Shape {
  public:
  Polyhedron (class FinECuPPA *);
  ~Polyhedron ();
  
  bool read(class finecuppa::Parser *);
  
  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);   
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);    

  protected:
  void command_parameters (class finecuppa::Parser *);    
  void command_generate ();

  class shape::polyhedron::Handler * polyhedron_handler;
  bool polyhedron_add;

};
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
