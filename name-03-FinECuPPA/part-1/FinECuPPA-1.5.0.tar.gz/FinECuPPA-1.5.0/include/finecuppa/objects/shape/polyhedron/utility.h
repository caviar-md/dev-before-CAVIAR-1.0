#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_UTILITY_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_UTILITY_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {

struct Polyhedron;
class Utility : protected Pointers {
public:
  Utility (class FinECuPPA *);
  ~Utility ();
  
  void make_normal (shape::polyhedron::Polyhedron &); // after reading unv file, it calculates normal vectors    
  void make_edge_norms (shape::polyhedron::Polyhedron &); // makes normals of faces made of edges and other normals used in check_inside() algorithm.
  void invert_normals (shape::polyhedron::Polyhedron &); // multiply all the normal Vectors with -1

};
} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
