#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_INPUT_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_INPUT_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Input : protected Pointers {
public:
  Input (class FinECuPPA *);
  ~Input ();
  
  void read_vtk (shape::polyhedron::Polyhedron&, const std::string &); // read vtk format // There's many unneeded points. 


};
} //polyhedron
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
