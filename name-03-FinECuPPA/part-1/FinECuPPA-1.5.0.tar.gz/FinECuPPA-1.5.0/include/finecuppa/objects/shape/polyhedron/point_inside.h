#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POINT_INSIDE_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POINT_INSIDE_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Point_Inside : protected Pointers {
public:
  Point_Inside (class FinECuPPA *);
  ~Point_Inside ();
  

  bool is_inside(shape::polyhedron::Polyhedron &, const Vector<double> &v0);
  bool is_outside(shape::polyhedron::Polyhedron &, const Vector<double> &v);
  
  bool is_inside(shape::polyhedron::Polyhedron &, const Vector<double> &v, const double r) ;
  bool is_outside(shape::polyhedron::Polyhedron &, const Vector<double> &v, const double r);
  
  bool in_contact1 (shape::polyhedron::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius, Vector<double> &contact_vector);
  bool in_contact2 (shape::polyhedron::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius, Vector<double> &contact_vector);
  
    
  bool check_inside (shape::polyhedron::Polyhedron &, const Vector<Real_t> &v1, const Real_t radius);
  
  bool check_inside_ray (shape::polyhedron::Polyhedron &, const Vector<Real_t> &v1, const int ray_axis);

};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
