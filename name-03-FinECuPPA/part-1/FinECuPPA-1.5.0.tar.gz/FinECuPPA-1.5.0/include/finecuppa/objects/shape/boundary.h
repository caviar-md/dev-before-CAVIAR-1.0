#ifndef FINECUPPA_SHAPE_BOUNDARY_H
#define FINECUPPA_SHAPE_BOUNDARY_H

#include "finecuppa/objects/shape.h"
#include "finecuppa/utility/vector.h"
#include <vector>
FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
class Boundary : public finecuppa::objects::Shape {
  public:
    Boundary (class FinECuPPA *);
    ~Boundary ();
//    bool read(Parser *, class Object_container *);    
    bool read(class finecuppa::Parser *);
    void satisfy_boundary ();
    
    bool inside_check;
    
    bool is_inside (const Vector<double> &);
    bool is_inside (const Vector<double> &, const double r);
    bool in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector);    
    
    //bool is_all (const Vector<double> &); //checks 'is_inside()' if 'inside_check==true'

    std::vector<finecuppa::objects::Shape*> shapes;
    std::vector<int> operators; // 1:and_inside, -1:and_outside, 2:or_inside, -2:or_outside
    bool shape_add;

};
} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE
#endif
 
