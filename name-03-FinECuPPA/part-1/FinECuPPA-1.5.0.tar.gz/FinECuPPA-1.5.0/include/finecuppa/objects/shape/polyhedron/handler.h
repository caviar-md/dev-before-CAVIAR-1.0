#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_HANDLER_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_HANDLER_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/objects/shape/polyhedron/polyhedron.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace shape {
namespace polyhedron {
class Input; 
class Preprocess;
class Postprocess;
class Utility;
class Point_Inside;
class Output;
class Handler : protected Pointers{
public:
  Handler (class FinECuPPA *);
  ~Handler ();
  
  bool read (Parser *);
  bool is_inside (const Vector<double> &v);
  bool is_inside (const Vector<double> &, const double rad);  
  bool in_contact (const Vector<double> &, const double rad, Vector<double> & contact_vector);  
   
protected:
  void  command_parameters (class finecuppa::Parser *);
  void  command_generate ();

  class shape::polyhedron::Input * polyhedron_input;
  class shape::polyhedron::Preprocess * polyhedron_preprocess;
  class shape::polyhedron::Postprocess * polyhedron_postprocess;
  class shape::polyhedron::Utility * polyhedron_utility;  
  class shape::polyhedron::Point_Inside * polyhedron_point_inside;  
  class shape::polyhedron::Output * polyhedron_output;
  
  
  struct finecuppa::objects::shape::polyhedron::Polyhedron polyhedron;   

  Real_t young_modulus;
  std::vector<Real_t> radius;
  
  bool polyhedron_read, output_mesh_tcl, output_normals_tcl, output_edges_tcl, output_mesh_povray;
  bool invert_normals, correct_normals;  
  
};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
