#ifndef FINECUPPA_INTEGRATION_VELOCITY_VERLET_H
#define FINECUPPA_INTEGRATION_VELOCITY_VERLET_H

#include "finecuppa/objects/integration.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

class Velocity_verlet : public Integration {
public:
  Velocity_verlet (class FinECuPPA *);
   ~Velocity_verlet();
  bool read (class finecuppa::Parser *);

protected:

  void step_part_I ();
  void step_part_II ();
   
};

} //integration
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
