#ifndef FINECUPPA_UTILITY_RANDOM_1D_H
#define FINECUPPA_UTILITY_RANDOM_1D_H

#include "finecuppa/utility/pointers.h"
#include <random>
#include <vector>
#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace utility {

class Random_1D : protected Pointers {
 public:
  Random_1D () ;
  Random_1D (class FinECuPPA *) ;    
  Random_1D (class FinECuPPA *, std::string TYPE, double MIN, double MAX, double STDDEV, double MEAN, int SEED) ;
  ~Random_1D () ;
  bool read(Parser *);
  void generate (); // creates the std::mt19937 with given parameters ...    
  double min, max, stddev, mean;
    
  std::string type;
  
  int seed;        
  int num; // number of random atoms or molecules to be created    
  int type_int;
        
  bool generated, generated_u_dist, generated_n_dist; 
    
  std::mt19937 *ran_gen;
  std::uniform_real_distribution<> *u_dist;
  std::normal_distribution<> *n_dist;
    
  protected:
};

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
