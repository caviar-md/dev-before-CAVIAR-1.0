#ifndef FINECUPPA_OBJECT_UTILITY_DISTRIBUTION_H
#define FINECUPPA_OBJECT_UTILITY_DISTRIBUTION_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace shape { class Boundary; }
namespace utility {
class Molecule;
class Atom;
class Distribution : protected Pointers {
 public:
  Distribution (class FinECuPPA *);
  ~Distribution () ;
  bool read (Parser *);    
  
  class shape::Boundary *boundary;
  class Molecule *m_object, *container;
  class Atom *a_object;
  bool boundary_check, a_object_check, m_object_check, container_check;
  
  bool distribute_grid_3D(Parser *);
  bool distribute_random_3D(Parser *)  ;

};

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
