#ifndef FINECUPPA_WRITER_H
#define FINECUPPA_WRITER_H

#include "finecuppa/utility/pointers.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

class Writer : protected Pointers {
 public:
  Writer (class FinECuPPA *);
   virtual ~Writer ( );
  virtual bool read (class finecuppa::Parser *) = 0;

  std::string object_base_class_name, object_class_name, object_name;
 protected:
  clock_t t_start, t_end;
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
