#ifndef FINECUPPA_FINITE_ELEMENT_H
#define FINECUPPA_FINITE_ELEMENT_H

#include "finecuppa/utility/pointers.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

class Finite_element : protected Pointers {
 public:
  Finite_element (class FinECuPPA *);
  virtual ~Finite_element();
  virtual void calculate_acceleration ();
  virtual bool read(class finecuppa::Parser *);//=0;  
  std::string object_base_class_name, object_class_name, object_name;
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
