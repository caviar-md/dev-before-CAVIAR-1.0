#ifndef FINECUPPA_OBJECTS_DOMAIN_BOX_H
#define FINECUPPA_OBJECTS_DOMAIN_BOX_H

#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/vector.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace domain {

class Box : public Domain {
public:
  Box (class FinECuPPA *);
  bool read (class finecuppa::Parser *);
  void calculate_local_domain ();
  void generate ();  

protected:
  
};

} //domain
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
