#ifndef FINECUPPA_DOMAIN_H
#define FINECUPPA_DOMAIN_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Domain : protected Pointers {
public:
  Domain (class FinECuPPA *);
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void calculate_local_domain ();
  virtual void generate() = 0;
  Vector <Real_t> lower_global, upper_global;
  Vector <Real_t> lower_local, upper_local;
  Vector<int> boundary_condition; 
  std::string object_base_class_name, object_class_name, object_name;
protected:
  
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
