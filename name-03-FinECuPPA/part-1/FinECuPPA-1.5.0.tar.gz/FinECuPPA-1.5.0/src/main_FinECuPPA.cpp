#ifdef USE_MD_MPI
#include <mpi.h>
#endif

#include "finecuppa/FinECuPPA.h"

#ifdef USE_FE_MPI
 #ifdef USE_DEALII
  #include <deal.II/base/mpi.h>
 #else
   # error Not implemented, USE_DEALII is required
 #endif
#endif

int main (int argc, char* argv[]) {
#ifdef USE_MD_MPI
 #ifdef USE_FE_MPI
  #ifdef USE_DEALII 
  dealii::Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv, 1);
  #else
   # error Not implemented, USE_DEALII is required
  #endif
  finecuppa::FinECuPPA finecuppa (argc, argv, MPI::COMM_WORLD);  
 #else
  MPI_Init (&argc, &argv);  
  finecuppa::FinECuPPA finecuppa (argc, argv, MPI::COMM_WORLD);
 #endif
#else
 #ifdef USE_FE_MPI
  #ifdef USE_DEALII  
  dealii::Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv, 1); 
  #else
   # error Not implemented, USE_DEALII is required
  #endif  
  finecuppa::FinECuPPA finecuppa (argc, argv); 
 #else
  finecuppa::FinECuPPA finecuppa (argc, argv); 
 #endif
#endif
  try {  
    finecuppa.execute ();
  }
  catch (std::exception &exc) {
    std::cerr << "Exception on processing: " << std::endl
              << exc.what() << std::endl;
  }
  catch (...) {
    std::cerr << "Unknown exception!" << std::endl;  
  } 
#ifdef USE_MD_MPI
 #ifdef USE_FE_MPI
 
 #else
  MPI_Barrier (MPI_COMM_WORLD);
  MPI_Finalize ();
 #endif 
#endif
  return 0;
}


