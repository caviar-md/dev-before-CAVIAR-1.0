#include "finecuppa/structure/object_handler/dictionary.h"

FINECUPPA_NAMESPACE_OPEN

namespace object_handler {


}

FINECUPPA_NAMESPACE_CLOSE
