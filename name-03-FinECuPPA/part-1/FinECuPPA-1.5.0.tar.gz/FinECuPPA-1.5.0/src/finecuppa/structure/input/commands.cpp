#include "finecuppa/structure/input.h"
#include "finecuppa/structure/object_creator.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/tools.h"

#include <map>
#include <cmath>
#include <algorithm>

FINECUPPA_NAMESPACE_OPEN

// used in order to remove 'if' or 'elseif' from the line and get the condition
static std::string remove_the_first_word (const std::string &str) {
  int i = 0;
  while (isblank(str[i])) i++;
  while (!isblank(str[i])) i++;
  while (isblank(str[i])) i++;
  if (i > str.size()) return "";
  return str.substr(i);
}
// commands

char Input::command_read_script_from_file (Parser *parser) {
  auto file_name = parser->get_string();
  std::string st = "read_script_from_file : " +  file_name;
  output->info(st);
  finecuppa::Input inp (fptr, file_name);
  inp.read();
  return true;
}

char Input::command_help (Parser *parser) {
  parser->end_of_line();
  std::cout << "Science Helps People!\n";
  return true;
}

char Input::command_exit_program (Parser *) {
  return false;
}

char Input::command_output (Parser *parser) {
  return output->read (parser);
}

char Input::command_object_container (Parser *) {
  return object_container->read (parser);
}

char Input::command_echo (Parser * parser) {
  std::string st = "";

  while (true) {
    //auto t = parser -> get_val_token();
    auto t = parser -> get_raw_token();
    if (t.kind == Kind::eof) break;
    else if (t.kind == Kind::eol) break;
    else if (t.kind == Kind::string) {
      // having 'get_string()' here may complicate 'kind::plus' conditions
      st += t.string_value;
    } else if (t.kind == Kind::identifier) {
      auto var_name = t.string_value;
      std::map<std::string,object_handler::Dictionary>::iterator it;
      it = object_container->dictionary.find(var_name);
      if (it == object_container->dictionary.end())   {
        error->all (FC_FILE_LINE_FUNC_PARSE, "unknown object name :" + var_name);      
      } else if (it->second.type == object_handler::gdst( "boolean_variable" )) {
        parser-> keep_current_token();
        bool r = parser-> get_bool();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "int_variable" )) {
        parser-> keep_current_token();
        double r = parser-> get_real();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "real_variable" )) {
        parser-> keep_current_token();
        double r = parser-> get_real();
        st += std::to_string(r);
      } else if (it->second.type == object_handler::gdst( "real_3d_vector" )) {
        auto v = object_container -> real_3d_vector [it->second.index];        
        st += "{" + std::to_string(v.x) + ", " + std::to_string(v.y) + ", "
            +  std::to_string(v.z) + "}";
      } else if (it->second.type == object_handler::gdst( "int_3d_vector" )) {
        auto v = object_container -> int_3d_vector [it->second.index];        
        st += "{" + std::to_string(v.x) + ", " + std::to_string(v.y) + ", "
            +  std::to_string(v.z) + "}";
      } else if (it->second.type == object_handler::gdst( "string_variable" )) {
        //st += object_container->string_variable[it->second.index];
        parser-> keep_current_token();
        std::string r = parser-> get_string();
        st += r;
      } else {
        error->all (FC_FILE_LINE_FUNC_PARSE, "this echo type is not implemented yet");      
      }
    } else if (t.kind == Kind::real_number || t.kind == Kind::int_number) {
      // the distinction between 'int_number' and 'real_number' is not nessecary
      // and it just complicates the code.
      parser-> keep_current_token();
      double r = parser-> get_real();
      st += std::to_string(r);
    } else if (t.kind == Kind::plus || t.kind == Kind::minus) {
      // the same as above
      parser-> keep_current_token();
      double r = parser-> get_real();
      st += std::to_string(r);
    } else {
      error->all (FC_FILE_LINE_FUNC_PARSE, "this echo type is not implemented yet");      
    }
  }

  std::cout << st << std::endl;
  return true;
}

char Input::command_print (Parser *parser) {
  std::string st = parser -> get_string();
  std::cout << st << std::endl;

//  std::string dollars = "$";
//  std::size_t found = st.find(dollars);

  return true;
}

char Input::command_evaluate(const std::string &str) {
  std::string st = str + "\n";
  std::istringstream iss (st);
  //std::cout << "iss: " << iss.str() << std::endl;
  finecuppa::Input inp (fptr, iss);
  inp.read();
  return true;
}

char Input::command_evaluate (Parser *parser) {
  command_evaluate ( parser -> get_string() );
  return true;
}

// TODO: complete
char Input::command_compare_int (Parser *parser) {
  return command_compare_real(parser);
}

char Input::command_compare_real (const std::string &st) {
  std::istringstream iss (st);
  Parser p(fptr, iss);
  //std::cout << "X: " << st << " , result: " << p.compare_real() << std::endl;
  return p.compare_real();
}

char Input::command_compare_real (Parser *parser) {
  std::string st = parser->rest_of_line();
  std::istringstream iss (st);
  Parser p(fptr, iss);
  bool result =  p.compare_real();
  //std::cout << "X: " << st << " , result: " << result << std::endl;
  parser->go_to_next_line();
  return result;
}

// TODO: complete
char Input::command_compare (Parser *parser) {
  return command_compare_real(parser);
}

char Input::command_calculate(const std::string &str) {
  std::string st = str + "\n";
  std::istringstream iss (st);
  //std::cout << "iss: " << iss.str() << std::endl;
  finecuppa::Input inp (fptr, iss);
  inp.read();
  return true;
}

char Input::command_calculate (Parser *parser) {
  int num_of_condition_operators = 0;
  int condition_operator = 10;
  double left_side = 0;
  double right_side = 0;
  bool operator_called = false;
  while (true) {
    auto t = parser -> get_raw_token();
    if (t.kind == Kind::eof) break;
    else if (t.kind == Kind::eol) break;
    else if (t.kind == Kind::smaller) { //-2
      ++num_of_condition_operators; operator_called = true;
      condition_operator = -2;
    } else if (t.kind == Kind::larger) { //+2
      ++num_of_condition_operators; operator_called = true;
      condition_operator = +2;
    } else if (t.kind == Kind::eqsmaller) { //-1
      ++num_of_condition_operators; operator_called = true;
      condition_operator = -1;
    } else if (t.kind == Kind::eqlarger) { //+1
      ++num_of_condition_operators; operator_called = true;
      condition_operator = +1;
    } else if (t.kind == Kind::equal) { // 0
      ++num_of_condition_operators; operator_called = true;
      condition_operator = 0;
    } else {
      parser -> keep_current_token();
      if (operator_called) {right_side = parser->get_real(); break;}
      else left_side = parser->get_real();
    } 
  }

  if (num_of_condition_operators == 0)
    error->all (FC_FILE_LINE_FUNC_PARSE, "expected a conditional operator" ); 

  if (num_of_condition_operators > 1)
    error->all (FC_FILE_LINE_FUNC_PARSE, "only one conditional operator is allowed" ); 

  //std::cout <<"left: " << left_side << " , right: " << right_side << std::endl;

  if (condition_operator == -2) return (left_side <  right_side);
  if (condition_operator == -1) return (left_side <= right_side);
  if (condition_operator ==  0) return (left_side == right_side);
  if (condition_operator ==  1) return (left_side >= right_side);
  if (condition_operator ==  2) return (left_side >  right_side);

  return true;
}


char Input::command_function(finecuppa::Parser*) {
  return true;
}
char Input::command_end_function(finecuppa::Parser*) {
  return true;
}
char Input::command_class(finecuppa::Parser*) {
  return true;
}
char Input::command_end_class(finecuppa::Parser*) {
  return true;
}
char Input::command_read(finecuppa::Parser*) {
  return true;
}
char Input::command_include(finecuppa::Parser*) {
  return true;
}
char Input::command_import(finecuppa::Parser*) {
  return true;
}
char Input::command_exit(finecuppa::Parser*) {
  return true;
}


char Input::command_compare_string(finecuppa::Parser*) {
  return true;
}
char Input::command_delete(finecuppa::Parser*) {
  return true;
}


FINECUPPA_NAMESPACE_CLOSE

