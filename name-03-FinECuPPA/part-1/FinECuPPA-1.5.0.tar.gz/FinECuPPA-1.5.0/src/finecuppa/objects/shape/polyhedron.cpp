#include "finecuppa/objects/shape/polyhedron.h"
#include "finecuppa/objects/shape/polyhedron/handler.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {

Polyhedron::Polyhedron (FinECuPPA *fptr) : Shape {fptr},
  polyhedron_handler {new shape::polyhedron::Handler{fptr}}
  {}

Polyhedron::~Polyhedron () { 
  delete polyhedron_handler;  
}

bool Polyhedron::read(finecuppa::Parser * parser) {
  return polyhedron_handler -> read (parser);
}

bool Polyhedron::is_inside(const Vector<double> &v) {
  return polyhedron_handler -> is_inside (v); 
}

bool Polyhedron::is_inside(const Vector<double> &v, const double r) {
  return polyhedron_handler -> is_inside (v, r); 
}


bool Polyhedron::in_contact(const Vector<double> &v, const double r, Vector<double> & contact_vector) {
  return polyhedron_handler -> in_contact(v, r, contact_vector);
}

} //shape
} //objects
FINECUPPA_NAMESPACE_CLOSE


