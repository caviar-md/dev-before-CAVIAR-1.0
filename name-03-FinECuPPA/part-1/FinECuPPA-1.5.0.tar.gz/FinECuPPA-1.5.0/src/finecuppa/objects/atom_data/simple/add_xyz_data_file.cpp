#include "finecuppa/objects/atom_data/simple.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/utility/atom.h"
#include "finecuppa/objects/utility/molecule.h"
#include "finecuppa/objects/utility/element.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace atom_data {

bool Simple::add_xyz_data_file (finecuppa::Parser *parser) {
  output->info("Simple::add_xyz_data_file ");

  std::string xyz_file_name = "";
  bool last_frame = false;
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"last_frame")) {
      last_frame = true;
    } else if (string_cmp(t,"file_name")) {
      const auto token = parser->get_val_token();
      const auto file_name = token.string_value;
//      GET_A_STRING(xyz_file_name,"","")
      xyz_file_name = file_name;
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");

  }

  int start_line = 1;

  if (last_frame) {
    int i = 1;
    int num_xyz_frames = 0;
//    finecuppa::Parser *pf (xyz_file_name);
    finecuppa::Parser pf (fptr, xyz_file_name);
    auto t = pf.get_val_token();
    while (t.kind != Kind::eof) {
      if (t.kind == Kind::identifier) {
        auto ts = t.string_value;
        if (string_cmp(ts,"atom") || string_cmp(ts,"atoms") ) {
          ++num_xyz_frames;
          if (i==1) error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown xyz format");
          start_line = i-1;
        }
      }
      pf.end_of_line();
      t = pf.get_val_token();
      ++i;
    }
    std::string st1 = "Num. of total xyz frames found : " + std::to_string(num_xyz_frames);    
    std::string st2 = "Last xyz frame found at line number : " + std::to_string(i);
    output->info(st1);
    output->info(st2);
  }


  finecuppa::Parser pf (fptr, xyz_file_name);
  for (int i = 1; i <start_line; ++i) {
    pf.end_of_line();
  }
/*
  int num_atoms = pf.get_literal_int();
  std::cout << "num_atoms : " << num_atoms << std::endl;
      pf.end_of_line();
  auto st = pf.get_val_token();
  std::cout << "st : " << st.string_value << std::endl;
      pf.end_of_line();
*/
  int num_atoms = pf.get_literal_int();
  pf.end_of_line();
  std::string st = " Number of atoms found at the inputted xyz file : " + std::to_string(num_atoms) ;
  if (num_atoms==0) error->all(FC_FILE_LINE_FUNC, "no atom found in the xyz file. Something is wrong.");
  output->info(st);
  pf.get_val_token();
  pf.end_of_line();
  for (int i = 0; i <num_atoms; ++i) {
    auto type = pf.get_literal_int();
    auto x = pf.get_literal_real();
    auto y = pf.get_literal_real();
    auto z = pf.get_literal_real();
    pf.end_of_line();
    auto id = get_global_id();
    auto pos = Vector<Real_t> {x, y, z};
    auto vel = Vector<Real_t> {0.0, 0.0, 0.0};
    add_atom (id, type, pos, vel);
    //std::cout << i << " "<< type << " " << x << " " << y << " " << z << std::endl;
  }

  return in_file;
}



} //atom_data
} //objects
FINECUPPA_NAMESPACE_CLOSE

