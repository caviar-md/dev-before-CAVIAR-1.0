#include "finecuppa/objects/domain/box.h"
#include "finecuppa/structure/communicator.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace domain {

Box::Box (FinECuPPA *fptr) : Domain{fptr} {}

bool Box::read (finecuppa::Parser *parser) {
  output->info("Domain Box read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"lower_global.x") || string_cmp(t,"xmin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.x,"","")
    } else if (string_cmp(t,"upper_global.x") || string_cmp(t,"xmax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.x,"","")
    } else if (string_cmp(t,"lower_global.y") || string_cmp(t,"ymin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.y,"","")
    } else if (string_cmp(t,"upper_global.y") || string_cmp(t,"ymax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.y,"","")
    } else if (string_cmp(t,"lower_global.z") || string_cmp(t,"zmin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.z,"","")
    } else if (string_cmp(t,"upper_global.z") || string_cmp(t,"zmax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.z,"","")
    } else if (string_cmp(t,"boundary_condition") || string_cmp(t,"bc") ) {
      GET_OR_CHOOSE_A_INT_3D_VECTOR(boundary_condition,"","")
    } else if (string_cmp(t,"generate")) {
      generate();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}
void Box::generate() {
  calculate_local_domain ();
  std::string s = "boundary condition: ";
  s += std::to_string(boundary_condition.x) + " "
     + std::to_string(boundary_condition.y) + " "
     + std::to_string(boundary_condition.z);
  output->info (s);
}

void Box::calculate_local_domain () {
  lower_local.x = lower_global.x + (upper_global.x - lower_global.x) * comm->grid_index_x / comm->nprocs_x;
  lower_local.y = lower_global.y + (upper_global.y - lower_global.y) * comm->grid_index_y / comm->nprocs_y;
  lower_local.z = lower_global.z + (upper_global.z - lower_global.z) * comm->grid_index_z / comm->nprocs_z;
  
  upper_local.x = lower_global.x + (upper_global.x - lower_global.x) * (comm->grid_index_x+1) / comm->nprocs_x;
  upper_local.y = lower_global.y + (upper_global.y - lower_global.y) * (comm->grid_index_y+1) / comm->nprocs_y;
  upper_local.z = lower_global.z + (upper_global.z - lower_global.z) * (comm->grid_index_z+1) / comm->nprocs_z;
/*  
std::cout <<" xlg:" << lower_global.x << " xug: " << upper_global.x 
          <<" ylg:" << lower_global.y << " yug: " << upper_global.y
          <<" zlg:" << lower_global.z << " zug: " << upper_global.z << std::endl;
std::cout <<" xll:" << lower_local.x  << " xul: " << upper_local.x 
          <<" yll:" << lower_local.y  << " yul: " << upper_local.y
          <<" zll:" << lower_local.z  << " zul: " << upper_local.z << std::endl;
*/
}

} //domain
} //objects
FINECUPPA_NAMESPACE_CLOSE

