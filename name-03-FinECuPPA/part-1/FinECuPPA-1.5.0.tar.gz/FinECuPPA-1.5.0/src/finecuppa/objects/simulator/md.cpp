#include "finecuppa/objects/simulator/md.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace simulator {

Md::Md (FinECuPPA *fptr) : Simulator{fptr}, integration{nullptr}
{
  use_time = false;
  use_step = false;
}

Md::~Md () {}

bool Md::read (finecuppa::Parser *parser) {
  output->info("simulator md: read:");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"integration") || string_cmp(t,"set_integration")) {
      FIND_OBJECT_BY_NAME(integration,it)
      integration = object_container->integration[it->second.index];
    } else if (string_cmp(t,"time_step")
          || string_cmp(t,"timestep") || string_cmp(t,"dt")) {
      GET_OR_CHOOSE_A_REAL(time_step,"","")
    } else if (string_cmp(t,"initial_time")) {
      GET_OR_CHOOSE_A_REAL(initial_time,"","")
      use_time = true;
    } else if (string_cmp(t,"final_time")) {
      GET_OR_CHOOSE_A_REAL(final_time,"","")
      use_time = true;
    } else if (string_cmp(t,"initial_step")) {
      GET_OR_CHOOSE_A_INT(initial_step,"","")
      use_step = true;
    } else if (string_cmp(t,"final_step")) {
      GET_OR_CHOOSE_A_INT(final_step,"","")
      use_step = true;
    } else if (string_cmp(t,"run")) {
      run();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

bool Md::run () {
  output->info ("Md started.");
  verify_settings ();
  setup ();

  integration->run (time_step, initial_step, final_step);

  cleanup ();
  output->info ("Md finished.");
  std::string s = "simulation time: " + std::to_string(total_time) + " (seconds)";
  output->info (s, 3);
  return true; //WARNING
}

void Md::verify_settings () {
  if (integration==nullptr) error->all ("Md::verify_settings: integration_set = false");
  if (use_time && use_step)
    error->all ("simulator md: verify_settings: cannot use both 'time' and 'step'.");
  if (!(use_time || use_step))
    error->all ("simulator md: verify_settings: please assign 'time' or 'step' variables.");

//  if (self_ghost_check())
//    error->all (FC_FILE_LINE_FUNC_PARSE, "Self ghost can happen. Force field cutoff is larger than half of a domain.");
/*
bool Simulation::self_ghost_check () {
  const auto x_llow = domain->lower_local.x;
  const auto x_lupp = domain->upper_local.x;
  const auto y_llow = domain->lower_local.y;
  const auto y_lupp = domain->upper_local.y;
  const auto z_llow = domain->lower_local.z;
  const auto z_lupp = domain->upper_local.z;

  const auto x_width = x_lupp - x_llow;
  const auto y_width = y_lupp - y_llow;
  const auto z_width = z_lupp - z_llow;

  const auto cutoff = force_field->cutoff;
  if (2*cutoff>x_width || 2*cutoff>y_width || 2*cutoff>z_width)
    return true;
  return false;
}*/

}

void Md::setup () {
  output->open_files ();
  t_start = clock();
  if (use_time) {
    initial_step = (int) initial_time/time_step;
    final_step = (int) final_time/time_step;
  }
}

void Md::cleanup () {
  output->close_files ();
  t_end = clock();
  total_time =  ( (float)t_end - (float)t_start ) / CLOCKS_PER_SEC;
}

} //simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

