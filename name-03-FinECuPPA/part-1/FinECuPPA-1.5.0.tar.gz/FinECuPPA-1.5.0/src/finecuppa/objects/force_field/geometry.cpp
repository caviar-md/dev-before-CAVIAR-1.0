#include "finecuppa/objects/force_field/geometry.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/shape/boundary.h"
#include "finecuppa/objects/atom_data.h"
#include <string>
#include <cmath>
#include <fstream>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Geometry::Geometry (FinECuPPA *fptr) : Force_field {fptr}, 
shape_size_warning{false}
{ 
  output->info ("A geometry force field is created.");
  young_modulus = 100.0;
  dissip_coef = 0.0;
}

Geometry::~Geometry () { 

}

bool Geometry::read (class Parser *parser) {

  output->info("Force_field geometry read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"cutoff")) {
      error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff is not implemented in force_field geometry");  
    } else if (string_cmp(t,"add_boundary")) {
      FIND_OBJECT_BY_NAME(boundary,it)
      shape.push_back (object_container->boundary[it->second.index]);
    }  else if (string_cmp(t,"add_shape")) {
      FIND_OBJECT_BY_NAME(shape,it)
      shape.push_back (object_container->shape[it->second.index]);
    } else if (string_cmp(t,"young_modulus")) {
      GET_OR_CHOOSE_A_REAL(young_modulus,"","")
    } else if (string_cmp(t,"dissip_coef")) {
      GET_OR_CHOOSE_A_REAL(dissip_coef,"","")
    } else if (string_cmp(t,"radius")) {
      GET_A_STDVECTOR_REAL_ELEMENT(radius)
      if (vector_value < 0)  error->all (FC_FILE_LINE_FUNC_PARSE, "radius have to be non-negative.");      
    } else if (string_cmp(t,"set_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist = object_container->neighborlist[it->second.index];
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  
  return in_file;
}


void Geometry::calculate_acceleration () {
  if (atom_data == nullptr) error->all("Geometry::calculate_acceleration: atom_data = nullptr");
  //if (neighborlist == nullptr) error->all("Geometry:calculate_acceleration: neighborlist = nullptr");
  if ((shape.size()==0) && (!shape_size_warning)) {
    output->warning("Geometry::calculate_acceleration: shape.size()==0");
    shape_size_warning = true;  
  }
  const auto &pos = atom_data -> owned.position;
  const auto &vel = atom_data -> owned.velocity;  
  auto &acc = atom_data -> owned.acceleration;
  for (unsigned int i=0;i<pos.size();++i) {
     const auto type_i = atom_data -> owned.type [i] ;
    const auto mass_i = atom_data -> owned.mass [ type_i ];   
    const auto r = radius [ type_i ];
    //Vector <Real_t> contact_vector {0,0,0};            
    for (unsigned int j=0; j<shape.size();++j) {
      Vector <Real_t> contact_vector {0,0,0};        
      if (shape[j] -> in_contact(pos[i], r, contact_vector)) {
        acc[i] -= contact_vector*young_modulus/mass_i;
        acc[i] -= contact_vector*(vel[i]*contact_vector)*dissip_coef/(mass_i*(contact_vector*contact_vector));
      }
    }
  }
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

