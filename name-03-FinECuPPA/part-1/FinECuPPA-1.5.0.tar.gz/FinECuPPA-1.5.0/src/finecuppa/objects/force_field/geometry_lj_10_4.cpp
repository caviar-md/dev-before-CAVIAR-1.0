#include "finecuppa/objects/force_field/geometry_lj_10_4.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/shape/boundary.h"
#include "finecuppa/objects/atom_data.h"
#include <string>
#include <cmath>
#include <fstream>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Geometry_lj_10_4::Geometry_lj_10_4 (FinECuPPA *fptr) : Force_field {fptr},
shape_size_warning{false} { 
  output->info ("A geometry_lj_10_4 force field is created.");
}

Geometry_lj_10_4::~Geometry_lj_10_4 () { 

}

bool Geometry_lj_10_4::read (class Parser *parser) {

  output->info("Force_field geometry read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
      if (cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "Force field cutoff have to non-negative.");    
    } else if (string_cmp(t,"add_boundary")) {
      FIND_OBJECT_BY_NAME(boundary,it)
      shape.push_back (object_container->boundary[it->second.index]);
    }  else if (string_cmp(t,"add_shape")) {
      FIND_OBJECT_BY_NAME(shape,it)
      shape.push_back (object_container->shape[it->second.index]);
    } else if (string_cmp(t,"wall_number_density")) {
      GET_OR_CHOOSE_A_REAL(wall_number_density,"","")
      if (cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "wall_number_density have to non-negative.");    
    } else if (string_cmp(t,"epsilon")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(epsilon)
      if (vector_value < 0)  error->all (FC_FILE_LINE_FUNC_PARSE, "Epsilon have to be non-negative.");      
    }  else if (string_cmp(t,"sigma")) {
      GET_A_STDVECTOR_STDVECTOR_REAL_ELEMENT(sigma)
      if (vector_value < 0)  error->all (FC_FILE_LINE_FUNC_PARSE, "Sigma have to be non-negative.");            
    } else if (string_cmp(t,"set_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist = object_container->neighborlist[it->second.index];
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, " Unknown variable or command");

  }
  
  return in_file;
}


void Geometry_lj_10_4::calculate_acceleration () {
  if (atom_data == nullptr) error->all("Geometry_lj_10_4::calculate_acceleration: atom_data = nullptr");
//if (neighborlist == nullptr) error->all("Geometry:calculate_acceleration: neighborlist = nullptr");
  if ((shape.size()==0) && (!shape_size_warning)) {
    output->warning("Geometry::calculate_acceleration: shape.size()==0");
    shape_size_warning = true;  
  }
  const auto &pos = atom_data -> owned.position;
//const auto &vel = atom_data -> owned.velocity;  
  auto &acc = atom_data -> owned.acceleration;
  for (unsigned int i=0;i<pos.size();++i) {
     const auto type_i = atom_data -> owned.type [i] ;
    const auto mass_i = atom_data -> owned.mass [ type_i ];   
    for (unsigned int j=0; j<shape.size();++j) {
      Vector <Real_t> contact_vector {0,0,0};        
      if (shape[j] -> in_contact(pos[i], cutoff, contact_vector)) { // NOTE the 'CUTOFF' instead of particle radius
/*
        auto eps_ij = epsilon [0][type_i];
        auto sig_ij = sigma   [0][type_i];
        auto sig_ij_inv = 1.0 / sig_ij;
        auto force_coef = 2.0 * 3.141592653589 * eps_ij * sig_ij * sig_ij * wall_number_density;
        
        auto r_sq     = contact_vector * contact_vector;
//      auto r_sq_inv = 1.0 / r_sq;
        auto r_norm   = std::sqrt (r_sq);
        auto r_inv    = 1.0 / r_norm;
        
        if (r_sq > cutoff*cutoff) continue;
        
        auto rho      = sig_ij * r_inv;
        auto rho_sq   = rho * rho;
        auto rho_5    = rho_sq * rho_sq * rho;
        
        auto r_cut        = cutoff;
//      auto r_cut_sq     = r_cut * r_cut;
//      auto r_cut_sq_inv = 1.0 / r_cut_sq;
        auto r_cut_norm   = r_cut;
        auto r_cut_inv    = 1.0 / r_cut_norm;
        
        auto rho_cut      = sig_ij * r_cut_inv;
        auto rho_cut_inv  = 1.0 / rho_cut;
        auto rho_cut_sq   = rho_cut * rho_cut;
        auto rho_cut_5    = rho_cut_sq * rho_cut_sq * rho_cut;
                
        auto force_norm     = force_coef * 4.0 *  ( - (rho_5*rho_5*r_inv)               + (rho_5*sig_ij_inv));
        auto force_norm_cut = force_coef * 4.0 *  ( - (rho_cut_5*rho_cut_5*rho_cut_inv) + (rho_cut_5*sig_ij_inv));
        
        auto force = (force_norm - force_norm_cut) * r_inv * contact_vector;
      
        acc[i] += force/mass_i;
*/
        auto dr = contact_vector; 
        auto r_sq = dr*dr;
        if (r_sq > cutoff*cutoff) continue;
        auto eps_ij   = epsilon [0] [type_i];
        auto sigma_ij =  sigma [0] [type_i];

        auto r_c_sq_inv    = 1/(cutoff*cutoff);
        auto rho_c_sq_inv  = sigma_ij*sigma_ij*r_c_sq_inv;
        auto rho_c_6_inv   = rho_c_sq_inv*rho_c_sq_inv*rho_c_sq_inv;
        auto rho_c_12_inv  = rho_c_6_inv*rho_c_6_inv;
      
        auto r_sq_inv      = 1/r_sq;
        auto rho_sq_inv    = sigma_ij*sigma_ij*r_sq_inv;
        auto rho_6_inv     = rho_sq_inv*rho_sq_inv*rho_sq_inv;
        auto rho_12_inv    = rho_6_inv*rho_6_inv;

        auto force = 4*eps_ij*(-12*rho_12_inv*r_sq_inv + 6*rho_6_inv*r_sq_inv + 
                             +12*rho_c_12_inv*r_c_sq_inv - 6*rho_c_6_inv*r_c_sq_inv   ) * dr;
/*                             
        auto dr_norm = std::sqrt(r_sq);
        auto r_m_rc = dr_norm-cutoff;
        potential_energy += 4*eps_ij*(+rho_12_inv - rho_6_inv 
                                       -rho_c_12_inv + rho_c_6_inv 
                                      +4.0*eps_ij*(-12*rho_c_12_inv*r_c_sq_inv +6*rho_c_6_inv*r_c_sq_inv )*r_m_rc*dr_norm);
*/
        acc[i] += force / mass_i;

       

      }
    }
  }
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

