#ifdef USE_DEALII

#include "finecuppa/objects/force_field/dealii_poisson_ewald.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Vector<double> Dealii_poisson_ewald::dipole_field () {
  error->all(FC_FILE_LINE_FUNC,"not implemented yet");
  return Vector<double> {0,0,0};
}

Vector<double> Dealii_poisson_ewald::slab_geometry_correction_field (const Vector<double> &r) {
  error->all(FC_FILE_LINE_FUNC,"not implemented yet");
  return r;
}

Vector<double> Dealii_poisson_ewald::ewald_total_field (const Vector<double> &r) {
  auto field = k_space_field(r) + r_space_field(r);
  if (slab_geometry)
    field += slab_geometry_correction_field(r);
  if (dipole)
    field += dipole_field_vector;
  return field;
}

Vector<double> Dealii_poisson_ewald::r_space_field (const Vector<double> &r) {

  Vector<double> field {0,0,0};

  const auto &pos = atom_data -> owned.position;
  const unsigned pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  const auto pos_i = r;

  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;
  const auto nb_i = neighborlist -> neigh_bin_index (r);

  for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];

    for (unsigned i = 0; i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++i) {

      unsigned int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][i];

      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      

      const auto r_ij = pos_i - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*FC_PIS_INV*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);


      field +=  k_electrostatic * charge_j *sum_r;          
    }
  }

  return field;
}

Vector<double> Dealii_poisson_ewald::k_space_field (const Vector<double> &r) {
  Vector<double> field {0,0,0};

  static std::complex<double> ii(0.0, 1.0);    

  std::complex<double> sum_kx (0.0, 0.0);
  std::complex<double> sum_ky (0.0, 0.0);
  std::complex<double> sum_kz (0.0, 0.0);

  for (int k = 0; k<n_k_vectors; ++k) {

    const auto sum_j_c = std::conj(potential_k_coef_cmplx[k]);
    const auto c = field_k_coef[k] * sum_j_c * std::exp(ii*(k_vector[k]*r));   

    sum_kx += k_vector[k].x * c;
    sum_ky += k_vector[k].y * c;
    sum_kz += k_vector[k].z * c;

  }  

  const double sum_jx = std::imag(sum_kx);
  const double sum_jy = std::imag(sum_ky);
  const double sum_jz = std::imag(sum_kz);

  Vector<double> sv {sum_jx, sum_jy, sum_jz};

  const auto sum = FC_4PI *  sv ;

  field =  k_electrostatic * l_xyz_inv * sum;

  return field;
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE
#endif
