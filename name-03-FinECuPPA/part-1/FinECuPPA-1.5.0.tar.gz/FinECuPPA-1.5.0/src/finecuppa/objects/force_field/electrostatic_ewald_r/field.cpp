#include "finecuppa/objects/force_field/electrostatic_ewald_r.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/long_range_solver.h"
#include "finecuppa/utility/macro_constants.h"

#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Vector<double> Electrostatic_ewald_r::field (const Vector<double> &r) {

  Vector<double> field {0,0,0};

  const auto &pos = atom_data -> owned.position;
  const unsigned pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  const auto pos_i = r;

  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;
  const auto nb_i = neighborlist -> neigh_bin_index (r);

  for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];

    for (unsigned i = 0; i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++i) {

      unsigned int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][i];

      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      

      const auto r_ij = pos_i - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*FC_PIS_INV*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);


      field +=  k_electrostatic * charge_j *sum_r;          
    }
  }

  return field;
}

Vector<double> Electrostatic_ewald_r::field (const int i) {
  Vector<double> field {0,0,0};

  error->all("not implemented. needs fixs for neighlist or maybe impossible.");

  const auto &pos = atom_data -> owned.position;
  const unsigned pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  const auto &nlist = neighborlist -> neighlist;

  const auto pos_i = atom_data->owned.position [i];

  for (auto j : nlist[i]) {
      double coef = 2.0; // ewald: 'coef=2' for owned in 'neighlist'. Not for binlist.
      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        coef = 1.0; // ewald:'coef=1' for ghost in 'neighlist'. Not for binlist.
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      

      const auto r_ij = pos_i - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*FC_PIS_INV*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);

      field +=  coef * k_electrostatic * charge_j *sum_r;    
   
  }

  return field;
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

