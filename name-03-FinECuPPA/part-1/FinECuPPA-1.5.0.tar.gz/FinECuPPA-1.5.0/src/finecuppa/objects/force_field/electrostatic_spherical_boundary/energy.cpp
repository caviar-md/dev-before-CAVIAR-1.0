#include "finecuppa/objects/force_field/electrostatic_spherical_boundary.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

double Electrostatic_spherical_boundary::energy () {
  // XXX scheme using potential formula.
  const auto &pos = atom_data -> owned.position;    
  double energy_r = 0 ;
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    //energy_r += charge_j * potential(j); // 
    energy_r += charge_j * potential(pos [j]); //
  }

  // there's no particle-particle interaction. only image-particle. so there
  // will be no '0.5' coefficient for energy.
  return energy_r ;
}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

