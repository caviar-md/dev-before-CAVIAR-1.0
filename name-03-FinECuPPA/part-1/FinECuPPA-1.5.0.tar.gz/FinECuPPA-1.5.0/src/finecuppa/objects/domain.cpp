#include "finecuppa/objects/domain.h"
#include "finecuppa/structure/communicator.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Domain::Domain (FinECuPPA *fptr) : Pointers{fptr}, boundary_condition{Vector<int> {0,0,0}} {}

void Domain::calculate_local_domain () {
  lower_local.x = lower_global.x + (upper_global.x - lower_global.x) * comm->grid_index_x / comm->nprocs_x;
  lower_local.y = lower_global.y + (upper_global.y - lower_global.y) * comm->grid_index_y / comm->nprocs_y;
  lower_local.z = lower_global.z + (upper_global.z - lower_global.z) * comm->grid_index_z / comm->nprocs_z;
  
  upper_local.x = lower_global.x + (upper_global.x - lower_global.x) * (comm->grid_index_x+1) / comm->nprocs_x;
  upper_local.y = lower_global.y + (upper_global.y - lower_global.y) * (comm->grid_index_y+1) / comm->nprocs_y;
  upper_local.z = lower_global.z + (upper_global.z - lower_global.z) * (comm->grid_index_z+1) / comm->nprocs_z;
/*  
std::cout <<" xlg:" << lower_global.x << " xug: " << upper_global.x 
          <<" ylg:" << lower_global.y << " yug: " << upper_global.y
          <<" zlg:" << lower_global.z << " zug: " << upper_global.z << std::endl;
std::cout <<" xll:" << lower_local.x  << " xul: " << upper_local.x 
          <<" yll:" << lower_local.y  << " yul: " << upper_local.y
          <<" zll:" << lower_local.z  << " zul: " << upper_local.z << std::endl;
*/
}

} //objects

FINECUPPA_NAMESPACE_CLOSE

