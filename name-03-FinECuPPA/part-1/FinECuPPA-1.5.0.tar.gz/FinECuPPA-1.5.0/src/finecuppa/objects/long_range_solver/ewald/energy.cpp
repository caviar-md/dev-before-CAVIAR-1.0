#include "finecuppa/objects/long_range_solver/ewald.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

#include <cmath>
#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {


double Ewald::k_space_energy () {
///*
  const auto &pos = atom_data -> owned.position;    
  const std::complex<double> ii(0.0, 1.0);    
  double sum_k = 0.0;

  for (int i = 0; i<n_k_vectors; ++i) {

    std::complex<double> rho (0,0);
    for (unsigned int j=0;j<pos.size();++j) {
      const auto type_j = atom_data -> owned.type [j] ;
      const auto charge_j = atom_data -> owned.charge [ type_j ];

      rho += charge_j * std::exp(-ii*(k_vector[i]*pos[j]));
    }
    const double rho_norm = std::abs(rho * std::conj(rho));
    sum_k += field_k_coef[i] * rho_norm;
  }    

  return 0.5 * l_xyz_inv * four_pi * sum_k;
//*/
/*
  const auto &pos = atom_data -> owned.position;    
  double energy_k = 0;
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    energy_k += charge_j * k_space_potential(pos[j]);
  }
  return 0.5 * energy_k ;   
*/

}

double Ewald::r_space_energy () {
  const auto &pos = atom_data -> owned.position;    
  double energy_r {0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    energy_r += charge_j * r_space_potential(pos[j]);
  }
  return 0.5 * energy_r ;
}

double Ewald::self_energy () {
  const auto &pos = atom_data -> owned.position;    
  double sum_j {0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;  
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    sum_j += charge_j* charge_j;  //
  }
  return - pi_root_inv*alpha*sum_j;
}

double Ewald::dipole_energy () {
  Vector<double> sum_j {0, 0, 0};
  const auto &pos = atom_data -> owned.position;  
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];   
    sum_j += charge_j* pos[j];
  }
  double coef = 2.0 * M_PI * l_xyz_inv/(1+2*epsilon_dipole);
  return coef*(sum_j*sum_j);
}

double Ewald::slab_geometry_correction_energy () {
  return 0;
}

double Ewald::total_energy () {
  double sum_energy = k_space_energy()+r_space_energy()+self_energy();
  if (dipole)
    sum_energy += dipole_energy();
  if (slab_geometry)
    sum_energy += slab_geometry_correction_energy();
  return sum_energy;
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

