#include "finecuppa/objects/long_range_solver/pppm.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {

PPPM::PPPM (FinECuPPA *fptr) :  Long_range_solver{fptr} { }

PPPM::~PPPM () {}

bool PPPM::read (finecuppa::Parser *parser) {
  output->info("PPPM read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"cutoff")) {
    }
  }
  return in_file;
}

void PPPM::calculate () {}



} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

