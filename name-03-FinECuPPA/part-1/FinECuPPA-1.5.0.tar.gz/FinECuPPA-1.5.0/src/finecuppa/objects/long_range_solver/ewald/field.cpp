#include "finecuppa/objects/long_range_solver/ewald.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/neighborlist.h"

#include <cmath>
#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {

Vector<double> Ewald::k_space_field (const Vector<double> &r) {
  const auto &pos = atom_data -> owned.position;
  Vector<double> field_k {0, 0, 0};

  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];      
    const auto r_ij = r - pos[j]; 
    Vector<double> sum {0, 0, 0};
    for (int k = 0; k < n_k_vectors; ++k) {
      sum +=  k_vector[k] * field_k_coef[k] * std::sin(k_vector[k]*r_ij) ;    
    } 
    field_k += charge_j * sum;
  }
  return four_pi * field_k * l_xyz_inv;
}

Vector<double> Ewald::k_space_field (int i) {
  return k_space_field (atom_data -> owned.position[i]);
}

Vector<double> Ewald::r_space_field (const Vector<double> &r) {


/*
  const auto &pos = atom_data -> owned.position;
  const int pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;

  Vector<double> field_r {0, 0, 0};

  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;

  const auto nb_i = neighborlist -> neigh_bin_index (r);

  for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];
    for (unsigned i = 0; i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++i) {

      int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][i];
      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      
      const auto r_ij = r - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*pi_root_inv*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);

      field_r +=  charge_j *sum_r;    
    }
  }
  return field_r ;
*/
  return r;
}     

Vector<double> Ewald::r_space_field (int i) {
//  return k_space_field (atom_data -> owned.position[i]);

  const auto &pos = atom_data -> owned.position;
  const auto pos_size = pos.size();
  const auto alpha_sq = alpha*alpha;
  const auto r = pos[i];
  Vector<double> field_r {0, 0, 0};

//auto cutoff_sq = cutoff_r * cutoff_r;
  const auto &nlist = neighborlist -> neighlist;
  for (auto j : nlist[i]) {
      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ];      
      const auto r_ij = r - pos_j;

      if (r_ij.x==0 && r_ij.y==0 && r_ij.z==0) continue;

      const auto rijml = r_ij;
      const auto rijml_sq = rijml*rijml;
      const auto rijml_norm = std::sqrt(rijml_sq);
      const auto erfc_arg = alpha*rijml_norm;

      //if (erfc_arg > erfc_cutoff) continue; 

      const auto sum_r = (2*alpha*pi_root_inv*std::exp(-alpha_sq*rijml_sq) 
                       + std::erfc(erfc_arg) / rijml_norm )*(rijml/rijml_sq);

      field_r +=  charge_j *sum_r;    
    
  }
  return field_r ;
}     

Vector<double> Ewald::dipole_field () {
  const auto &pos = atom_data -> owned.position;
  Vector<double> sum_j {0, 0, 0};
  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];   
    sum_j += charge_j* pos[j];
  }
  return four_pi * l_xyz_inv * sum_j / (1+2*epsilon_dipole);
}

Vector<double> Ewald::slab_geometry_correction_field (const Vector<double> &r) {
/*
  const auto &pos = atom_data -> owned.position;
  Vector<double> field_k {0, 0, 0};

  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];      
    const auto r_ij = r - pos[j]; 

    const auto x_ij = r_ij.x;
    const auto y_ij = r_ij.y;
    const auto z_ij = r_ij.z;

    const auto cosh_kp_zij = std::cosh(kp*z_ij);
    const auto sinh_kp_zij = std::sinh(kp*z_ij);
    const auto cosh_kx_zij = std::cosh(kx*z_ij);
    const auto sinh_kx_zij = std::sinh(kx*z_ij);
    const auto cosh_ky_zij = std::cosh(ky*z_ij);
    const auto sinh_ky_zij = std::sinh(ky*z_ij);

    const auto cos_kx_xij = std::cos(kx*x_ij);
    const auto sin_kx_xij = std::sin(kx*x_ij);
    const auto cos_ky_yij = std::cos(ky*y_ij);
    const auto sin_ky_yij = std::sin(ky*y_ij);

    Vector<double> sum {0, 0, 0};
    for (int k = 0; k < n_k_vectors; ++k) {
      sum +=  k_vector[k] * field_k_coef[k] * std::sin(k_vector[k]*r_ij) ;    
    } 
    field_k += charge_j * sum;
  }
  return -2.0 * four_pi * field_k * l_x_inv * l_y_inv;
*/
  return r;
}

Vector<double> Ewald::slab_geometry_correction_field (int i) {
  return slab_geometry_correction_field (atom_data -> owned.position[i]);
}

Vector<double> Ewald::total_field (int i) {
  auto field = k_space_field(i)+r_space_field(i);  

  if (slab_geometry)
    field += slab_geometry_correction_field(i);
  if (dipole)
    field += dipole_field();
  return field;
}

Vector<double> Ewald::total_field (const Vector<double> &r) {
  auto field = k_space_field(r)+r_space_field(r);
  if (slab_geometry)
    field += slab_geometry_correction_field(r);
  if (dipole)
    field += dipole_field_vector;
  return field;
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

