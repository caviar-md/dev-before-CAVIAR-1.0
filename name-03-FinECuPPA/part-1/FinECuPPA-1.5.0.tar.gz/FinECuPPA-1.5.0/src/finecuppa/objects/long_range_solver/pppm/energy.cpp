#include "finecuppa/objects/long_range_solver/pppm.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {


double PPPM::k_space_energy () {
  double energy {0};  
  return energy;
}

double PPPM::r_space_energy () {
  double energy {0};  
  return energy;
}

double PPPM::self_energy () {
  double energy {0};  
  return energy;
}

double PPPM::dipole_energy () {
  double energy {0};  
  return energy;
}

double PPPM::total_energy () {
  return k_space_energy()+r_space_energy()+self_energy()+dipole_energy();
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

