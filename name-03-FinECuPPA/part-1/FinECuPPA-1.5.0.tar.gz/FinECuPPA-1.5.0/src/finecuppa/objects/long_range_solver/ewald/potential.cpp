#include "finecuppa/objects/long_range_solver/ewald.h"
#include "finecuppa/FinECuPPA.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/neighborlist.h"

#include <cmath>
#include <complex>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace long_range_solver {


double Ewald::k_space_potential (const Vector<double> &r) {

  const std::complex<double> ii(0.0, 1.0);    
  const auto &pos = atom_data -> owned.position;    

  double sum_k = 0.0;

  for (int i = 0; i<n_k_vectors; ++i) {

    std::complex<double> rho (0,0);
    for (unsigned int j=0;j<pos.size();++j) {
      const auto type_j = atom_data -> owned.type [j] ;
      const auto charge_j = atom_data -> owned.charge [ type_j ];

      rho += charge_j * std::exp(-ii*(k_vector[i]*(r - pos[j])));
    }
    const double rho_norm = std::abs(rho * std::conj(rho));
    sum_k += field_k_coef[i] * rho_norm;
  }    

  return  four_pi * l_xyz_inv * sum_k;
/*

  double sum_k = 0;

  static std::complex<double> ii(0.0, 1.0);    
  const auto &pos = atom_data -> owned.position;

  for (unsigned int j=0;j<pos.size();++j) {
    const auto type_j = atom_data -> owned.type [j] ;
    const auto charge_j = atom_data -> owned.charge [ type_j ];
    const auto r_ij = r - pos[j];
    std::complex<double> rho (0,0);
    for (int k = 0; k < n_k_vectors; ++k) {
      rho +=  field_k_coef[k] * std::exp(-ii*(k_vector[k]*r_ij));
    }

//  the real part or the abs of the value   
    const double rho_norm = std::abs(rho); //XXX//
    sum_k += charge_j * rho_norm;
//    potential_k += charge_j * sum_rho;
  }


  return four_pi * l_xyz_inv * sum_k;
*/
}


double Ewald::r_space_potential (const Vector<double> &r) {
  double potential_r {0};  
/*
  const auto &pos = atom_data -> owned.position;
  const auto &binlist = neighborlist -> binlist;
  const auto &nb = neighborlist -> neigh_bin;
  const auto nb_i = neighborlist -> neigh_bin_index (r);
  const int pos_size = pos.size();
  int sum_same = 0;
  for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
    const auto &nb_ij = nb[nb_i][nb_j];
    for (unsigned i = 0; i < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++i) {

      int j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][i];
      bool is_ghost = j >= pos_size;
      Vector<Real_t> pos_j;
      Real_t type_j;
      if (is_ghost) {
        j -= pos_size;
        pos_j = atom_data->ghost.position [j];
        type_j = atom_data->ghost.type [j];
      } else {
        pos_j = atom_data->owned.position [j];
        type_j = atom_data->owned.type [j];
      }

      const auto charge_j = atom_data -> owned.charge [ type_j ]; 
      const auto r_ij = r - pos_j;

      if (r_ij.x == 0 && r_ij.y == 0 && r_ij.z == 0) {sum_same +=1;
        continue;    
      }


      const auto rijml = r_ij;
      const auto rijml_norm = std::sqrt(rijml*rijml);
      const auto erfc_arg = alpha*rijml_norm;

      if (erfc_arg > erfc_cutoff) continue; // it may never be needed   
    
      potential_r += charge_j * std::erfc(erfc_arg) / rijml_norm;    
    }
  }
*/
  return potential_r; 
}

double Ewald::slab_geometry_correction_potential (const Vector<double> &r) {
  return r.x;
}

double Ewald::self_potential (const Vector<double> &r) {
// self potential and energy does not depend on the position and is
// constant during simulation if the net charge does not change
  double potential {0};  
  return r*r*potential;
}

double Ewald::dipole_potential (const Vector<double> &r) {
  double potential {0};  
  return r*r*potential;
}

double Ewald::total_potential (const Vector<double> &r) {
  if (slab_geometry)
    return k_space_potential(r) + r_space_potential(r)
          + slab_geometry_correction_potential(r);
  else 
    return k_space_potential(r) + r_space_potential(r);
}

} //long_range_solver
} //objects

FINECUPPA_NAMESPACE_CLOSE

