#include "finecuppa/objects/finite_element.h"
#include "finecuppa/structure/input/parser.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

  Finite_element::Finite_element (FinECuPPA *fptr) : Pointers{fptr} {}

  Finite_element::~Finite_element () {}
  
  void Finite_element::calculate_acceleration () {} 
  
  bool Finite_element::read (Parser *parser) {return parser->end_of_line();}  
    
} //objects

FINECUPPA_NAMESPACE_CLOSE

