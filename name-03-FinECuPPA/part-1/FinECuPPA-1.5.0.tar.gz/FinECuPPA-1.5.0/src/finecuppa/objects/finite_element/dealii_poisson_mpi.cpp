#ifdef USE_DEALII_WITH_MPI

#include "finecuppa/objects/finite_element/dealii_poisson.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/atom_data.h"
//#include "finecuppa/objects/long_range_solver.h"

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/grid/grid_refinement.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/grid/manifold_lib.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/base/logstream.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/error_estimator.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_bicgstab.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/vector_memory.h>
#include <deal.II/lac/filtered_matrix.h>

#ifdef USE_DEALII_WITH_OPENCASCADE
 #include <deal.II/opencascade/boundary_lib.h>
 #include <deal.II/opencascade/utilities.h>
#endif

#include <fstream>
#include <iostream>
#include <cmath>

// #define FMETHOD // compile with the filteredMatrix method // 

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace finite_element {
//==================================================
//==================================================
//==================================================
namespace dealii_poisson_mpi {

template <int dim>
double BoundaryValues<dim>::potential_of_free_charges (const dealii::Point<3> &p) const
{
  const auto &pos = atom_data -> owned.position;
  double total_potential = 0;
  for (unsigned int i=0;i<pos.size();++i) {
     const auto type_i = atom_data -> owned.type [i] ;
    const auto charge_i = atom_data -> owned.charge [ type_i ];
    const dealii::Point<3> c_pos = {pos[i].x, pos[i].y, pos[i].z};
    double c_dist = p.distance(c_pos);
    total_potential += charge_i / c_dist;
  }   
  total_potential *= k_electrostatic;
  return total_potential;
}
//--------------------------------------------------

template <int dim>
double BoundaryValues<dim>::value (const Point<dim> &p,
                                   const unsigned int ) const
{
#ifdef USE_MD_MPI
  double total_potential_of_free_charges = 0;
  double local_potential_of_free_charges = potential_of_free_charges (p);
//  MPI_Barrier (MPI::COMM_WORLD); // XXX is it nessecary?

  MPI_Allreduce(&local_potential_of_free_charges,
    &total_potential_of_free_charges,
    1, MPI::DOUBLE, MPI_SUM,  MPI::COMM_WORLD);
    
  return total_potential - total_potential_of_free_charges;
#else
  return total_potential - potential_of_free_charges (p);
#endif  
}
} // dealii_poisson_mpi


//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson_mpi<dim>::FE_dealii_poisson_mpi(FinECuPPA * fptr) : 
  finite_element::Finite_element<dim>{fptr},
  mpi_communicator (MPI::COMM_WORLD),
  triangulation (MPI::COMM_WORLD,
                 typename Triangulation<dim>::MeshSmoothing
                 (Triangulation<dim>::smoothing_on_refinement |
                  Triangulation<dim>::smoothing_on_coarsening)),
//    pcout (std::cout,
//           (Utilities::MPI::this_mpi_process(MPI::COMM_WORLD) == 0)),
//    computing_timer (MPI::COMM_WORLD, pcout, TimerOutput::summary,
//                        TimerOutput::wall_times),
  dof_handler (triangulation),
  fe (2),
  atom_data{fptr->atom_data}, output{fptr->output}, error{fptr->error}, initialized{false}, k_electrostatic{1.0},
  time_step_count{0}, time_step_solve{1}, time_step_output_vtk{1}, time_step_induced_charge{1},
  output_vtk{false}, derivation_length{1e-6}, induced_charge_id_init{false}, output_induced_charge{false}, boundary_id_max{0}
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
  ,my_mpi_rank{fptr->comm->me}
#endif
{}

//==================================================
//==================================================
//==================================================


template <int dim>
FE_dealii_poisson_mpi<dim>::~FE_dealii_poisson_mpi() {
    dof_handler.clear ();
}
//==================================================
//==================================================
//==================================================

template <int dim>
bool FE_dealii_poisson_mpi<dim>::read (Parser *parser) {
  output->info("FE_dealii_poisson_mpi: read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"make_grid")) {
      make_grid();
    } else if (string_cmp(t,"refine_global")) {    
      int n = parser->get_literal_int();//0;      
      refine_sequence_type.push_back (0);
      refine_sequence_value.push_back (n);
    } else if (string_cmp(t,"refine_boundary")) {
      int n = parser->get_literal_int();    
      refine_sequence_type.push_back (1);
      refine_sequence_value.push_back (n);
    } else if (string_cmp(t,"boundary_id_value")) {
      int id = parser->get_literal_int();
      if (id == 0) {
        error->all (FC_FILE_LINE_FUNC_PARSE, "#boundary_id=0 is reserved for free boundary");
      }
      double value = parser->get_literal_real();
      boundary_id_value.push_back(std::make_pair(id, value));
      boundary_id_list.push_back(id);
    } else if (string_cmp(t,"k_electrostatic")) {
      k_electrostatic = parser->get_literal_real();
    } else if (string_cmp(t,"derivation_length")) {
      derivation_length = parser->get_literal_real();
    } else if (string_cmp(t,"add_unv_mesh")) {
      auto token = parser->get_val_token();
      auto file_name = token.string_value;
      unv_mesh_filename.push_back(file_name);
      std::cout << "hey" <<std::endl; 
    } else if (string_cmp(t,"read_unv_mesh")) {
      read_domain();
    } else if (string_cmp(t,"time_step_solve")) {
      time_step_solve = parser->get_literal_int();    
    } else if (string_cmp(t,"output_vtk")) {
      output_vtk = true;
      time_step_output_vtk = parser->get_literal_int();
    } else if (string_cmp(t,"output_induced_charge")) {
      output_induced_charge = true;
      time_step_induced_charge = parser->get_literal_int();
#if defined(USE_MD_MPI) || defined(USE_FE_MPI)
      if (my_mpi_rank == 0)     
        ofs_induced_charge.open ("o_induced_charge");
#else 
      ofs_induced_charge.open ("o_induced_charge");
#endif
    } else if (string_cmp(t,"induced_charge_ignore_id")) {
      unsigned id = parser->get_literal_int();
      face_id_ignore.push_back(id);
    }
    
    else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  
  return in_file;
}

//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::rotate_and_add_reserve(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (tria_reserve);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }

//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::rotate_and_add(const double angle, const int axis, const double merge_toll) {
    Triangulation<3, 3> tria2;
    tria2.copy_triangulation (triangulation);
    GridTools::rotate (angle, axis, tria2);
    match_boundary_vertices (tria2, merge_toll);     
    GridGenerator::merge_triangulations (triangulation, tria2, triangulation);        
  }



//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::match_boundary_vertices (Triangulation<3,3> & tria2,
                                               const double merge_toll) {
    int no_matched_vertices = 0;
    int no_corrected_vertices = 0;
    
    for (typename Triangulation<3,3>::active_cell_iterator
         cell2=tria2.begin_active(); cell2!=tria2.end(); ++cell2) {
      for (unsigned int f2=0; f2<GeometryInfo<3>::faces_per_cell; ++f2) {
        if (cell2->face(f2)->at_boundary()) {
          
          for (typename Triangulation<3,3>::active_cell_iterator
               cell=triangulation.begin_active();cell!=triangulation.end();++cell) { 
            for (unsigned int f=0; f<GeometryInfo<3>::faces_per_cell; ++f) {
              if (cell->face(f)->at_boundary()) {
      
                for (unsigned int i=0; i<4; ++i)  { 
                  const Point<3> p1 = cell->face(f)->vertex(i);
                  bool point_match_found = false;                             
                  for (unsigned int j=0; j<4; ++j)  {           
                    const Point<3> p2 = cell2->face(f2)->vertex(j);
                    const double distance = p2.distance(p1);
                    
                    if (distance < merge_toll) {
                      ++no_matched_vertices;
                      point_match_found = true;
                      if (distance > 0) {
                        ++no_corrected_vertices;
                        cell2->face(f2)->vertex(j) =  cell->face(f)->vertex(i);
                      }
                      break;                        
                    }
                  }
                  if (!point_match_found) break;
                }
              }
            }
          }           
        }        
      }
    }
    
    tot_no_matched +=  no_matched_vertices;
    tot_no_corrected += no_corrected_vertices;
  }
  
//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::read_domain()
  {

  if (unv_mesh_filename.size()==0) {
    //error->all (FC_FILE_LINE_FUNC_PARSE, "unv_mesh_filename is empty. Add a file to the list.");
    std::cout << "unv_mesh_filename is empty. Add a file to the list." << std::endl;
    return;
  }
  tot_no_matched=0; tot_no_corrected=0;


  std::ifstream in;

  in.open(unv_mesh_filename[0].c_str());

  GridIn<3,3> gi;
  gi.attach_triangulation(triangulation);
  gi.read_unv(in);


  const double merge_toll = 1e-4;
  std::cout << "read_domain: " << unv_mesh_filename[0] << std::endl;
  unsigned int tot_mesh_num = unv_mesh_filename.size();
  for (unsigned int i = 1; i <  tot_mesh_num; ++i) { // BUG
    std::cout << "read_domain: " << unv_mesh_filename[i] << std::endl;

      Triangulation<3,3> tria2;
     
      std::ifstream in;
      
      in.open(unv_mesh_filename[i].c_str());

      GridIn<3,3> gi;
      gi.attach_triangulation(tria2); 
      gi.read_unv(in);
      
      match_boundary_vertices (tria2, merge_toll);  
       
      GridGenerator::merge_triangulations (triangulation, tria2, triangulation);
    
  }
    

  std::cout << "merge_tollerance_of_vertices:       " << merge_toll << std::endl;
  std::cout << "total_no_matched_vertices:   " << tot_no_matched << std::endl;
  std::cout << "total_no_corrected_vertices: " << tot_no_corrected << std::endl;

  unv_mesh_filename.clear();

} 
  
//===================================================
//===================================================
//===================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::set_spherical_manifold() {
  const Point<3> center (0,0,0);
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (1, manifold_description);
  triangulation.set_all_manifold_ids(1);
}

//===================================================
//===================================================
//===================================================
  

template <int dim>
void FE_dealii_poisson_mpi<dim>::make_grid ()
{

  const Point<3> center (0,0,0); 
  const double  radius = 1.0;
  GridGenerator::hyper_ball   (triangulation, center,    radius);
 
  static const SphericalManifold<3> manifold_description(center);
  triangulation.set_manifold (0, manifold_description);

  std::cout << "   Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl
            << "   Total number of cells: "
            << triangulation.n_cells()
            << std::endl;
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::setup_system ()
{
#ifdef FMETHOD  
  dof_handler.distribute_dofs (fe);
  
  std::cout << "   Number of degrees of freedom: "
            << dof_handler.n_dofs()
            << std::endl;
                      
  solution.reinit (dof_handler.n_dofs()); 
  
  system_rhs.reinit (dof_handler.n_dofs());

  constraints.clear ();
  
  DoFTools::make_hanging_node_constraints (dof_handler,
                                           constraints);

  constraints.close ();  

  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  
  DoFTools::make_sparsity_pattern(dof_handler,
                                  dsp,
                                  constraints,
                                  /*keep_constrained_dofs = */ false);
  
  sparsity_pattern.copy_from(dsp);
  
  system_matrix.reinit (sparsity_pattern);
#else
//    TimerOutput::Scope t(computing_timer, "setup");

    dof_handler.distribute_dofs (fe);

    locally_owned_dofs = dof_handler.locally_owned_dofs ();
    DoFTools::extract_locally_relevant_dofs (dof_handler,
                                             locally_relevant_dofs);

    locally_relevant_solution.reinit (locally_owned_dofs,
                                      locally_relevant_dofs, MPI::COMM_WORLD);
    system_rhs.reinit (locally_owned_dofs, MPI::COMM_WORLD);

    constraints.clear ();
    constraints.reinit (locally_relevant_dofs);
    DoFTools::make_hanging_node_constraints (dof_handler, constraints);

//-- this added
    for (auto i : boundary_id_value) {
      VectorTools::interpolate_boundary_values (
        dof_handler,
        i.first,
        dealii_poisson_mpi::BoundaryValues<dim>(i.second, k_electrostatic, atom_data),
        constraints);
    }                                            

    
//==  instead of
//    VectorTools::interpolate_boundary_values (dof_handler,
//                                              0,
//                                              ZeroFunction<dim>(),
//                                              constraints);
    constraints.close ();

    DynamicSparsityPattern dsp (locally_relevant_dofs);

    DoFTools::make_sparsity_pattern (dof_handler, dsp,
                                     constraints, false);
    SparsityTools::distribute_sparsity_pattern (dsp,
                                                dof_handler.n_locally_owned_dofs_per_processor(),
                                                MPI::COMM_WORLD,
                                                locally_relevant_dofs);

    system_matrix.reinit (locally_owned_dofs,
                          locally_owned_dofs,
                          dsp,
                          MPI::COMM_WORLD);
#endif
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::assemble_system ()
{
#ifdef FMETHOD
  const QGauss<dim> quadrature_formula(3);

  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values | update_gradients |
                           update_quadrature_points | update_JxW_values);

//  FEValues<dim> fe_values (fe, quadrature_formula,
//                           update_gradients |
//                           update_quadrature_points | update_JxW_values);

  //FEValues<dim> fe_values (fe, quadrature_formula,
 //                          update_gradients |  update_JxW_values);
                           
  
  const unsigned int dofs_per_cell = fe.dofs_per_cell;
  const unsigned int n_q_points = quadrature_formula.size();

  FullMatrix<double> cell_matrix (dofs_per_cell, dofs_per_cell);
  dealii::Vector<double> cell_rhs (dofs_per_cell);
  cell_rhs = 0;
      
  std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();
  for (; cell!=endc; ++cell)
    {
 
      fe_values.reinit (cell);
      cell_matrix = 0;

      for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        for (unsigned int i=0; i<dofs_per_cell; ++i)
          {
            for (unsigned int j=0; j<dofs_per_cell; ++j)
              cell_matrix(i,j) += (fe_values.shape_grad (i, q_index) *
                                   fe_values.shape_grad (j, q_index) *
                                   fe_values.JxW (q_index));


          }


      cell->get_dof_indices (local_dof_indices);

      constraints.distribute_local_to_global (cell_matrix,
                                              cell_rhs,
                                              local_dof_indices,
                                              system_matrix,
                                              system_rhs);
                                              
    }
#else
//    TimerOutput::Scope t(computing_timer, "assembly");

    const QGauss<dim>  quadrature_formula(3);

    FEValues<dim> fe_values (fe, quadrature_formula,
                             update_values    |  update_gradients |
                             update_quadrature_points |
                             update_JxW_values);

    const unsigned int   dofs_per_cell = fe.dofs_per_cell;
    const unsigned int   n_q_points    = quadrature_formula.size();

    FullMatrix<double>   cell_matrix (dofs_per_cell, dofs_per_cell);
    dealii::Vector<double>       cell_rhs (dofs_per_cell);

    std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();
    for (; cell!=endc; ++cell)
      if (cell->is_locally_owned())
        {
          cell_matrix = 0;
          cell_rhs = 0;

          fe_values.reinit (cell);

          for (unsigned int q_point=0; q_point<n_q_points; ++q_point)
            {
            
/* commented because of my equation
              const double
              rhs_value
                = (fe_values.quadrature_point(q_point)[1]
                   >
                   0.5+0.25*std::sin(4.0 * numbers::PI *
                                     fe_values.quadrature_point(q_point)[0])
                   ? 1 : -1);
*/
              for (unsigned int i=0; i<dofs_per_cell; ++i)
                {
                  for (unsigned int j=0; j<dofs_per_cell; ++j)
                    cell_matrix(i,j) += (fe_values.shape_grad(i,q_point) *
                                         fe_values.shape_grad(j,q_point) *
                                         fe_values.JxW(q_point));
// commented because of my equation
                //  cell_rhs(i) += (rhs_value *
                //                  fe_values.shape_value(i,q_point) *
                //                  fe_values.JxW(q_point));
                }
            }

          cell->get_dof_indices (local_dof_indices);
          constraints.distribute_local_to_global (cell_matrix,
                                                  cell_rhs,
                                                  local_dof_indices,
                                                  system_matrix,
                                                  system_rhs);
        }


    system_matrix.compress (VectorOperation::add);
    system_rhs.compress (VectorOperation::add);
#endif
                                                  
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::solve ()
{
#ifdef FMETHOD
  std::map<types::global_dof_index,double> boundary_values;
  
  for (auto i : boundary_id_value) {
    VectorTools::interpolate_boundary_values (
      dof_handler,
      i.first,
      dealii_poisson_mpi::BoundaryValues<dim>(i.second, k_electrostatic, atom_data),
      boundary_values);
  }                                            
                                            

                  // matrix and boundary value constraints
  FilteredMatrix<dealii::Vector<double> > filtered_A (system_matrix);
  filtered_A.add_constraints (boundary_values);


                  // set up a linear solver
  SolverControl solver_control (1000, 1.e-6, false, false);
  //SolverControl solver_control (1000, 1.e-10);  
  GrowingVectorMemory<dealii::Vector<double> > mem;
  SolverCG<dealii::Vector<double> > solver (solver_control, mem);

 
  
                  // set up a preconditioner object
  PreconditionJacobi<SparseMatrix<double> > prec;
  prec.initialize (system_matrix, 1.2);
  FilteredMatrix<dealii::Vector<double> > filtered_prec (prec);
  filtered_prec.add_constraints (boundary_values);
  
  
                  // compute modification of right hand side
  auto system_rhs_tmp = system_rhs;
  filtered_A.apply_constraints (system_rhs_tmp);
                  // solve for solution vector x
  solver.solve (filtered_A, solution, system_rhs_tmp, filtered_prec);


  constraints.distribute (solution);

#else

//    TimerOutput::Scope t(computing_timer, "solve");
    LA::MPI::Vector
    completely_distributed_solution (locally_owned_dofs, MPI::COMM_WORLD);

    SolverControl solver_control (dof_handler.n_dofs(), 1e-6);

#ifdef USE_PETSC_LA
    LA::SolverCG solver(solver_control, MPI::COMM_WORLD);
#else
    LA::SolverCG solver(solver_control);
#endif

    LA::MPI::PreconditionAMG preconditioner;

    LA::MPI::PreconditionAMG::AdditionalData data;

#ifdef USE_PETSC_LA
    data.symmetric_operator = true;
#else
    /* Trilinos defaults are good */
#endif
    preconditioner.initialize(system_matrix, data);

    solver.solve (system_matrix, completely_distributed_solution, system_rhs,
                  preconditioner);

//    pcout << "   Solved in " << solver_control.last_step()
//          << " iterations." << std::endl;

    constraints.distribute (completely_distributed_solution);

    locally_relevant_solution = completely_distributed_solution;
#endif
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::output_vtk_solution (const int cycle) const
{
  
    DataOut<dim> data_out;
    data_out.attach_dof_handler (dof_handler);
    data_out.add_data_vector (locally_relevant_solution, "u");

    dealii::Vector<float> subdomain (triangulation.n_active_cells());
    for (unsigned int i=0; i<subdomain.size(); ++i)
      subdomain(i) = triangulation.locally_owned_subdomain();
    data_out.add_data_vector (subdomain, "subdomain");

    data_out.build_patches ();

    const std::string filename = ("o_solution-" +
                                  Utilities::int_to_string (cycle, 2) +
                                  "." +
                                  Utilities::int_to_string
                                  (triangulation.locally_owned_subdomain(), 4));
    std::ofstream output ((filename + ".vtu").c_str());
    data_out.write_vtu (output);

    if (Utilities::MPI::this_mpi_process(MPI::COMM_WORLD) == 0)
      {
        std::vector<std::string> filenames;
        for (unsigned int i=0;
             i<Utilities::MPI::n_mpi_processes(MPI::COMM_WORLD);
             ++i)
          filenames.push_back ("solution-" +
                               Utilities::int_to_string (cycle, 2) +
                               "." +
                               Utilities::int_to_string (i, 4) +
                               ".vtu");

        std::ofstream master_output (("solution-" +
                                      Utilities::int_to_string (cycle, 2) +
                                      ".pvtu").c_str());
        data_out.write_pvtu_record (master_output, filenames);
      }
  
}


//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::set_boundary ()
{
// To be added at UNV_HANDLER class if possible
// 
/*
  const double sn = 0.001;
      
  Triangulation<3>::active_cell_iterator cell = triangulation.begin_active();
  Triangulation<3>::active_cell_iterator endc = triangulation.end();    
  for (; cell!=endc; ++cell) {    
    for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f) {
      if (cell->face(f)->at_boundary()) {

      }          
    }
  }
*/
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::refine_boundary (const unsigned int refine_levels)
{

    for (unsigned int j = 1; j <= refine_levels; ++j) {
      std::cout << "refine level " << j << std::endl;
      Triangulation<3>::active_cell_iterator cell = triangulation.begin_active();//XXX
      Triangulation<3>::active_cell_iterator endc = triangulation.end();//XXX
    
      for (; cell!=endc; ++cell) {    
        for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
          if (cell->face(f)->at_boundary()) {
            if (cell->face(f)->boundary_id()!=0)
              cell->set_refine_flag ();          


          }          
      }
      triangulation.execute_coarsening_and_refinement ();   
    }
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::refine_grid_adaptive ()
{
   // TimerOutput::Scope t(computing_timer, "refine");
/*
    Vector<float> estimated_error_per_cell (triangulation.n_active_cells());
    KellyErrorEstimator<dim>::estimate (dof_handler,
                                        QGauss<dim-1>(3),
                                        typename FunctionMap<dim>::type(),
                                        locally_relevant_solution,
                                        estimated_error_per_cell);
    parallel::distributed::GridRefinement::
    refine_and_coarsen_fixed_number (triangulation,
                                     estimated_error_per_cell,
                                     0.3, 0.03);
    triangulation.execute_coarsening_and_refinement (); 
  */
}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::calculate_acceleration () {

  const auto &pos = atom_data -> owned.position;
  const auto &type = atom_data -> owned.type;     
  
  run ();
    

#ifdef USE_MD_MPI
// In case of 4 processes, this thing happens
//
// 0 -> 1, 2, 3, 4 -> 0
// 1 -> 2, 3, 4, -> 1
// 2 -> 3, 4 -> 2
// 3 -> 4 -> 3


  int me, nprocs;
  MPI_Comm_rank (MPI::COMM_WORLD, &me);
  MPI_Comm_size (MPI::COMM_WORLD, &nprocs);

  MPI_Barrier (MPI_COMM_WORLD);  
  
  int root = 0;
  while (root < nprocs) {
  
    unsigned root_pos_size = pos.size();
    MPI_Bcast (&root_pos_size, 1,  MPI::UNSIGNED, root, MPI::COMM_WORLD);
    MPI_Barrier (MPI::COMM_WORLD);
      
    if (root == me) {
      

      for (int i = root+1; i < nprocs; ++i) {
        MPI_Send (type.data(), root_pos_size, MPI::UNSIGNED, i, 0, MPI::COMM_WORLD);
        MPI_Send (pos.data(), 3*root_pos_size, MPI::DOUBLE, i, 1, MPI::COMM_WORLD);  
      }

      std::vector<Vector<double>> root_acc (root_pos_size,{0,0,0});
      
      for (int i = root+1; i < nprocs; ++i) {
        MPI_Recv (root_acc.data(), 3*root_pos_size, MPI::DOUBLE,
          root, 2, MPI::COMM_WORLD, MPI_STATUS_IGNORE);
      }
      
      for (unsigned i=0;i<pos.size();++i) {      
        atom_data -> owned.acceleration [i] += root_acc[i];
      }
      
    } else {
      if (me > root) {
        std::vector<Vector<double>> root_pos   (root_pos_size);
        std::vector<unsigned> root_type (root_pos_size);        
        
        MPI_Recv (root_type.data(), root_pos_size, MPI::UNSIGNED,
          root, 0, MPI::COMM_WORLD, MPI_STATUS_IGNORE);        
          
        MPI_Recv (root_pos.data(), 3*root_pos_size, MPI::DOUBLE,
          root, 1, MPI::COMM_WORLD, MPI_STATUS_IGNORE);        


        std::vector<Vector<double>> root_acc (root_pos_size,{0,0,0});    


        for (unsigned i=0;i<pos.size();++i) {
           const auto type_i = atom_data -> owned.type [i] ;
          const auto mass_i = atom_data -> owned.mass [ type_i ];
          const auto charge_i = atom_data -> owned.charge [ type_i ];

   
          for (unsigned j=i+1;j<root_pos.size();++j) {    
             const auto type_j = root_type [j] ;
            const auto mass_j = atom_data -> owned.mass [ type_j ];
            const auto charge_j = atom_data -> owned.charge [ type_j ];      
            const auto dr = root_pos[j] - pos[i]; 
            const auto dr_sq = dr*dr;
            const auto dr_norm = std::sqrt(dr_sq);      
            const auto force = k_electrostatic * charge_i * charge_j * dr / (dr_sq*dr_norm);
            atom_data -> owned.acceleration [i] -= force / mass_i;
            root_acc [j] += force / mass_j; // no periodic boundary condition yet      
          }
        }
      }
      
    }
    
    MPI_Barrier (MPI::COMM_WORLD);  
    ++root;
  }  
  
  
#endif


  for (unsigned int i=0;i<pos.size();++i) {
     const auto type_i = atom_data -> owned.type [i] ;
    const auto mass_i = atom_data -> owned.mass [ type_i ];
    const auto charge_i = atom_data -> owned.charge [ type_i ];
    for (unsigned int j=i+1;j<pos.size();++j) {
       const auto type_j = atom_data -> owned.type [j] ;
      const auto mass_j = atom_data -> owned.mass [ type_j ];
      const auto charge_j = atom_data -> owned.charge [ type_j ];      
      const auto dr = pos[j] - pos[i]; 
      const auto dr_sq = dr*dr;
      const auto dr_norm = std::sqrt(dr_sq);      
      const auto force = k_electrostatic * charge_i * charge_j * dr / (dr_sq*dr_norm);
      atom_data -> owned.acceleration [i] -= force / mass_i;
      atom_data -> owned.acceleration [j] += force / mass_j; // no periodic boundary condition yet
    }
    

    const dealii::Point<3> r = {pos[i].x, pos[i].y, pos[i].z}; 
#ifdef USE_FE_MPI
// XXX can we have an exception here when 'r' is outside local mesh? 
    auto field = - VectorTools::point_gradient (dof_handler, locally_relevant_solution, r);
#else
    auto field = - VectorTools::point_gradient (dof_handler, locally_relevant_solution, r); 
#endif     
    auto frc = field * charge_i;
    auto force = Vector<double> {frc[0], frc[1], frc[2]};
    atom_data -> owned.acceleration [i] += force / mass_i;    
  }
   


}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::make_boundary_face_normals () {

    std::ofstream ofs ("o_mesh_boundary_normals"); 

    for (typename Triangulation<3,3>::active_cell_iterator
         cell=triangulation.begin_active(); cell!=triangulation.end(); ++cell) {
      auto cc = cell->center();         
      
      for (unsigned int f=0; f<GeometryInfo<3>::faces_per_cell; ++f) {
        
        if (cell->face(f)->at_boundary()) {
        
          auto boundary_id = static_cast<unsigned>(cell->face(f)->boundary_id());
                              
          if (boundary_id_max < boundary_id)          
            boundary_id_max = boundary_id;  
                  
          auto fc = cell->face(f)->center();

          // n_o: a vector (approximately) to the direction of normal         
          auto n_o = cc - fc;
          
          auto src1 = cell->face(f)->vertex(1) - cell->face(f)->vertex(0);
          auto src2 = cell->face(f)->vertex(2) - cell->face(f)->vertex(0);          
          auto n    =  cross_product_3d   ( src1, src2 );

          auto dot = n * n_o;
          if (dot < 0 ) n *= -1;
          auto norm_n = std::sqrt(n*n);      
          n /= norm_n;
       

          face_area.push_back (cell->face(f)->measure ());
          face_normal.push_back (n);
          face_center.push_back (fc);
          face_id.push_back (boundary_id);
                    
          ofs << fc(0) << " " << fc(1) << " " << fc(2) << " "
              << n[0]  << " " << n[1]  << " " << n[2]  << "\n";
              
          //std::cout << "fx:" << cell->face(f)->index() << std::endl;
        }
        
      }
    }

}

//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::calculate_induced_charge (int t) {

  std::vector<double> induced_charge(boundary_id_max + 1, 0);  

  for (unsigned int k = 0; k < face_id.size(); ++k) {
  
    if (face_id[k]==0) continue;
    if (std::count(face_id_ignore.begin(), face_id_ignore.end(), face_id[k]) > 0)
      continue;
    auto p1 = face_center[k];    
    
    auto f_sm = - VectorTools::point_gradient (dof_handler, locally_relevant_solution, p1);

    Vector<double> f_si {0, 0, 0};
    Vector<double> pos_j {p1[0], p1[1], p1[2]};
    const auto &pos = atom_data -> owned.position;
    for (unsigned int i=0;i<pos.size();++i) {
       const auto type_i = atom_data -> owned.type [i] ;
      const auto charge_i = atom_data -> owned.charge [ type_i ];
      const auto dr = pos_j - pos[i]; 
      const auto dr_sq = dr*dr;
      const auto dr_norm = std::sqrt(dr_sq);      
      f_si += k_electrostatic * charge_i * dr / (dr_sq*dr_norm); 
    }

// in this class, no FE_MPI is implemented, so checking USE_FE_MPI is useless.

#ifdef USE_MD_MPI
 #ifdef USE_FE_MPI
      auto field_tot = dealii::Point<3> {f_si.x, f_si.y, f_si.z} + f_sm;//XXX
 #else
    double f_si_local[3] = {f_si.x, f_si.y, f_si.z};
    double f_si_total[3] = {0, 0, 0};
//  MPI_Barrier (MPI::COMM_WORLD); // XXX is it nessecary?
    MPI_Allreduce(&f_si_local, &f_si_total,
      3, MPI::DOUBLE, MPI_SUM,  MPI::COMM_WORLD);
     auto field_tot = dealii::Point<3> {f_si_total[0], f_si_total[1], f_si_total[2]} + f_sm; 
 #endif
#else  
// using FE_MPI doesn't matter in this case
     auto field_tot = dealii::Point<3> {f_si.x, f_si.y, f_si.z} + f_sm;
#endif    

    auto field_normal = face_normal[k] * field_tot;

    auto local_q = field_normal * face_area[k] * k_electrostatic;
    
    induced_charge[face_id[k]] += local_q;
  }

  if (!induced_charge_id_init) {
    induced_charge_id_init = true;
    ofs_induced_charge << "# time ";
    for (unsigned int i=0; i<induced_charge.size(); ++i) {
      if (induced_charge[i] == 0) continue;
      ofs_induced_charge << " " << i;
    }
  ofs_induced_charge << " " << "sum_q" << " " << "sum_abs_q" << "\n" << std::flush;    
  }
  
  double sum_q = 0;
  double sum_abs_q = 0;  
  ofs_induced_charge << t;
  for (auto q : induced_charge) {
    if (q == 0) continue;
    ofs_induced_charge << " " << q;
    sum_q += q;
    sum_abs_q += std::abs(q);
  }
  ofs_induced_charge << " " << sum_q << " " << sum_abs_q << "\n" << std::flush;

}
//==================================================
//==================================================
//==================================================

template <int dim>
void FE_dealii_poisson_mpi<dim>::run ()
{
  
  if (!initialized) {
    initialized = true;
    //read_domain ();    
    for (unsigned int i=0; i < refine_sequence_type.size(); ++i) {
      if (refine_sequence_type[i]==0)
        triangulation.refine_global (refine_sequence_value[i]);
      if (refine_sequence_type[i]==1) 
        refine_boundary (refine_sequence_value[i]);
    }
    make_boundary_face_normals ();
    setup_system ();
    assemble_system ();
    solve ();      
    output_vtk_solution (0); 
    if (output_induced_charge) 
      calculate_induced_charge (0);
  } else {
    ++time_step_count;
#ifndef FMETHOD
    setup_system ();
    assemble_system ();
#endif    
    if (time_step_count%time_step_solve==0) 
      solve ();
    
    if (output_vtk && time_step_count%time_step_output_vtk==0) 
      output_vtk_solution (time_step_count);
    
    if (output_induced_charge && time_step_count%time_step_induced_charge==0) 
      calculate_induced_charge (time_step_count);
  }

}

//==================================================
//==================================================
//==================================================

} //finite_element
} //objects
FINECUPPA_NAMESPACE_CLOSE

template class finecuppa::objects::finite_element::FE_dealii_poisson_mpi<3>;
template class finecuppa::objects::finite_element::dealii_poisson_mpi::BoundaryValues<3>;

#endif
