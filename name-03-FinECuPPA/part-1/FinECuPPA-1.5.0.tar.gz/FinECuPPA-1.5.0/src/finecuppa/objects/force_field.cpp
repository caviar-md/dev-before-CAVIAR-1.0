#include "finecuppa/objects/force_field.h"
#include "finecuppa/structure/error.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Force_field::Force_field (FinECuPPA *fptr) : Pointers{fptr}, 
  atom_data{nullptr}, neighborlist{nullptr}
 {}

double Force_field::energy() {
  error->all(FC_FILE_LINE_FUNC, "The energy calculation of this force_field is not implemented");
  return 0.0;
}

double Force_field::potential (const Vector<double> &) {
  error->all(FC_FILE_LINE_FUNC, "The potential calculation of this force_field is not implemented");
  return 0.0;
}

double Force_field::potential (const int) {
  error->all(FC_FILE_LINE_FUNC, "The potential calculation of this force_field is not implemented");
  return 0.0;
}


Vector<double> Force_field::field (const Vector<double> &) {
  error->all(FC_FILE_LINE_FUNC, "The field calculation of this force_field is not implemented");
  return Vector<double> {0,0,0};
}

Vector<double> Force_field::field (const int) {
  error->all(FC_FILE_LINE_FUNC, "The field calculation of this force_field is not implemented");
  return Vector<double> {0,0,0};
}


} //objects

FINECUPPA_NAMESPACE_CLOSE

