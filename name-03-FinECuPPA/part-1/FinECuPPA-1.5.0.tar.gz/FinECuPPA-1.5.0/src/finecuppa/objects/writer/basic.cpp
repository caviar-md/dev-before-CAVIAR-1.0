#include "finecuppa/objects/writer/basic.h"
#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/tools.h"
#include <ctime>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace writer {

Basic::Basic (FinECuPPA *fptr) : Writer{fptr}
{

}

Basic::~Basic () {}

bool Basic::read (finecuppa::Parser *parser) {
  output->info("writer basic: read:");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;

  }
  return in_file;
}


} //basic
} //objects
FINECUPPA_NAMESPACE_CLOSE

