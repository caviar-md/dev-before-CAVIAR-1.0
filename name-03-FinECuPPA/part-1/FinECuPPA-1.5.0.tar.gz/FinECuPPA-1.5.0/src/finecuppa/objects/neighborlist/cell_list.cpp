#include "finecuppa/objects/neighborlist/cell_list.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/tools.h"
#include "finecuppa/objects/domain.h"

#include <cmath>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace neighborlist {
inline int int_floor(double x) 
{ 
    return (int)(x+100000) - 100000; 
}

Cell_list::Cell_list (FinECuPPA *fptr) : Neighborlist{fptr}, domain{nullptr}
{
  cutoff = 0;
  cutoff_neighlist = 0;
  make_neighlist = false;
}

bool Cell_list::read (finecuppa::Parser *parser) {
  output->info("Neighborlist Cell_list read");
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"cutoff")) {
      GET_OR_CHOOSE_A_REAL(cutoff,"","")
      if (cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff have to non-negative."); 
    } else if (string_cmp(t,"cutoff_neighlist")) {
      GET_OR_CHOOSE_A_REAL(cutoff_neighlist,"","")
      if (cutoff_neighlist < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "cutoff_neighlist have to non-negative."); 
    } else if (string_cmp(t,"make_neighlist")) {
      make_neighlist = true;
    } else if (string_cmp(t,"set_domain") || string_cmp(t,"domain")) {
      FIND_OBJECT_BY_NAME(domain,it)
      domain = object_container->domain[it->second.index];
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

void Cell_list::init () {

  if (atom_data == nullptr) error->all("Cell_list::init: atom_data = nullptr");
  if (domain == nullptr) error->all("Cell_list::init: domain = nullptr");
  if (make_neighlist == false)
  output->warning("'make_neighlist' is false. You can only use force_field "
                  "classes that have 'cell_list' implementation. if not, you "
                  "may get a 'segmentation fault' error.");

  no_bins.x = std::ceil((domain->upper_local.x - domain->lower_local.x)/cutoff) + 2;
  no_bins.y = std::ceil((domain->upper_local.y - domain->lower_local.y)/cutoff) + 2;
  no_bins.z = std::ceil((domain->upper_local.z - domain->lower_local.z)/cutoff) + 2;

  std::string s = "no_bins.x : " + std::to_string(no_bins.x)
                + " ,no_bins.y : " + std::to_string(no_bins.y)
                + " ,no_bins.z : " + std::to_string(no_bins.z);
  output->info (s);

  binlist.resize(no_bins.x);

  for (unsigned i=0 ; i < binlist.size(); ++i)
    binlist[i].resize(no_bins.y);

  for (unsigned i=0 ; i < binlist.size(); ++i)
    for (unsigned j=0 ; j < binlist[i].size(); ++j)
      binlist[i][j].resize(no_bins.z);

  make_neigh_bin();
}

bool Cell_list::rebuild_neighlist () {
  return true;
}

Vector<int> Cell_list::binlist_index (const Vector<double> & pos) {
  Vector<int> ind {0, 0, 0};
  ind.x = int_floor( (pos.x - domain->lower_local.x)/cutoff ) + 1;
  ind.y = int_floor( (pos.y - domain->lower_local.y)/cutoff ) + 1;
  ind.z = int_floor( (pos.z - domain->lower_local.z)/cutoff ) + 1;
  if (ind.x < 0) ind.x = 0;
  if (ind.y < 0) ind.y = 0;
  if (ind.z < 0) ind.z = 0;
  if (ind.x >= no_bins.x) ind.x = no_bins.x - 1;
  if (ind.y >= no_bins.y) ind.y = no_bins.y - 1;
  if (ind.z >= no_bins.z) ind.z = no_bins.z - 1;
  return ind;
}

int Cell_list::neigh_bin_index (const Vector<double> & pos) {
  const auto ind = binlist_index (pos);
  return ind.x + no_bins.x*ind.y + no_bins.x*no_bins.y*ind.z;
}

void Cell_list::build_binlist () {
  for (unsigned i=0 ; i < binlist.size(); ++i)
  for (unsigned j=0 ; j < binlist[i].size(); ++j)
  for (unsigned k=0 ; k < binlist[i][j].size(); ++k) {
    int old_size = binlist[i][j][k].size();
    binlist[i][j][k].clear();
    binlist[i][j][k].reserve(old_size);
  }

  const auto &pos = atom_data->owned.position;
  const auto &pos_ghost = atom_data->ghost.position;
  const auto pos_size = pos.size();

  for (unsigned int i=0; i<pos_size; ++i) {
    const auto ind = binlist_index (pos[i]);
    binlist[ind.x][ind.y][ind.z].push_back(i);
  }

  for (unsigned int i=0; i<pos_ghost.size(); ++i) {
    const auto ind = binlist_index (pos_ghost[i]);
    binlist[ind.x][ind.y][ind.z].push_back(i+pos_size);
  }
}


void Cell_list::build_neighlist () {
  build_binlist ();
  if (make_neighlist) {
    const auto &pos = atom_data->owned.position;
    const int pos_size = pos.size();
    const auto cutoff_neighlist_sq = cutoff_neighlist*cutoff_neighlist;
    const auto &nb = neigh_bin;
    neighlist.clear ();
    neighlist.resize (pos_size);


    for (int i=0; i<pos_size; ++i) {

      auto nb_i = neigh_bin_index (pos[i]);

      for (unsigned nb_j = 0; nb_j < nb[nb_i].size(); ++nb_j) {
        const auto &nb_ij = nb[nb_i][nb_j];
        for (unsigned j = 0; j < binlist [nb_ij.x] [nb_ij.y] [nb_ij.z].size(); ++j) {

          const auto ind_j = binlist[nb_ij.x] [nb_ij.y] [nb_ij.z][j];
          if (ind_j>i) {
            auto dr = pos[i];
            if (ind_j >= pos_size) // Ghost condition
              dr -= atom_data->ghost.position[ind_j-pos_size];
            else 
              dr -= atom_data->owned.position[ind_j]; 
            if (dr*dr < cutoff_neighlist_sq) 
              neighlist[i].push_back (ind_j);
          }
        }
      }
    }
  }
}

void Cell_list::make_neigh_bin () {
  neigh_bin.clear();
  neigh_bin.resize(no_bins.x*no_bins.y*no_bins.z);

  Vector<int> ind {0,0,0};

  for (ind.x = 0; ind.x < no_bins.x; ++ind.x)
  for (ind.y = 0; ind.y < no_bins.y; ++ind.y)
  for (ind.z = 0; ind.z < no_bins.z; ++ind.z) {

    const int ind_x_min = ind.x > 0 ? ind.x - 1 : 0 ;
    const int ind_y_min = ind.y > 0 ? ind.y - 1 : 0 ;
    const int ind_z_min = ind.z > 0 ? ind.z - 1 : 0 ;

    const int ind_x_max = ind.x < no_bins.x - 1 ? ind.x + 1 : no_bins.x - 1 ;
    const int ind_y_max = ind.y < no_bins.y - 1 ? ind.y + 1 : no_bins.y - 1 ;
    const int ind_z_max = ind.z < no_bins.z - 1 ? ind.z + 1 : no_bins.z - 1 ;

    for (int ind_x_i = ind_x_min; ind_x_i <= ind_x_max; ++ind_x_i)
    for (int ind_y_i = ind_y_min; ind_y_i <= ind_y_max; ++ind_y_i)
    for (int ind_z_i = ind_z_min; ind_z_i <= ind_z_max; ++ind_z_i) {
      
      const int k = ind.x + no_bins.x*ind.y + no_bins.x*no_bins.y*ind.z;
      neigh_bin[k].push_back(Vector<int>{ind_x_i, ind_y_i, ind_z_i});
    }
  }

}

} //neighborlist
} //objects
FINECUPPA_NAMESPACE_CLOSE

