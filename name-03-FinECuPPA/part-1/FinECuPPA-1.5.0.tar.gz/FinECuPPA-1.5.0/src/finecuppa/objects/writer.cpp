#include "finecuppa/objects/writer.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Writer::Writer (FinECuPPA *fptr) : Pointers{fptr} {}

Writer::~Writer () {}

} //objects



FINECUPPA_NAMESPACE_CLOSE

