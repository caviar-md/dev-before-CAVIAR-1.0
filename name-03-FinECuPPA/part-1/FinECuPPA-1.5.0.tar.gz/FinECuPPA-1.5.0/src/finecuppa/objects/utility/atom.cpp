#include "finecuppa/objects/utility/atom.h"
#include "finecuppa/objects/utility/element.h"
#include "finecuppa/objects/utility/molecule.h"
#include "finecuppa/objects/tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace utility {

Atom::Atom (FinECuPPA *fptr) : Pointers{fptr},
    part_of_a_molecule{false}, upper_level_molecule{nullptr},
    position{Vector<double>{0,0,0}},
    velocity{Vector<double>{0,0,0}}, element_index{0}  {}   
   
Atom::Atom (FinECuPPA *fptr, class Molecule * f, Vector<double> pos,
    Vector<double> vel, unsigned int el_indx) : Pointers{fptr},
    part_of_a_molecule{true}, upper_level_molecule{f},
    position{pos}, velocity{vel}, element_index{el_indx}  {}
  
Atom::~Atom () {}


Atom::Atom (const Atom & a) : Pointers{a} {
  part_of_a_molecule = false; upper_level_molecule = nullptr;
  position = a.position; velocity = a.velocity;
  element_index = a.element_index;
}


bool Atom::read ( Parser * parser) {
  output->info("Atom read");
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    ASSIGN_REAL_3D_VECTOR(position,"ATOM READ: ","")
    else ASSIGN_REAL_3D_VECTOR(velocity,"ATOM READ: ","")
    else if (string_cmp(token.string_value,"element") || string_cmp(token.string_value,"set_element")) {
      FIND_OBJECT_BY_NAME(element,it)
      element_index = object_container->element[it->second.index]->get_element_index();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "ATOM read: Unknown variable or command");
  }

  return in_file;;
}

Vector<double> Atom::pos_tot () const {
  if (part_of_a_molecule) return position + upper_level_molecule->pos_tot();
   else return position;   
}

Vector<double> Atom::vel_tot () const {
  if (part_of_a_molecule) return velocity + upper_level_molecule->vel_tot();
  else return velocity;    
}


void Atom::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  e.push_back (element_index);
  p.push_back (pos_tot());
  v.push_back (vel_tot());
  //std::cout << "1pos : " << pos_tot() << std::endl;
}

void Atom::output_xyz (std::ofstream & out_file) {
  const auto p = pos_tot();
  out_file << element_index << " " << p.x << " " << p.y << " " << p.z << std::endl;  

}

Vector<double> Atom::pos () const {
  return position;  
}

Vector<double> & Atom::pos ()  {
  return position;
}

Vector<double> Atom::vel () const {
  return velocity;  
}

Vector<double> & Atom::vel ()  {
  return velocity;
}

double Atom::get_radius () const {
  return object_container->element[element_index]->get_radius();
}

unsigned int Atom::get_element_index () const {
  return element_index;
}

} //utility
} //objects

FINECUPPA_NAMESPACE_CLOSE

