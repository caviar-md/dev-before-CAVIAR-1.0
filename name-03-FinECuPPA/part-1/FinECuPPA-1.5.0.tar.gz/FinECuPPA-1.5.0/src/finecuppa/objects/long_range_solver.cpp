#include "finecuppa/objects/long_range_solver.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
Long_range_solver::Long_range_solver(FinECuPPA *fptr) : Pointers{fptr},
domain{nullptr}, atom_data{nullptr}, neighborlist{nullptr} {}

Long_range_solver::~Long_range_solver() {}
} //objects

FINECUPPA_NAMESPACE_CLOSE

