
## About Scripts

This folder contains the script that have been used in developing FinECuPPA.
