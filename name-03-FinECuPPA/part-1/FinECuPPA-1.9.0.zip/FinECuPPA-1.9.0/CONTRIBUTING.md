
## Contact info
If you want to contribute to the project, contact (m.biagooi .at. gmail.com).

## Bug report
Also for bug report and anything else...
