
## About Scripts

This folder contains the script that have been used in developing FinECuPPA.
Some of the files may contain only a (non-working!) example of a shell command.
We hope it becomes more than this in the future.

