
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECT_HANDLER_GDST_H
#define FINECUPPA_OBJECT_HANDLER_GDST_H

#include "finecuppa/utility/finecuppa_config.h"
#include <string>
#include <vector>
//#include <map>

FINECUPPA_NAMESPACE_OPEN

namespace object_handler {

int gdst(const std::string &);//get_dictionary_second_type
//const static std::map<std::string,int> dictionary_second_type;

const std::vector<std::string> dictionary_second_type = {
  "wrong_type",

#define FC_GENERAL_CLASSNAME_MACRO(VAR1,VAR2,VAR3) \
  #VAR2 , 

#define FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#include "finecuppa/objects/macro/all.h"
#include "finecuppa/objects/single_type_objects/macro/all.h"

#undef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
#undef FC_GENERAL_CLASSNAME_MACRO

#define FC_BASIC_TYPES_MACRO(VAR1)\
  #VAR1 ,

#define FC_BASIC_TYPES_MACRO_ACTIVATED
#include "finecuppa/structure/object_handler/all_basic_types_macro.h"
#undef FC_BASIC_TYPES_MACRO_ACTIVATED
#undef FC_BASIC_TYPES_MACRO
};

/*
const std::map<std::string,int> dictionary_second_type = {

  //single-type objects
  {"element",1},
  {"atom",2},
  {"molecule",3},  
  {"random_1d",4},
  //{"something",5},  
  {"shape",6},  
  {"grid_1d",7},
  {"distribution",8},

  //multiple-type objects
  {"force_field",9},
  {"finite_element",10},  
  {"long_range_solver",11},
  {"integration",12},
  {"simulator",13},
  {"domain",14},
  {"neighborlist",15},
  {"atom_data",16},
  {"writer",17},
  {"constraint",18},

  //basic types
  {"int_variable",-1},  
  {"real_variable",-2},  
  {"int_2d_vector",-3},  
  {"real_2d_vector",-4},  
  {"int_3d_vector",-5},  
  {"real_3d_vector",-6},
  {"string_variable",-7},
  {"boolean_variable",-8},
};
*/

}

FINECUPPA_NAMESPACE_CLOSE

#endif
 
