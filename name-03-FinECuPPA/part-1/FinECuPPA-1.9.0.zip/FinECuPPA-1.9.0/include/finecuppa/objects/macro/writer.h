
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================


#ifdef FC_GENERAL_CLASSNAME_MACRO_ACTIVATED
FC_GENERAL_CLASSNAME_MACRO(Writer,writer,objects::Writer)
#endif

#ifdef FC_COMPLETE_FORWARD_DECLERATION
FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Writer;
}
FINECUPPA_NAMESPACE_CLOSE
#endif

#ifdef FC_OBJECT_CREATOR_FUNCTION_DEFINITON
FC_OBJECT_CREATOR_DEFAULT_FUNCTION(writer) {

  FC_GET_OBJECT_NAME(writer)

  objects::Writer * p_sh = nullptr; 

#include "finecuppa/objects/writer/macro/all.h"

  FC_ADD_OBJECT_TO_CONTAINER(writer)
}
#endif
