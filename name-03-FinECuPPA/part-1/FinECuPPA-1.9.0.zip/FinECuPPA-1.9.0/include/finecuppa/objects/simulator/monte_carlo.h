
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_SIMULATOR_MONTE_CARLO_H
#define FINECUPPA_SIMULATOR_MONTE_CARLO_H

#include "finecuppa/objects/simulator.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace simulator {

class Monte_carlo : public Simulator {
 public:
  Monte_carlo (class FinECuPPA *);
   ~Monte_carlo ( );
  bool read (class finecuppa::Parser *);
  bool run ();
  void verify_settings ();
  void setup ();
  void cleanup ();

 protected:
  int initial_step, final_step;
  double total_time;
};

} //simulator
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
