
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POSTPROCESS_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POSTPROCESS_H

#include "finecuppa/utility/pointers.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron;
class Postprocess : protected Pointers{
public:
  Postprocess (class FinECuPPA *);
  ~Postprocess ();
  

  void make_grid (shape::polyhedron::Polyhedron &); // contains the faces neccesary to check
                        // make_grid has to be called after lowest_highest_coord()
  void lowest_highest_coord (shape::polyhedron::Polyhedron &); // calculates gxlo, gxhi, gylo...


};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
