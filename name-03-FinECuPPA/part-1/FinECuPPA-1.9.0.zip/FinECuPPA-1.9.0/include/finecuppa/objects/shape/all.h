
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/shape/circle.h"
#include "finecuppa/objects/shape/cylinder.h"
#include "finecuppa/objects/shape/triangle.h"
#include "finecuppa/objects/shape/plane.h"
#include "finecuppa/objects/shape/sphere.h"
#include "finecuppa/objects/shape/closed_lines.h"
#include "finecuppa/objects/shape/polyhedron.h"
#include "finecuppa/objects/shape/boundary.h"
