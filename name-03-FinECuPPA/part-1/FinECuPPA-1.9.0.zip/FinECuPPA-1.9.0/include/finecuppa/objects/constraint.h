
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_CONSTRAINT_H
#define FINECUPPA_CONSTRAINT_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Integration;
class Atom_data;
class Constraint : protected Pointers {
 public:
  Constraint (class FinECuPPA *);
  virtual ~Constraint ( );
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void step_part_I () = 0;
  virtual void step_part_II () = 0;

  int integration_type;
  class Integration *integration;
  class objects::Atom_data *atom_data;
 protected:

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
