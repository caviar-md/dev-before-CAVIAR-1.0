
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_CONSTRAINT_M_SHAKE_H
#define FINECUPPA_CONSTRAINT_M_SHAKE_H

#include "finecuppa/objects/constraint.h"

#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Atom_data;
class Domain;
namespace constraint {




class M_shake : public Constraint {
 public:
  M_shake (class FinECuPPA *);
   ~M_shake ( );
  bool read (class finecuppa::Parser *);

  void step_part_I ();
  void step_part_II ();

  inline double normalize_distance_x(double d) {
#ifndef FINECUPPA_WITH_MPI
    return ( d > domain_dh.x ? domain_dh.x*2.0 - d : d );
#else
    FC_ERR_NOT_IMPLEMENTED
    return 0.0;
#endif
  }

  inline double normalize_distance_y(double d) {
#ifndef FINECUPPA_WITH_MPI
    return ( d > domain_dh.y ? domain_dh.y*2.0 - d: d );
#else
    FC_ERR_NOT_IMPLEMENTED
    return 0.0;
#endif
  }

  inline double normalize_distance_z(double d) {
#ifndef FINECUPPA_WITH_MPI
    return ( d > domain_dh.z ? domain_dh.z*2.0 - d: d );
#else
    FC_ERR_NOT_IMPLEMENTED
    return 0.0;
#endif
  }

  void bond_mshake ();
  void inverse2 (std::vector<std::vector<double>>& , std::vector<std::vector<double>>& );
  inline double reset_distance (double );

  static inline int delta(int a,int b) {
	  if(a==b)return 1;
  	else return 0;
  }

  class Atom_data *atom_data;
  class objects::Domain *domain;

  double dt;
  double error_tolerance;
  finecuppa::Vector<double> domain_dh;

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
