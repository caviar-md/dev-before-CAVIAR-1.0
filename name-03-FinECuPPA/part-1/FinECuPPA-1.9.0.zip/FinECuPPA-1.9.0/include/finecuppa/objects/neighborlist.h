
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_NEIGHBORLIST_H
#define FINECUPPA_NEIGHBORLIST_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"

#include <vector>
#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Atom_data; 
class Neighborlist : protected Pointers {

public:
  Neighborlist (class FinECuPPA *);
  virtual ~Neighborlist ();
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void init () = 0;
  virtual bool rebuild_neighlist () = 0;
  virtual void build_neighlist () = 0;
  std::vector<std::vector<LocalID_t>> neighlist;

// 'Cell_list' public functions and variables;
  virtual Vector<int> binlist_index (const Vector<double> &);
  virtual int neigh_bin_index (const Vector<double> &);
  std::vector<std::vector<std::vector<std::vector<int>>>> binlist;
  std::vector<std::vector<Vector<int>>> neigh_bin;
  Vector<int> no_bins;
  double cutoff; 
  std::string object_base_class_name, object_class_name, object_name;
protected:
  class finecuppa::objects::Atom_data *atom_data;

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
