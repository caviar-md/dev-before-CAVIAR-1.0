
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_ATOM_DATA_H
#define FINECUPPA_ATOM_DATA_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/objects/atom_data/utility/bond.h"

#include <vector>
#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

class Domain;
namespace single_type_objects { class Atom; class Molecule; }
class Atom_data : protected Pointers {
public:
  Atom_data (class FinECuPPA *);
  virtual ~Atom_data ();
  virtual bool read (class finecuppa::Parser *) = 0;
  virtual void output_data(const int) = 0;
  void set_num_total_atoms (GlobalID_t);
  void set_num_atom_types (AtomType_t n) {num_atom_types = n;}
  void dump_povray (int i);

  
  virtual bool add_atom (GlobalID_t, AtomType_t, const Vector<Real_t> &,
      const std::vector<Real_t> &other_real = std::vector<Real_t>{},
      const std::vector<int> &other_int = std::vector<int>{});
  virtual bool add_atom (GlobalID_t, AtomType_t, const Vector<Real_t> &,
      const Vector<Real_t> &,
      const std::vector<Real_t> &other_real = std::vector<Real_t>{},
      const std::vector<int> &other_int = std::vector<int>{});

  virtual bool add_masses (unsigned int, Real_t);  
  virtual bool add_charges (unsigned int, Real_t);  

  virtual bool add_molecule_directly(finecuppa::objects::single_type_objects::Molecule &m);
  virtual bool add_atom_directly(finecuppa::objects::single_type_objects::Atom &a);
  virtual bool add_elements_directly();

  // calculates total kinetic energy of the atoms
  virtual double kinetic_energy();

  // calculates total kinetic energy of a type of atoms
  virtual double kinetic_energy(const int);
  
  // used when there are different MPI domains and all of them should know all
  // the atom_data
  virtual void synch_owned_data(int type);
  bool synch_owned_data_bcast_details;
  
  // Here we define an unnamed structure and make two of it. It can have a name
  // but since it is used only once here, its name won't be of any use. Also 
  // a good name would be 'atom_data' which is used before!.
  struct {
    // 'id' is a global and unique number assigned to an atom.
    std::vector<GlobalID_t> id;

    // A tag to be done on the atoms.
    std::vector<AtomType_t> tag;

    // Atom type decides the charge, mass and any other property shared between
    // a defined type (for example, Elements).
    std::vector<AtomType_t> type;

    // 'mass' of an atom defined by the type.
    std::vector<Real_t> mass;

    // 'charge' of an atom defined by the type.
    std::vector<Real_t> charge;


    // Different by atom_id. Can be changed in simulation (it is needed to be sent-recv. by MPI)
    std::vector<Real_t> charge_atom; 

    // Different by atom_id. Can be changed in simulation (it is needed to be sent-recv. by MPI)
    std::vector<Real_t> mass_atom; 

    // Atom kinematic properties in the current time-step.
    std::vector<Vector<Real_t>> position, velocity, acceleration;

    // This vectors are used in some integration schemes and constraint methods.
    // They can be defined in their related objects, but they may be needed in
    // more than one objects at once (for example, constraint::M_shake and 
    // integration::Leap_frog). This makes it the reason to define it here.
    // This function may be needed to have MPI_send-recv. process in these case.
    // look up to it.
    std::vector<Vector<Real_t>> position_old, velocity_old, acceleration_old; 


    //
    // this part matters when molecules are in the play. The first index, meaning
    // the first std::vector is the molecule index. the inner data contain bonds
    // note that this is different from Molecule->atomic_bond
    std::vector <std::vector<Bond>> atomic_bond_vector; 
    // and a list of atoms which are in the molecule
    // note that this is different from Molecule->atomic_bond_index_list
    std::vector <std::vector<int>> atomic_bond_index_vector; 
    // this vector contain a molecule index for all the atoms. if it's '-1' the
    // atom is not of any molecule. This matters in the MPI process. All of the
    // atoms of a molecule should be existed in one process.
    std::vector <int> molecule_index; // 
  }  
  // There are two types of this unnamed structure: owned and ghost. 'owned' atoms
  // are the one that matter in integrations in the domain. Ghost particles are
  // the particle near the domain boundaries which are not from the domain. Their
  // usage is for short-range force-field calculations.
  owned, ghost; 

  LocalID_t num_local_atoms, num_local_atoms_est;
  GlobalID_t num_total_atoms;
  AtomType_t num_atom_types;

  std::vector<int> ghost_rank; // the rank of the domain in which the owned counterpart exists


  std::vector<Vector<Real_t>> last_reneighborlist_pos;
  bool exchange_owned ();
  void exchange_ghost ();
  Vector<Real_t> periodic_distance (Vector<Real_t>, const int, const int, const int);
  bool position_inside_local_domain(const Vector<double> &pos);
  GlobalID_t get_global_id ();
  double neighborlist_cutoff, ghost_cutoff, cutoff_extra;
  class objects::Domain *domain;

  std::string object_base_class_name, object_class_name, object_name;

protected:
  virtual void allocate ();

  FC_BASE_OBJECT_COMMON_TOOLS

};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
