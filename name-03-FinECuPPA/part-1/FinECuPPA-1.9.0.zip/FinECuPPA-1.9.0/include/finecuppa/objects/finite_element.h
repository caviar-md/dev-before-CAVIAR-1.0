
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_FINITE_ELEMENT_H
#define FINECUPPA_FINITE_ELEMENT_H

#include "finecuppa/utility/pointers.h"

#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {

class Finite_element : protected Pointers {
 public:
  Finite_element (class FinECuPPA *);
  virtual ~Finite_element();
  virtual void calculate_acceleration ();
  virtual bool read(class finecuppa::Parser *);//=0;  
  std::string object_base_class_name, object_class_name, object_name;

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
 
