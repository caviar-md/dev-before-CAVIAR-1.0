
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_INTEGRATION_VELOCITY_VERLET_LANGEVIN_H
#define FINECUPPA_INTEGRATION_VELOCITY_VERLET_LANGEVIN_H

#include "finecuppa/objects/integration.h"
#include <random>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

class Velocity_verlet_langevin : public Integration {
public:
  Velocity_verlet_langevin (class FinECuPPA *);
   ~Velocity_verlet_langevin();    
  bool read (class finecuppa::Parser *);
protected:

  void step_part_I ();
  void step_part_II ();
  void setup_custom ();
  std::mt19937 rnd_generator_x, rnd_generator_y, rnd_generator_z;
  std::vector<double> eta_x, eta_y, eta_z;
// the default stddev is 1  
  std::normal_distribution<double> rnd_ndist_x, rnd_ndist_y, rnd_ndist_z;    
  double temperature, zeta, kb;
  double a, b, c; 
  void print_langevin_parameters();
};

} //integration
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
