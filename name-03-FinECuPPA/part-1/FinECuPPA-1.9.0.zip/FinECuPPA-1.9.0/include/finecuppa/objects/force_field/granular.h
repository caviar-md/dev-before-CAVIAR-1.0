
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_FORCE_FIELD_GRANULAR_H
#define FINECUPPA_FORCE_FIELD_GRANULAR_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Granular : public Force_field {
public:
  Granular (class FinECuPPA *);
  ~Granular () {};
  
  bool read (class finecuppa::Parser *);
  void calculate_acceleration ();
protected:
  std::vector<Real_t> elastic_coef,dissip_coef, radius;
  Vector<Real_t> gravity;
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
