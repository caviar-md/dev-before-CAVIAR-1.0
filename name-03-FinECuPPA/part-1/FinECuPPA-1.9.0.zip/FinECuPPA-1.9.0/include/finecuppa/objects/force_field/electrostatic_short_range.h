
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_FORCE_FIELD_ELECTROSTATIC_SHORT_RANGE_H
#define FINECUPPA_FORCE_FIELD_ELECTROSTATIC_SHORT_RANGE_H

#include "finecuppa/objects/force_field.h"
#include "finecuppa/utility/vector.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

class Electrostatic_short_range : public Force_field {
public:
  Electrostatic_short_range (class FinECuPPA *);
  ~Electrostatic_short_range () {};
  double potential (const Vector<double> &);
  double potential (const int);

  Vector<double> field (const Vector<double> &);
  Vector<double> field (const int);

  double energy();

  bool read (class Parser *);
  void calculate_acceleration ();

  void initialize();
  double k_electrostatic;
  Vector<double> external_field;

  // short range force shift
  // V(r) = ( q_i q_j / 4 Pi epsilon ) * (1/r + c r ^beta + d) 
  // (Steinbach 1994)
  // journal of computational chemistry Vol 15 No 7 pages 667-683 (1994)
  double C, D, beta; 
  bool initialized;
  double cutoff_sq;
 
};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
