
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_STOBJECTS_RANDOM_1D_H
#define FINECUPPA_STOBJECTS_RANDOM_1D_H

#include "finecuppa/utility/pointers.h"
#include <random>
#include <vector>
#include <string>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
namespace single_type_objects {

class Random_1D : protected Pointers {
 public:
  Random_1D () ;
  Random_1D (class FinECuPPA *) ;    
  Random_1D (class FinECuPPA *, std::string TYPE, double MIN, double MAX, double STDDEV, double MEAN, int SEED) ;
  ~Random_1D () ;
  bool read(Parser *);
  void generate (); // creates the std::mt19937 with given parameters ...    
  double min, max, stddev, mean;
    
  std::string type;
  
  int seed;        
  int num; // number of random atoms or molecules to be created    
  int type_int;
        
  bool generated, generated_u_dist, generated_n_dist; 
    
  std::mt19937 *ran_gen;
  std::uniform_real_distribution<> *u_dist;
  std::normal_distribution<> *n_dist;
    
  protected:

  FC_BASE_OBJECT_COMMON_TOOLS
};

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif

