
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECT_STOBJECTS_MOLECULE_H
#define FINECUPPA_OBJECT_STOBJECTS_MOLECULE_H

#include "finecuppa/utility/pointers.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/objects/atom_data/utility/bond.h"
#include <vector>

FINECUPPA_NAMESPACE_OPEN
class Parser;
namespace objects {
class Atom_data;
namespace single_type_objects {
class Atom;
struct Atomic_Bond {
  int i1, i2;
  double distance;
};
class Molecule : protected Pointers {
 public:
  Molecule (class FinECuPPA *);
  Molecule (class FinECuPPA *, class Molecule *,  Vector<double>, Vector<double>);
  Molecule (const Molecule & a);
  Molecule ();
  ~Molecule ();

  bool read (Parser *);
  Vector<double> pos_tot () const;
  Vector<double> vel_tot () const;  
  Vector<double> pos () const ;
  Vector<double> & pos () ;
  Vector<double> vel () const;
  Vector<double> & vel ()  ;
  void give_position_and_radius (std::vector<Vector<double>>&, std::vector<double>&);
  void correct_heritage ();
  
  bool add_atom (const class Atom &);
  bool add_atom (const class Atom &, const Vector<double> &p, const Vector<double> &v);  
  bool add_molecule (const Molecule &);  
  bool add_molecule (const Molecule &, const Vector<double> &p, const Vector<double> &v);
  bool add_directly(Parser *);
  void number_of_atoms(int &);
  void output_xyz (std::ofstream &);

  void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&,
      std::vector<Vector<double>>&);

  void extract_all_e_pos_vel (std::vector<int>&, std::vector<Vector<double>>&,
      std::vector<Vector<double>>&, std::vector <std::vector<Bond>>&,
      std::vector <std::vector<int>> &, std::vector<int>& );

  void report();
   
  bool part_of_a_molecule;
  Molecule * upper_level_molecule;

  Vector<double> position, velocity;
  std::vector<Atom> atoms;
  std::vector<Molecule> molecules;

  std::vector<Bond> atomic_bond; // note that this is different from Atom_data->atomic_bond
  std::vector<int> atomic_bond_index; // note that this is different from Atom_data->atomic_bond_index_list

  class Atom_data *atom_data;
  bool add_to_atom_data(class Atom_data *, const Vector<double>, const Vector<double>);
  bool add_molecule(Parser *);
  bool add_atom(Parser *);
  FC_BASE_OBJECT_COMMON_TOOLS
  
};

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
