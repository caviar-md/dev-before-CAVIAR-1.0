
A directory to do interesting things with cmake!
What we do here is configuration, compile and linking the FinECuPPA package. 
CMake is platform independent, however what we have written here is a little bit
idealistic and may not work properly on some machines. We hope to make 
improvements to this directory with each new version of FinECuPPA.
