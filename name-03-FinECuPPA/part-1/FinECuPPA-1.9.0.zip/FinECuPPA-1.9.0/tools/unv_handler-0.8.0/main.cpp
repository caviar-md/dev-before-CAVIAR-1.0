#include <iostream>
#include "unv_handler.h"

int main () {

  NS_mesh_handler::Unv_handler unv_handler;

/*
  // a tetra mesh with internal faces
  unv_handler.import("../mesh/Mesh_box_gr.unv", true);
  unv_handler.convert_tetra_to_hexa ();  
  unv_handler.remove_hexa_internals (1e-9);    
  unv_handler.export_("../mesh/test.unv", false);  
*/  

/*
  // adding meshes and removing internal faces, then making a VTK file
  unv_handler.import ("../mesh/Mesh_5_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_6_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_7_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_8_merge_g.unv", true); 
  unv_handler.remove_hexa_internals (1e-9);  
  unv_handler.export_vtk("../mesh/test.vtk");  
*/

/*
  // merging multiple meshes and removing internal faces
  unv_handler.import ("../mesh/Mesh_5_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_6_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_7_merge_g.unv", true);
  unv_handler.import ("../mesh/Mesh_8_merge_g.unv", true);    
  unv_handler.merge_all (true);
  unv_handler.remove_hexa_internals (1e-9);    
  unv_handler.export_ ("../mesh/test.unv",false);
*/

/*
  // import multiple tetra, merge them, convert to hexa, remove internal faces
  unv_handler.import("../mesh/Mesh_4_compound_tetra.unv", true);  
  unv_handler.import("../mesh/Mesh_1.unv", true);    
  unv_handler.import("../mesh/Mesh_2.unv", true);      
  unv_handler.merge_all (true);  
  unv_handler.convert_tetra_to_hexa ();
  unv_handler.remove_hexa_internals (1e-9); 
  unv_handler.export_("../mesh/test.unv", false);  
*/  

/*  
  // removing similar points from unv data
  unv_handler.import("../mesh/Mesh_1_compound_1part_hexa.unv", true);
  unv_handler.remove_similar_points (1e-9);  
  unv_handler.export_("../mesh/test.unv", false);  
*/ 



/*
  // simple removing internal faces
  unv_handler.import ("../mesh/compound_1.unv", true);  
  unv_handler.remove_hexa_internals (1e-9);
  unv_handler.export_("../mesh/test.unv", false);    
*/



///*
  //unv_handler.import ("../mesh/mesh_raw_pore_2seg.unv", true);
  unv_handler.import ("../mesh/mesh_raw_pore_2seg_fixed.unv", true);

/*
  // XXX: initial geometry fix
  // bulk edge
  {
    std::vector<Point_condition> pc_s15;

    Vector<double> v_center15 {15,0,0};
    pc_s15.push_back( Point_condition("distance",v_center15,">",3) );
    pc_s15.push_back( Point_condition("x",">",14.5) );
    pc_s15.push_back( Point_condition("x","<",16.5) );

    Vector<double> v_scale15 {1.0, 2.0/12.0,  2.0/12.0};
    unv_handler.scale_vertices(&pc_s15, v_center15, v_scale15);
  }
  // bulk edge
  {
    std::vector<Point_condition> pc_s15;

    Vector<double> v_center15 {-15,0,0};
    pc_s15.push_back( Point_condition("distance",v_center15,">",3) );
    pc_s15.push_back( Point_condition("x","<",-14.5) );
    pc_s15.push_back( Point_condition("x",">",-16.5) );

    Vector<double> v_scale15 {1.0, 2.0/12.0,  2.0/12.0};
    unv_handler.scale_vertices(&pc_s15, v_center15, v_scale15);
  }
  // tips
  {
    std::vector<Point_condition> pc_s;

    Vector<double> v_center {-62.9,0,0};
    pc_s.push_back( Point_condition("x","<",-62.9) );

    Vector<double> v_scale {1.0, 1.0/2.0,  1.0/2.0};
    unv_handler.scale_vertices(&pc_s, v_center, v_scale);
  }
  // tips
  {
    std::vector<Point_condition> pc_s;

    Vector<double> v_center {62.9,0,0};
    pc_s.push_back( Point_condition("x",">",62.9) );

    Vector<double> v_scale {1.0, 1.0/2.0,  1.0/2.0};
    unv_handler.scale_vertices(&pc_s, v_center, v_scale);
  }
*/

///*
  // XXX necks part
  {
    std::vector<Point_condition> pc_s;

    Vector<double> v_center {-29,0,0};
    pc_s.push_back( Point_condition("x","<",-28.9) );
    pc_s.push_back( Point_condition("x",">",-29.1) );

    Vector<double> v_scale {1.0, 1.5/2.0,  1.5/2.0};
    unv_handler.scale_vertices(&pc_s, v_center, v_scale);
  }
  // necks
  {
    std::vector<Point_condition> pc_s;

    Vector<double> v_center {29,0,0};
    pc_s.push_back( Point_condition("x",">",28.9) );
    pc_s.push_back( Point_condition("x","<",29.1) );

    Vector<double> v_scale {1.0, 1.5/2.0,  1.5/2.0};
    unv_handler.scale_vertices(&pc_s, v_center, v_scale);
  }
//*/




///*
  // XXX : add some groups to the mesh


  std::vector<Point_condition> pc_l1, pc_l2, pc_l3, pc_l4;
  std::vector<Point_condition> pc_r1, pc_r2, pc_r3, pc_r4;

  pc_r1.push_back( Point_condition("x",">",15) );
  pc_r1.push_back( Point_condition("x","<",27) );

  pc_r2.push_back( Point_condition("x",">",27) );
  pc_r2.push_back( Point_condition("x","<",31) );

  pc_r3.push_back( Point_condition("x",">",31) );
  pc_r3.push_back( Point_condition("x","<",51) );

  pc_r4.push_back( Point_condition("x",">",51) );
  pc_r4.push_back( Point_condition("x","<",63) );


  pc_l1.push_back( Point_condition("x","<",-15) );
  pc_l1.push_back( Point_condition("x",">",-27) );

  pc_l2.push_back( Point_condition("x","<",-27) );
  pc_l2.push_back( Point_condition("x",">",-31) );

  pc_l3.push_back( Point_condition("x","<",-31) );
  pc_l3.push_back( Point_condition("x",">",-51) );

  pc_l4.push_back( Point_condition("x","<",-51) );
  pc_l4.push_back( Point_condition("x",">",-63) );


  unv_handler.add_face_to_group_with_condition ("1", &pc_l1);
  unv_handler.add_face_to_group_with_condition ("2", &pc_l2);
  unv_handler.add_face_to_group_with_condition ("3", &pc_l3);
  unv_handler.add_face_to_group_with_condition ("4", &pc_l4);

  unv_handler.add_face_to_group_with_condition ("11", &pc_r1);
  unv_handler.add_face_to_group_with_condition ("12", &pc_r2);
  unv_handler.add_face_to_group_with_condition ("13", &pc_r3);
  unv_handler.add_face_to_group_with_condition ("14", &pc_r4);

//*/


  //unv_handler.remove_hexa_internals (1e-9); // XXX initial geometry fix

  //unv_handler.export_("../mesh/mesh_raw_pore_2seg_fixed.unv", true);  // XXX initial geometry fix

  //unv_handler.export_("../mesh/mesh_raw_pore_2seg_fixed_with_group.unv", true);
  unv_handler.export_("../mesh/pore_neck1.unv", true);

  //unv_handler.export_vtk_boundary("../mesh/mesh_raw_pore_2seg_fixed.vtk");  
  //unv_handler.export_stl_boundary("../mesh/mesh_raw_pore_2seg_fixed.stl");  

//*/

}
