#ifndef UDN_UNSUPPORTED_H
#define UDN_UNSUPPORTED_H

#include <vector>
#include <string>

namespace NS_mesh_handler {

struct Universal_dataset_number_unsupported {
/* 
just to copy and paste lines.
After merging unv files, only the first one should be printed.
*/
  std::vector<std::string> records;

};

}

#endif


