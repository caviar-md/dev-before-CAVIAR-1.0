
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/structure/object_handler/all.h"
#include "finecuppa/structure/object_handler.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/atom_data.h"
//#include "finecuppa/objects/single_type_objects/all.h"
#include "finecuppa/objects/single_type_objects/atom.h"
#include "finecuppa/objects/single_type_objects/molecule.h"

#include <fstream>

FINECUPPA_NAMESPACE_OPEN




bool Object_handler::output_xyz (Parser *parser) {
  output->info("output_xyz: ");
 
  std::ofstream out_file;
  std::string out_file_name = "o_";

  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    const auto t = token.string_value;     
     if (string_cmp(t,"molecule")) {
      std::map<std::string,object_handler::Dictionary>::iterator it_1;
      std::string name_1;
      GET_A_STRING(name_1,"OUTPUT_XYZ: "," expected an molecule or atom NAME.. ")
      CHECK_NAME_EXISTANCE(name_1, it_1, "DISTRIBUTION Read: ","")
      if (it_1->second.type == object_handler::gdst("atom")) {
        out_file_name += "atom_" + name_1 + ".xyz";
        out_file.open (out_file_name.c_str());
        object_container -> atom[it_1->second.index] -> output_xyz (out_file);
      }  else if (it_1->second.type == object_handler::gdst("molecule")) {
        out_file_name += "molecule_" + name_1 + ".xyz";
        out_file.open (out_file_name.c_str());
        int n = 0;
        object_container -> molecule[it_1->second.index] -> number_of_atoms (n);
        out_file << n << "\n" << "Atom\n";
        object_container -> molecule[it_1->second.index] -> output_xyz (out_file);
      }  else error->all(FC_FILE_LINE_FUNC_PARSE,"Object_handler: OUTPUT_XYZ: expected an molecule or atom NAME. ");
    } else  error->all(FC_FILE_LINE_FUNC_PARSE,"OUTPUT_XYZ: Unknown variable or command ");
  
  }
  
  out_file.close ();
  
  return in_file;

}


FINECUPPA_NAMESPACE_CLOSE

