
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/single_type_objects/random_1d.h"
#include "finecuppa/objects/all_structure_tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {

//====================================
//====================================
//====================================

Random_1D::Random_1D (FinECuPPA *fptr) : Pointers{fptr},
   min{0}, max{2}, stddev{1}, mean{1}, type{"type"}, seed{1}, generated{false}
{
  FC_OBJECT_INITIALIZE_INFO
  type_int = 0;
}  
  
Random_1D::Random_1D (FinECuPPA *fptr, std::string type, double min,
    double max, double stddev, double mean, int seed) : Pointers{fptr},
    min{min}, max{max}, stddev{stddev}, mean{mean}, type{type}, seed{seed},
    generated{false}, generated_u_dist{false}, generated_n_dist{false}
{
  FC_OBJECT_INITIALIZE_INFO
  type_int = 0;
}
  
Random_1D::~Random_1D () {
  if (generated == true) 
    delete ran_gen;
  if (generated_u_dist == true)
    delete u_dist;
  if (generated_n_dist == true)
    delete n_dist;
}

bool Random_1D::read(Parser* parser) {
  FC_OBJECT_READ_INFO
    
    bool in_file = true;
    while(true) {
      GET_A_TOKEN_FOR_CREATION
      if (token.string_value=="GENERATE") {generate(); break;}
      else ASSIGN_STRING(type,"Random_1D creation: ","")
      else ASSIGN_REAL(min,"Random_1D creation: ","")
      else ASSIGN_REAL(max,"Random_1D creation: ","")
      else ASSIGN_REAL(stddev,"Random_1D creation: ","")
      else ASSIGN_REAL(mean,"Random_1D creation: ","")
      else ASSIGN_INT(seed,"Random_1D creation: ","")  
      else error->all(FC_FILE_LINE_FUNC_PARSE,"Random_1D creation: Unknown variable or command ");
    }
    return in_file;;

  }
  
void Random_1D::generate () {
  output->info("Random_1D Generate: ");  
  if (generated == true) {
    error->all("Random_1D: Generate: cannot be generated twice. ");
    ran_gen = new std::mt19937 (seed);
    generated = true;
    if (type=="UNIFORM") {
      type_int = 1;
      u_dist = new std::uniform_real_distribution<> (min, max) ;
      generated_u_dist = true;
    } else if (type=="NORMAL") {
      type_int = 2;
      n_dist = new std::normal_distribution<> (mean, stddev);
      generated_n_dist = true;
    } else error->all ("RANDOM_1D generate: Expected NORMAL or UNIFORM for the type. ");
  }
}
  
} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

