
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/single_type_objects/element.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/structure/object_handler/preprocessors_new.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {

Element::Element (FinECuPPA *fptr) : Pointers{fptr},
    mass{1}, radius{1}, charge{0} {
    FC_OBJECT_INITIALIZE_INFO
    element_index = object_container -> element.size();
    }

Element::~Element () {}
  

bool Element::read ( Parser * parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;

  while(true) {
    FC_IF_RAW_TOKEN_EOF_EOL
    else if (t.kind==Kind::identifier) {
      FC_IF_GET_REAL(radius)
      else FC_IF_GET_REAL(mass)
      else FC_IF_GET_REAL(charge)
      else FC_ERROR_PARAMETER("element");
    } else if (t.kind==Kind::assign) {
      error->all(FC_FILE_LINE_FUNC_PARSE, "assign operation is not implemented yet");
    } else {
      error->all(FC_FILE_LINE_FUNC_PARSE, "unexpected token.");
    }
  }

  return in_file;;
}

double Element::get_radius () const {
  return radius;
}

double Element::get_mass () const {
  return mass;
}

double Element::get_charge () const {
  return charge;
}            

int Element::get_element_index() const {
  return element_index;
}

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE
