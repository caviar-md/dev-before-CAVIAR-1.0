
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/single_type_objects/molecule.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/single_type_objects/atom.h"
#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace single_type_objects {


Molecule::Molecule (FinECuPPA *fptr) : Pointers{fptr},
    part_of_a_molecule{false}, upper_level_molecule{nullptr},
    position{Vector<double>{0,0,0}},
    velocity{Vector<double>{0,0,0}}, atom_data{nullptr}
{
  // (maybe) the only user accessable creation funciton.
  FC_OBJECT_INITIALIZE_INFO
}    
    
Molecule::Molecule (FinECuPPA *fptr, class Molecule * f,
    Vector<double> pos, Vector<double> vel) :  Pointers{fptr},
    part_of_a_molecule{true}, upper_level_molecule{f},
    position{pos}, velocity{vel}
{}
    
   
Molecule::Molecule (const Molecule & a) : Pointers{a},
atomic_bond{a.atomic_bond},
atomic_bond_index{a.atomic_bond_index}
{
  part_of_a_molecule = false;
  upper_level_molecule = nullptr;
  position = a.position;
  velocity = a.velocity;
  for (auto i : a.molecules) {
    Molecule a_new (i);
    a_new.part_of_a_molecule = true;
    a_new.upper_level_molecule = this;
    molecules.push_back (a_new);
  }
  for (auto i : a.atoms) {
    Atom a_new (i);
    a_new.part_of_a_molecule = true;
    a_new.upper_level_molecule = this;      
    atoms.push_back (a_new);
  }
}

Molecule::~Molecule () {}


bool Molecule::read ( Parser * parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    ASSIGN_REAL_3D_VECTOR(position,"MOLECULE READ: ","")
    else ASSIGN_REAL_3D_VECTOR(velocity,"MOLECULE READ: ","")
    else if (string_cmp(t,"add")) {
      in_file = add_directly(parser);
    } else if (string_cmp(t,"add_atomic_bond") || string_cmp(t,"atomic_bond") ) {
      Bond b;
      GET_OR_CHOOSE_A_INT(b.index_1,"","")
      GET_OR_CHOOSE_A_INT(b.index_2,"","")
      GET_OR_CHOOSE_A_REAL(b.length,"","")

      atomic_bond.push_back(b);


      if (b.index_1 == b.index_2)
        error->all (FC_FILE_LINE_FUNC_PARSE, "bond indices cannot be similar.");

      bool index_1_exist = false;
      bool index_2_exist = false;
      for (unsigned int i = 0; i < atomic_bond_index.size(); ++i) {
        if (atomic_bond_index[i]==b.index_1) index_1_exist = true;
        if (atomic_bond_index[i]==b.index_2) index_2_exist = true;
      }
      if (!index_1_exist) atomic_bond_index.push_back(b.index_1);
      if (!index_2_exist) atomic_bond_index.push_back(b.index_2);


    } else if (string_cmp(t,"report")) {
      report();
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"add_to_atom_data")) {
      FC_NULLPTR_CHECK(atom_data)
      add_to_atom_data(atom_data, Vector<double>{0,0,0}, Vector<double>{0,0,0});
    } else if (string_cmp(t,"add_molecule")) {
      add_molecule (parser);
      return in_file;
    } else if (string_cmp(t,"add_atom")) {
      add_atom (parser);
      return in_file;
    } else FC_ERR_UNDEFINED_VAR(t)
  }
  
  return in_file;
}

bool Molecule::add_atom ( Parser * parser) {
  FIND_OBJECT_BY_NAME(atom,it)
//  auto m = *object_container->atom[it->second.index];
  objects::single_type_objects::Atom a = *object_container->atom[it->second.index];

  bool in_file = true;
  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL(pos_.x,"","")
      GET_OR_CHOOSE_A_REAL(pos_.y,"","")
      GET_OR_CHOOSE_A_REAL(pos_.z,"","")
    } else if (string_cmp(t,"at_velocity")) {
      velocity_called = true;
      GET_OR_CHOOSE_A_REAL(vel_.x,"","")
      GET_OR_CHOOSE_A_REAL(vel_.y,"","")
      GET_OR_CHOOSE_A_REAL(vel_.z,"","")
    } else FC_ERR_UNDEFINED_VAR(t)
  }


  if (position_called) a.position = pos_;
  if (velocity_called) a.velocity = vel_;
  atoms.push_back (a);

  return in_file;
}

bool Molecule::add_molecule ( Parser * parser) {

  FIND_OBJECT_BY_NAME(molecule,it)
//  auto m = *object_container->molecule[it->second.index];
  objects::single_type_objects::Molecule m = *object_container->molecule[it->second.index];

  bool in_file = true;
  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL(pos_.x,"","")
      GET_OR_CHOOSE_A_REAL(pos_.y,"","")
      GET_OR_CHOOSE_A_REAL(pos_.z,"","")
    } else if (string_cmp(t,"at_velocity")) {
      velocity_called = true;
      GET_OR_CHOOSE_A_REAL(vel_.x,"","")
      GET_OR_CHOOSE_A_REAL(vel_.y,"","")
      GET_OR_CHOOSE_A_REAL(vel_.z,"","")
    } else FC_ERR_UNDEFINED_VAR(t)
  }
/*
  std::cout << "atomic_bond.size()" << m.atomic_bond.size() << std::endl;
  std::cout << "main_atom " << object_container->molecule[it->second.index]->atomic_bond.size() << std::endl;
  for (int i = 0; i < m.atomic_bond.size();++i) {
    std::cout << m.atomic_bond[i].index_1 << std::endl;
  }
*/
  if (position_called) m.position = pos_;
  if (velocity_called) m.velocity = vel_;
  molecules.push_back (m);

  in_file = true;
  return in_file;
}

 void Molecule::report() {
  return ;
}

bool Molecule::add_to_atom_data(class Atom_data *atom_data, const Vector<double> parent_pos, const Vector<double> parent_vel) {
  FC_NULLPTR_CHECK(atom_data)

  const auto local_pos = position + parent_pos;
  const auto local_vel = velocity + parent_vel;
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].add_to_atom_data(atom_data, local_pos, local_vel);
  }


  // check molecule validity...
  bool position_is_inside = true;
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    if(!atom_data->position_inside_local_domain (atoms[i].position + local_pos)) {
      position_is_inside = false;
      return false; // false does not do anything.
    }
  }
  if (position_is_inside) {}


  // ...if it's ok, add the molecules.
  std::vector <int> indices (atoms.size(), -1);
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    const auto id = atom_data -> get_global_id();
    const auto index = atom_data -> owned.position.size();
    atom_data -> add_atom (id, atoms[i].element_index, atoms[i].position + local_pos, atoms[i].velocity + local_vel);
    indices[i] = index;
  }


  // add the bonds if there are some.
  auto dummy_atomic_bond = atomic_bond;
  for (unsigned int j = 0;j<dummy_atomic_bond.size(); ++j) {
    dummy_atomic_bond[j].index_1 = indices[dummy_atomic_bond[j].index_1];
    dummy_atomic_bond[j].index_2 = indices[dummy_atomic_bond[j].index_2];
  }



  auto dummy_atomic_bond_index = atomic_bond_index;    

  for (unsigned int j = 0;j<dummy_atomic_bond_index.size(); ++j) {
    dummy_atomic_bond_index[j] = indices[dummy_atomic_bond_index[j]];
  }


  auto &ab = atom_data -> owned.atomic_bond_vector;
  auto &abiv = atom_data -> owned.atomic_bond_index_vector;
  ab.push_back(dummy_atomic_bond);
  abiv.push_back(dummy_atomic_bond_index);


  return true;
}

bool Molecule::add_directly ( Parser * parser) {

  auto t1 = parser->get_val_token();
  auto t1s = t1.string_value;
  if (t1.kind == Kind::eof || t1.kind == Kind::eol) 
    error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: add what?");

  std::map<std::string,object_handler::Dictionary>::iterator it;
  if (string_cmp(t1s,"atom")) {
    FIND_OBJECT_BY_NAME_NIC(atom,it)
  } else if (string_cmp(t1s,"molecule")) {
    FIND_OBJECT_BY_NAME_NIC(molecule,it)
  } else error->all (FC_FILE_LINE_FUNC_PARSE, "Molecule: add: expected atom or molecule");

  Vector<double> pos_ = {0,0,0};
  Vector<double> vel_ = {0,0,0};
  bool position_called = false;
  bool velocity_called = false;
  bool in_file = true;
  while (true) {
    GET_A_TOKEN_FOR_CREATION 
    const auto t = token.string_value;    
    if (string_cmp(t,"at_position")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(pos_,"","")\
    } else if (string_cmp(t,"at_velocity")) {
      position_called = true;
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(vel_,"","")\
    }
  }

  if (string_cmp(t1s,"atom")) {
    objects::single_type_objects::Atom a_new = *object_container -> atom[it->second.index];
    if (position_called) 
      a_new.pos() = pos_;
    if (velocity_called) 
      a_new.vel() = vel_;
    add_atom (a_new);
  } else if (string_cmp(t1s,"molecule")) {
    objects::single_type_objects::Molecule a_new = *object_container -> molecule[it->second.index];  
    if (position_called)
      a_new.pos() = pos_;
    if (velocity_called) 
      a_new.vel() = vel_;
    add_molecule(a_new);
  }

  return in_file;
}

void Molecule::give_position_and_radius (std::vector<Vector<double>> &p_vector, std::vector<double> &r_vector) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].give_position_and_radius (p_vector, r_vector);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    r_vector.push_back (atoms[i].get_radius());
    p_vector.push_back (atoms[i].pos_tot());
  }  
}


void Molecule::correct_heritage () {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].upper_level_molecule = this;
    molecules[i].part_of_a_molecule = true;
    molecules[i].correct_heritage ();
  }  
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].upper_level_molecule = this;
    atoms[i].part_of_a_molecule = true; 
  }
}


void Molecule::extract_all_e_pos_vel (std::vector<int>& e, std::vector<Vector<double>>&p,
 std::vector<Vector<double>>&v) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].extract_all_e_pos_vel(e, p, v);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].extract_all_e_pos_vel(e, p, v);
  }
}
 

void Molecule::extract_all_e_pos_vel (std::vector<int> &e, std::vector<Vector<double>> &p,
    std::vector<Vector<double>> &v, std::vector <std::vector<Bond>> &ab,
      std::vector <std::vector<int>> &abil, std::vector<int>& asim ) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].extract_all_e_pos_vel(e, p, v, ab, abil, asim);
  }

  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].extract_all_e_pos_vel(e, p, v);
  }

  ab.push_back(atomic_bond);
  abil.push_back(atomic_bond_index);
  //aism.push_back(atoms.size());
}

void Molecule::number_of_atoms (int &n) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].number_of_atoms (n);
  }
  n += atoms.size();
}


void Molecule::output_xyz (std::ofstream & out_file) {
  for (unsigned int i = 0; i < molecules.size(); ++i) {
    molecules[i].output_xyz (out_file);
  }
  for (unsigned int i = 0; i < atoms.size(); ++i) {
    atoms[i].output_xyz (out_file);
  }
}


Vector<double> Molecule::pos_tot () const {
  if (part_of_a_molecule) return position + upper_level_molecule->pos_tot();
   else return position;  
}
Vector<double> Molecule::vel_tot () const {
  if (part_of_a_molecule) return velocity + upper_level_molecule->vel_tot();
  else return velocity;  
}


bool Molecule::add_atom (const objects::single_type_objects::Atom &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].upper_level_molecule = this;
  atoms[i].part_of_a_molecule = true;
  atoms[i].pos() = p;
  atoms[i].vel() = v;
  return true; //WARNING
}

bool Molecule::add_molecule (const objects::single_type_objects::Molecule &a, const Vector<double> &p, const Vector<double> &v) {
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].upper_level_molecule = this;
  molecules[i].part_of_a_molecule = true;
  molecules[i].pos() = p;
  molecules[i].vel() = v;
  return true; //WARNING  
}

bool Molecule::add_atom (const objects::single_type_objects::Atom & a){
  unsigned int i = atoms.size();
  atoms.push_back (a);
  atoms[i].upper_level_molecule = this;
  atoms[i].part_of_a_molecule = true;
  return true; //WARNING  
}

bool Molecule::add_molecule (const objects::single_type_objects::Molecule & a){
  unsigned int i = molecules.size();
  molecules.push_back (a);
  molecules[i].upper_level_molecule = this;
  molecules[i].part_of_a_molecule = true;
  return true; //WARNING  
}

Vector<double> Molecule::pos () const {
  return position;  
}

Vector<double> & Molecule::pos ()  {
  return position;
}

Vector<double> Molecule::vel () const {
  return velocity;  
}

Vector<double> & Molecule::vel ()  {
  return velocity;
}

} //single_type_objects
} //objects

FINECUPPA_NAMESPACE_CLOSE

