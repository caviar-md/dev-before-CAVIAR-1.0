
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/domain/box_single.h"
#include "finecuppa/structure/communicator.h"
#include "finecuppa/objects/all_structure_tools.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace domain {

Box_single::Box_single (FinECuPPA *fptr) : Domain{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

bool Box_single::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"lower_global.x") || string_cmp(t,"xmin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.x,"","")
    } else if (string_cmp(t,"upper_global.x") || string_cmp(t,"xmax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.x,"","")
    } else if (string_cmp(t,"lower_global.y") || string_cmp(t,"ymin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.y,"","")
    } else if (string_cmp(t,"upper_global.y") || string_cmp(t,"ymax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.y,"","")
    } else if (string_cmp(t,"lower_global.z") || string_cmp(t,"zmin") ) {
      GET_OR_CHOOSE_A_REAL(lower_global.z,"","")
    } else if (string_cmp(t,"upper_global.z") || string_cmp(t,"zmax") ) {
      GET_OR_CHOOSE_A_REAL(upper_global.z,"","")
    } else if (string_cmp(t,"boundary_condition") || string_cmp(t,"bc") ) {
      GET_OR_CHOOSE_A_INT_3D_VECTOR(boundary_condition,"","")
    } else if (string_cmp(t,"generate")) {
      generate();
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}
void Box_single::generate() {
  calculate_local_domain ();
}

void Box_single::calculate_local_domain () {
  lower_local.x = lower_global.x;
  lower_local.y = lower_global.y;
  lower_local.z = lower_global.z;
  
  upper_local.x = upper_global.x;
  upper_local.y = upper_global.y;
  upper_local.z = upper_global.z;
}

} //domain
} //objects
FINECUPPA_NAMESPACE_CLOSE

