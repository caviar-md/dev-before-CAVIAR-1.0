
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/atom_data/simple.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/single_type_objects/atom.h"
#include "finecuppa/objects/single_type_objects/molecule.h"
#include "finecuppa/objects/single_type_objects/element.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace atom_data {

Simple::Simple (FinECuPPA *fptr) : Atom_data{fptr} {
  FC_OBJECT_INITIALIZE_INFO
}

void Simple::allocate () {
  
}

bool Simple::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"ghost_cutoff")) {
      GET_OR_CHOOSE_A_REAL(ghost_cutoff,"","")
      if (ghost_cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "ghost_cutoff have to non-negative."); 
    } else if (string_cmp(t,"neighborlist_cutoff")) {
      GET_OR_CHOOSE_A_REAL(neighborlist_cutoff,"","")
      if (neighborlist_cutoff < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "neighborlist_cutoff have to non-negative."); 
    } else if (string_cmp(t,"cutoff_extra")) {
      GET_OR_CHOOSE_A_REAL(cutoff_extra,"","")
      if (cutoff_extra < 0.0) error->all (FC_FILE_LINE_FUNC_PARSE, "neighborlist_cutoff have to non-negative."); 
    } else if (string_cmp(t,"add_atom")) {
      FIND_OBJECT_BY_NAME(atom,it)
      add_atom_directly(*object_container->atom[it->second.index]);
    } else if (string_cmp(t,"add_molecule")) {
      FIND_OBJECT_BY_NAME(molecule,it)
      add_molecule_directly(*object_container->molecule[it->second.index]);
    } else if (string_cmp(t,"add_elements")) {
      add_elements_directly();
    } else if (string_cmp(t,"set_domain") || string_cmp(t,"domain")) {
      FIND_OBJECT_BY_NAME(domain,it)
      domain = object_container->domain[it->second.index];
    } else if (string_cmp(t,"add_xyz_data_file")) {
      add_xyz_data_file(parser);
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");

  }
  return in_file;
}

void Simple::output_data (int i) {
  
}

} //atom_data
} //objects
FINECUPPA_NAMESPACE_CLOSE

