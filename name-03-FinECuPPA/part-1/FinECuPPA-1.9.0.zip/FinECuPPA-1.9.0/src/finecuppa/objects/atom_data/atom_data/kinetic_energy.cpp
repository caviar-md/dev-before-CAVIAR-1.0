
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/atom_data.h"
#include "finecuppa/structure/communicator.h"
#include "finecuppa/structure/error.h"
#include "finecuppa/objects/domain.h"

#include <algorithm>


FINECUPPA_NAMESPACE_OPEN
namespace objects {


double Atom_data::kinetic_energy () {
  double e_total = 0.0;

  double e_owned = 0.0;

  for (int i = 0; i < static_cast<int>(owned.position.size()); ++i) {
    e_owned += owned.mass[owned.type[i]] * (owned.velocity[i] * owned.velocity[i]);
  }
  e_owned *= 0.5;

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  e_total = e_owned;
#elif defined(FINECUPPA_WITH_MPI)
  MPI_Allreduce (&e_owned, &e_total, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
#else
  e_total = e_owned;
#endif
  return e_total;
}

double Atom_data::kinetic_energy (const int t) {
  double e_total = 0.0;

  double e_owned = 0.0;

  for (int i = 0; i < static_cast<int>(owned.position.size()); ++i) {
    if (t==static_cast<int>(owned.type[i])) {
      e_owned += owned.mass[owned.type[i]] * (owned.velocity[i] * owned.velocity[i]);
    }
  }
  e_owned *= 0.5;

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  e_total = e_owned;
#elif defined(FINECUPPA_WITH_MPI)
  MPI_Allreduce (&e_owned, &e_total, 1, MPI_DOUBLE, MPI_SUM, mpi_comm);
#else
  e_total = e_owned;
#endif
  return e_total;

}

} //objects

FINECUPPA_NAMESPACE_CLOSE


