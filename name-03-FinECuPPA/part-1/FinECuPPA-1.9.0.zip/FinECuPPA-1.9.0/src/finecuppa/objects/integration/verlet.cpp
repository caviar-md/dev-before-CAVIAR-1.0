
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/integration/verlet.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integration {

Verlet::Verlet (FinECuPPA *fptr) : Integration{fptr} {
  FC_OBJECT_INITIALIZE_INFO
  integration_type = 4;
}

Verlet::~Verlet (){}

bool Verlet::read (finecuppa::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"add_neighborlist") || string_cmp(t,"neighborlist")) {
      FIND_OBJECT_BY_NAME(neighborlist,it)
      neighborlist.push_back(object_container->neighborlist[it->second.index]);
    } else if (string_cmp(t,"add_force_field") || string_cmp(t,"force_field")) {
      FIND_OBJECT_BY_NAME(force_field,it)
      force_field.push_back(object_container->force_field[it->second.index]);
    } else if (string_cmp(t,"add_constraint") || string_cmp(t,"constraint")) {
      FIND_OBJECT_BY_NAME(constraint,it)
      constraint.push_back(object_container->constraint[it->second.index]);
    } else if (read_base_class_commands(parser)) {
    } else error->all (FC_FILE_LINE_FUNC_PARSE, "Unknown variable or command");
  }
  return in_file;
}

void Verlet::step_part_I () {

  auto &pos = atom_data -> owned.position;
  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;

  const auto psize = pos.size();

  if (position_old.size() != psize) {
    acceleration_old.resize(psize);
  }

  for (unsigned int i=0; i<psize; i++) { 
    acceleration_old[i] = acc[i];
    pos [i] += vel [i] * dt + 0.5 * acc [i] * dt * dt;
    acc [i].x = 0.0;acc [i].y = 0.0;acc [i].z = 0.0;
  }

}

void Verlet::step_part_II () {

  auto &vel = atom_data -> owned.velocity;
  auto &acc = atom_data -> owned.acceleration;
    
  for (unsigned int i=0; i<vel.size(); i++) {
    vel [i] += 0.5 * (acc [i] + acceleration_old[i]) * dt;
  }

}

} //integration
} //objects

FINECUPPA_NAMESPACE_CLOSE


