
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/force_field/magnetic_external.h"
#include "finecuppa/objects/all_structure_tools.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include <cmath>
#include <iomanip>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace force_field {

Magnetic_external::Magnetic_external (FinECuPPA *fptr) : Force_field{fptr},
 amplitude{1.0}, direction{Vector<double>{0,0,0}}
 {
  FC_OBJECT_INITIALIZE_INFO 
  //FC_ERR_NOT_IMPLEMENTED
}

bool Magnetic_external::read (Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;

  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"amplitude")) {
      GET_OR_CHOOSE_A_REAL(amplitude,"","")
    } else if (string_cmp(t,"direction")) {
      GET_OR_CHOOSE_A_REAL_3D_VECTOR(direction, "", "");
      auto d_sq = direction*direction;
      auto d_norm = std::sqrt(d_sq);
      direction = direction/d_norm;
    } else if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else FC_ERR_UNDEFINED_VAR(t)
  }
  
  return in_file;
}

void Magnetic_external::calculate_acceleration () {
  FC_NULLPTR_CHECK(atom_data)

  const auto &pos = atom_data -> owned.position;  
  const auto &vel = atom_data -> owned.velocity;  

  for (unsigned int i=0;i<pos.size();++i) {
    const auto type_i = atom_data -> owned.type [i] ;
    const auto mass_i = atom_data -> owned.mass [ type_i ];


    const auto a = amplitude * (cross_product(vel[i], direction)) / mass_i;
    atom_data -> owned.acceleration [i] += a;
    
  }  

}

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

