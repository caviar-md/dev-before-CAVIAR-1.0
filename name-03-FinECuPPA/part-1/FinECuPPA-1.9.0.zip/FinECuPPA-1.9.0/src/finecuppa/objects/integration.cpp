
//========================================================================
//
// Copyright (C) 2016 - 2019 by the FinECuPPA author, Morad Biagooi.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/integration.h"
#include "finecuppa/objects/neighborlist.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/force_field.h"
#include "finecuppa/objects/constraint.h"
#include "finecuppa/objects/all_structure_tools.h"

#include <iomanip>
#include <string>

FINECUPPA_NAMESPACE_OPEN

namespace objects {

Integration::Integration (FinECuPPA *fptr) : Pointers{fptr}, 
    atom_data{nullptr} {
  FC_OBJECT_INITIALIZE
}
Integration::~Integration (){}

bool Integration::read_base_class_commands (finecuppa::Parser *parser) {
  bool command_called = false;
  parser -> keep_current_token();
  auto token = parser -> get_val_token();
  auto t = token.string_value;
  if (string_cmp(t,"output_total_force") ) {
    command_called = true;
    output_total_force();
  } else if (string_cmp(t,"output_total_energy") ) {
    command_called = true;
    output_total_energy();
  }
  return command_called;
}

bool Integration::run (const double timestep, const int initial_step,
    const int final_step) {

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)
  int my_mpi_rank = comm->me;
#endif

  dt = timestep;

  setup();

  setup_custom();

  for (auto i = initial_step; i < final_step; ++i) {

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)


    if (my_mpi_rank==0) {

      // contains (initial) velocity and position incrementations and other things.
      step_part_I ();


      // fixing position and velocity according to the constraints
      for (auto&& c : constraint)
        c -> step_part_I ();


      bool make_list = boundary_condition (); 


      if (make_list) 
        for (auto&& n: neighborlist) n->build_neighlist ();
      else {
        for (auto&& n: neighborlist)
          make_list = make_list || n->rebuild_neighlist ();
        if (make_list) 
          for (auto&& n: neighborlist) n->build_neighlist ();
      }

    }


    atom_data->synch_owned_data(0);

    for (auto&& f : force_field)
      f -> calculate_acceleration ();

    MPI_Barrier(mpi_comm);

    if (my_mpi_rank==0) {


      // contains (final) velocity incrementations.
      step_part_II ();


      // last fixing of the velocity (if needed).
      for (auto&& c : constraint)
        c -> step_part_II ();
    }


    output->dump_data (i);

#else

    // contains (initial) velocity and position incrementations and other things.
    step_part_I ();

    // fixing position and velocity according to the constraints
    for (auto&& c : constraint)
      c -> step_part_I ();

    bool make_list = boundary_condition (); 


    if (make_list) 
      for (auto&& n: neighborlist) n->build_neighlist ();
    else {
      for (auto&& n: neighborlist)
        make_list = make_list || n->rebuild_neighlist ();
      if (make_list) 
        for (auto&& n: neighborlist) n->build_neighlist ();
    }

    for (auto&& f : force_field)
      f -> calculate_acceleration ();


    // contains (final) velocity incrementations.
    step_part_II ();

    // last fixing of the velocity (if needed).
    for (auto&& c : constraint)
      c -> step_part_II ();

    output->dump_data (i);

#endif

  } 
  
  cleanup(); 
  cleanup_custom();
  return true; //WARNING
}


bool Integration::boundary_condition () {
  bool result = false;

// the result only in MPI case can
// become true, due to exchanging a particle between domains
  result = atom_data -> exchange_owned (); 

  atom_data -> exchange_ghost ();
#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)

#elif defined(FINECUPPA_WITH_MPI)
  MPI_Allreduce (MPI::IN_PLACE, &result, 1, MPI::BOOL, MPI::LOR, mpi_comm);
#endif
  return result;
}

void Integration::setup () {

  FC_NULLPTR_CHECK(atom_data)
  if (neighborlist.size()==0) output->warning("Integration::setup: neighborlist.size() = 0");
  if (force_field.size()==0) output->warning("Integration::setup: force_field.size() = 0");

#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)

  atom_data->synch_owned_data(0);

  //if (my_mpi_rank==0) { // XXX STRANGE MPI BUG! if uncommented, the code will stuck somewhere else.

    for (auto&& n: neighborlist) n->init ();

    atom_data -> exchange_owned (); // isn't neccesary

    atom_data -> exchange_ghost ();

    for (auto&& n: neighborlist)
      n->build_neighlist ();

  //}




  for (auto&& f : force_field) 
    f -> calculate_acceleration ();


  //if (my_mpi_rank==0) {// XXX STRANGE MPI BUG! if uncommented, the code will stuck somewhere else.
    output->dump_data (0);
  //}


#else

  for (auto&& n: neighborlist) n->init ();

  atom_data -> exchange_owned (); // isn't neccesary

  atom_data -> exchange_ghost ();

  for (auto&& n: neighborlist) n->build_neighlist ();

  for (auto&& f : force_field) 
    f -> calculate_acceleration ();

  output->dump_data (0);

#endif

}

void Integration::setup_custom () { }

void Integration::cleanup () { }

void Integration::cleanup_custom () { }

void Integration::output_total_force() {
  FC_NULLPTR_CHECK(atom_data)
  std::cout << std::setprecision(10);
  std::cout << "Integration::output_total_force :\n";
  const auto &pos_size = atom_data->owned.position.size();
  const auto &acc = atom_data->owned.acceleration;
  const auto &type = atom_data->owned.type;
  const auto &mass = atom_data->owned.mass;
  
  for (unsigned i = 0; i < pos_size ; ++i)
    std::cout << i << ": " << acc[i]*mass[ type[i] ] << "\n";
  std::cout << std::setprecision(6);
}

void Integration::output_total_energy() {
  if (force_field.size()==0) {
    std::cout << "Integration::output_total_energy: force_field.size()=0 \n";
    return;
  }
  std::cout << std::setprecision(10);
  double sum_e = 0;
  for (auto f : force_field) {
    const auto e = f -> energy ();
    sum_e += e;
    std::cout << "e: " << e << "\n";
  }
  std::cout << "sum_e: " << sum_e << std::endl;
  std::cout << std::setprecision(6);
}


} //objects

FINECUPPA_NAMESPACE_CLOSE


