
## What is this directoy?

This directory with its subdirectories contains mainly all the C++ header files
for FinECuPPA package. 
