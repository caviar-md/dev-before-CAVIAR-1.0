
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_UNIQUE_MOLECULEGROUP_H
#define FINECUPPA_OBJECTS_UNIQUE_MOLECULEGROUP_H

#include "finecuppa/objects/unique.h"
#include "finecuppa/objects/unique/molecule.h"

FINECUPPA_NAMESPACE_OPEN

namespace objects {
class Atom_data;
namespace unique {

class Molecule_group : public Unique {
 public:
  Molecule_group (class FinECuPPA *);
  Molecule_group (const Molecule_group &);
  Molecule_group ();
  ~Molecule_group ();

  bool read (finecuppa::interpreter::Parser *);
  void verify_settings ();

  Vector<double> pos_tot () const;
  Vector<double> vel_tot () const; 

  void add_molecule(const objects::unique::Molecule &);
  void add_molecule(const objects::unique::Molecule &,
                    finecuppa::Vector<double> p=finecuppa::Vector<double>{0,0,0},
                    finecuppa::Vector<double> v=finecuppa::Vector<double>{0,0,0});

  std::vector<objects::unique::Molecule> molecules;

  bool part_of_a_molecule_group;    
  Molecule_group * upper_level_molecule_group;

  Vector<double> position, velocity;
 
};

} //unique
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
