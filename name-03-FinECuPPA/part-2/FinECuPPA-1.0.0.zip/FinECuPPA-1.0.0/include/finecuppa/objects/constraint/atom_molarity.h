
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_CONSTRAINT_ATOMMOLARITY_H
#define FINECUPPA_OBJECTS_CONSTRAINT_ATOMMOLARITY_H

#include "finecuppa/objects/constraint.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
class Atom_data;
namespace unique {
class Atom; class Molecule;
}
namespace constraint {

class Atom_molarity : public Constraint {
 public:
  Atom_molarity (class FinECuPPA *);
   ~Atom_molarity ( );
  bool read (class finecuppa::interpreter::Parser *);

  void step_part_I ();
  void step_part_II ();
  void verify_settings();

  bool minimum_set, maximum_set;
  int maximum_limit;
  int atom_type;
  int minimum_limit;
  int creation_try;
  int steps, check_steps;
  Vector<double> calculation_box_low, calculation_box_high;
  Vector<double> creation_box_low,    creation_box_high;
  unique::Molecule *creation_molecule;
  unique::Atom *creation_atom;
  Atom_data *atom_data;
  bool settings_verified;  

};

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
