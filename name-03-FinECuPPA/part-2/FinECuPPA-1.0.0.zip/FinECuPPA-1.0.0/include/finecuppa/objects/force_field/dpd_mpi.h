
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_FORCEFIELD_DPDMPI_H
#define FINECUPPA_OBJECTS_FORCEFIELD_DPDMPI_H

#include "finecuppa/objects/force_field.h"

#include <random>

FINECUPPA_NAMESPACE_OPEN
namespace objects {

namespace force_field {

class Dpd_mpi : public Force_field { // this is maybe slower than dpd but more accurate, in the scense that it will send the force caclulated to the owned counterpart of ghost atoms.
public:
  Dpd_mpi (class FinECuPPA *);
  ~Dpd_mpi () {};
  
  bool read (class finecuppa::interpreter::Parser *);
  void verify_settings ();
  void calculate_acceleration ();
public:
  std::vector<std::vector<Real_t>> conserv_coef, dissip_coef;
  Real_t temperature, kBoltzman;
  int rnd_seed;
  std::mt19937 rnd_generator;
  std::normal_distribution<double> rnd_ndist; // stddev() == 1
  double dt;

};

} //force_field
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
