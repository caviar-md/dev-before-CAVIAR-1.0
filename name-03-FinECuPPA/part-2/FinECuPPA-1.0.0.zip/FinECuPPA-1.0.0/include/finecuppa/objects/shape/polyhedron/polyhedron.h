
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POLYHEDRON_H
#define FINECUPPA_OBJECTS_SHAPE_POLYHEDRON_POLYHEDRON_H

#include "finecuppa/utility/finecuppa_config.h"
#include "finecuppa/utility/vector.h"
#include "finecuppa/utility/types.h"
#include <vector>
#include <map>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace shape {
namespace polyhedron {
struct Polyhedron {

  Polyhedron () : nx_part{1}, ny_part{1}, nz_part{1}, thickness{1.0}, grid_toll{0.0} {}

  std::vector<Vector<Real_t>> vertex;  // contains cartesian coordinates
  std::vector<std::vector<unsigned int>> vertex_map;  // made in "merge_vertices()" it's a map to the index of possible similar vertex with the lower index

  std::vector<std::vector<unsigned int>> face;  // contains vertex indices of ngons
  std::vector<Vector<Real_t>> normal; // normal of faces (inward or outward?)
//  Locally Defined // std::vector<std::vector<Vector<Real_t>>> edge_norms1; // addition of normals of neighborlist faces for each edge
//  Locally Defined // std::vector<std::vector<Vector<Real_t>>> edge_norms2; // face[][j]-face[][j+1]
  std::vector<std::vector<Vector<Real_t>>> edge_norms3; // edge_norms1 cross edge_norms2

  std::map<std::vector<unsigned int>,std::vector<unsigned int>> edges; // first: the edge that has vertex[i],vertex[j] ... second: face[m],face[n] that has this edge

  std::vector<std::vector<std::vector<std::vector<unsigned int>>>> grid; // contains face indices within the grid;
  Real_t xlo, ylo, zlo, xhi, yhi, zhi; // highest and lowest coordinates of vertices; used in grid;
  Real_t dx_part, dy_part, dz_part; // used in grid;
  unsigned int nx_part, ny_part, nz_part;   // used in grid;
  
        
  Real_t thickness; // it defines the maximum thickness of each surface. If a particle go farther than it inside, it won't be inside anymore.
  Real_t grid_toll;

};
} //polyhedron
} //shape
} //objects

FINECUPPA_NAMESPACE_CLOSE

#endif
