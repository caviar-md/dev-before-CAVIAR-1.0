
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_ATOMDATA_BASIC_H
#define FINECUPPA_OBJECTS_ATOMDATA_BASIC_H

#include "finecuppa/objects/atom_data.h"

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace atom_data {
class Basic : public Atom_data {
public:
  Basic (class FinECuPPA *);
  bool read (class finecuppa::interpreter::Parser *);
  bool add_xyz_data_file(class finecuppa::interpreter::Parser *);
  void output_data(const int);
  void report();

  void allocate ();
};

} //atom_data
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
