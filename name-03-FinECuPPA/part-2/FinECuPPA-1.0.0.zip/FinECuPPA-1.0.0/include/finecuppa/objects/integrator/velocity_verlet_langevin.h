
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_OBJECTS_INTEGRATOR_VELOCITYVERLETLANGEVIN_H
#define FINECUPPA_OBJECTS_INTEGRATOR_VELOCITYVERLETLANGEVIN_H

#include "finecuppa/objects/integrator.h"
#include <random>

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace integrator {

class Velocity_verlet_langevin : public Integrator {
public:
  Velocity_verlet_langevin (class FinECuPPA *);
   ~Velocity_verlet_langevin();    
  bool read (class finecuppa::interpreter::Parser *);
public:

  void step_part_I ();
  void step_part_II ();
  void verify_settings ();
  void initialize ();
  void print_langevin_parameters();

  std::mt19937 rnd_generator_x, rnd_generator_y, rnd_generator_z;
  std::vector<double> eta_x, eta_y, eta_z;
// the default stddev is 1  
  std::normal_distribution<double> rnd_ndist_x, rnd_ndist_y, rnd_ndist_z;    
  double temperature, friction, kb, kbt;
  double a, b, c; 
  bool initialized;
};

} //integrator
} //objects
FINECUPPA_NAMESPACE_CLOSE

#endif
