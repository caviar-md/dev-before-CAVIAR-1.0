
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#ifndef FINECUPPA_UTILITY_H
#define FINECUPPA_UTILITY_H

#include "finecuppa_config.h"
#include <algorithm>

// This file contains some small and useful functions used in the FinECuPPA.

FINECUPPA_NAMESPACE_OPEN

// A function that compares two strings. It can be defined case sensitive or not.
// Object names won't be compared by this function, so they are case sensitive.
template <typename T1, typename T2>
bool string_cmp(const T1 a, const T2 b) {
#ifdef FINECUPPA_SCRIPT_COMMAND_CASE_INSENSITIVE
  T1 a_lowercase = a;
  T1 b_lowercase = b;
  std::transform(a_lowercase.begin(), a_lowercase.end(), a_lowercase.begin(), ::tolower);  
  std::transform(b_lowercase.begin(), b_lowercase.end(), b_lowercase.begin(), ::tolower);  
  return (a_lowercase == b_lowercase);
#else
  return (a==b);
#endif
}

// default case insensitive string compare template function
template <typename T1, typename T2>
bool string_cmp_i(const T1 a, const T2 b) {
  T1 a_lowercase = a;
  T1 b_lowercase = b;
  std::transform(a_lowercase.begin(), a_lowercase.end(), a_lowercase.begin(), ::tolower);  
  std::transform(b_lowercase.begin(), b_lowercase.end(), b_lowercase.begin(), ::tolower);  
  return (a_lowercase == b_lowercase);
}

// minimum function (returns in compile time if possible)
template <typename T>
constexpr T min (T a, T b) {
  return a < b ? a : b;
}

// maximum function (returns in compile time if possible)
template <typename T>
constexpr T max (T a, T b) {
  return a > b ? a : b;
}

// integer power function (returns in compile time if possible)
template <typename T>
constexpr T ipow (T num, unsigned pow) {
  return pow ? num*ipow(num, pow-1) : 1;
}

FINECUPPA_NAMESPACE_CLOSE

#endif
