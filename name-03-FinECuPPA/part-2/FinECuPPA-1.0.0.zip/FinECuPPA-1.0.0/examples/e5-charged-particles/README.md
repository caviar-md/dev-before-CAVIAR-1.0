
Use this directory as is instructed in the FinECuPPA user guide.
