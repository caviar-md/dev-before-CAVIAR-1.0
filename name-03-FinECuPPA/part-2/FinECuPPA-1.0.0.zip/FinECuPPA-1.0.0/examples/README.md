

## What is this directoy?
As its name says, it has some examples for the users and developers of the 
package. 
