
## What is this directoy?

This directory contains some tools that have been developed as some pre and
post processing tools for FinECuPPA. Some of them may merge into FinECuPPA main
 code. in the next releases. 

If you made or upgrade any other tools, please contact us. We gladly add it in 
future releases of FinECuPPA.

