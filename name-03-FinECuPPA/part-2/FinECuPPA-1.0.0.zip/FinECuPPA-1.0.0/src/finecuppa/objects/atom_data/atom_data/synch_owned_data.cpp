
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/atom_data.h"
#include "finecuppa/interpreter/communicator.h"
#include "finecuppa/interpreter/error.h"
#include "finecuppa/objects/domain.h"

#include <algorithm>


FINECUPPA_NAMESPACE_OPEN
namespace objects {


void Atom_data::synch_owned_data (int ) {
#if defined(FINECUPPA_SINGLE_MPI_MD_DOMAIN)



  auto mpi_fc_vector_type = comm->mpi_fc_vector_type;
  auto my_mpi_rank = comm->me;
  if (comm->nprocs == 1) return;


  int root_rank = 0;

  int      pos_size = owned.position.size();
  int root_pos_size =            pos_size;

  int      type_size =  owned.type.size();
  int root_type_size =        type_size;

  int      mass_size =  owned.mass.size();
  int root_mass_size =        mass_size;

  int      charge_size =  owned.charge.size();
  int root_charge_size =        charge_size;
  


  MPI_Bcast (&root_pos_size,    1, MPI::INT, 0, mpi_comm);

  // XXX not necessary yet.
  //MPI_Bcast (&synch_owned_data_bcast_details,   1, MPI::BOOL, 0, mpi_comm);

  if (synch_owned_data_bcast_details) {
    MPI_Bcast (&root_type_size,   1, MPI::INT, 0, mpi_comm);
    MPI_Bcast (&root_mass_size,   1, MPI::INT, 0, mpi_comm);
    MPI_Bcast (&root_charge_size, 1, MPI::INT, 0, mpi_comm);
  }




  if (my_mpi_rank != root_rank) {


    if (pos_size != root_pos_size) {
      owned.position.resize(root_pos_size, finecuppa::Vector<double> {0,0,0});
      owned.velocity.resize(root_pos_size, finecuppa::Vector<double> {0,0,0});
      owned.acceleration.resize(root_pos_size, finecuppa::Vector<double> {0,0,0});
    }


    if (type_size != root_type_size) {
      owned.type.resize(root_type_size, 0);
    }



    if (mass_size != root_mass_size) {
      owned.mass.resize(root_mass_size, 1.0);
    }


    if (charge_size != root_charge_size) {
      owned.charge.resize(root_charge_size, 0.0);
    }

  }



  MPI_Bcast (&owned.position[0], root_pos_size, mpi_fc_vector_type, 0, mpi_comm);


  if (synch_owned_data_bcast_details) {
    MPI_Bcast (&owned.type[0], root_type_size, MPI::INT, 0, mpi_comm);

    MPI_Bcast (&owned.mass[0], root_mass_size, MPI::DOUBLE, 0, mpi_comm);

    MPI_Bcast (&owned.charge[0],  root_charge_size, MPI::DOUBLE, 0, mpi_comm);
  }

  synch_owned_data_bcast_details = false;

#endif
}

} //objects

FINECUPPA_NAMESPACE_CLOSE


