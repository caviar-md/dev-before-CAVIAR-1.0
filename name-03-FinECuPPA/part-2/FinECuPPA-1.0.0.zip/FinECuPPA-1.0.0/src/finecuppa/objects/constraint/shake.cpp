
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// Implementation of Shake algorithm is done by Ashkan Shahmoradi
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================

#include "finecuppa/objects/constraint/shake.h"
#include "finecuppa/objects/atom_data.h"
#include "finecuppa/objects/domain.h"
#include "finecuppa/utility/interpreter_io_headers.h"

//#define ABS(x) (x<0 ? -x : x)

FINECUPPA_NAMESPACE_OPEN
namespace objects {
namespace constraint {

Shake::Shake (FinECuPPA *fptr) : Constraint{fptr},
    atom_data{nullptr}, domain{nullptr},
    dt{-1.0}, error_tolerance{1e-6},
    domain_dh{Vector<double>{0,0,0}},
    domain_bc{Vector<int>{0,0,0}},
    initialized{false}, velocity_fix{true}
 {
  FC_OBJECT_INITIALIZE_INFO
  shake_type = 0;
}

Shake::~Shake () {}

bool Shake::read (finecuppa::interpreter::Parser *parser) {
  FC_OBJECT_READ_INFO
  bool in_file = true;
  while(true) {
    GET_A_TOKEN_FOR_CREATION
    auto t = token.string_value;
    if (string_cmp(t,"set_atom_data") || string_cmp(t,"atom_data")) {
      FIND_OBJECT_BY_NAME(atom_data,it)
      atom_data = object_container->atom_data[it->second.index];
    } else if (string_cmp(t,"dt") ) {
      GET_OR_CHOOSE_A_REAL(dt,"","")
    } else if (string_cmp(t,"shake_type") ) {
      GET_OR_CHOOSE_A_INT(shake_type,"","")
    } else if (string_cmp(t,"error_tolerance") ) {
      GET_OR_CHOOSE_A_REAL(error_tolerance,"","")
    } else if (string_cmp(t,"set_domain") || string_cmp(t,"domain")) {
      FIND_OBJECT_BY_NAME(domain,it)
      domain = object_container->domain[it->second.index];
      domain_dh = 0.5*(domain->upper_global - domain->lower_global);
      domain_bc = domain->boundary_condition;
    } else if (string_cmp(t,"velocity_fix")) {
      int v = 0;
      GET_OR_CHOOSE_A_INT(v,"","")
      if (v==0) velocity_fix = false;
      if (v==1) velocity_fix = true;
    } 
    else FC_ERR_UNDEFINED_VAR(t)

  }
  return in_file;
}

void Shake::verify_settings () {
  FC_NULLPTR_CHECK(atom_data)
  atom_data->record_owned_position_old = true;
  FC_NULLPTR_CHECK(domain)
  if (dt <= 0.0) error->all (FC_FILE_LINE_FUNC, "dt have to be a positive number");      

}

void Shake::step_part_I () {
  if (shake_type == 1) {
    bond_fix(); // XXX P.I
  }
}

void Shake::step_part_II () {

  FC_OBJECT_VERIFY_SETTINGS

  if (shake_type == 0) {
    bond_fix(); // XXX P.I
  }
std::cout << "AAAAA" << std::endl;
  if (velocity_fix) {
    // this fix has to be done only on the Shake molecules. If not, the normal
    // leap-frog step has to be enough.
    auto &vel = atom_data -> owned.velocity;
    auto &pos = atom_data -> owned.position;
    auto &pos_old = atom_data -> owned.position_old;
    //auto &acc = atom_data -> owned.acceleration;
    auto &atomic_bond_index_vector = atom_data -> owned.atomic_bond_index_vector;
    for (unsigned int i=0; i<atomic_bond_index_vector.size(); i++) { 
    for (unsigned int j=0; j<atomic_bond_index_vector[i].size(); j++) { // XXX P.II
      const auto k = atomic_bond_index_vector[i][j];
      vel[k] = (pos[k] - pos_old[k]) / dt ;			
    }
    }
  }
std::cout << "AAAAA2" << std::endl;
}




void Shake::bond_fix () {

  auto &pos = atom_data -> owned.position;
  auto &pos_old = atom_data -> owned.position_old;
  auto &atomic_bond_index_vector = atom_data -> owned.atomic_bond_index_vector;
  auto &atomic_bond_vector = atom_data -> owned.atomic_bond_vector;	

  for (unsigned int i=0; i<atomic_bond_index_vector.size(); i++) { 

    auto Nc = atomic_bond_index_vector[i].size();
    if (Nc==0) continue;

  	std::vector<double> l(Nc,0);
	  std::vector<double> C(Nc,0);

		double sum_err = 1.0;

		while(sum_err>error_tolerance) {
			
		
      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;

        double d = atomic_bond_vector[i][j].length;

        double mass_inv_k1 = 1.0/atom_data->owned.mass[atom_data->owned.type[k1]];
        double mass_inv_k2 = 1.0/atom_data->owned.mass[atom_data->owned.type[k2]];

				double dx =  fix_distance_x(pos[k1].x-pos[k2].x);
				double dy =  fix_distance_y(pos[k1].y-pos[k2].y);
				double dz =  fix_distance_z(pos[k1].z-pos[k2].z);

				double dx_old =  fix_distance_x(pos_old[k1].x-pos_old[k2].x);
				double dy_old =  fix_distance_y(pos_old[k1].y-pos_old[k2].y);
				double dz_old =  fix_distance_z(pos_old[k1].z-pos_old[k2].z);


				double r2 = (dx*dx)+(dy*dy)+(dz*dz);

				double dot = (dx_old*dx) + (dy_old*dy) + (dz_old*dz);

//				l[k%3] = (r2 - d*d)/(4*dt*dt*dot*(mass_inv[k1%3]+mass_inv[k2%3]));
				l[j] = (r2 - d*d)/(4*dt*dt*dot*(mass_inv_k1+mass_inv_k2));
			}
			
	
	
      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;

        double mass_inv_k1 = 1.0/atom_data->owned.mass[atom_data->owned.type[k1]];
        double mass_inv_k2 = 1.0/atom_data->owned.mass[atom_data->owned.type[k2]];

	  	  double dx_old = fix_distance_x ( pos_old[k1].x - pos_old[k2].x );
		    double dy_old = fix_distance_y ( pos_old[k1].y - pos_old[k2].y );
	      double dz_old = fix_distance_z ( pos_old[k1].z - pos_old[k2].z );

        double r_k1k2_x = dx_old;
        double r_k1k2_y = dy_old;
        double r_k1k2_z = dz_old;

        double f_coef = -2*dt*dt*l[j];
			
				
        double fcx = -f_coef*r_k1k2_x;
        double fcy = -f_coef*r_k1k2_y;		
        double fcz = -f_coef*r_k1k2_z;		
			
        pos[k1].x -= fcx * mass_inv_k1;
        pos[k1].y -= fcy * mass_inv_k1;
        pos[k1].z -= fcz * mass_inv_k1;
        pos[k2].x += fcx * mass_inv_k2;
        pos[k2].y += fcy * mass_inv_k2;
        pos[k2].z += fcz * mass_inv_k2;
      }
	
		

      sum_err = 0.0;
      for (unsigned int j=0; j<atomic_bond_vector[i].size(); j++) { 
        int k1 = atomic_bond_vector[i][j].index_1, k2 = atomic_bond_vector[i][j].index_2;
        double d = atomic_bond_vector[i][j].length;
				double dx =  fix_distance_x ( pos[k1].x - pos[k2].x );
				double dy =  fix_distance_y ( pos[k1].y - pos[k2].y );
				double dz =  fix_distance_z ( pos[k1].z - pos[k2].z );
				double r2 = (dx*dx) + (dy*dy) + (dz*dz);
				C[j] = (r2 - d*d)/(2*d*d);
				sum_err += C[j];
			}
      sum_err = abs( sum_err );

		
		}
			
	}
}
	
		
	

} //constraint
} //objects
FINECUPPA_NAMESPACE_CLOSE

