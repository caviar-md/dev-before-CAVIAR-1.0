
//========================================================================
//
// Copyright (C) 2016 - 2019 by Morad Biagooi and Ehsan Nedaaee Oskoee.
//
// This file is part of the FinECuPPA package.
//
// The FinECuPPA package is free software; you can use it, redistribute
// it, and/or modify it under the terms of the GNU Lesser General
// Public License as published by the Free Software Foundation; either
// version 3.0 of the License, or (at your option) any later version.
// The full text of the license can be found in the file LICENSE at
// the top level of the FinECuPPA distribution.
//
//========================================================================


#ifdef FINECUPPA_WITH_MPI
 #include <mpi.h>
#endif

#include "finecuppa/FinECuPPA.h"

#ifdef FINECUPPA_WITH_DEALII_MPI
 #include <deal.II/base/mpi.h>
#endif

int main (int argc, char* argv[]) {

#if defined(FINECUPPA_WITH_DEALII_MPI)
  dealii::Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv, 1);
  finecuppa::FinECuPPA finecuppa (argc, argv, MPI::COMM_WORLD);  
#elif defined(FINECUPPA_WITH_MPI)
  MPI_Init (&argc, &argv);  
  finecuppa::FinECuPPA finecuppa (argc, argv, MPI::COMM_WORLD);
#else
  finecuppa::FinECuPPA finecuppa (argc, argv); 
#endif

  try {  
    finecuppa.execute ();
  }
  catch (std::exception &exc) {
    std::cerr << "Exception on processing: " << std::endl
              << exc.what() << std::endl;
  }
  catch (...) {
    std::cerr << "Unknown exception!" << std::endl;  
  }
 
#if defined(FINECUPPA_WITH_DEALII_MPI)
  // Do nothing
#elif defined(FINECUPPA_WITH_MPI)
  MPI_Finalize ();
#endif

  return 0;
}


