
## What is this directoy?

This directory with its subdirectories contains mainly all the C++ source files 
for FinECuPPA package. One can use them according to FinECuPPA license.
